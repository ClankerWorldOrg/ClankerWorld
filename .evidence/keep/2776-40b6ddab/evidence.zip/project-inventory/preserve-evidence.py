import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parent
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'c5606874d809fbe571ed4f4a5c5741f892fbe701'
commands = json.loads((root / 'measurement-commands.json').read_text())
assert all(row['exit'] == 0 for row in commands)
assert commands[-1]['label'] == 'coverage-comparison'
receipts = list((root / 'per-test-base').rglob('completion.json'))
assert len(receipts) == 9 and all(json.loads(p.read_text())['success'] for p in receipts)
archive = root / 'evidence.zip'
files = [p for p in root.rglob('*') if p.is_file() and p != archive and p.suffix != '.index' and not p.name.startswith('index-')]
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in files:
        output.write(path, 'project-inventory/' + str(path.relative_to(root)))
    for name in ['restore-base.log', 'build-base.log', 'diagnostic-build.log']:
        p = Path('/workspace/ClankerWorld-2564-care-base/.evidence/keep/2564-care') / name
        output.write(p, 'project-inventory/base-builds/' + name)
manifest = {'head': head, 'base': '4e0d56f5739a1cc12ad3f9d54d967903135bfb3e',
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size,
            'files': len(files) + 3, 'contains': 'Raw paired XML+JSON+TRX, nine original isolated reports/completion receipts, measured DLL/PDB bytes and pins, builds, discovery, ledger, source/second-reader/merge/branch/CI/timing evidence.',
            'branch': 'codex/2564-project-evidence-40b6ddab', 'neverMergeOrOpenPR': True}
path = root / 'archive-manifest.json'
path.write_text(json.dumps(manifest, indent=2))
env = os.environ.copy()
env['GIT_INDEX_FILE'] = str(root / 'preservation.index')
subprocess.run(['git', 'read-tree', head], env=env, check=True)
for source, name in [(archive, 'evidence.zip'), (path, 'archive-manifest.json'), (root / 'project-ledger.json', 'ledger.json'), (root / 'stable-branch-comparison.json', 'coverage-bounds.json'), (root / 'project-cross-lane-reader.md', 'second-reader.md')]:
    blob = subprocess.check_output(['git', 'hash-object', '-w', str(source)], text=True).strip()
    subprocess.run(['git', 'update-index', '--add', '--cacheinfo', '100644,' + blob + ',.evidence/keep/2776-40b6ddab/' + name], env=env, check=True)
tree = subprocess.check_output(['git', 'write-tree'], env=env, text=True).strip()
commit = subprocess.check_output(['git', 'commit-tree', tree, '-p', head], input='Preserve fixed-base project test audit evidence\n\nEvidence only; never merge or open a pull request. Codex session40b6ddab.\n', text=True).strip()
assert subprocess.run(['git', 'show-ref', '--verify', '--quiet', 'refs/heads/' + manifest['branch']]).returncode == 1
subprocess.run(['git', 'update-ref', 'refs/heads/' + manifest['branch'], commit], check=True)
manifest['commit'] = commit
(root / 'remote-evidence-ref.json').write_text(json.dumps(manifest, indent=2))
print(json.dumps(manifest, indent=2))
