import collections
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
logs = {'base': Path('/workspace/ClankerWorld-2564-care-base/.evidence/keep/2564-care/diagnostic-build.log'), 'head': root / 'diagnostic-build.log'}
warnings = {}
unused = {}
for label, path in logs.items():
    text = path.read_text()
    assert 'Build succeeded.' in text and '0 Error(s)' in text, label
    entries = set()
    for line in text.splitlines():
        match = re.match(r'.*?/(src/.*?|tests/.*?)\(\d+,\d+\): warning (\w+): (.*?) \[.*?/([^/]+\.csproj)\]', line)
        if match:
            entries.add(match.groups())
    warnings[label] = entries
    unused[label] = {entry for entry in entries if entry[1] in {'IDE0051', 'IDE0052', 'IDE0060', 'IDE0005', 'CS8019', 'CS0168', 'CS0169', 'CS0219', 'CS0414', 'CS8321'}}
result = {'allDiagnosticCounts': {key: len(value) for key, value in warnings.items()},
          'unusedCounts': {key: len(value) for key, value in unused.items()},
          'newUnused': sorted(unused['head'] - unused['base']),
          'newDiagnostics': sorted(warnings['head'] - warnings['base']),
          'removedDiagnostics': sorted(warnings['base'] - warnings['head'])}
(root / 'diagnostic-comparison.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
assert not result['newUnused'] and not result['newDiagnostics']
