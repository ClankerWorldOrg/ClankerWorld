import json
import subprocess
from pathlib import Path

p = Path(__file__).parent
base = '4e0d56f5739a1cc12ad3f9d54d967903135bfb3e'
head = 'c5606874'
prs = [r for r in json.loads((p / 'open-pr-files.json').read_text()) if any(f.startswith('tests/') for f in r['files'])]
missing = [r['sha'] for r in prs if subprocess.run(['git', 'cat-file', '-e', r['sha'] + '^{commit}'], capture_output=True).returncode]
if missing:
    r = subprocess.run(['git', 'fetch', '--no-tags', 'origin', *sorted(set(missing))], capture_output=True, text=True)
    (p / 'fetch-pr-heads.log').write_text(r.stdout + r.stderr)
    assert r.returncode == 0, r.stderr
out = []
for pr in prs:
    row = {'pr': pr['n'], 'sha': pr['sha'], 'comparisons': []}
    for label, revision in [('base', base), ('head', head)]:
        r = subprocess.run(['git', 'merge-tree', '--write-tree', '--name-only', revision, pr['sha']], capture_output=True, text=True)
        assert r.returncode in (0, 1), (pr['n'], r.stderr)
        lines = r.stdout.splitlines()
        conflicts = []
        if r.returncode:
            for line in lines[1:]:
                if not line:
                    break
                conflicts.append(line)
        row['comparisons'].append({'revision': label, 'exit': r.returncode, 'conflicts': conflicts, 'tree': lines[0]})
    row['newConflicts'] = sorted(set(row['comparisons'][1]['conflicts']) - set(row['comparisons'][0]['conflicts']))
    out.append(row)
(p / 'overlap-merge-check.json').write_text(json.dumps(out, indent=2) + '\n')
new = [r for r in out if r['newConflicts']]
print(json.dumps({'testPRs': len(prs), 'missingHeadsFetched': len(set(missing)), 'newConflicts': new,
                  'preexistingConflicts': sum(bool(r['comparisons'][0]['conflicts']) for r in out)}))
assert not new
