# Care stock and placement support second reading

Signed: Codex session 40b6ddab/cross-lane-reader. This is same-session test-audit support review, not independent-session merge approval.

Pristine candidate base/head: 4e0d56f5739a1cc12ad3f9d54d967903135bfb3e, worktree /workspace/ClankerWorld-2564-care. No source edits/builds/tests/refs/GitHub actions. Only this authorized evidence note was written.

Decision: approve sharing the two existing CareProductionTests helpers, conditional on actual committed diff preservation and root's required measurements/open-PR compatibility checks. Care.At and Clinic.PutAt match byte-for-byte after method/local alpha renaming; Care.Stock and Clinic.AddStock match after method/storage-parameter alpha renaming. Both WithInventory bodies match exactly and are plain nested record replacement, with no custody normalization.

At executes the same actor Single lookup before copying, captures the original position, iterates the same Agents list in order, moves the chosen actor and sets FullnessBasisPoints9000/LastDecisionContext=null, moves another target occupant to the chosen actor's previous position and leaves all other fields unchanged. Same record-with shapes and ToArray allocation remain. Stock calls InventoryAuthority.AddLot with identical inventory/ID/kind/owner/quantity/storage and replaces the same Society nesting. AddLot's validation, defaults, lot/event construction/order and commit point are unchanged. Neither helper reads Care constants, instance output or provider state. Care has no static field initializer or static constructor, only constants; static invocation does not instantiate its ITestOutputHelper primary constructor.

Qualify exactly three Clinic.PutAt calls and four Clinic.AddStock calls. Preserve the third call as CareProductionTests.At(state,seller,sellerStart) with { Agents = state.Agents.Select(...) }; evaluate the helper first and retain the initializer's reference to the preassignment state. Its Agents result is overwritten, but the original Single lookup and clone/allocation still occur; do not simplify the surrounding expression. All call arguments are positional, so storage/building parameter names cause no named-argument change.

The four Care methods retain 7 cases (House/Tailor false,true; medicine reserved-water,broken-jug; supply reserved-water,storage-room; ordinary native supply Fact). Clinic retains its one Fact. Source counts: Care417lines/77Assert sites, Clinic227lines/71Assert sites. Sharing changes no method, attribute, tick bound, fixture input or assertion; no removed-case credit. Deleting Clinic's10-line PutAt+blank and3-line AddStock+blank saves15lines with qualified one-line calls, while Care changes visibility only. Exact formatter output remains root's responsibility.

Required fixed before/head filter includes both COMPLETE nonpartial classes:

FullyQualifiedName~ClankerWorld.Tests.CareProductionTests.|FullyQualifiedName~ClankerWorld.Tests.ClinicTradeCareTests.

This includes every existing private-helper consumer and every future qualified consumer. No shared fixture/provider implementation changes, so unrelated test classes need not enter. All five retained proof method names are unchanged:

- CareProductionTests.HouseAndTailorCutOnlyTheirOwnedOnSiteClothIntoBandagesAcrossReload
- CareProductionTests.MedicineCannotUseRemotePrivateReservedOrBrokenVesselInputs
- CareProductionTests.ClinicSupplyMovesTheWholeFilledJugOnlyWithActualRoomAndUnreservedContentsAcrossReload
- CareProductionTests.OrdinarySupplyWalksFromTheRealHerbPatchAndCarriesFreshWaterHomeToTheClinicBeforeProducingMedicine
- ClinicTradeCareTests.AnIllVisitorBuysActualClinicMedicineAndUsesOnlyThePurchasedDoseAcrossReload

Read both complete source files, previous care-reader.md, CareContent recipes/costs/durations, WorldRuntime.CareSupplies and MedicalCare runtime ownership/validation adapter, InventoryAuthority.AddLot and state record semantics, and #752 introduction/history. Both helper pairs were introduced in4d79b3fd with the same raw stock and swap semantics. Current recipes still differ in House/Tailor workstation ownership, while Clinic's trade proof retains actual paid manufacture, seller travel, barter reservations/strict replay, foreign production/treatment refusal, purchased-dose provenance/consent boundaries and native treatment completion. Shared fixture transformation does not collapse those contracts.

Do not share placement/provider helpers: Care's ordered near-House placement and Clinic's unsorted placement are distinct and unchanged. Preserve Care's production/supply ticks, distant real-herb depletion, cooking-water reserve and reload; preserve Clinic's two16tick batches, native seller journey and separate treatment/reload phases. Existing dead branches/ready cuts are outside this proposal.

Known #2740 raw WithInventory deletion adjoins these helpers. Root owns exact before/after merge-tree checking and any holdback; this approval does not authorize editing that PR or replacing raw stock with custody-normalizing support. Production, test configuration and previous ready cuts must remain unchanged. No execution evidence is supplied by this note.
