import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

head = Path('/workspace/ClankerWorld-2564-care')
base = Path('/workspace/ClankerWorld-2564-care-base')
evidence = Path(__file__).resolve().parent
env = os.environ.copy()
env.update(PATH='/workspace/.tools/dotnet:' + env['PATH'], DOTNET_ROOT='/workspace/.tools/dotnet', DOTNET_PROCESSOR_COUNT='4')
selected = (evidence / 'project-scope.filter').read_text().strip()
project = 'tests/ClankerWorld.Tests/ClankerWorld.Tests.csproj'
settings = head / 'skills/test-audit/references/coverage.runsettings'
adapter = next((Path('/home/agent/.nuget/packages/coverlet.collector/6.0.4/build')).glob('netstandard*'))
records = []

def run(label, args, cwd):
    print(label, flush=True)
    with (evidence / (label + '.log')).open('w') as log:
        result = subprocess.run(args, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    records.append({'label': label, 'command': args, 'cwd': str(cwd), 'exit': result.returncode})
    (evidence / 'measurement-commands.json').write_text(json.dumps(records, indent=2))
    assert result.returncode == 0, label

for folder in [base, head]:
    text = (folder / '.evidence/keep/2564-care/diagnostic-build.log').read_text()
    assert 'Build succeeded.' in text and '0 Error(s)' in text
    config = folder / 'tests/ClankerWorld.Tests/.editorconfig'
    assert config.read_text().startswith('[*.cs]\ndotnet_diagnostic.IDE0051')
    config.unlink()

run('format', ['dotnet', 'format', '--verify-no-changes', '--no-restore'], head)

# Generated production scope is pinned before either measurement. Test binaries stay distinct.
pins = {}
out = Path('tests/ClankerWorld.Tests/bin/Release/net10.0')
for name in ['ClankerWorld.Simulation.dll', 'ClankerWorld.Simulation.pdb', 'ClankerWorld.Server.dll', 'ClankerWorld.Server.pdb']:
    shutil.copy2(base / out / name, head / out / name)
for label, folder in [('base', base), ('head', head)]:
    pins[label] = {name: hashlib.sha256((folder / out / name).read_bytes()).hexdigest()
                   for name in ['ClankerWorld.Simulation.dll', 'ClankerWorld.Simulation.pdb', 'ClankerWorld.Server.dll', 'ClankerWorld.Server.pdb', 'ClankerWorld.Tests.dll', 'ClankerWorld.Tests.pdb']}
    run('discovery-' + label, ['dotnet', 'test', project, '-c', 'Release', '--no-build', '--no-restore', '--list-tests'], folder)
(evidence / 'measurement-pins.json').write_text(json.dumps(pins, indent=2))
run('ledger', ['python', 'skills/test-audit/scripts/check_ledger.py', str(evidence / 'project-ledger.json'), '--tests', str(evidence / 'discovery-head.log')], head)
run('normal-head', ['dotnet', 'test', project, '-c', 'Release', '--no-build', '--no-restore', '--filter', selected, '--results-directory', str(evidence / 'normal-head'), '--logger', 'trx;LogFileName=test.trx', '--', 'xUnit.MaxParallelThreads=2'], head)
for label, folder in [('base', base), ('head', head)]:
    run('coverage-' + label, ['dotnet', 'test', project, '-c', 'Release', '--no-build', '--no-restore', '--settings', str(settings), '--collect', 'XPlat Code Coverage;Format=cobertura,json', '--test-adapter-path', str(adapter), '--filter', selected, '--results-directory', str(evidence / ('coverage-' + label)), '--logger', 'trx;LogFileName=test.trx', '--', 'xUnit.MaxParallelThreads=2'], folder)
run('per-test-base', ['python', 'skills/test-audit/scripts/per_test_coverage.py', '--assembly', str(base / out / 'ClankerWorld.Tests.dll'), '--settings', str(settings), '--methods', str(evidence / 'project-methods.txt'), '--out', str(evidence / 'per-test-base'), '--workers', '2', '--cwd', str(base)], base)
run('unique', ['python', 'skills/test-audit/scripts/unique_coverage.py', str(evidence / 'per-test-base'), '--table', str(evidence / 'unique.tsv')], head)
before = next((evidence / 'coverage-base').rglob('coverage.cobertura.xml'))
after = next((evidence / 'coverage-head').rglob('coverage.cobertura.xml'))
run('coverage-comparison', ['python', 'skills/test-audit/scripts/compare_coverage.py', str(before), str(after), '--repo', str(head), '--threshold-scope', 'each'], head)
print('measurement complete', flush=True)
