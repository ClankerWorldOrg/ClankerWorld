import importlib.util
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('compare_coverage', root.parents[2] / 'skills/test-audit/scripts/compare_coverage.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def read(folder):
    xml = next(folder.rglob('coverage.cobertura.xml'))
    raw = json.loads(next(folder.rglob('coverage.json')).read_text())
    reports = module.load_report(xml)
    branches = {}
    for assembly, files in raw.items():
        name = assembly.removesuffix('.dll')
        values = {}
        for path, classes in files.items():
            file = module.source_key(path)
            assert file.startswith('src/'), file
            for cls, methods in classes.items():
                for method, body in methods.items():
                    for branch in body.get('Branches', []):
                        key = (file, cls, method, branch['Line'], branch['Offset'], branch['EndOffset'], branch['Path'], branch['Ordinal'])
                        assert key not in values, key
                        values[key] = branch['Hits'] > 0
        branches[name] = values
    assert set(branches) == set(reports)
    total = {'covered': sum(sum(v.values()) for v in branches.values()), 'valid': sum(len(v) for v in branches.values())}
    assert total['covered'] == reports.aggregate['branches_covered'], (total, reports.aggregate)
    assert total['valid'] == reports.aggregate['branches_valid'], (total, reports.aggregate)
    return reports, branches

old, first = read(root / 'coverage-base')
new, last = read(root / 'coverage-head')
result = {}
for assembly in old:
    assert first[assembly].keys() == last[assembly].keys(), assembly
    lines = [key for key in old[assembly] if old[assembly][key]['hit'] and not new[assembly][key]['hit']]
    branches = [key for key in first[assembly] if first[assembly][key] and not last[assembly][key]]
    result[assembly] = {'linesCoveredBefore': sum(v['hit'] for v in old[assembly].values()),
                        'linesCoveredAfter': sum(v['hit'] for v in new[assembly].values()),
                        'linesValid': len(old[assembly]),
                        'branchesCoveredBefore': sum(first[assembly].values()),
                        'branchesCoveredAfter': sum(last[assembly].values()),
                        'branchesValid': len(first[assembly]),
                        'lostLines': lines, 'lostBranchIdentities': branches,
                        'lineLossBoundPP': 100 * len(lines) / len(old[assembly]),
                        'branchLossBoundPP': 100 * len(branches) / len(first[assembly])}
    assert result[assembly]['lineLossBoundPP'] <= 2 and result[assembly]['branchLossBoundPP'] <= 2
result['total'] = {'baseline': old.aggregate, 'head': new.aggregate,
                   'lostLines': sum(len(v['lostLines']) for v in result.values()),
                   'lostBranches': sum(len(v['lostBranchIdentities']) for v in result.values()),
                   'noNewHitOffsets': True, 'rawBranchCountersReconciled': True}
(root / 'stable-branch-comparison.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
