import importlib.util,json,hashlib,pathlib,subprocess
p=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prior_reader',p/'report_reader.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
left,before_xml,before_counts=reader.read_report(p/'before',136)
right,after_xml,after_counts=reader.read_report(p/'final',132)
assert left.keys()==right.keys();out={'cases_before':before_counts,'cases_after':after_counts,'assemblies':{}};total={metric:{'valid':0,'before':0,'after':0,'lost':0,'gained':0} for metric in ['lines','branches']}
for module in left:
 out['assemblies'][module]={}
 for metric in total:
  a,b=left[module][metric],right[module][metric];assert a.keys()==b.keys(),(module,metric)
  lost=[k for k in a if a[k] and not b[k]];gained=[k for k in a if not a[k] and b[k]]
  data={'valid':len(a),'before':sum(a.values()),'after':sum(b.values()),'lost':len(lost),'gained':len(gained),'lost_identities':lost,'gained_identities':gained,'loss_bound_pp':100*len(lost)/len(a) if a else 0};assert data['loss_bound_pp']<=2
  out['assemblies'][module][metric]=data
  for key in total[metric]:total[metric][key]+=data[key]
for metric,data in total.items():data['loss_bound_pp']=100*data['lost']/data['valid'];assert data['loss_bound_pp']<=2
out['total']=total;(p/'identity-comparison.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
manifest=json.loads((p/'manifest.json').read_text())
for revision,checkout in [('base','/workspace/review-2684-base-99f37e1f'),('head','/workspace/review-2684-99f37e1f')]:
 root=pathlib.Path(checkout)/'tests/ClankerWorld.Tests/bin/Release/net10.0'
 for name,expected in manifest['production_pins'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,(revision,name)
 manifest[revision+'_test_dll_sha256']=hashlib.sha256((root/'ClankerWorld.Tests.dll').read_bytes()).hexdigest()
(p/'manifest.json').write_text(json.dumps(manifest,indent=2))
subprocess.run(['python3','/workspace/ClankerWorld/skills/test-audit/scripts/compare_coverage.py',str(before_xml),str(after_xml),'--repo','/workspace/review-2684-99f37e1f','--threshold-scope','each'],check=True,stdout=open(p/'official-comparison.json','w'))
