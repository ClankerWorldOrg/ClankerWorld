from pathlib import Path
import subprocess
root=Path('/workspace/review-2692-99f37e1f');prefix='tests/ClankerWorld.Tests/Simulation/World/Towns/'
changes={
'TownMembershipTests.cs':[
('    private static readonly string[] Founders = [Founder(1), Founder(2), Founder(3), Founder(4)];','    private static readonly string[] Founders =\n        [NormalPathWorld.FounderId(1), NormalPathWorld.FounderId(2), NormalPathWorld.FounderId(3), NormalPathWorld.FounderId(4)];'),
('ShortDays(Generated("membership-travel"), 30)','Generated("membership-travel", 30)'),
('ShortDays(Generated("membership-refused", applicant), 30)','Generated("membership-refused", 30, applicant)'),
('Generated("membership-household-first", applicant)','Generated("membership-household-first", added: [applicant])'),
('Generated("membership-outside", newcomer)','Generated("membership-outside", added: [newcomer])'),
('Generated("membership-dead-newcomer", newcomer)','Generated("membership-dead-newcomer", added: [newcomer])'),
('Generated(seed, newcomer)','Generated(seed, added: [newcomer])'),
('Generated("membership-tampered", newcomer)','Generated("membership-tampered", added: [newcomer])'),
('    private static string Founder(int number) => NormalPathWorld.FounderId(number);\n\n',''),
('Generated(string seed, params string[] added)','Generated(string seed, int? ticksPerDay = null, params string[] added)'),
('NormalPathWorld.CreateGenerated(seed, _ => new ActionCoverageRecorder(chooseIdle: true))','NormalPathWorld.CreateGenerated(seed, _ => new ActionCoverageRecorder(chooseIdle: true), ticksPerDay: ticksPerDay)')],
'TownMembershipExpiryTests.cs':[
('ShortDays(Generated("membership-own-request-unaffected", newcomer), AcceptanceDay)','Generated("membership-own-request-unaffected", AcceptanceDay, newcomer)'),
('ShortDays(Generated(seed, newcomer), AcceptanceDay)','Generated(seed, AcceptanceDay, newcomer)')],
'TownAbandonmentTests.cs':[
('ShortDays(Generated("town-resettled-law"), 30)','Generated("town-resettled-law", 30)')]
}
for name,edits in changes.items():
 path=prefix+name;source=subprocess.check_output(['git','show','HEAD^:'+path],cwd=root,text=True)
 if name=='TownMembershipTests.cs':
  start=source.index('    /// <summary>The same world with shorter days,');end=source.index('    /// <summary>Ages one agent',start);source=source[:start]+source[end:]
 for old,new in edits:
  expected=2 if old=='Generated("membership-outside", newcomer)' else 1
  assert source.count(old)==expected,(name,old,source.count(old));source=source.replace(old,new)
 assert source==(root/path).read_text(),name
print('All three complete files exactly reconstruct from the stated helper/call substitutions. No test/assertion/body changes beyond setup calls.')
