using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.IO.Compression;
using System.Text.Json;
var testDirectory = Path.GetFullPath(args[0]);
var output = Path.GetFullPath(args[1]); Directory.CreateDirectory(output);
AssemblyLoadContext.Default.Resolving += (context, name) => {
    var candidate = Path.Combine(testDirectory, name.Name + ".dll");
    return File.Exists(candidate) ? context.LoadFromAssemblyPath(candidate) : null;
};
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(testDirectory, "ClankerWorld.Tests.dll"));
var fixture = assembly.GetType("ClankerWorld.Tests.TownMembershipTests", true)!;
const BindingFlags flags = BindingFlags.NonPublic | BindingFlags.Static;
var generated = fixture.GetMethod("Generated", flags)!;
var shortened = fixture.GetMethod("ShortDays", flags);
var withTowns = fixture.GetMethod("WithTowns", flags)!;
var founders = (string[])fixture.GetField("Founders", flags)!.GetValue(null)!;
const string newcomer = "agent:99999999999999999999999999999999";
var specifications = new List<(string Seed,int? Day,bool Added,int Roster)> {
 ("membership-travel",30,false,1), ("membership-refused",30,true,2),
 ("membership-own-request-unaffected",40,true,2), ("membership-approval-expiry",40,true,2),
 ("membership-last-acceptance",40,true,2), ("membership-held-acceptance",40,true,2),
 ("town-resettled-law",30,false,3),
 ("membership-household-first",null,true,0), ("membership-outside",null,true,0),
 ("membership-dead-newcomer",null,true,0), ("membership-sponsored",null,true,0),
 ("membership-replay",null,true,0), ("membership-tampered",null,true,0),
 ("membership-add-agent",null,false,0)
};
var manifest = new List<object>();
foreach (var spec in specifications) {
    string[] added = spec.Added ? [newcomer] : [];
    object state = generated.Invoke(null, shortened is null ? [spec.Seed, spec.Day, added] : [spec.Seed, added])!;
    if (shortened is not null && spec.Day is int day) state = shortened.Invoke(null, [state,day])!;
    if (spec.Roster != 0) {
        string[] first = spec.Roster == 1 ? founders[..3] : spec.Roster == 3 ? founders[..1] : founders;
        string[]? second = spec.Roster == 1 ? founders[3..] : spec.Roster == 3 ? [] : null;
        state = withTowns.Invoke(null, [state,first,second])!;
    }
    var codec = state.GetType().Assembly.GetType("ClankerWorld.Simulation.World.WorldRuntimeCodec",true)!;
    var encode = codec.GetMethods(BindingFlags.Public|BindingFlags.Static).Single(m => m.Name == "Encode" && m.GetParameters().Length == 1 && m.GetParameters()[0].ParameterType == state.GetType());
    var bytes = (byte[])encode.Invoke(null,[state])!;
    var path = Path.Combine(output,spec.Seed+".bin.gz");
    using (var file = File.Create(path)) using (var gzip = new GZipStream(file,CompressionLevel.SmallestSize)) gzip.Write(bytes);
    manifest.Add(new { spec.Seed,spec.Day,spec.Added,spec.Roster,Bytes=bytes.Length,SHA256=Convert.ToHexStringLower(SHA256.HashData(bytes)) });
    Console.WriteLine(spec.Seed+" "+bytes.Length);
}
File.WriteAllText(Path.Combine(output,"manifest.json"),JsonSerializer.Serialize(manifest,new JsonSerializerOptions { WriteIndented=true }));
