from pathlib import Path
import subprocess
root=Path('/workspace/review-2703-99f37e1f');file='tests/ClankerWorld.Tests/Simulation/World/Towns/TownProjectRuntimeTests.cs'
base=subprocess.check_output(['git','show','HEAD^:'+file],cwd=root,text=True);head=(root/file).read_text();start=base.index('            JsonSerializer.Serialize(World.Towns[0].Projects.Select(project => new');end=base.index('\n    }\n\n    internal (string Actor, string LotId)? DonationTraveler()',start)
replacement='            JsonSerializer.Serialize(World.Towns[0].Projects, JsonOptions) + " Choices: " +\n            string.Join(", ", Policy.Choices.TakeLast(12).Select(choice => choice.Id)));'
assert base[:start]+replacement+base[end:]==head
print('Entire changed file exactly reconstructs from the single documented diagnostic expression replacement.')
