import re,subprocess
from pathlib import Path
root=Path('/workspace/review-2711-99f37e1f');scope='tests/ClankerWorld.Tests/Simulation/World/Runtime/'
def original(name):return subprocess.check_output(['git','show','HEAD^:'+scope+name],cwd=root,text=True)
base=original('BuildingMovementTests.cs');head=(root/scope/'BuildingMovementTests.cs').read_text();start=head.index('    private static GridPoint FreeSite(');end=head.index('    private static BuildingDefinition Definition(',start);helper=head[start:end];begin=helper.index('        var blocked');finish=helper.rfind('    }');body=helper[begin:finish].rstrip();body=body.replace('        return state.Map','        var site = state.Map',1)
expanded=head[:start]+head[end:]
for roads in ['generated.RoadTiles','setup.RoadTiles']:
 needle=f'        var site = FreeSite(state, {roads});';assert expanded.count(needle)==1;expanded=expanded.replace(needle,body.replace('.Concat(roads)',f'.Concat({roads})'))
def normalized(s):
 s=re.sub(r'\s+','',s.replace('WorldContent!','WorldContent'))
 return s.replace('Single(item=>item.CanonicalId==building.DefinitionId)','Single(definition=>definition.CanonicalId==building.DefinitionId)')
assert normalized(base)==normalized(expanded),'Building file differs outside exact helper expansion / nullable annotations / lambda alpha-rename'
base=original('SwimmingRuntimeTests.cs');head=(root/scope/'SwimmingRuntimeTests.cs').read_text();start=base.index('        var crossedWater = false;');end=base.index('        var swimming = world.ExportState();',start)
replacement='        for (var tick = 0; tick < 64 && Position(world) != firstWater; tick++)\n            Assert.True((await world.AdvanceOneTickAsync()).Advanced);\n        Assert.Equal(firstWater, Position(world));\n'
assert base[:start]+replacement+base[end:]==head,'Swimming file differs outside documented loop/assert replacement'
assert 'var firstWater = new GridPoint(start.X + 1, start.Y);' in head
print('Complete Building file matches base after expanding only FreeSite calls, nullable annotations and one lambda rename. Complete Swimming file differs only by exact loop/assert replacement. Initial target is start.X+1 in both retained rows.')
