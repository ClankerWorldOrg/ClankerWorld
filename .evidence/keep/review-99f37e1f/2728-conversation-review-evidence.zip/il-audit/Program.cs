using System.Reflection;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Text.Json;
var names = JsonSerializer.Deserialize<string[]>(File.ReadAllText(args[1]))!.ToHashSet();
using var stream = File.OpenRead(args[0]);
using var pe = new PEReader(stream);
var md = pe.GetMetadataReader();
var runtime = md.TypeDefinitions.Single(h => { var t=md.GetTypeDefinition(h);return md.GetString(t.Namespace)=="ClankerWorld.Simulation.World" && md.GetString(t.Name)=="WorldRuntime"; });
var targets=md.GetTypeDefinition(runtime).GetMethods().Where(h => names.Contains(md.GetString(md.GetMethodDefinition(h).Name))).ToArray();
if(targets.Length!=14 || targets.Any(h => (md.GetMethodDefinition(h).Attributes & MethodAttributes.MemberAccessMask)!=MethodAttributes.Private)) throw new Exception("Expected exactly14 private original methods");
var targetTokens=targets.Select(h=>MetadataTokens.GetToken(h)).ToHashSet();
var counts=targets.ToDictionary(h=>md.GetString(md.GetMethodDefinition(h).Name),_=>0);
var opcodes=typeof(OpCodes).GetFields(BindingFlags.Static|BindingFlags.Public).Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)!).ToDictionary(o=>unchecked((ushort)o.Value));
var hits=new List<object>();int bodies=0,instructions=0;
string? Target(int token) {
 if(targetTokens.Contains(token))return md.GetString(md.GetMethodDefinition((MethodDefinitionHandle)MetadataTokens.EntityHandle(token)).Name);
 var handle=MetadataTokens.EntityHandle(token);
 if(handle.Kind==HandleKind.MethodSpecification)return Target(MetadataTokens.GetToken(md.GetMethodSpecification((MethodSpecificationHandle)handle).Method));
 if(handle.Kind!=HandleKind.MemberReference)return null;
 var r=md.GetMemberReference((MemberReferenceHandle)handle);if(r.Parent!=runtime || !names.Contains(md.GetString(r.Name)))return null;
 return md.GetString(r.Name);
}
foreach(var h in md.MethodDefinitions) {
 var method=md.GetMethodDefinition(h);if(method.RelativeVirtualAddress==0)continue;
 bodies++;var il=pe.GetMethodBody(method.RelativeVirtualAddress).GetILBytes()!;int p=0;
 while(p<il.Length) {
  int at=p;ushort code=il[p++];if(code==0xfe)code=(ushort)(0xfe00|il[p++]);
  if(!opcodes.TryGetValue(code,out var op))throw new Exception($"Unknown opcode at{at}");instructions++;
  int bytes=op.OperandType switch {
   OperandType.InlineNone=>0,
   OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar=>1,
   OperandType.InlineVar=>2,
   OperandType.InlineI8 or OperandType.InlineR=>8,
   OperandType.InlineSwitch=>4+4*BitConverter.ToInt32(il,p),
   _=>4
  };
  if(p+bytes>il.Length)throw new Exception("Truncated IL");
  if(op.OperandType is OperandType.InlineMethod or OperandType.InlineTok) {
   var token=BitConverter.ToInt32(il,p);var target=Target(token);
   if(target is not null){counts[target]++;hits.Add(new {caller=md.GetString(method.Name),offset=at,target,opcode=op.Name});}
  }
  p+=bytes;
 }
}
var result=new {assembly=Path.GetFullPath(args[0]),sha256=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),privateTargets=targets.Length,methodBodies=bodies,instructions,references=counts,hits};
Console.WriteLine(JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));
if(hits.Count!=0)throw new Exception("Removed target referenced");
