import pathlib,subprocess,re,json
root=pathlib.Path('/workspace/review-2728-99f37e1f');out=pathlib.Path('/workspace/review-evidence-99f37e1f/2728');p='src/ClankerWorld.Simulation/World/Runtime/WorldRuntime.Conversations.cs'
names=['AcceptConversation','DeclineConversation','ResumeConversation','EndConversation','AcceptConversationWrapUp','DeclineConversationWrapUp','ReserveConversationAllowance','TrimConversationHistory','IsUrgentConversationNeed','AreConversationParticipantsTogether','ConversationListeners','ExtractConversationMemoryClaims','RunConversationProviderAsync','ToWire']
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True)
old=git('show','HEAD^:'+p);new=(root/p).read_text();expected=old
for n in names:
 pattern=r'    private[^\n]*\b'+n+r'\([^;]*?=>[^;]*;\n'
 expected,count=re.subn(pattern,'',expected);assert count==1,(n,count)
for u in ['System.Security.Cryptography','System.Text','System.Text.Json','ClankerWorld.Simulation.Society']:expected=expected.replace('using '+u+';\n','')
assert re.sub(r'\s+','',expected)==re.sub(r'\s+','',new),'Retained token changed'
assert git('diff','--name-only','HEAD^','HEAD').splitlines()==[p]
assert git('diff','--numstat','HEAD^','HEAD').startswith('0\t46\t')
partials=[f for f in (root/'src/ClankerWorld.Simulation').rglob('*.cs') if re.search(r'\bpartial\s+class\s+WorldRuntime\b',f.read_text())];hits=[]
for f in partials:
 for i,l in enumerate(f.read_text().splitlines(),1):
  if re.search(r'\b('+'|'.join(names)+r')\b',l):hits.append({'path':str(f.relative_to(root)),'line':i,'text':l.strip()})
(out/'removed-names.json').write_text(json.dumps(names,indent=2)+'\n');(out/'remaining-partial-name-hits.json').write_text(json.dumps(hits,indent=2)+'\n')
print('Onefile source+0/-46. All retained tokens identical after exactly14 private expression-bodied wrappers and4unused imports removed. Scanned',len(partials),'WorldRuntime partial files; remaining same-name hits:',len(hits));print(json.dumps(hits,indent=2))
