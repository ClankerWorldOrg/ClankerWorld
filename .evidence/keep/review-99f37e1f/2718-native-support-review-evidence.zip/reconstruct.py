import json,re,subprocess
from pathlib import Path
root=Path('/workspace/review-2718-99f37e1f');out=Path('/workspace/review-evidence-99f37e1f/2718');head='584804b540eaf5c82231bf6656727efcded714e2';base=head+'^'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True)
paths=git('diff','--name-only',base,head).splitlines();assert len(paths)==9
scope=[];ledger=[]
for f in git('ls-tree','-r','--name-only',head,'tests/').splitlines():
 if not f.endswith('.cs'):continue
 t=(root/f).read_text()
 m=re.search(r'public sealed (?:partial )?class (ActionRefusalTests|ChildInitialIdentityTests|DescendantConversationListenerTests|GrownAgentHelperMemoryTests)\b',t)
 if not m:continue
 scope.append(f)
 for declaration in re.finditer(r'\[(?:Fact|Theory)\][\s\S]*?public (?:async )?(?:Task(?:<[^\n]*?>)?|void) (\w+)\(',t):
  name=declaration[1]
  ledger.append({'test':'ClankerWorld.Tests.'+m[1]+'.'+name,'file':f,'decision':'retain','retained_proof':['ClankerWorld.Tests.'+m[1]+'.'+name]})

for f in paths:
 old=git('show',base+':'+f);new=(root/f).read_text();expected=old
 for name in ['WaitForActualRequests','AwaitNativeProviderWorkAsync','AwaitConversationRequestsAsync']:
  expected=re.sub(r'    private static async Task '+name+r'\(WorldRuntime world\)\n    \{\n        await ModelWorkHarness.WaitForExistingAsync\(world\);\n    \}\n\n','',expected)
  expected=expected.replace(name+'(', 'ModelWorkHarness.WaitForExistingAsync(')
 if f.endswith('ActionRefusalTests.cs'):
  for line in ['            var ids = world.Agents.Select(person => person.AgentId).ToArray();\n','        public List<string[]> Offered { get; } = [];\n','                Offered.Add(request.Observation.Candidates.Select(candidate => candidate.Id).ToArray());\n']:
   assert expected.count(line)==1;expected=expected.replace(line,'')
 if f.endswith('GrownAgentLandHearingTests.cs'):expected=expected.replace('        if (laterGeneration) Assert.InRange(birth.ChildId.Length, 1, DerivedId.MaximumLength);\n','')
 if f.endswith('GrownResidentIndexTests.cs'):
  line='            Assert.Same(linear, checkpoint.GetAgent(person.Id));\n';assert expected.count(line)==2;expected=expected.replace(line+line,line)
 if f.endswith('LaterGenerationLandHearingTests.cs'):expected=expected.replace('            JevEnabled = false,\n            RoutineHelper = RoutineHelperSettings.Off,\n','')
 assert expected==new, f+' differs outside enumerated transformations'
 assert re.findall(r'^\s*\[(?:Fact|Theory|InlineData|MemberData|ClassData)[^\n]*',old,re.M)==re.findall(r'^\s*\[(?:Fact|Theory|InlineData|MemberData|ClassData)[^\n]*',new,re.M),f+' changes test data'
for f in scope:
 if f not in paths:assert git('show',base+':'+f)==(root/f).read_text()
# Main's sole touched-file interaction is an identical pure factory body.
old=git('show',base+':tests/ClankerWorld.Tests/Simulation/World/Runtime/GrownAgentConversationTests.cs')
now=git('show','origin/main:tests/ClankerWorld.Tests/Simulation/World/Runtime/GrownAgentOrderCancellationTests.cs')
def factory(text,name):
 start=text.index('    private static async Task<byte[]> '+name+'()');b=text.index('{',start);depth=1;i=b+1
 while depth:
  if text[i]=='{':depth+=1
  elif text[i]=='}':depth-=1
  i+=1
 return text[b:i]
assert factory(old,'CreateConversationAdultAsync')==factory(now,'CreateCancellationAdultAsync')
assert len(scope)==27,len(scope)
assert len(ledger)==38,len(ledger)
(out/'scope.json').write_text(json.dumps(scope,indent=2)+'\n');(out/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('All nine whole files exactly match the enumerated pure forwarding/dead bookkeeping/adjacent duplicate/default changes. Test attributes identical; 27 full class/support files; 38 retained test methods. Main factory replacement body byte-identical. No test-case removal.')
