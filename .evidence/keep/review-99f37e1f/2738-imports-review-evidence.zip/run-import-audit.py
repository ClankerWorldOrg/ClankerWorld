from pathlib import Path
import subprocess,json,collections
root=Path('/workspace/review-2738-base-99f37e1f');head=Path('/workspace/review-2738-99f37e1f');e=Path('/workspace/review-evidence-99f37e1f/2738');paths=json.load(open(e/'changed-paths.json'));backup=e/'baseline-originals';result=None
try:
 cmd=['/workspace/toolchains/run-dotnet-99f37e1f.sh','format','style','src/ClankerWorld.Simulation/ClankerWorld.Simulation.csproj','--no-restore','--diagnostics','IDE0005','--severity','info','--include',*paths,'--report',str(e/'ide0005-report.json'),'--verbosity','normal']
 (e/'ide0005-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with open(e/'ide0005.log','w') as log:result=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 assert result.returncode==0,('dotnetformat exit',result.returncode)
 count=0;wanted=0;details=[]
 for f in paths:
  old=(backup/f).read_text();actual=(root/f).read_text();final=(head/f).read_text()
  nonimports=lambda s:[l for l in s.splitlines() if l.strip() and not l.startswith('using ')]
  assert nonimports(old)==nonimports(actual)==nonimports(final),f+'formatter changed code'
  imports=lambda s:collections.Counter(l for l in s.splitlines() if l.startswith('using '))
  removed=imports(old)-imports(actual);planned=imports(old)-imports(final)
  assert not planned-removed,(f,'requested import not independently unused',planned-removed)
  assert not imports(actual)-imports(old),f+'formatter added import'
  count+=sum(removed.values());wanted+=sum(planned.values());details.append({'file':f,'wanted':dict(planned),'compiler_removed':dict(removed)})
  dest=e/'ide-formatted'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(actual)
 assert wanted==66
 (e/'ide0005-proof.json').write_text(json.dumps({'code':result.returncode,'wanted_imports':wanted,'compiler_removed_imports':count,'all_wanted_proven_unused':True,'unchanged_nonimport_files':len(paths),'details':details},indent=2)+'\n')
 print('CompilerIDE0005 proves all66 requested imports unused across32files; actualremovals',count)
finally:
 for f in paths+['.editorconfig']:(root/f).write_bytes((backup/f).read_bytes())
 status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True);assert not status,status
 print('Disposable baseline source/config restored byte-for-byte; clean.')
