using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace ClankerWorld.Simulation.World;

/// <summary>Protected resident decisions and elected mandates. Law text never grants authority.</summary>
public static partial class TownGovernmentRules
{
    private static bool Has(IEnumerable<string> values, string value) => values.Contains(value, StringComparer.Ordinal);
    private static string[] Ordered(IEnumerable<string> values) => TownCouncilRules.Ordered(values);
    public static TownGovernmentChange? ActiveChange(TownGovernmentState state) =>
        state.Changes.SingleOrDefault(c => c.Status is "voting" or "handover");
    public static string[] Mandates(TownArrangement arrangement) =>
        TownArrangementRules.Mandates(arrangement)?.Split('+') ?? [];
    public static string VoteNoticeToken(TownGovernmentChange change) =>
        DerivedId.Create(change.Id + ":vote:" + change.OpenedTick?.ToString(CultureInfo.InvariantCulture));
    internal static string NonLandGrantId(string changeId) => DerivedId.Create(changeId + ":non-land");
    public static string RoundToken(TownMayoralContest contest) =>
        DerivedId.Create($"{contest.Id}:{contest.Round.ToString(CultureInfo.InvariantCulture)}:{contest.RoundOpenedTick?.ToString(CultureInfo.InvariantCulture)}");
    public static TownOffice? GoverningOffice(TownGovernmentState state) =>
        state.Offices.SingleOrDefault(o => o.Mandates == "ordinary");
    private static string Fingerprint(IEnumerable<string> fields) =>
        DerivedId.Hash(string.Join('\n', fields));
    private static string Circumstances(TownGovernmentState state, string[] adults) =>
        Fingerprint(adults.Prepend(TownArrangementRules.Key(state.Arrangement))
            .Concat(state.Offices.OrderBy(o => o.Mandates, StringComparer.Ordinal).Select(o => o.Mandates + ":" + o.HolderId)));
    private static string ElectionCircumstances(TownGovernmentState state, string[] adults, string mandates, string? changeId = null) =>
        Fingerprint(adults.Prepend(mandates).Concat(Willing(state, adults, mandates, changeId).Select(id => "candidate:" + id)));
    private static string[] Willing(TownGovernmentState state, string[] adults, string mandates, string? changeId = null) =>
        adults.Where(id => state.Consents.Any(c => c.AgentId == id && c.Mandates == mandates) &&
            CanStandForMayoralContest(state, id, mandates, changeId)).ToArray();
    private static string[] RequiredSuccessorMandates(TownArrangement current, TownGovernmentChange change) =>
        change.Kind == "replace_mayor" ? Mandates(change.Target) :
            Mandates(change.Target).Except(Mandates(current), StringComparer.Ordinal)
                .Where(m => m != "non_land" || change.NonLandExtension is null).ToArray();
    private static TownGovernmentState Replace(TownGovernmentState state, TownGovernmentChange change) =>
        state with { Changes = state.Changes.Select(c => c.Id == change.Id ? change : c).ToArray() };
    private static TownCouncilState Notice(TownCouncilState council, string kind, string subject, string text, long tick) =>
        TownCouncilRules.PostNotice(council, kind, subject, text, tick);

    public static (TownCouncilState Council, TownGovernmentState Government) Propose(
        TownCouncilState council, TownGovernmentState state, string townId, string actor,
        TownArrangement target, bool replaceMayor, IEnumerable<string> adultResidents, long tick, int day,
        string? nonLandBaseMandate = null, string? expectedNonLandBaseElectionId = null)
    {
        var adults = Ordered(adultResidents);
        if (!Has(adults, actor) || !TownArrangementRules.IsSupported(target) ||
            replaceMayor && (target != state.Arrangement || !TownArrangementRules.HasOffice(target)) ||
            !replaceMayor && target == state.Arrangement || nonLandBaseMandate is null && expectedNonLandBaseElectionId is not null)
            throw new InvalidOperationException("Only an adult resident may propose a supported, different arrangement or replace an existing elected office.");
        var kind = replaceMayor ? "replace_mayor" : "arrangement";
        TownNonLandExtension? extension = null;
        if (nonLandBaseMandate is not null)
        {
            var source = state.Offices.SingleOrDefault(office => office.Mandates == nonLandBaseMandate && office.HolderId is not null);
            if (replaceMayor || nonLandBaseMandate is not ("land" or "ordinary") ||
                target.NonLand != TownArrangementRules.Mayor || state.Arrangement.NonLand != TownArrangementRules.NoOffice ||
                !Has(Mandates(target), nonLandBaseMandate) || source is not { ElectionId: not null, TermStartTick: not null, TermEndTick: not null } ||
                source.TermEndTick <= tick || !Has(adults, source.HolderId!) ||
                expectedNonLandBaseElectionId is not null && source.ElectionId != expectedNonLandBaseElectionId)
                throw new InvalidOperationException("Added duties must name a current elected term retained by the proposed arrangement.");
            extension = new(source.HolderId!, source.Mandates, source.ElectionId, source.TermStartTick.Value, source.TermEndTick.Value);
        }
        var key = ChangeRequestKey(kind, target, extension);
        if (state.Changes.Any(c => c.RequestKey == key && c.Status is "queued" or "voting" or "handover"))
            return (council, state);
        var circumstances = Circumstances(state, adults);
        if (state.Changes.LastOrDefault(c => c.RequestKey == key) is { Status: "rejected" or "withdrawn" } prior &&
            tick < prior.SettledTick + day && prior.Circumstances == circumstances)
            throw new InvalidOperationException("This resident proposal must wait one unpaused day or a material change before retrying.");
        var id = TownRecordIds.Government(townId, checked(state.Sequence + 1));
        var change = new TownGovernmentChange(id, key, kind, target, actor, circumstances, tick, "queued", null, null, [], [])
        { NonLandExtension = extension };
        state = state with { Sequence = state.Sequence + 1, Changes = state.Changes.Append(change).ToArray() };
        council = Notice(council, "government", id, $"{actor} proposed a protected resident vote. " +
            (replaceMayor ? "Elect a replacement for the current mayoral mandates. " : "") +
            TownArrangementRules.Declaration(target) + ExtensionDeclaration(extension) + " The resident-majority safeguard cannot be removed.", tick);
        return OpenNext(council, state, adults, tick, day);
    }

    public static TownGovernmentState Vote(TownGovernmentState state, string id, string actor, bool yes, long tick)
    {
        var change = state.Changes.SingleOrDefault(c => c.Id == id);
        if (change is not { Status: "voting" } || tick >= change.DeadlineTick || !Has(change.Voters, actor) ||
            change.Votes.Any(v => v.AgentId == actor))
            throw new InvalidOperationException("This resident vote is stale, final or ineligible.");
        return Replace(state, change with { Votes = change.Votes.Append(new(actor, yes)).ToArray() });
    }

    public static (TownCouncilState Council, TownGovernmentState Government) Withdraw(
        TownCouncilState council, TownGovernmentState state, string id, string actor, long tick)
    {
        var change = state.Changes.SingleOrDefault(c => c.Id == id);
        if (change is null || change.AuthorId != actor || change.Status is not ("queued" or "voting"))
            throw new InvalidOperationException("Only the author may withdraw a queued or unfinished resident vote.");
        state = Replace(state, change with { Status = "withdrawn", SettledTick = tick, Reason = "The person who proposed it withdrew it." });
        return (Notice(council, "government", id, "Resident government proposal withdrawn.", tick), state);
    }

    private static (TownCouncilState, TownGovernmentState) OpenNext(TownCouncilState council,
        TownGovernmentState state, string[] adults, long tick, int day)
    {
        if (ActiveChange(state) is not null) return (council, state);
        foreach (var queued in state.Changes.Where(c => c.Status == "queued").ToArray())
        {
            if (!Has(adults, queued.AuthorId) || queued.Kind == "arrangement" && queued.Target == state.Arrangement ||
                queued.Kind == "replace_mayor" && queued.Target != state.Arrangement ||
                queued.NonLandExtension is { } extension && (state.Arrangement.NonLand != TownArrangementRules.NoOffice ||
                    !ExtensionBaseCurrent(state, extension, tick)))
            {
                state = Replace(state, queued with { Status = "cancelled", SettledTick = tick, Reason = "This waiting proposal no longer applies, because its author or the Town's government changed." });
                council = Notice(council, "government", queued.Id, "Queued government proposal cancelled because its author or requested arrangement changed.", tick);
                continue;
            }
            state = Replace(state, queued with
            {
                Status = "voting",
                OpenedTick = tick,
                DeadlineTick = tick + day,
                Voters = adults,
                OpeningVoters = adults,
                Votes = [],
                Circumstances = Circumstances(state, adults)
            });
            council = Notice(council, "government", VoteNoticeToken(state.Changes.Single(c => c.Id == queued.Id)),
                $"Resident government vote opened: {TownArrangementRules.Declaration(queued.Target)}{ExtensionDeclaration(queued.NonLandExtension)} " +
                $"Needs more than half of the {adults.Length} eligible opening residents to vote yes by tick {tick + day}. Votes are final; silence is not approval.", tick);
            break;
        }
        return (council, state);
    }

    public static (TownCouncilState Council, TownGovernmentState Government) Advance(
        TownCouncilState council, TownGovernmentState state, string townId, string townName, string seed,
        IEnumerable<string> adultResidents, long tick, int day, bool caseElectionActive = false)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(day);
        var adults = Ordered(adultResidents);
        state = state with { Consents = state.Consents.Where(c => Has(adults, c.AgentId)).ToArray() };
        foreach (var office in state.Offices.Where(o => o.HolderId is not null).ToArray())
            if (!Has(adults, office.HolderId!) || tick >= office.TermEndTick)
                (council, state) = EndOffice(council, state, office, tick,
                    !Has(adults, office.HolderId!) ? "The mayor died or left the Town." : "The term ended.");

        if (ActiveChange(state) is { Status: "voting" } voting)
        {
            var voters = voting.Voters.Where(id => Has(adults, id)).ToArray();
            voting = voting with { Voters = voters, Votes = voting.Votes.Where(v => Has(voters, v.AgentId)).ToArray() };
            var yes = voting.Votes.Count(v => v.Yes);
            var required = voters.Length / 2 + 1;
            if (yes >= required && tick <= voting.DeadlineTick)
            {
                voting = voting with { Status = "handover", ApprovedTick = tick, HandoverDeadlineTick = tick + (long)TownArrangementRules.HandoverDays * day };
                council = Notice(council, "government", voting.Id,
                    $"Residents approved the government proposal. Incumbent authority continues until a valid handover, due by tick {voting.HandoverDeadlineTick}.", tick);
            }
            else if (tick >= voting.DeadlineTick || yes + voters.Length - voting.Votes.Count < required)
            {
                voting = voting with { Status = "rejected", SettledTick = tick, Reason = "Not enough residents voted yes." };
                council = Notice(council, "government", voting.Id, "Resident government proposal failed: no required majority.", tick);
            }
            state = Replace(state, voting);
        }

        var handover = ActiveChange(state) is { Status: "handover" } active ? active : null;
        var changesOrdinaryAuthority = handover is not null && handover.Target.Ordinary != state.Arrangement.Ordinary;
        var targetNeedsCouncil = changesOrdinaryAuthority && NeedsElectedCouncil(handover!.Target, adults.Length);
        var currentNeedsCouncil = state.Arrangement.Ordinary is TownArrangementRules.Council or TownArrangementRules.ElectedCouncil;
        // Both automatic and explicit representation now start and resume at four adults.
        var currentElectsCouncil = currentNeedsCouncil && NeedsElectedCouncil(state.Arrangement, adults.Length);
        var leader = GoverningOffice(state);
        if (state.Arrangement.Ordinary == TownArrangementRules.Mayor)
            council = TownCouncilRules.ChangeCouncil(council, leader?.HolderId is { } holder ? [holder] : adults,
                leader?.HolderId is not null ? "leader" : "all_adult", "arrangement", null, tick);
        else if (state.Arrangement.Ordinary == TownArrangementRules.AllAdultCouncil)
            council = TownCouncilRules.ChangeCouncil(council, adults, "all_adult", "arrangement", null, tick);
        // A ready winner waiting for this handover must not hold back the council election it also needs.
        var holdOtherElections = caseElectionActive || state.Contest is { Stage: "voting" } or { Stage: "ready", Purpose: not "handover" };
        // Only an election this handover actually opened waits for its completion.
        // A population change must not turn an existing ordinary election into a dependent one.
        var mayCreateForcedAttempt = targetNeedsCouncil && !currentElectsCouncil && council.Election is null;
        var historyCountBefore = council.ElectionHistory.Count;
        var fallbackBefore = council.Fallback;
        council = TownCouncilRules.Advance(council, townId, seed, adults, tick, day,
            allowNewElections: (currentNeedsCouncil || targetNeedsCouncil) && !holdOtherElections,
            forceRepresentation: targetNeedsCouncil || state.Arrangement.Ordinary == TownArrangementRules.ElectedCouncil,
            deferFullHandover: ForcedElectionIsLive(handover, council));
        if (mayCreateForcedAttempt && handover is not null)
        {
            // Too few willing candidates can fail a newly opened attempt immediately.
            var forced = council.Election is { Kind: "initial" } live ? live :
                council.ElectionHistory.Skip(historyCountBefore).FirstOrDefault(e => e.Kind == "initial");
            if (forced is not null)
            {
                handover = handover with { ForcedCouncilElectionId = forced.Id };
                state = Replace(state, handover);
            }
        }
        // A failed election forced by this handover must not leave the council retrying for
        // candidates: residents never approved that representation.
        if (handover?.ForcedCouncilElectionId is { } forcedId && council.Fallback == "candidates" && fallbackBefore != "candidates" &&
            council.ElectionHistory.Skip(historyCountBefore).Any(e => e.Id == forcedId && e.Stage == "failed"))
            council = TownCouncilRules.ChangeCouncil(council, council.Members, council.Form, fallbackBefore, council.TermEndTick, tick);
        (council, state) = TownLawRules.Enact(council, state, townId, townName, tick);

        (council, state) = AdvanceMayor(council, state, townId, adults, tick, day, caseElectionActive);
        if (handover is not null)
        {
            var winner = state.Contest is { Stage: "ready", Purpose: "handover" } contest && contest.ChangeId == handover.Id ? contest : null;
            var officeReady = (handover.NonLandExtension is null || ExtensionReady(state, handover, tick)) &&
                RequiredSuccessorMandates(state.Arrangement, handover).All(m =>
                winner is not null && Has(winner.Mandates.Split('+'), m));
            var councilReady = !targetNeedsCouncil || council.Form == "representative" && council.Members.Count == TownCouncilRules.Seats ||
                council.Election is { Stage: "ready", SettledSeats.Count: TownCouncilRules.Seats };
            if (officeReady && councilReady && tick <= handover.HandoverDeadlineTick)
            {
                if (winner is not null) (council, state) = SeatMayor(council, state, winner, tick, day);
                if (state.Contest?.ChangeId == handover.Id)
                    (council, state) = ArchiveContest(council, state, "cancelled", "The government change finished without needing this election.", adults, tick, day);
                if (handover.NonLandExtension is not null)
                    (council, state) = ExtendNonLandOffice(council, state, handover, tick);
                foreach (var office in state.Offices.Where(o => !Has(Mandates(handover.Target), o.Mandates)).ToArray())
                {
                    if (office.HolderId is not null) (council, state) = EndOffice(council, state, office, tick, "Residents voted to remove this duty.");
                    state = state with { Offices = state.Offices.Where(o => o.Mandates != office.Mandates).ToArray() };
                }
                state = state with { Arrangement = handover.Target };
                if (state.Contest is { Purpose: not "handover" } obsolete &&
                    obsolete.Mandates.Split('+').Any(m => !Has(Mandates(handover.Target), m)))
                    (council, state) = ArchiveContest(council, state, "cancelled", "The government change removed the duty this election would have filled.", adults, tick, day);
                state = Replace(state, handover with
                {
                    Status = "completed",
                    SettledTick = tick,
                    SuccessorId = handover.NonLandExtension?.HolderId ?? winner?.WinnerId
                });
                if (targetNeedsCouncil && council.Election is { Stage: "ready" } successor)
                    council = TownCouncilRules.SeatFullCouncil(council, successor, tick, day);
                else if (changesOrdinaryAuthority && !targetNeedsCouncil)
                {
                    council = TownCouncilRules.CancelElection(council, tick, "The protected government handover changed ordinary authority.");
                    var governing = GoverningOffice(state)?.HolderId;
                    council = TownCouncilRules.ChangeCouncil(council,
                        handover.Target.Ordinary == TownArrangementRules.Mayor && governing is not null ? [governing] : adults,
                        handover.Target.Ordinary == TownArrangementRules.Mayor && governing is not null ? "leader" : "all_adult", "arrangement", null, tick);
                }
                if (ForcedElectionIsLive(handover, council))
                    council = TownCouncilRules.CancelElection(council, tick, "The government handover completed without needing this election.");
                council = Notice(council, "government", handover.Id, "Government handover completed. " + TownArrangementRules.Declaration(handover.Target), tick);
            }
            else if (tick >= handover.HandoverDeadlineTick)
            {
                state = Replace(state, handover with { Status = "cancelled", SettledTick = tick, Reason = "Nobody was ready to take over within three days, so the change was called off." });
                if (state.Contest?.ChangeId == handover.Id)
                    (council, state) = ArchiveContest(council, state, "cancelled", "The government change that called this election ran out of time.", adults, tick, day);
                if (ForcedElectionIsLive(handover, council))
                    council = TownCouncilRules.CancelElection(council, tick, "The creating government transition expired.");
                council = Notice(council, "government", handover.Id, "Government handover cancelled: no valid successor was ready within three days. Existing lawful authority remains.", tick);
            }
        }
        // A new leader elected after a vacancy resumes the already approved authority.
        if (state.Arrangement.Ordinary == TownArrangementRules.Mayor)
        {
            var holder = GoverningOffice(state)?.HolderId;
            council = TownCouncilRules.ChangeCouncil(council, holder is not null ? [holder] : adults,
                holder is not null ? "leader" : "all_adult", "arrangement", null, tick);
        }
        (council, state) = TownLawRules.Enact(council, state, townId, townName, tick);
        return OpenNext(council, state, adults, tick, day);
    }

    private static bool ForcedElectionIsLive(TownGovernmentChange? change, TownCouncilState council) =>
        change?.ForcedCouncilElectionId is { } id && council.Election?.Id == id;

    private static bool NeedsElectedCouncil(TownArrangement arrangement, int adults) =>
        arrangement.Ordinary == TownArrangementRules.ElectedCouncil && adults > TownCouncilRules.Seats ||
        arrangement.Ordinary == TownArrangementRules.Council && adults >= TownCouncilRules.RepresentationThreshold;
}
