using System.Globalization;
using ClankerWorld.Simulation.Cognition;

namespace ClankerWorld.Simulation.World;

public sealed partial class WorldRuntime
{
    private IEnumerable<GridPoint> TownProjectProtectedSites(string? exceptProjectId = null) =>
        Ground.ProtectedProjectSites(exceptProjectId);

    // Proposed project sites, so a second proposal or a household request cannot overlap one while its vote is open.
    private HashSet<GridPoint> PendingTownProjectSiteTiles() => towns
        .SelectMany(town => town.Council?.Proposals ?? [])
        .Where(proposal => proposal is { Kind: "project", Status: "pending", Project: { BoatPortId: null } })
        .SelectMany(proposal => TownProjectRules.Footprint(proposal.Project!).Append(proposal.Project!.Entrance)
            .Concat(proposal.Project!.BoatPortId is null && TownProjectRules.DefinitionFor(proposal.Project.DefinitionId) is { } definition &&
                PortNavigationRules.IsPort(definition) ? PortNavigationRules.Geometry(map, definition, proposal.Project.Site).DockingTiles : []))
        .ToHashSet();

    private HashSet<GridPoint> TownProjectLandTiles(TownRuntimeState town, bool ignorePendingRequests = false)
    {
        var claimed = householdLandUseRights.SelectMany(r => r.Tiles)
            .Concat(householdLandUseRequests.Where(r => r.Status == "pending" && !ignorePendingRequests).SelectMany(r => r.Tiles))
            .Concat(townLandTitles.Where(t => t.TownId != town.Id).SelectMany(t => t.Tiles)).ToHashSet();
        return townLandTitles.Where(t => t.TownId == town.Id).SelectMany(t => t.Tiles)
            .Where(p => !claimed.Contains(p)).ToHashSet();
    }

    // The world's tiles a Town project site check reads. Gathering them walks every resource, building,
    // field, title and proposal, so a caller checking many sites in one go gathers them once. Each set is
    // gathered when a check first needs it, so a site refused early never gathers the rest.
    private sealed record TownProjectSiteWorld(string TownId, string? ProjectId, bool IgnorePendingRequests,
        Lazy<HashSet<GridPoint>> Legal, Lazy<HashSet<GridPoint>> Pending, Lazy<HashSet<GridPoint>> Occupied,
        Lazy<HashSet<GridPoint>> BridgeEnds, Lazy<PortProjectSiteWorld> Ports, BuildingPlacementWorld Placement);

    private TownProjectSiteWorld CreateTownProjectSiteWorld(TownRuntimeState town, string? projectId = null,
        bool ignorePendingRequests = false) => new(town.Id, projectId, ignorePendingRequests,
        new(() => TownProjectLandTiles(town, ignorePendingRequests), LazyThreadSafetyMode.None),
        new(PendingTownProjectSiteTiles, LazyThreadSafetyMode.None),
        new(() =>
        {
            var ground = Ground;
            return GroundOccupancy.Combine(ground.Resources, ground.MapObjects, ground.Fields,
                ground.BuildingFootprints, ground.ExpansionSites, ground.ProtectedProjectSites(projectId));
        }, LazyThreadSafetyMode.None),
        new(() => Ground.BridgeEntrances.ToHashSet(), LazyThreadSafetyMode.None),
        new(() => CreatePortProjectSiteWorld(projectId), LazyThreadSafetyMode.None), CreateBuildingPlacementWorld(projectId));

    private string? TownProjectSiteFailure(TownRuntimeState town, TownProjectPayload plan,
        string? projectId = null, string? actor = null, bool ignorePendingRequests = false, TownProjectSiteWorld? world = null)
    {
        var definition = TownProjectRules.DefinitionFor(plan.DefinitionId);
        var lantern = StreetLanternContent.IsLantern(plan.DefinitionId);
        if (definition is null || !worldContent.Buildings.Any(d => d.CanonicalId == plan.DefinitionId))
            return "This kind of Town building is no longer available in this version.";
        if (world is not null && (world.TownId != town.Id || world.ProjectId != projectId || world.IgnorePendingRequests != ignorePendingRequests))
            throw new InvalidOperationException("A Town project site check was given tiles gathered for another check.");
        world ??= CreateTownProjectSiteWorld(town, projectId, ignorePendingRequests);
        if (PortNavigationRules.IsPort(definition))
            return PortProjectSiteFailure(town, plan, definition, projectId, actor, world);
        var footprint = TownProjectRules.Footprint(plan).ToArray();
        var legal = world.Legal.Value;
        if (footprint.Any(p => !legal.Contains(p)))
            return "The whole site must be undisputed Town land, with no household use right or pending land request on it.";
        if (projectId is null && footprint.Append(plan.Entrance).Any(world.Pending.Value.Contains))
            return "Another proposed Town project already uses part of this site.";
        if (definition.Tags.Contains(MarketContent.StallTag, StringComparer.Ordinal) && MarketForStallPlan(town, plan) is null)
            return "Another stall needs a free stall space in one of this Town's finished Markets.";
        if (definition.Tags.Contains(MarketContent.HallTag, StringComparer.Ordinal) && town.Markets
                .Where(market => market.RemovedTick is null).Any(market => MarketContent.SiteTiles(market.Site).Intersect(footprint).Any()))
            return "The new Market site overlaps an existing Market.";
        if (lantern && (!StreetLanternContent.IsRoadEdge(plan.Site, plan.Entrance) ||
            !roadTiles.Contains(plan.Entrance) || !legal.Contains(plan.Entrance)))
            return "The lantern must stand beside a Road, on undisputed Town land.";
        if (!CanPlaceBuilding(definition, plan.Site, out var failure, out _, projectId, world.Placement,
                requiredEntrance: plan.Entrance)) return failure;
        var occupied = world.Occupied.Value;
        if (footprint.Any(point => !map.IsBuildable(point) || occupied.Contains(point)))
            return "The approved building and its plaza need clear buildable ground.";
        if (footprint.Any(world.BridgeEnds.Value.Contains))
            return "The approved building and its plaza cannot cover a bridge end.";
        if (definition.Tags.Contains(MarketContent.HallTag, StringComparer.Ordinal) &&
            Enumerable.Range(0, MarketContent.MaximumStalls).Any(slot => RoadTiles.Contains(MarketContent.StallSite(plan.Site, slot))))
            return "The Market's stall layout crosses an existing Road.";
        // The occupied tiles are exactly the resources, map objects, fields, buildings, running or paused
        // expansions and protected project sites that can block a doorway.
        if (!map.IsBuildable(plan.Entrance) || occupied.Contains(plan.Entrance))
            return "The approved building's doorway is blocked.";
        if (actor is not null && agents.TryGetValue(actor, out var person) &&
            person.Position != plan.Site && Reach(actor, plan.Site, ReachPurpose.TownProjectProposal, 0, 0, SwimmingPolicy.WhenCapable).Count == 0)
            return "No walking route reaches the approved building site.";
        return null;
    }

    private static (TownMarketState Market, int Slot)? MarketForStallPlan(TownRuntimeState town, TownProjectPayload plan) =>
        MarketSystem.MarketForStallPlan(town, plan);

    private void AddTownProjectProposalCandidates(List<CognitionCandidate> candidates, string actor, TownRuntimeState town)
    {
        // Communal project layouts share occupied tiles and foot routes. Port checks and lantern
        // ranking also share the site facts they need within this query; final validation gathers its own.
        // A basis built for another kind of building is refused by CreateTownLayoutContext.
        var basis = new Lazy<TownLayoutBasis>(() => CreateTownLayoutBasis(actor, building: TownHallContent.Hall3x4()),
            LazyThreadSafetyMode.None);
        var siteWorld = CreateTownProjectSiteWorld(town);
        AddPortProjectProposalCandidates(candidates, actor, town, siteWorld);
        foreach (var definition in TownProjectRules.Definitions.Where(item => !item.Tags.Contains(MarketContent.StallTag, StringComparer.Ordinal) &&
                     !StreetLanternContent.IsLantern(item.CanonicalId) && !PortNavigationRules.IsPort(item)))
        {
            if (!worldContent.Buildings.Any(item => item.CanonicalId == definition.CanonicalId)) continue;
            var layout = CreateTownLayoutContext(actor, building: definition, forTownProject: true, basis: basis.Value);
            var offered = 0;
            foreach (var site in TownLayoutService.RankConstructionSites(layout, definition, TownLayoutService.MaximumCandidateLimit))
            {
                var plan = PlanFor(town, definition, site.Position, definition.DisplayName);
                if (plan is null || !AddTownProjectProposalCandidate(candidates, actor, town, definition, site.Position, plan)) continue;
                if (++offered == TownLayoutService.DefaultCandidateLimit) break;
            }
        }
        AddStreetLanternProposalCandidates(candidates, actor, town, basis, siteWorld);
        var stallDefinition = MarketContent.Stall1x1();
        if (!worldContent.Buildings.Any(item => item.CanonicalId == stallDefinition.CanonicalId)) return;
        foreach (var market in town.Markets.Where(item => item.RemovedTick is null && MarketNeedsMoreStalls(town, item)))
            for (var slot = 0; slot < MarketContent.MaximumStalls; slot++)
            {
                if (market.Stalls.Any(stall => stall.SlotIndex == slot)) continue;
                var site = MarketContent.StallSite(market.Site, slot);
                var plan = PlanFor(town, stallDefinition, site, "Market stall");
                // One more stall at a time: the next waits until this one is built and borrowed too.
                if (plan is null || !AddTownProjectProposalCandidate(candidates, actor, town, stallDefinition, site, plan)) continue;
                break;
            }
    }

    // Every standing stall is borrowed, and no further stall for this Market is already proposed or being built.
    private static bool MarketNeedsMoreStalls(TownRuntimeState town, TownMarketState market)
    {
        var standing = market.Stalls.Where(stall => stall.RemovedTick is null).ToArray();
        var slots = Enumerable.Range(0, MarketContent.MaximumStalls).Select(slot => MarketContent.StallSite(market.Site, slot)).ToHashSet();
        var stallId = MarketContent.Stall1x1().CanonicalId;
        return standing.Length > 0 &&
            standing.All(stall => market.Occupancies.Any(occupancy => occupancy.StallBuildingId == stall.BuildingId && occupancy.EndedTick is null)) &&
            !town.Projects.Any(project => IsLiveTownProject(project) && project.Plan.DefinitionId == stallId && slots.Contains(project.Plan.Site)) &&
            !(town.Council?.Proposals ?? []).Any(proposal => proposal is { Kind: "project", Status: "pending", Project: not null } &&
                proposal.Project.DefinitionId == stallId && slots.Contains(proposal.Project.Site));
    }

    private static bool TownProjectDemandIsCurrent(TownRuntimeState town, TownProjectPayload plan) =>
        plan.BoatPortId is { } port
            ? !town.Projects.Any(project => IsLiveTownProject(project) && project.Plan.BoatPortId == port) &&
                !(town.Council?.Proposals ?? []).Any(proposal => proposal.Status == "pending" && proposal.Project?.BoatPortId == port)
            : plan.DefinitionId != MarketContent.Stall1x1().CanonicalId ||
                MarketForStallPlan(town, plan) is { } selected && MarketNeedsMoreStalls(town, selected.Market);

    private bool AddTownProjectProposalCandidate(List<CognitionCandidate> candidates, string actor, TownRuntimeState town,
        ClankerWorld.Simulation.Content.BuildingDefinition definition, GridPoint site, TownProjectPayload selected)
    {
        var coordinates = site.X.ToString(CultureInfo.InvariantCulture) + "," + site.Y.ToString(CultureInfo.InvariantCulture);
        var budget = string.Join(" and ", definition.BuildCosts.Select(cost =>
            cost.Amount.ToString(CultureInfo.InvariantCulture) + " " + cost.ResourceId));
        var choice = new TownProjectProposalChoice(town.Id, false, definition.LocalId, coordinates);
        var plan = TownSystem.PlanTownProjectProposal(civicWorld, actor, choice, selected);
        if (plan is null || !TownSystem.CheckTownProjectProposal(civicWorld, plan).Allowed) return false;
        candidates.Add(new(choice.Encode(),
            $"Propose a named {definition.DisplayName} at ({coordinates}) in {town.Name}, with a provisional budget of {budget}; put its name in civic_proposal. Council approval creates no goods or private-stock access.", 191)
        { ActionPlan = plan });
        return true;
    }

    // Both lantern designs stand on one tile beside a Road and share the caller's layout basis. Every Road
    // edge is scored, but the full site check runs only in rank order until four edges pass: the same
    // four that checking every edge would give.
    private void AddStreetLanternProposalCandidates(List<CognitionCandidate> candidates, string actor, TownRuntimeState town,
        Lazy<TownLayoutBasis> basis, TownProjectSiteWorld siteWorld)
    {
        var designs = new[] { StreetLanternContent.Stone(), StreetLanternContent.Hanging() }
            .Where(definition => worldContent.Buildings.Any(item => item.CanonicalId == definition.CanonicalId)).ToArray();
        if (designs.Length == 0) return;
        var ordinary = CreateTownLayoutContext(actor, building: designs[0], basis: basis.Value);
        var legal = siteWorld.Legal.Value;
        var layout = new TownLayoutContext(map, town, ordinary.OccupiedTiles, ordinary.ReachableFootCosts,
            ordinary.Resources, ordinary.Buildings, roadTiles: roadTiles, requiredLandTiles: legal);
        var roadEdges = roadTiles.Where(legal.Contains).OrderBy(point => point.Y).ThenBy(point => point.X)
            .SelectMany(road => map.FootNeighbors(road).Where(point => StreetLanternContent.IsRoadEdge(point, road))
                .Select(post => (Post: post, Road: road)))
            .ToArray();
        foreach (var definition in designs)
        {
            var edges = new List<(TownConstructionSiteCandidate Site, GridPoint Road)>();
            foreach (var (post, road) in roadEdges)
                if (TownLayoutService.TryEvaluateConstructionSite(layout, definition, post, out var site) && site is not null)
                    edges.Add((site, road));
            var offered = 0;
            foreach (var edge in edges.OrderByDescending(edge => edge.Site.Score)
                         .ThenBy(edge => edge.Site.TownBorderGrowthTiles).ThenBy(edge => edge.Site.RouteCost)
                         .ThenBy(edge => edge.Site.Position.Y).ThenBy(edge => edge.Site.Position.X)
                         .ThenBy(edge => edge.Road.Y).ThenBy(edge => edge.Road.X))
            {
                var coordinates = FormattableString.Invariant($"{edge.Site.Position.X},{edge.Site.Position.Y},{edge.Road.X},{edge.Road.Y}");
                var budget = definition.CanonicalId == StreetLanternContent.Stone().CanonicalId ? "4 stone" : "4 wood and 1 refined iron";
                var choice = new TownProjectProposalChoice(town.Id, false, definition.LocalId, coordinates);
                var plan = TownSystem.PlanTownProjectProposal(civicWorld, actor, choice, new(definition.DisplayName, definition.CanonicalId, edge.Site.Position, edge.Road, definition.BuildCosts));
                if (plan is null || !TownSystem.CheckTownProjectProposal(civicWorld, plan).Allowed) continue;
                candidates.Add(new(choice.Encode(),
                    FormattableString.Invariant($"Propose a named {definition.DisplayName} at ({edge.Site.Position.X},{edge.Site.Position.Y}) beside Road ({edge.Road.X},{edge.Road.Y}) in {town.Name}, with a provisional budget of {budget}; put its name in civic_proposal. Council approval creates no goods or private-stock access."), 190)
                { ActionPlan = plan });
                if (++offered == 4) break;
            }
        }
    }

    private TownProjectPayload? PlanFor(TownRuntimeState town, ClankerWorld.Simulation.Content.BuildingDefinition definition,
        GridPoint site, string name, TownProjectSiteWorld? world = null)
    {
        if (PortNavigationRules.IsPort(definition))
            world ??= CreateTownProjectSiteWorld(town);
        var entrance = PortNavigationRules.IsPort(definition)
            ? PortNavigationRules.Geometry(map, definition, site).ApproachTiles.Where(point => map.IsBuildable(point) &&
                world!.Legal.Value.Contains(point) && (!PortConstructionObstacles(world).Contains(point) || roadTiles.Contains(point)))
                .Cast<GridPoint?>().FirstOrDefault()
            : definition.Tags.Contains(TownHallContent.HallTag, StringComparer.Ordinal)
            ? TownHallContent.Entrance(site) : definition.Tags.Contains(MarketContent.HallTag, StringComparer.Ordinal)
                ? MarketContent.HallEntrance(site) : Enumerable.Range(0, MarketContent.MaximumStalls)
                    .SelectMany(slot => town.Markets.Where(market => market.RemovedTick is null &&
                        MarketContent.StallSite(market.Site, slot) == site && !market.Stalls.Any(stall => stall.SlotIndex == slot))
                        .Select(market => (GridPoint?)MarketContent.StallEntrance(market.Site, slot))).FirstOrDefault();
        return entrance is { } door ? new(name, definition.CanonicalId, site, door, definition.BuildCosts) : null;
    }

    private TownProjectPayload? OfferedTownProjectPlan(TownRuntimeState town, string actor, string definition,
        string coordinates, string? name)
    {
        var point = coordinates.Split(',');
        var supported = TownProjectRules.Definitions.SingleOrDefault(item => item.LocalId == definition);
        var lantern = supported is not null && StreetLanternContent.IsLantern(supported.CanonicalId);
        if (supported is null || point.Length != (lantern ? 4 : 2) ||
            !int.TryParse(point[0], NumberStyles.None, CultureInfo.InvariantCulture, out var x) ||
            !int.TryParse(point[1], NumberStyles.None, CultureInfo.InvariantCulture, out var y)) return null;
        var label = string.IsNullOrWhiteSpace(name) ? supported.DisplayName : name.Trim();
        GridPoint? road = null;
        if (lantern)
        {
            if (!int.TryParse(point[2], NumberStyles.None, CultureInfo.InvariantCulture, out var roadX) ||
                !int.TryParse(point[3], NumberStyles.None, CultureInfo.InvariantCulture, out var roadY)) return null;
            road = new(roadX, roadY);
        }
        var plan = road is { } edge ? new TownProjectPayload(label, supported.CanonicalId, new(x, y), edge, supported.BuildCosts)
            : PlanFor(town, supported, new(x, y), label);
        if (plan is null) return null;
        if (TownProjectRules.PayloadRefusal(plan) is not null) return null;
        return TownProjectSiteFailure(town, plan, actor: actor) is null ? plan : null;
    }
}
