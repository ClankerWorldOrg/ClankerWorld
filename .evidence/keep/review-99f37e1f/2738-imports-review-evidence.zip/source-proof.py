import pathlib,subprocess,json,re,collections
root=pathlib.Path('/workspace/review-2738-99f37e1f');out=pathlib.Path('/workspace/review-evidence-99f37e1f/2738')
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True)
paths=git('diff','--name-only','HEAD^','HEAD').splitlines();assert len(paths)==32 and all(p.startswith('src/ClankerWorld.Simulation/World/Towns/') and p.endswith('.cs') for p in paths)
imports=[];blank=0
for f in paths:
 old=git('show','HEAD^:'+f);new=(root/f).read_text();assert not re.search(r'^\s*#',old,re.M),f
 keep=lambda s:[l for l in s.splitlines() if l.strip() and not l.startswith('using ')]
 assert keep(old)==keep(new),f+' alters nonimportline'
 before=old.splitlines();after=new.splitlines();beforeimports=[l for l in before if l.startswith('using ')];afterimports=[l for l in after if l.startswith('using ')];remaining=collections.Counter(beforeimports)-collections.Counter(afterimports)
 assert not collections.Counter(afterimports)-collections.Counter(beforeimports)
 for i,l in enumerate(before,1):
  if remaining[l]:imports.append({'path':f,'line':i,'text':l});remaining[l]-=1
 blank+=sum(not l.strip() for l in before)-sum(not l.strip() for l in after)
assert len(imports)==66 and blank==10,(len(imports),blank)
assert len([x for x in imports if '=' in x['text']])==1
assert git('diff','--numstat','HEAD^','HEAD').splitlines() and all(l.startswith('0\t') for l in git('diff','--numstat','HEAD^','HEAD').splitlines())
(out/'changed-paths.json').write_text(json.dumps(paths,indent=2)+'\n');(out/'removed-imports.json').write_text(json.dumps(imports,indent=2)+'\n');print('All32 complete ordered non-empty/non-import line sequences identical; only66imports(1alias) and10blanklines removed; no directives/config/tests changed.')
