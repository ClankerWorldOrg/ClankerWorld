using System.Text.Json;
using ClankerWorld.Simulation.Cognition;
using ClankerWorld.Simulation.Society;

namespace ClankerWorld.Simulation.World;

public sealed partial class WorldRuntime
{
    public OwnerInstructionReceipt SubmitInstruction(OwnerInstructionRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);
        ValidateInstructionRequest(request);
        gate.Wait();
        try
        {
            return OrderSystem.SubmitInstruction(OrderIngressWorld, request);
        }
        finally
        {
            gate.Release();
        }
    }

    public OwnerOrderControlReceipt CancelOrder(OwnerOrderCancelRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);
        ValidateOrderCancelRequest(request);
        gate.Wait();
        try
        {
            return OrderSystem.CancelOrder(OrderIngressWorld, request);
        }
        finally
        {
            gate.Release();
        }
    }

    public bool SetAgingOverride(int rate)
    {
        gate.Wait();
        try
        {
            var before = society.Checkpoint.LifeClock;
            society.Apply(checkpoint => SocietyRules.SetAgingOverride(checkpoint, rate));
            if (before == society.Checkpoint.LifeClock) return false;
            checkpointSchemaVersion = StateSchemaVersion;
            AppendEvent(new AgingOverrideChangedEventPayload(null, rate));
            return true;
        }
        finally
        {
            gate.Release();
        }
    }

    public bool SetJevEnabled(bool enabled) => SetRoutineHelper(enabled ? RoutineHelperSettings.Jev : RoutineHelperSettings.Off);

    public bool SetRoutineHelper(RoutineHelperSettings settings, string? expectedWorldId = null)
    {
        ArgumentNullException.ThrowIfNull(settings);
        settings.Validate();
        gate.Wait();
        try
        {
            if (expectedWorldId is not null && expectedWorldId != society.Checkpoint.WorldId)
                throw new InvalidOperationException("The active world changed. Open World Settings again.");
            if (!society.Checkpoint.IsPaused)
                throw new InvalidOperationException("Pause the world before changing the routine helper.");
            // The first explicit selection activates helper routing even when
            // its values match the untouched installation-compatible defaults.
            if (routineHelper == settings && jevPolicyRevision > 0) return false;
            foreach (var id in pendingModelCalls.Keys.ToArray()) CancelPendingModelCall(id);
            foreach (var id in pendingWills.Keys.ToArray()) this.familyWills.CancelPendingWill(this.FamilyWillWorld, id, "interrupted", true);
            routineHelper = settings;
            jevEnabled = settings.Provider != "off";
            jevPolicyRevision = checked(jevPolicyRevision + 1);
            checkpointSchemaVersion = StateSchemaVersion;
            AppendEvent(new RoutineHelperChangedEventPayload(null, settings.Provider, settings.Model));
            return true;
        }
        finally { gate.Release(); }
    }

    // Provider startup and synchronous cancellation completions can reserve or
    // finish a model call on the thread holding this nonreentrant runtime gate.
    [ThreadStatic] private static WorldRuntime? providerInvocationUnderGate;

    /// <summary>
    /// True while this thread invokes a provider or its cancellation callbacks
    /// under the runtime gate. Code reached from those callbacks must not wait
    /// for this nonreentrant gate.
    /// </summary>
    public bool IsInvokingProviderUnderGateOnThisThread => ReferenceEquals(providerInvocationUnderGate, this);

    private void CancelProviderCall(CancellationTokenSource cancellation, bool underRuntimeGate)
    {
        var outerInvocation = providerInvocationUnderGate;
        if (underRuntimeGate) providerInvocationUnderGate = this;
        try
        {
            cancellation.Cancel();
        }
        finally
        {
            providerInvocationUnderGate = outerInvocation;
        }
    }

    public void Pause()
    {
        gate.Wait();
        try
        {
            PauseCore();
        }
        finally
        {
            gate.Release();
        }
    }

    /// <summary>
    /// Pauses like <see cref="Pause"/>, but returns false without pausing if
    /// the runtime stays busy for <paramref name="wait"/> or this thread is
    /// invoking a provider or its cancellation callbacks under the runtime gate.
    /// An optional condition is checked after acquiring the runtime gate. A
    /// condition that no longer applies completes successfully without pausing.
    /// </summary>
    public bool TryPause(TimeSpan wait, Func<bool>? shouldPause = null)
    {
        if (IsInvokingProviderUnderGateOnThisThread || !gate.Wait(wait)) return false;
        try
        {
            if (shouldPause is not null && !shouldPause()) return true;
            PauseCore();
            return true;
        }
        finally
        {
            gate.Release();
        }
    }

    private void PauseCore()
    {
        var wasPaused = society.Checkpoint.IsPaused;
        var result = society.Pause();
        if (!wasPaused && result.Checkpoint.IsPaused)
        {
            foreach (var id in pendingModelCalls.Keys.ToArray()) CancelPendingModelCall(id);
            foreach (var id in pendingWills.Keys.ToArray()) this.familyWills.CancelPendingWill(this.FamilyWillWorld, id, "interrupted", true);
            CancelIdentityMoments();
            foreach (var id in pendingConversationTurns.Keys.ToArray())
                CancelPendingConversationTurn(id, AgentConversationInterruption.OwnerPaused);
            SuspendAllConversations(AgentConversationInterruption.OwnerPaused);
            AppendEvent(new PausedEventPayload(null));
        }
    }

    /// <summary>
    /// Writes the installation's 80% model-call warning into this world's
    /// Event Log. The count and limit stay in installation accounting; the
    /// event only records what the player was told, like a pause. Returns
    /// false, recording nothing, when the runtime stays busy for
    /// <paramref name="wait"/> or this thread invokes a provider or its
    /// cancellation callbacks under the runtime gate.
    /// </summary>
    public bool TryRecordModelCallWarning(long attempts, long attemptLimit, TimeSpan wait)
    {
        if (attemptLimit < 1 || attempts < 1 || attempts > attemptLimit)
            throw new ArgumentOutOfRangeException(nameof(attempts), "A model-call warning needs a used count within a positive limit.");
        if (IsInvokingProviderUnderGateOnThisThread || !gate.Wait(wait)) return false;
        try
        {
            AppendEvent(new ModelCallWarningEventPayload(null, attempts, attemptLimit));
            return true;
        }
        finally
        {
            gate.Release();
        }
    }

    public void Resume()
    {
        gate.Wait();
        try
        {
            if (founderSetup is { Started: false })
                throw new InvalidOperationException("Place four founders and explicitly start the world before time can run.");
            var wasPaused = society.Checkpoint.IsPaused;
            var result = society.Resume();
            if (wasPaused && !result.Checkpoint.IsPaused)
            {
                AppendEvent(new ResumedEventPayload(null, result.Checkpoint.RunEpoch));
            }
        }
        finally
        {
            gate.Release();
        }
    }

    private bool IsInstructionComplete(OwnerQueuedInstruction instruction) =>
        instruction.Task?.IsTerminal ?? completedSuggestionIds.Contains(instruction.InstructionId);

    private IEnumerable<string> CompletedInstructionIds() =>
        completedSuggestionIds.Concat(instructionsByIdempotency.Values
            .Where(item => item.Task?.IsTerminal == true).Select(item => item.InstructionId));

    private OwnerQueuedInstruction? PendingInstructionFor(string agentId) =>
        OrderSystem.PendingInstructionFor(ControlWorld, agentId);

    public static OwnerQueuedInstruction? FirstActiveOrderFor(IEnumerable<OwnerQueuedInstruction> instructions, string agentId) =>
        instructions
            .Where(item => item.TargetAgentId == agentId &&
                item.Kind == OwnerInstructionKind.Order &&
                item.Task is not null && IsActiveOrder(item.Task.Status))
            .OrderBy(item => item.Task!.Status == "queued")
            .ThenBy(item => item.SubmissionSequence)
            .FirstOrDefault();

    private void ReplacePendingOrder(string agentId) =>
        OrderSystem.ReplacePendingOrder(ControlWorld, agentId);

    private void CancelActiveOrder(OwnerQueuedInstruction instruction, string cause, string? reason) =>
        OrderSystem.CancelActiveOrder(ControlWorld, instruction, cause, reason);

    private static bool IsActiveOrder(string status) =>
        status is "queued" or "waiting" or "doing" or "interrupted" or "blocked";

    private bool HasNewObserverGuidanceFor(string agentId) =>
        OrderSystem.HasNewObserverGuidanceFor(ControlWorld, agentId);

    private OwnerQueuedInstruction[] ObserverGuidanceInstructionsFor(string agentId) =>
        OrderSystem.ObserverGuidanceInstructionsFor(ControlWorld, agentId);

    private CognitionObserverGuidance[] ObserverGuidanceFor(string agentId) =>
        OrderSystem.ObserverGuidanceFor(ControlWorld, agentId);

    private static string? UnderstoodTaskFor(string? candidate) => candidate switch
    {
        "load_handcart" => "load the requested loose goods into the selected owned handcart",
        "unload_handcart" or "unload_handcart_ground" => "unload the requested cargo from the selected owned handcart",
        "talk_to" => TalkOrderTask,
        "propose_marriage" => MarriageOrderTask,
        "attach_handcart" => "reach and attach the selected owned handcart",
        "park_handcart" => "park the selected attached handcart here with its cargo intact",
        "repair_handcart" => "repair the selected owned handcart with real carried supplies",
        "animal_care" => "care for the named animal with real feed and jug water",
        "animal_collect" => "collect the named animal's ready products locally",
        "animal_tame" => "tame the named wild animal for your household",
        "animal_lead_home" => "lead the named animal to its household yard",
        "animal_saddle" => "fit a real household saddle on the named horse",
        "animal_mount" => "mount the named cared-for horse with permission",
        "animal_dismount" => "dismount the named horse and leave excess cargo here",
        "seek_shelter" => "reach the requested permitted shelter",
        "tend_fire" => "light one permitted hearth using your own wood",
        "read_knowledge" => KnowledgeReadOrderTask,
        "consume_food" => "eat one carried food item",
        "move_to" => "travel to the exact tile named in this order",
        "travel_by_boat" => "travel by communal boat to the exact Port named in this order",
        "seek_food" => "travel within gathering range of an available food source",
        "harvest_food" => "gather several food servings from a nearby food source",
        "gather_material" => "gather the requested material from a natural source",
        "till_field" => "till a field for your household",
        "plant_field" => "plant the requested crop in your household field",
        "plant_tree" or "plant_broadleaf" or "plant_conifer" or "plant_orchard" => "plant the requested tree using a real seed outside Town borders",
        "tend_field" => "tend your household crop",
        "harvest_field" => "harvest your household crop",
        "repair_tool" => "repair your own worn tool",
        "repair_equipment" => "repair your own worn clothing or carrying aid",
        "collect_material" => "collect your own stored or dropped material",
        "collect_food" => "collect your own stored or dropped food",
        "collect_equipment" => "collect your own stored or dropped equipment",
        "collect_goods" => "collect your own stored or dropped goods",
        "store_material" => "store your own carried material in your House",
        "store_equipment" => "store your own carried equipment in your House",
        "accept_guardianship" => "accept primary care of the named child through their guardian search",
        "store_goods" => "store your own carried goods in your House",
        "return_borrowed" => "return borrowed goods to their owning household's House",
        "deliver_stock" => "deliver the requested goods to a permitted building",
        "produce_item" => "make the requested goods at a permitted workstation",
        "write_knowledge" => "write the requested record, map or book from your learned sites using real materials",
        "copy_knowledge" => "copy the requested held record, map or book using real materials and sites you know",
        "construct_building" => "construct the requested household building at a permitted site",
        "expand_building" => "complete the requested building's next permitted expansion",
        _ => null,
    };

    private OrderTask? ParseOrderTask(string text, string actor) =>
        OrderSystem.ParseOrderTask(ControlWorld, text, actor);

    // A direct order that names no action the game can carry out is closed
    // at once. It never waits for a decision or holds up later instructions.
    private void CloseOrdersNotUnderstood(string agentId) =>
        OrderSystem.CloseOrdersNotUnderstood(ControlWorld, agentId);

    private static string InstructionIdFor(long sequence) =>
        DerivedId.Create(FormattableString.Invariant($"private-instruction-{sequence:D10}"));

    private const string InstructionRequestDigestPrefix = "order-request-";

    private static string InstructionRequestDigest(OwnerInstructionRequest request) =>
        DerivedId.Hash(JsonSerializer.Serialize(request with
        {
            IdempotencyKey = request.IdempotencyKey.Trim(),
            IssuerId = request.IssuerId.Trim(),
            TargetAgentId = request.TargetAgentId.Trim(),
            Text = request.Text.Trim(),
        }), InstructionRequestDigestPrefix);

    private static string InstructionRequestDigest(OwnerQueuedInstruction instruction) =>
        InstructionRequestDigest(new OwnerInstructionRequest(instruction.IdempotencyKey, instruction.IssuerId,
            instruction.TargetAgentId, instruction.Kind, instruction.Text, instruction.Queue));

    private static bool Matches(OwnerOrderCancellation existing, OwnerOrderCancelRequest request) =>
        existing.IssuerId == request.IssuerId.Trim() &&
        existing.WorldId == request.WorldId.Trim() &&
        existing.TargetAgentId == request.TargetAgentId.Trim() &&
        existing.OrderId == request.OrderId.Trim();

    private static void ValidateOrderCancelRequest(OwnerOrderCancelRequest request)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(request.IdempotencyKey);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.IssuerId);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.WorldId);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.TargetAgentId);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.OrderId);
        foreach (var value in new[] { request.IdempotencyKey, request.IssuerId, request.WorldId,
                     request.OrderId })
            if (value.Trim().Length > 128 || value.Any(char.IsControl))
                throw new ArgumentOutOfRangeException(nameof(request), "Order cancellation identities must be bounded and contain no control characters.");
        if (request.TargetAgentId.Any(char.IsControl))
            throw new ArgumentOutOfRangeException(nameof(request), "Order cancellation target must contain no control characters.");
    }

    // Refuse everything a save would refuse before the request touches live
    // state, so a bad request cannot leave the world unable to save.
    private static void ValidateInstructionRequest(OwnerInstructionRequest request)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(request.IdempotencyKey);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.IssuerId);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.TargetAgentId);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.Text);
        if (!IdentityRules.Reference(request.IdempotencyKey.Trim(), OwnerQueuedInstruction.MaximumIdentifierLength))
            throw new ArgumentOutOfRangeException(nameof(request), "Instruction idempotency key must be at most 128 characters without control characters.");
        if (!IdentityRules.Reference(request.IssuerId.Trim(), OwnerQueuedInstruction.MaximumIdentifierLength))
            throw new ArgumentOutOfRangeException(nameof(request), "Instruction issuer ID must be at most 128 characters without control characters.");
        if (request.Kind is not (OwnerInstructionKind.Suggestion or OwnerInstructionKind.Order))
            throw new ArgumentOutOfRangeException(nameof(request), "Instruction kind must be suggestion or order.");
        var text = request.Text.Trim();
        if (text.Length > OwnerQueuedInstruction.MaximumTextLength || text.Any(char.IsControl))
            throw new ArgumentOutOfRangeException(nameof(request), "Instruction text must be at most 512 characters without control characters.");
    }

    internal static bool IsValidInstructionIdentifier(string? value) =>
        IdentityRules.Reference(value, OwnerQueuedInstruction.MaximumIdentifierLength);

    private static string ToWireValue(OwnerInstructionKind kind) => kind switch
    {
        OwnerInstructionKind.Suggestion => "suggestion",
        OwnerInstructionKind.Order => "order",
        _ => throw new ArgumentOutOfRangeException(nameof(kind)),
    };

}
