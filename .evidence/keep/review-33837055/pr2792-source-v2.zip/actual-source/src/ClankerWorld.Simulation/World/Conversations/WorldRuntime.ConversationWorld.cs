using ClankerWorld.Simulation.Society;

namespace ClankerWorld.Simulation.World;

public sealed partial class WorldRuntime
{
    private sealed class ConversationWorldAdapter(WorldRuntime runtime) : IConversationWorld
    {
        public long WorldTick => runtime.WorldTick;
        public string WorldSeed => runtime.worldSeed;
        public SocietyCheckpoint Society => runtime.society.Checkpoint;
        public IReadOnlyDictionary<string, AgentState> Agents => runtime.agents;
        public long WorldDayAt(long tick) => WorldCalendarRules.FromTick(tick, runtime.worldSystems.Config).DayIndex;
        public bool NeedsUrgentFood(AgentState person) => WorldRuntime.NeedsUrgentFood(person);
        public bool NeedsUrgentWarmth(AgentState person) => runtime.NeedsUrgentWarmth(person);
        public bool IsAboardBoat(string agentId) => runtime.PassengerBoat(agentId) is not null;
        public int FootDistance(GridPoint from, GridPoint to) => runtime.map.FootDistance(from, to);
        public bool IsWithinInteractionRange(GridPoint from, GridPoint to, int range) =>
                runtime.IsWithinInteractionRange(from, to, range);
        public bool HasExplicitConversationProvider(string agentId) => runtime.HasExplicitConversationProvider(agentId);
        public bool ActiveTalkOrderUses(string conversationId) => runtime.ActiveTalkOrderUses(conversationId);
        public void IncreaseTrust(string from, string to, int amount, string reason) => CommunitySystem.IncreaseTrust(runtime.CommunitySkillWorld, from, to, amount, reason);
        public void AppendEvent(WorldEventPayload payload, GridPoint? position) => runtime.AppendEvent(payload, position);
        public SocietyOperationResult Apply(Func<SocietyCheckpoint, SocietyOperationResult> operation) => runtime.society.Apply(operation);
        public SocietyOperationResult RenameFromPlayer(SocietyCheckpoint checkpoint, string agentId, string name) =>
                runtime.RenameFromPlayer(checkpoint, agentId, name);
    }
}
