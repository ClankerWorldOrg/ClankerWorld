using System.Text.Json;
using ClankerWorld.Simulation.Kernel;
using ClankerWorld.Simulation.Society;

namespace ClankerWorld.Simulation.World;

public sealed partial class WorldRuntime
{
    public static IReadOnlyList<string> DeveloperGoods { get; } = Array.AsReadOnly(new[]
    {
        "berries", "fruit", "wild_greens", "cultivated_greens", "grain", "flour", "wood", "stone",
        "fiber", "rope", "cloth", "clothing", "padded_coat", "rain_cloak", "basket", "sack",
        "wooden_axe", "wooden_pickaxe", "iron_ore", "iron", "storage_pot", "water_jug", "medicine", "tree_seed",
        "eggs", "milk", "wool", "hide", "leather", "leather_sack", "saddle", "cooked_eggs", "milk_porridge", "rich_meal",
    });

    public WorldDeveloperEditResult ApplyDeveloperEdit(WorldDeveloperEdit edit,
        Action<WorldRuntimeState>? persist = null)
    {
        ArgumentNullException.ThrowIfNull(edit);
        gate.Wait();
        try
        {
            if (edit.WorldId != society.Checkpoint.WorldId)
                return new(false, false, "The active world changed. Refresh before editing.");
            if (!society.Checkpoint.IsPaused)
                return new(false, false, "Pause the world before making a developer edit.");
            var detail = JsonSerializer.Serialize(edit);
            // A lost response can be retried without applying a second grant.
            // Once this event leaves hot history the old expected ID still
            // refuses the retry, rather than allowing it to run again.
            if (events.Any(item => item.Kind == "developer_edit" && item.Detail == detail))
                return new(false, true, null);
            if (edit.ExpectedEventId != nextEventId - 1)
                return new(false, false, "The world changed. Refresh before editing.");
            using var proposed = RestoreCore(CaptureState(), providerFactory,
                maxCognitionDispatchPerCycle, trustedPreparedState: true, preparedCivic: townSystem.CheckpointState);
            try
            {
                proposed.ApplyDeveloperEditCore(edit);
                proposed.AppendEvent(new DeveloperEditEventPayload(edit.AgentId, edit.WorldId, edit.ExpectedEventId, edit.Operation, edit.Value, edit.Amount, edit.OtherAgentId));
                proposed.Validate();
                ValidateStateForCodec(proposed.CaptureState());
            }
            catch (Exception exception) when (exception is ArgumentException or InvalidOperationException or InvalidDataException)
            {
                return new(false, false, exception.Message);
            }
            // Persist the validated proposal before exposing it. An I/O failure
            // leaves live state and the expected-event precondition unchanged.
            persist?.Invoke(proposed.CaptureState());
            CommitPreparedTick(proposed);
            plannedRoutes = [];
            return new(true, false, null);
        }
        finally { gate.Release(); }
    }

    private void ApplyDeveloperEditCore(WorldDeveloperEdit edit)
    {
        if (new[] { edit.AgentId, edit.Operation, edit.Value, edit.OtherAgentId ?? "" }
            .Any(value => value is null || value.Length > 512 || value.Any(char.IsControl)))
            throw new ArgumentException("Developer edit values must be short and contain no control characters.");
        if (!agents.TryGetValue(edit.AgentId, out var person) ||
            society.Checkpoint.GetAgent(edit.AgentId).Status != SocietyAgentStatus.Active)
            throw new InvalidOperationException("Select a living agent.");
        var actor = edit.AgentId;
        var id = $"developer-edit-{edit.ExpectedEventId + 1}";
        switch (edit.Operation)
        {
            case "add_animal":
                if (!IsAdult(actor) || HouseholdFor(actor) is not { } animalHousehold || AnimalYard(animalHousehold) is not { } animalYard)
                    throw new InvalidOperationException("Select an adult whose household has a completed animal yard.");
                var animalParts = edit.Value.Split(':');
                if (animalParts.Length != 2 || !AnimalRules.Species.Any(species => species.Id == animalParts[0]) ||
                    animalParts[1] is not ("female" or "male") || edit.Amount != 0 || edit.OtherAgentId is not null)
                    throw new ArgumentException("Choose a chicken, sheep, cow or horse and female or male.");
                if (!HasAnimalSpace(animalHousehold, animalYard) || FreeAnimalYardTile(animalYard) is not { } animalPosition)
                    throw new InvalidOperationException("The animal yard and household need one free animal place.");
                SeedWildAnimals();
                SetAnimal(new("animal-" + id, animalParts[0] + " " + (animalWorld.Animals.Count + 1), animalParts[0], animalParts[1],
                    WorldTick - (long)AnimalRules.Definition(animalParts[0]).AdultDays * AnimalDayTicks, animalPosition,
                    AnimalHerdId(animalHousehold), animalHousehold, animalYard.InstanceId));
                AppendEvent(new AnimalAddedEventPayload(actor, id), animalPosition);
                break;
            case "set_need":
                if (edit.Amount is < 0 or > 100)
                    throw new ArgumentOutOfRangeException(nameof(edit), "Needs must be between 0 and 100 percent.");
                var survival = person.Survival ?? new SurvivalCondition();
                if (edit.Value != "fullness") survivalState ??= new SurvivalState(WorldTick, []);
                agentStore.ApplyDeveloperNeedEdit(actor, edit.Value switch
                {
                    "fullness" => AgentStore.PrepareFullness(person, edit.Amount * 100),
                    "warmth" => AgentStore.PrepareSurvival(person, survival with { WarmthBasisPoints = edit.Amount * 100 }),
                    "illness" => AgentStore.PrepareSurvival(person, survival with { IllnessBasisPoints = edit.Amount * 100 }),
                    "nutrition" => AgentStore.PrepareSurvival(person, survival with { NutritionBasisPoints = edit.Amount * 100 }),
                    _ => throw new ArgumentException("Choose fullness, warmth, illness or nutrition."),
                });
                break;
            case "give_goods":
                if (!DeveloperGoods.Contains(edit.Value, StringComparer.Ordinal) || edit.Amount is < 1 or > 100)
                    throw new ArgumentException("Choose a supported good and a quantity from 1 to 100.");
                if (edit.Amount > FreeCarryCapacity(actor))
                    throw new InvalidOperationException("The agent cannot carry that many goods.");
                var individualVessels = InventoryContainerRules.IsContainer(edit.Value);
                var lotsToAdd = individualVessels ? edit.Amount : 1;
                for (var index = 0; index < lotsToAdd; index++)
                {
                    var lotId = lotsToAdd == 1 ? id : DeveloperVesselUnitId(id, index);
                    RunInventoryCommand(InventorySystem.AddDeveloperStock(lotId, edit, actor, individualVessels));
                }
                break;
            case "remove_goods":
                if (edit.Amount is < 1 or > 100)
                    throw new ArgumentException("Choose a quantity from 1 to 100.");
                var removable = society.Checkpoint.Inventory.Lots.Where(lot => lot.OwnerId == actor &&
                        lot.ItemKind == edit.Value && PersonalEquipmentRules.IsCarried(lot, actor) &&
                        lot.DeliveryBuildingId is null && lot.ContainerLotId is null &&
                        !PersonalEquipmentRules.IsSelected(person.Equipment, lot.Id) &&
                        !knowledge.Artifacts.Any(artifact => artifact.LotId == lot.Id) &&
                        !society.Checkpoint.Inventory.Lots.Any(content => content.ContainerLotId == lot.Id))
                    .OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
                if (removable.Sum(PhysicalUnreservedQuantity) < edit.Amount)
                    throw new InvalidOperationException("Not enough unreserved personal goods are carried. Equipped items, filled vessels and knowledge records are protected.");
                var remaining = edit.Amount;
                foreach (var lot in removable)
                {
                    var amount = Math.Min(remaining, PhysicalUnreservedQuantity(lot));
                    if (amount == 0) continue;
                    RunInventoryCommand(InventorySystem.DiscardDeveloperStock(actor, lot, amount));
                    remaining -= amount;
                    if (remaining == 0) break;
                }
                break;
            case "add_skill":
            case "remove_skill":
                if (!Enum.TryParse<SkillKind>(edit.Value, true, out var skill) || !Enum.IsDefined(skill))
                    throw new ArgumentException("Choose building, farming, crafting or smithing.");
                var hasSkill = person.Skills?.Any(item => item.Kind == skill) == true;
                if (hasSkill == (edit.Operation == "add_skill"))
                    throw new InvalidOperationException(hasSkill ? "The agent already has that skill." : "The agent does not have that skill.");
                var skills = (person.Skills ?? []).Where(item => item.Kind != skill).ToList();
                if (edit.Operation == "add_skill")
                    skills.Add(person.Skills?.FirstOrDefault(item => item.Kind == skill) ?? new LearnedSkill(skill, WorldTick));
                agentStore.RecordSkills(actor, person, skills.OrderBy(item => item.Kind).ToArray());
                break;
            case "start_partnership":
            case "end_partnership":
                if (edit.Value != "partnership") throw new ArgumentException("Choose partnership as the relationship type.");
                var other = edit.OtherAgentId;
                if (other is null || other == actor || !IsAdult(actor) || !IsAdult(other))
                    throw new InvalidOperationException("Choose two different living adults.");
                if (edit.Operation == "start_partnership")
                {
                    if (!FamilySystem.AvailablePartner(this.FamilyPartnershipWorld, actor) || !FamilySystem.AvailablePartner(this.FamilyPartnershipWorld, other) || FamilySystem.CloseKin(this.FamilyPartnershipWorld, actor, other))
                        throw new InvalidOperationException("Both adults must be unpartnered and not close relatives.");
                    society.Apply(checkpoint => SocietyRules.ProposeRelationship(checkpoint,
                        new(id, 1, SocietyRelationshipType.Partnership, actor, other, WorldTick, PrivacyClass: "public")));
                    society.Apply(checkpoint => SocietyRules.AcceptRelationship(checkpoint, id, 1, other));
                    if (society.Checkpoint.GetRelationship(id).State != SocietyRelationshipState.Accepted)
                        throw new InvalidOperationException("The partnership could not be started.");
                }
                else
                {
                    var partnership = FamilySystem.Partnerships(this.FamilyPartnershipWorld, actor).FirstOrDefault(item =>
                        item.State is SocietyRelationshipState.Accepted or SocietyRelationshipState.Proposed &&
                        (item.ProposerId == other || item.TargetId == other));
                    if (partnership is null) throw new InvalidOperationException("These agents have no current partnership.");
                    society.Apply(checkpoint => SocietyRules.RevokeRelationship(checkpoint, partnership.Id, actor));
                    MaintainMarriages();
                }
                break;
            default:
                throw new ArgumentException("Choose a supported developer edit.");
        }
        agentStore.RecordDecisionContext(actor, agents[actor], null);
        checkpointSchemaVersion = StateSchemaVersion;
    }
}
