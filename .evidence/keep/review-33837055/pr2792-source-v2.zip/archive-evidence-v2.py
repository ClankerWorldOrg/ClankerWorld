from pathlib import Path
import zipfile,hashlib,json
p=Path('/workspace/review-coverage-33837055/fix2554b');native=Path('/workspace/native-2554b-v2-33837055');target=Path('/workspace/review-evidence-33837055/.evidence/keep/review-33837055');target.mkdir(parents=True,exist_ok=True)
assert json.load(open(p/'focused-reconciliation-v2.json'))['methods']==275
source=[(f,f.relative_to(p)) for f in sorted(p.rglob('*')) if f.is_file() and not ({'baseline-binaries','pinned-binaries'}&set(f.relative_to(p).parts)) and f.suffix not in {'.zip','.dll','.pdb'}]
binaries=[(f,f.relative_to(p)) for folder in [p/'baseline-binaries',*(p/'pinned-binaries'/name for name in ['head-v2','tests-v2','native-baseline-v2'])] for f in sorted(folder.rglob('*')) if f.is_file()]
sets={'source-v2':source,'binaries-v2':binaries,'native-v2':[(f,f.relative_to(native)) for f in sorted(native.rglob('*')) if f.is_file()]};rows=[]
for label,files in sets.items():
 path=target/('pr2792-'+label+'.zip')
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f,name in files:z.write(f,name)
 rows.append({'kind':label,'file':str(path),'bytes':path.stat().st_size,'files':len(files),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 assert path.stat().st_size<32*1024*1024
(p/'archive-manifest-v2.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
