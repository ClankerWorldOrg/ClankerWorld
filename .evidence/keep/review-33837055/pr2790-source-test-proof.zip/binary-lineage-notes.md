# Compiled lineage — Codex session 33837055

The first Simulation build preceded the source commit. Its informational version contains base835f9db; full dependent Release after commit contains exact head9f1bd441. A proposed first/full byte-equality assertion correctly rejected the different Git metadata. The original first build/probe is retained in first-uncommitted-binaries and binary-shape-first, labeled accordingly.

The final proof uses the committed full-build Simulation DLL/PDB pinned in head-binaries and the byte-identical test copies in test-binaries. binary-shape contains the rerun against those actual committed assemblies; binary-shape-final.log is its result. No product source changed, and no test binary was replaced during execution. The source proof verifies all1031 actual source token streams and all50 effective validator predicates/targets. The informational metadata difference does not weaken any check or count as test equivalence.
