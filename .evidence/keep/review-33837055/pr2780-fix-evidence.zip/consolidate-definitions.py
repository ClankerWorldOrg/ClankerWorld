from pathlib import Path
import re,json
c=Path('src/ClankerWorld.Simulation/World/Civic')
p=c/'WorldRuntime.GovernanceDefinitions.cs'
s=p.read_text();old='''        where TChoice : class where TPlan : ActionPlan => new(
            DecodeReferenceChoice(decode), encode, TownSystem.GovernanceCapabilities,
            (world, actor, choice, _) => plan(world.civicWorld, actor, choice),
            (world, original, policy) => check(world.civicWorld, original, policy),
            ApplyCivicPlan);'''
new='''        where TChoice : class where TPlan : ActionPlan => CreateCivicDefinition<TChoice, TPlan>(decode, encode,
            (world, actor, choice) => plan(world.civicWorld, actor, choice),
            (world, original, policy) => check(world.civicWorld, original, policy));

    private static ActionDefinition<TChoice, TPlan> CreateCivicDefinition<TChoice, TPlan>(
        Func<string, TChoice?> decode, Func<TChoice, string> encode,
        Func<WorldRuntime, string, TChoice, TPlan?> plan,
        Func<WorldRuntime, TPlan, ActorCapabilityPolicy, ActionCheck> check)
        where TChoice : class where TPlan : ActionPlan => new(
            DecodeReferenceChoice(decode), encode, TownSystem.GovernanceCapabilities,
            (world, actor, choice, _) => plan(world, actor, choice), check, ApplyCivicPlan);'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
static_plans={'CouncilConsent','CivicNotice','TownLandClaim','HouseholdLandResponse','NonLandJudge'}
records=[]
pattern=re.compile(r'(?P<decl>        internal static readonly ActionDefinition<(?P<choice>\w+), (?P<plan>\w+)> \w+) = new\(\n            DecodeReferenceChoice\((?P=choice)\.Decode\), static choice => choice\.Encode\(\), TownSystem\.GovernanceCapabilities,\n            static \(world, actor, choice, _\) => (?P<planner>[^\n]+),\n            static \(world, plan, policy\) => (?P<checker>[^\n]+),\n            ApplyCivicPlan\);')
for p in c.glob('WorldRuntime.*Definitions.cs'):
 s=p.read_text()
 def replace(m):
  a=m.groupdict(); planner=a['planner']; checker=a['checker']
  static=any(planner==f'TownSystem.Plan{name}(world.civicWorld, actor, choice)' for name in static_plans) and not 'world.townSystem.' in checker
  if static:
   factory='CreateGovernanceDefinition'; pl=planner.replace('(world.civicWorld, actor, choice)','');ch=checker.replace('world.civicWorld','world')
   planline=pl
  else:
   factory='CreateCivicDefinition'; ch=checker;planline='static (world, actor, choice) => '+planner
  records.append(dict(file=str(p),choice=a['choice'],plan=a['plan'],factory=factory,planner=planner,checker=checker))
  return f"{a['decl']} = {factory}<{a['choice']}, {a['plan']}>(\n            {a['choice']}.Decode, static choice => choice.Encode(), {planline},\n            static (world, plan, policy) => {ch});"
 n=pattern.sub(replace,s)
 if n!=s:p.write_text(n)
assert len(records)==20,len(records)
Path('/workspace/review-coverage-33837055/fix2551/definition-map.json').write_text(json.dumps(records,indent=2))
