using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=Path.GetFullPath(args[0]);
var files=Directory.GetFiles(root+"/src/ClankerWorld.Simulation", "*.cs",SearchOption.AllDirectories).Where(p=>!p.Contains("/bin/")&&!p.Contains("/obj/")).ToList();
files.Add(root+"/src/ClankerWorld.Simulation/obj/Release/net10.0/ClankerWorld.Simulation.GlobalUsings.g.cs");
foreach(var f in new[]{"AgentPlacementRules.cs","BoundedText.cs","RoutineHelperDefaults.cs","Contracts/CalendarRules.cs","Contracts/NeedStates.cs"})files.Add(root+"/src/ClankerWorld.Shared/"+f);
files.AddRange(Directory.GetFiles(root+"/src/ClankerWorld.Shared/WorldEvents","*.cs"));
var trees=files.Select(f=>CSharpSyntaxTree.ParseText(File.ReadAllText(f),path:f)).ToArray();
var refs=((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator).Select(p=>MetadataReference.CreateFromFile(p));
var compilation=CSharpCompilation.Create("ClankerWorld.Simulation",trees,refs,new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,nullableContextOptions:NullableContextOptions.Enable));
if(args.Length>1 && args[1]=="imports"){
 var diagnostics=compilation.GetDiagnostics();
 Console.WriteLine(JsonSerializer.Serialize(new {errors=diagnostics.Where(d=>d.Severity==DiagnosticSeverity.Error).Select(d=>d.ToString()).ToArray(),unused=diagnostics.Where(d=>d.Id=="CS8019" && d.Location.SourceTree!.FilePath.Contains("/World/Civic/")).Select(d=>new{file=d.Location.SourceTree!.FilePath,line=d.Location.GetLineSpan().StartLinePosition.Line+1,source=d.Location.SourceTree.GetText().ToString(d.Location.SourceSpan)}).ToArray()},new JsonSerializerOptions{WriteIndented=true}));return;
}
var config=new Dictionary<string,(string State,string? Restore)>{["foodStewardship"]=("FoodStewardship","RestoreFoodStewardship"),["founderSetup"]=("FounderSetup","RestoreFounderSetup"),["towns"]=("Towns",null),["townLandTitles"]=("TownLandTitles","RestoreTownLandTitles"),["householdLandUseRights"]=("HouseholdLandUseRights","RestoreHouseholdLandUseRights"),["householdLandUseRequests"]=("HouseholdLandUseRequests","RestoreHouseholdLandUseRequests")};
var owner=compilation.GetTypeByMetadataName("ClankerWorld.Simulation.World.TownSystem")!;
var symbols=config.Keys.ToDictionary(n=>n,n=>owner.GetMembers(n).OfType<IPropertySymbol>().Single());
var receipts=new List<object>();
foreach(var tree in trees.Where(t=>t.FilePath.Contains("/World/Civic/"))){
 var model=compilation.GetSemanticModel(tree);var rewriter=new Aliases(model,config,symbols,receipts,tree.FilePath);var before=tree.GetRoot();var after=rewriter.Visit(before)!;
 if(before.ToFullString()!=after.ToFullString())File.WriteAllText(tree.FilePath,after.ToFullString());
}
Console.WriteLine(JsonSerializer.Serialize(receipts,new JsonSerializerOptions{WriteIndented=true}));
sealed class Aliases(SemanticModel model,Dictionary<string,(string State,string? Restore)> config,Dictionary<string,IPropertySymbol> symbols,List<object> receipts,string file):CSharpSyntaxRewriter{
 bool Selected(SyntaxNode node,out string name){var symbol=model.GetSymbolInfo(node).Symbol;name=symbol?.Name??"";return symbols.TryGetValue(name,out var expected)&&SymbolEqualityComparer.Default.Equals(symbol,expected);}
 public override SyntaxNode? VisitPropertyDeclaration(PropertyDeclarationSyntax node){var symbol=model.GetDeclaredSymbol(node);if(symbols.TryGetValue(node.Identifier.ValueText,out var expected)&&SymbolEqualityComparer.Default.Equals(symbol,expected)){receipts.Add(new{file,kind="declaration",source=node.ToFullString()});return null;}return base.VisitPropertyDeclaration(node);}
 public override SyntaxNode? VisitAssignmentExpression(AssignmentExpressionSyntax node){if(Selected(node.Left,out var name)){if(!node.IsKind(SyntaxKind.SimpleAssignmentExpression)||config[name].Restore is not {} restore)throw new Exception("Unexpected assignment "+node);receipts.Add(new{file,kind="setter",source=node.ToString()});return SyntaxFactory.InvocationExpression(SyntaxFactory.IdentifierName(restore),SyntaxFactory.ArgumentList(SyntaxFactory.SingletonSeparatedList(SyntaxFactory.Argument((ExpressionSyntax)Visit(node.Right)!)))).WithTriviaFrom(node);}return base.VisitAssignmentExpression(node);}
 public override SyntaxNode? VisitIdentifierName(IdentifierNameSyntax node){if(Selected(node,out var name)){receipts.Add(new{file,kind="getter",source=node.ToString(),line=node.GetLocation().GetLineSpan().StartLinePosition.Line+1});return SyntaxFactory.ParseExpression("State."+config[name].State).WithTriviaFrom(node);}return base.VisitIdentifierName(node);}
}
