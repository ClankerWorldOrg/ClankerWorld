using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var methods = Directory.GetFiles(args[0], "*.cs").SelectMany(file => CSharpSyntaxTree.ParseText(File.ReadAllText(file)).GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>().Select(node => {
    var names = node.ParameterList.Parameters.Select((p,i) => (p.Identifier.ValueText,Name: "ARG"+i)).ToDictionary(x=>x.ValueText,x=>x.Name);
    var body = (SyntaxNode?)node.Body ?? node.ExpressionBody;
    return new {file, name=node.Identifier.ValueText, lines=node.ToString().Count(c=>c=='\n')+1, normalized=body is null? "":string.Join(" ",body.DescendantTokens().Select(t=>names.GetValueOrDefault(t.ValueText,t.Text))), source=node.ToFullString()};
})).ToArray();
Console.WriteLine(JsonSerializer.Serialize(new {duplicates=methods.Where(x=>x.lines>=3 && x.normalized!="").GroupBy(x=>x.normalized).Where(g=>g.Count()>1).Select(g=>g.ToArray()), forwarders=methods.Where(x=>x.lines>=3 && x.normalized.StartsWith("=>") && !x.normalized.Contains(" switch ")).ToArray()},new JsonSerializerOptions{WriteIndented=true}));
