from pathlib import Path
import re,json
base=Path('/workspace/base-2551-78f-33837055/src/ClankerWorld.Simulation/World/Civic');head=Path('/workspace/fix-2551-33837055/src/ClankerWorld.Simulation/World/Civic')
old=re.compile(r'ActionDefinition<(?P<choice>\w+), (?P<plan>\w+)> (?P<field>\w+) = new\(\n\s+DecodeReferenceChoice\((?P=choice)\.Decode\), (?P<encode>static choice => choice\.Encode\(\)), TownSystem\.(?P<policy>\w+),\n\s+static \(world, actor, choice, _\) => (?P<planner>[^\n]+),\n\s+static \(world, plan, policy\) => (?P<checker>[^\n]+),\n\s+ApplyCivicPlan\);')
new=re.compile(r'ActionDefinition<(?P<choice>\w+), (?P<plan>\w+)> (?P<field>\w+) = (?P<factory>CreateCivicDefinition|CreateGovernanceDefinition)<(?P=choice), (?P=plan)>\(\n\s+(?P=choice)\.Decode, (?P<encode>static choice => choice\.Encode\(\)), (?P<planner>[^\n]+),\n\s+static \(world, plan, policy\) => (?P<checker>[^\n]+)\);')
allowed={'GovernanceCapabilities','CouncilElectionCapabilities','LandRightsCapabilities','CivicMembershipCapabilities','TownProjectProposalCapabilities','NonLandAdultCapabilities','LandHearingCapabilities'}
def norm(s):return re.sub(r'\s+','',s)
rows=[]
for p in head.glob('WorldRuntime.*Definitions.cs'):
 old_rows={m['field']:m.groupdict() for m in old.finditer((base/p.name).read_text())}
 for m in new.finditer(p.read_text()):
  h=m.groupdict()
  if h['field'] not in old_rows:continue
  b=old_rows[h['field']];assert b['policy'] in allowed
  for k in ['choice','plan','encode']:assert b[k]==h[k],(p,k)
  if h['factory']=='CreateGovernanceDefinition':
   assert re.fullmatch(r'TownSystem\.\w+',h['planner'])
   planner=h['planner']+'(world.civicWorld, actor, choice)'
   checker=re.sub(r'\bworld\b','world.civicWorld',h['checker'])
  else:
   prefix='static (world, actor, choice) => ';assert h['planner'].startswith(prefix);planner=h['planner'][len(prefix):];checker=h['checker']
  assert norm(b['planner'])==norm(planner),(p,h['field'],'planner',b['planner'],planner)
  assert norm(b['checker'])==norm(checker),(p,h['field'],'checker',b['checker'],checker)
  rows.append(dict(file=p.name,field=h['field'],choice=b['choice'],plan=b['plan'],before_policy=b['policy'],after_policy='GovernanceCapabilities (identical readonly record-struct values)',factory=h['factory'],planner_exact=True,check_exact=True,decode_exact=True,encode_exact=True,apply='unchanged ApplyCivicPlan',planner=b['planner'],checker=b['checker']))
assert len(rows)==20,len(rows)
Path('/workspace/review-coverage-33837055/fix2551/definition-proof.json').write_text(json.dumps(rows,indent=2));print('All20 source field/type/decode/encode/policy/planner/check/apply mappings verified')
