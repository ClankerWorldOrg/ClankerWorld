from pathlib import Path
import zipfile,hashlib,json
source=Path('/workspace/review-coverage-33837055/fix2551');dest=Path('/workspace/review-evidence-33837055/.evidence/keep/review-33837055');dest.mkdir(parents=True,exist_ok=True);archive=dest/'pr2780-fix-evidence.zip'
files=sorted(p for p in source.rglob('*') if p.is_file())
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,p.relative_to(source))
sha=hashlib.sha256(archive.read_bytes()).hexdigest();r=json.loads((source/'result.json').read_text())
index=f'''# PR2780 Civic cleanup evidence

Codex session33837055. NEVER merge or open a PR for this evidence branch.

Source PR: https://github.com/ClankerWorldOrg/ClankerWorld/pull/2780
Base `{r['base']}`; head `{r['head']}`. Source+277/-429=152net fewer,56files; tests/docs unchanged. Civic118files8927lines,488 fewer than original9415;1883target still short1395. Refs2551 remains open; no exhaustion claim.

Archive `{archive.name}`: {archive.stat().st_size}bytes, SHA256`{sha}`,{len(files)}files. Raw source copies before/after, final diff/hashes, baseline/head compiled-reference records, all proof tool sources, bound alias receipts, factory/method proofs, build/format/stale logs, native outputs and focused TRX retained. Includes actual test-output dependency DLL/PDB copies separately from native probe project outputs, plus SHA256 manifest.

Checks: locked full dependent Release build0warnings/errors; correct Simulation project format verification and diff/stale searches passed.331/331focused cases,198unique methods,33whole actual classes,349seconds,0skips/failures. Initial328forecast counted only the first offered-choice fact; whole class contributes4cases, so325listed+6=331. Corrected metadata without rerunning or altering any test/assertion.

All68 native initial/committed frames match decompressed checkpoint bytes, ordered events and observation digests. Exact clean base/head source commits recorded in each run.json. Defaults2seeds x generated/legacy x17frames; bounded correctness proof, no performance or full-path claim.

Reference proof: nine requested unused root/helper/cache/facade names absent from head metadata. Baseline local nongeneric MethodDef windows establish root0incoming and sole dead-caller chains; source/reflection review plus complete dependent build supplement this limited scan. Keep live same-named WorldRuntime remedy path and saved plans.736retained methods match after explicitly documented alias/forwarder normalization. Only factory adaptation and definitely initialized stewardship local differ; all20consolidated action type/decode/encode/policy/planner/check/apply mappings verified.175getter/28setter uses and6declarations rewritten with Roslyn bound symbols. Three unused imports independently reported CS8019; source-only diagnostic omits GeneratedRegex implementation and reports that sole known error, while actual full build succeeds.

Full CI still pending at archival: Verify39945121496; actual scope120386272659 read, checkout`04f8ed293ea98e5cf078ab19ec004cdad3678ed2` includes exact head into main`bba9508ca7f19775acbaa54f60906eb6d7069332`. Windows documentation/storage green; Linux/export/installer still running. No coverage or local full suite, no manual gameplay. Final CI and timing receipt will be recorded separately before ready.
'''
(dest/'pr2780-fix-evidence.md').write_text(index);print(json.dumps(dict(bytes=archive.stat().st_size,sha256=sha,files=len(files)),indent=2))
