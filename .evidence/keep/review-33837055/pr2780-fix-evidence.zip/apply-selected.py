from pathlib import Path
import re,json
r=Path('src/ClankerWorld.Simulation/World'); c=r/'Civic'
changes=[]
def edit(p,fn):
 s=p.read_text(); n=fn(s); assert n!=s,p; p.write_text(n); changes.append(str(p))
def cut(s,a,b):
 assert s.count(a)==1 and s.count(b)==1,(a,b)
 i=s.index(a); j=s.index(b,i); return s[:i]+s[j:]
for file,start in [('TownSystem.Government.cs','    internal static GridPoint[] SiteFromToken('),('TownSystem.GovernmentActions.cs','    internal static TownOffice NonLandExtensionOffice(')]:
 edit(c/file,lambda s:s[:s.index(start)]+s[s.rindex('\n}')+1:])
edit(c/'TownSystem.NonLandPhysical.cs',lambda s:cut(s,'    internal bool ApplyNonLandRemedyAction(','    internal void ApplyCheckedNonLandReportRelay('))
edit(c/'TownSystem.TownAbandonment.cs',lambda s:cut(s,'    internal IEnumerable<(TownRuntimeState Town, InventoryLot Lot, int Quantity)> AbandonedStockForPickup(','    internal void AddTownSalvageCandidates(').replace('using ClankerWorld.Simulation.Kernel;\n',''))
edit(c/'TownSystem.LandHearings.Actions.cs',lambda s:re.sub(r'    internal static string LandHearingText\(string\? text\) =>[^\n]*\n[^\n]*\n\n','',s,count=1))
edit(c/'TownSystem.History.cs',lambda s:s.replace('        public TownCouncilState State { get; }\n','').replace('            State = state;\n',''))
edit(c/'WorldRuntime.CivicTownWorld.cs',lambda s:s.replace('        internal static int AvailableLotQuantity(InventoryCheckpoint inventory, InventoryLot lot) => WorldRuntime.AvailableLotQuantity(inventory, lot);\n',''))
aliases=['CouncilElectionCapabilities','LandRightsCapabilities','CivicMembershipCapabilities','TownProjectProposalCapabilities','NonLandAdultCapabilities','LandHearingCapabilities']
body='        new(ActionLifeStages.Adults, AllowBoat: true, AllowUrgentFood: true, AllowUrgentWarmth: false, AllowActiveOrder: true);\n'
assert (c/'TownSystem.GovernmentOfficePlans.cs').read_text().count('    internal static ActorCapabilityPolicy GovernanceCapabilities =>\n'+body)==1
for alias in aliases:
 hits=[]
 for p in r.parent.rglob('*.cs'):
  if '/obj/' in str(p) or '/bin/' in str(p): continue
  s=p.read_text()
  if alias not in s:continue
  declaration='    internal static ActorCapabilityPolicy '+alias+' =>\n'+body
  if declaration in s: hits.append(str(p));s=s.replace(declaration,'')
  s=re.sub(r'\b'+alias+r'\b','GovernanceCapabilities',s)
  p.write_text(s);changes.append(str(p))
 assert len(hits)==1,(alias,hits)
edit(c/'TownSystem.cs',lambda s:re.sub(r'    internal void Record(?:ConstructedMarkets|RemovedMarketBuildings)\([^\n]*\n','',s).replace('    private void RecordMarkets(','    internal void RecordMarkets('))
edit(r/'Markets/WorldRuntime.MarketWorld.cs',lambda s:s.replace('runtime.townSystem.RecordConstructedMarkets(','runtime.townSystem.RecordMarkets(').replace('runtime.townSystem.RecordRemovedMarketBuildings(','runtime.townSystem.RecordMarkets('))
edit(c/'TownSystem.StockActionPlans.cs',lambda s:cut(s,'    internal ActionCheck CheckTownSalvagePlan(ITownWorld world, TownStockActionPlan plan) =>','    internal ActionCheck CheckTownSalvagePlan(ITownWorld world, TownStockActionPlan plan, ActorCapabilityPolicy policy)').replace('CheckTownSalvagePlan(world, plan).Allowed','CheckTownSalvagePlan(world, plan, SalvageCapabilities).Allowed'))
Path('/workspace/review-coverage-33837055/fix2551/selected-files.json').write_text(json.dumps(sorted(set(changes)),indent=2))
