using System.Globalization;
using System.Text.Json;

namespace ClankerWorld.Simulation.World;

internal sealed partial class TownSystem
{
    internal static string LandHearingLawToken(TownLaw law, TownLawVersion version) =>
            TownLandHearingRules.LawRecordId(law.Id, version.Version);

    internal (TownLaw Law, TownLawVersion Version)[] LandHearingApplicableLaws(ITownWorld world, TownRuntimeState town, TownLandCase item)
    {
        if (town.Government is not { } government) return [];
        var revision = TownLandHearingRules.CurrentRevision(item);
        var hasResidentParty = revision.Parties.SelectMany(party => party.AdultIds).Any(id => town.ResidentIds.Contains(id, StringComparer.Ordinal));
        var moments = item.Evidence.Select(evidence => evidence.ObservedTick).Append(world.WorldTick).Distinct();
        return moments.SelectMany(moment => revision.Tiles.SelectMany(tile => TownLawRules.Applicable(government,
                town.Id, townLandTitles, hasResidentParty, tile, moment)))
            .DistinctBy(pair => LandHearingLawToken(pair.Law, pair.Version)).OrderBy(pair => pair.Law.Id, StringComparer.Ordinal)
            .ThenBy(pair => pair.Version.Version).ToArray();
    }

    internal TownLandRecords LandHearingInspectRecords(ITownWorld world, TownRuntimeState town, TownLandRecords hearings,
            string caseId, string actor, TownCouncilState council)
    {
        var item = hearings.Cases.Single(c => c.Id == caseId);
        var revision = TownLandHearingRules.CurrentRevision(item);
        foreach (var (id, version, text) in LandHearingUnreadRecords(world, town, item))
        {
            var current = hearings.Cases.Single(c => c.Id == caseId);
            hearings = TownLandHearingRules.AddEvidence(hearings, caseId, revision.Number,
                new(LandHearingEvidenceId(current, actor, "record", id + version), revision.Number, "record", "record_inspection",
                    actor, id, version, world.WorldTick, actor, world.WorldTick, text), council.Knowledge);
        }
        return TownLandHearingRules.Inspect(hearings, caseId, revision.Number, actor, world.WorldTick);
    }

    internal (string Id, string Version, string Text)[] LandHearingUnreadRecords(ITownWorld world, TownRuntimeState town, TownLandCase item)
    {
        var revision = TownLandHearingRules.CurrentRevision(item);
        var records = householdLandUseRights.Where(right => right.TownId == town.Id && right.Tiles.Any(revision.Tiles.Contains))
            .Select(right => (right.Id, TownLandHearingRules.Version(right),
                LandHearingRightText(right)))
            .Concat(townLandTitles.Where(title => title.TownId == town.Id && title.Tiles.Any(revision.Tiles.Contains))
                .Select(title => (title.Id, TownLandHearingRules.Digest(JsonSerializer.Serialize(title)),
                    LandHearingTitleText(title))))
            .Concat(LandHearingApplicableLaws(world, town, item).Select(pair => (LandHearingLawToken(pair.Law, pair.Version),
                TownLandHearingRules.LawVersion(pair.Version), TownLawRules.Text(pair.Version.Subject, pair.Version.Rule))))
            .Concat(item.Rulings.Select(ruling => (ruling.Id, TownLandHearingRules.Digest(JsonSerializer.Serialize(ruling)),
                LandHearingRulingText(ruling))))
            .Concat(item.Property is { } property ? property.Snapshots.Where(snapshot => snapshot.Revision == revision.Number)
                .Select(snapshot => (TownPropertyRules.RecordId(item, snapshot.Revision), TownLandHearingRules.RecordVersion(snapshot),
                    "Recorded property: " + snapshot.Building.InstanceId + ", owned by " + (property.Request.SourceHouseholdId ?? town.Id) +
                    "; shared goods lots: " + snapshot.SharedLots.Count + "; living former members: " +
                    snapshot.LivingFormerMemberIds.Count + "; adults who would receive it: " + snapshot.RecipientAdultIds.Count + ".")) : []);
        return records.Where(record => !item.Evidence.Any(evidence => evidence.Revision == revision.Number && evidence.Kind == "record" &&
            evidence.SourceRecordId == record.Item1 && evidence.SourceVersion == record.Item2)).ToArray();
    }

    internal static string LandHearingRightText(HouseholdLandUseRight right) =>
            FormattableString.Invariant($"Recorded household {right.HouseholdId} permission for {right.Tiles.Count} tiles; grant {right.GrantSource}; granted {right.GrantedTick}; agreed end {right.AgreedEndTick?.ToString(CultureInfo.InvariantCulture) ?? "none"}.");

    internal static string LandHearingTitleText(TownLandTitleRecord title) =>
            FormattableString.Invariant($"Town {title.TownId} holds formal title to {title.Tiles.Count} recorded tiles from {title.RecordedTick}.");

    internal static string LandHearingRulingText(TownLandRuling ruling) =>
            FormattableString.Invariant($"Recorded ruling {ruling.Id}, hearing {ruling.Revision}, made at {ruling.Tick}: {ruling.Outcome.Kind}.");

    internal static string LandHearingEvidenceId(TownLandCase item, string actor, string kind, string source) =>
            "land-evidence:" + TownLandHearingRules.Digest(item.Id + "|" + TownLandHearingRules.CurrentRevision(item).Number +
                "|" + item.Evidence.Count + "|" + actor + "|" + kind + "|" + source)[..32];

    internal static LandPlotObservation PlanLandPlotObservation(ITownWorld world, TownLandCase item, string actor)
    {
        var revision = TownLandHearingRules.CurrentRevision(item);
        var visible = revision.Tiles.Where(tile => world.IsWithinInteractionRange(world.Agents[actor].Position, tile, WorldRuntime.CivicSharedRules.ResourceInteractionRange)).ToHashSet();
        var buildings = world.WorldSimulation.Buildings.Where(building => visible.Contains(building.Position)).OrderBy(building => building.InstanceId, StringComparer.Ordinal)
            .Select(building => $"{building.DefinitionId} at ({building.Position.X}, {building.Position.Y})");
        var crops = world.Fields.Where(field => visible.Contains(field.Position)).OrderBy(field => field.Position.Y).ThenBy(field => field.Position.X)
            .Select(field => $"field at ({field.Position.X}, {field.Position.Y}), {field.Stage}, crop {field.Crop ?? "none"}");
        var description = "Personally observed nearby plot: " + string.Join("; ", buildings.Concat(crops));
        if (description == "Personally observed nearby plot: ") description += "no building origin or cultivated field on the inspected tiles.";
        if (description.Length > TownLandHearingRules.MaximumTextLength) description = description[..TownLandHearingRules.MaximumTextLength];
        return new(revision.Tiles.Where(visible.Contains).ToArray(), description);
    }

    internal static TownLandRecords LandHearingObserve(ITownWorld world, TownLandRecords hearings, TownLandCase item,
            string actor, TownCouncilState council, LandPlotObservation? observation = null)
    {
        var revision = TownLandHearingRules.CurrentRevision(item);
        observation ??= PlanLandPlotObservation(world, item, actor);
        if (observation.VisibleTiles.Count == 0) throw new InvalidOperationException("A plot observation requires actual physical proximity.");
        var description = observation.Description;
        if (item.Evidence.Any(evidence => evidence.Revision == revision.Number && evidence.Kind == "observation" &&
                evidence.SourceAgentId == actor && evidence.Text == description)) return hearings;
        return TownLandHearingRules.AddEvidence(hearings, item.Id, revision.Number,
            new(LandHearingEvidenceId(item, actor, "observation", description), revision.Number, "observation", "firsthand",
                actor, null, null, world.WorldTick, actor, world.WorldTick, description), council.Knowledge);
    }

}
