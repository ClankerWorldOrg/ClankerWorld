using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ClankerWorld.Simulation.Kernel;

public enum InventoryLotState
{
    Usable,
    Degraded,
    Spoiled,
    Destroyed,
}

public enum InventoryReservationState
{
    Reserved,
    PartiallyConsumed,
    Committed,
    Completed,
    Released,
}

public enum DirectBarterState
{
    Open,
    Settled,
    Cancelled,
}

/// <summary>
/// Immutable inventory identity. A split retains the source lot as provenance;
/// quantities, condition and freshness are never fabricated by a transfer.
/// </summary>
public readonly record struct InventoryGroundPosition(int X, int Y);

public sealed record InventoryLot(
    string Id,
    string ItemKind,
    string OwnerId,
    int Quantity,
    int ConditionBasisPoints,
    int FreshnessBasisPoints,
    long LastProcessedTick,
    string? ProvenanceLotId = null,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] string? StorageBuildingId = null,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] string? DeliveryBuildingId = null,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] string? ContainerLotId = null,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] InventoryGroundPosition? GroundPosition = null,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] string? CarrierId = null,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] InventoryHoldSet? Holds = null);

public sealed record InventoryReservation(
    Identity Id,
    string OwnerId,
    string LotId,
    int Quantity,
    string Purpose,
    long ExpiryTick,
    bool IsExclusive,
    InventoryReservationState State,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] InventoryHoldSet? HoldAccess = null);

public sealed record DirectBarterOffer(
    Identity Id,
    int Revision,
    string FirstPartyId,
    string SecondPartyId,
    string FirstLotId,
    int FirstQuantity,
    string SecondLotId,
    int SecondQuantity,
    long ExpiryTick,
    DirectBarterState State,
    IReadOnlyList<string> AcceptedBy);

public sealed record InventoryStorageChange(string BuildingId, string ItemKind, long QuantityChange);

public sealed record InventoryEvent(long EventId, long WorldTick, string Kind, string Detail)
{
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public IReadOnlyList<InventoryStorageChange>? StorageChanges { get; init; }
}

public sealed record InventoryCheckpoint(
    long WorldTick,
    IReadOnlyList<InventoryLot> Lots,
    IReadOnlyList<InventoryReservation> Reservations,
    IReadOnlyList<DirectBarterOffer> Offers,
    IReadOnlyList<InventoryEvent> Events,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)] long EventHistoryFloor = 0)
{
    [JsonRequired]
    public long ArchivedRepairReservationCount { get; init; }

    public InventoryLot GetLot(string id) => Lots.Single(lot => string.Equals(lot.Id, id, StringComparison.Ordinal));
    public InventoryReservation GetReservation(Identity id) => GetReservation(id.Value);
    public InventoryReservation GetReservation(string id) => Reservations.Single(reservation => string.Equals(reservation.Id, id, StringComparison.Ordinal));
    public DirectBarterOffer GetOffer(string id) => Offers.Single(offer => string.Equals(offer.Id, id, StringComparison.Ordinal));
}

public sealed record DirectBarterProposal(
    Identity Id,
    int Revision,
    string FirstPartyId,
    string SecondPartyId,
    string FirstLotId,
    int FirstQuantity,
    string SecondLotId,
    int SecondQuantity,
    long ExpiryTick);

/// <summary>Current physical containers and provisional playtest capacity limits.</summary>
public static class InventoryContainerRules
{
    public const string Handcart = "handcart";
    public const int HandcartCapacity = 32;
    public const string StoragePot = "storage_pot";
    public const string WaterJug = "water_jug";
    public const string FreshWater = "fresh_water";
    public const int StoragePotCapacity = 8;
    public const int WaterJugCapacity = 4;

    public static bool IsContainer(string itemKind) => itemKind is StoragePot or WaterJug or Handcart;

    public static int Capacity(string itemKind) => itemKind switch
    {
        Handcart => HandcartCapacity,
        StoragePot => StoragePotCapacity,
        WaterJug => WaterJugCapacity,
        _ => throw new InvalidOperationException($"'{itemKind}' is not a container."),
    };

    public static bool Allows(string containerKind, string contentKind) => containerKind switch
    {
        Handcart => !IsContainer(contentKind) && contentKind != FreshWater,
        StoragePot => FoodRules.IsFood(contentKind),
        WaterJug => contentKind == FreshWater,
        _ => false,
    };

    public static bool IsFood(string itemKind) => FoodRules.IsFood(itemKind);
}

/// <summary>
/// Compact authoritative inventory. Every public transition validates
/// before it creates replacement records, so a rejection leaves its supplied
/// checkpoint untouched.
/// </summary>
public static partial class InventoryAuthority
{
    public static InventoryCheckpoint CreateGenesis(IEnumerable<InventoryLot> lots)
    {
        ArgumentNullException.ThrowIfNull(lots);
        var orderedLots = lots.OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
        ValidateLots(orderedLots);
        ValidateContainerGroups(orderedLots);
        var empty = InventoryStore.CreateInventoryCheckpoint(0, [], [], [], []);
        return InventoryStore.CreateInventoryCheckpoint(0, UpdateCustodyHolds(empty, orderedLots), [], [], []);
    }

    public static InventoryCheckpoint SplitLot(
        InventoryCheckpoint checkpoint,
        string lotId,
        int splitQuantity,
        string splitLotId,
        IReadOnlyList<InventoryHold>? holdAccess = null)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(splitLotId);
        var source = checkpoint.GetLot(lotId);
        EnsureHoldAccess(checkpoint, source, holdAccess);
        if (splitQuantity <= 0 || splitQuantity >= source.Quantity ||
            checkpoint.Lots.Any(lot => string.Equals(lot.Id, splitLotId, StringComparison.Ordinal)))
        {
            throw new InvalidOperationException("A lot split requires a unique ID and a strict positive subquantity.");
        }

        EnsureUnreservedQuantity(checkpoint, source, splitQuantity);
        var split = InventoryStore.PrepareLotSplit(source, splitLotId, splitQuantity, source.Id);
        var lots = checkpoint.Lots.Select(lot => string.Equals(lot.Id, source.Id, StringComparison.Ordinal)
                ? InventoryStore.PrepareQuantity(lot, lot.Quantity - splitQuantity)
                : lot)
            .Append(split)
            .OrderBy(lot => lot.Id, StringComparer.Ordinal)
            .ToArray();
        return Commit(checkpoint, lots: lots, eventKind: "lot_split", detail: $"{source.Id}:{splitLotId}:{splitQuantity}");
    }

    /// <summary>
    /// Adds a deterministic produced lot. Production callers must choose the
    /// lot ID and owner before entering this pure transition; no resource is
    /// fabricated by the inventory layer beyond the explicitly requested lot.
    /// </summary>
    public static InventoryCheckpoint AddLot(
        InventoryCheckpoint checkpoint,
        string lotId,
        string itemKind,
        string ownerId,
        int quantity,
        long? targetTick = null,
        int conditionBasisPoints = 10_000,
        int freshnessBasisPoints = 10_000,
        string? storageBuildingId = null,
        string? containerLotId = null,
        InventoryGroundPosition? groundPosition = null,
        IReadOnlyList<InventoryHold>? holdAccess = null)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(lotId);
        ArgumentException.ThrowIfNullOrWhiteSpace(itemKind);
        ArgumentException.ThrowIfNullOrWhiteSpace(ownerId);
        var container = containerLotId is null ? null : checkpoint.GetLot(containerLotId);
        if (container is not null)
        {
            EnsureFamilyHoldAccess(checkpoint, container, holdAccess);
            EnsureUsableContainer(container);
        }
        var nextTick = targetTick ?? checkpoint.WorldTick;
        if (nextTick < checkpoint.WorldTick)
        {
            throw new ArgumentOutOfRangeException(nameof(targetTick));
        }

        if (quantity <= 0 || conditionBasisPoints is < 0 or > 10_000 || freshnessBasisPoints is < 0 or > 10_000 ||
            checkpoint.Lots.Any(lot => lot.Id == lotId))
        {
            throw new InvalidOperationException("A produced lot must have a unique positive ID and valid condition.");
        }

        var lot = InventoryStore.CreateInventoryLot(lotId, itemKind.Trim(), ownerId.Trim(), quantity, conditionBasisPoints, freshnessBasisPoints, nextTick, StorageBuildingId: storageBuildingId, ContainerLotId: containerLotId, GroundPosition: groundPosition, CarrierId: container?.CarrierId);
        ValidateLots([lot]);
        var lots = checkpoint.Lots
            .Append(lot)
            .OrderBy(candidate => candidate.Id, StringComparer.Ordinal)
            .ToArray();
        return Commit(
            checkpoint,
            targetTick,
            lots,
            eventKind: "lot_created",
            detail: $"{lot.Id}:{lot.ItemKind}:{lot.Quantity}");
    }

    public static InventoryCheckpoint ProcessSpoilage(
        InventoryCheckpoint checkpoint,
        long targetTick,
        int freshnessLossPerTick,
        IReadOnlySet<string>? itemKinds = null,
        IReadOnlySet<string>? protectedOwnerIds = null,
        IReadOnlyDictionary<string, int>? itemFreshnessLossPerTick = null)
    {
        ValidateCheckpoint(checkpoint);
        if (targetTick < checkpoint.WorldTick || freshnessLossPerTick < 0 ||
            itemFreshnessLossPerTick?.Values.Any(rate => rate < 0) == true)
        {
            throw new ArgumentOutOfRangeException(nameof(targetTick));
        }

        var pendingEvents = new List<(string Kind, string Detail)>();
        var lots = checkpoint.Lots.Select(lot =>
        {
            var elapsed = targetTick - lot.LastProcessedTick;
            if (elapsed <= 0 || lot.Quantity == 0)
            {
                return lot;
            }

            var rate = itemKinds is not null && !itemKinds.Contains(lot.ItemKind) ? 0
                : itemFreshnessLossPerTick?.GetValueOrDefault(lot.ItemKind, freshnessLossPerTick) ?? freshnessLossPerTick;
            var cadence = 1;
            if (lot.ContainerLotId is { } containerId &&
                checkpoint.Lots.Any(container => container.Id == containerId && container.ItemKind == InventoryContainerRules.StoragePot))
            {
                // Use a stable two-tick cadence so a one-point-per-tick decay
                // rate still decays at half speed instead of truncating to zero.
                cadence = 2;
            }
            if (protectedOwnerIds?.Contains(lot.OwnerId) == true)
            {
                if (rate % 2 == 0) rate /= 2;
                else cadence *= 2;
            }
            var elapsedAtRate = targetTick / cadence - lot.LastProcessedTick / cadence;
            var freshnessLoss = checked(elapsedAtRate * rate);
            var freshness = freshnessLoss >= lot.FreshnessBasisPoints
                ? 0
                : lot.FreshnessBasisPoints - checked((int)freshnessLoss);
            if (lot.FreshnessBasisPoints > 0 && freshness == 0)
            {
                pendingEvents.Add(("lot_spoiled", lot.Id));
            }

            return InventoryStore.PrepareSpoilage(lot, freshness, targetTick);
        }).OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();

        return Commit(checkpoint, targetTick, lots, pendingEvents: pendingEvents);
    }

    public static InventoryCheckpoint Reserve(
        InventoryCheckpoint checkpoint,
        string reservationId,
        string ownerId,
        string lotId,
        int quantity,
        string purpose,
        long expiryTick,
        bool isExclusive = true,
        IReadOnlyList<InventoryHold>? holdAccess = null)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(reservationId);
        ArgumentException.ThrowIfNullOrWhiteSpace(ownerId);
        ArgumentException.ThrowIfNullOrWhiteSpace(purpose);
        if (quantity <= 0 || expiryTick < checkpoint.WorldTick ||
            checkpoint.Reservations.Any(reservation => string.Equals(reservation.Id, reservationId, StringComparison.Ordinal)))
        {
            throw new InvalidOperationException("Reservation ID, quantity, and expiry must be valid.");
        }

        var lot = checkpoint.GetLot(lotId);
        EnsureHoldAccess(checkpoint, lot, holdAccess);
        EnsureContainerUsableForContents(checkpoint, lot);
        if (InventoryContainerRules.IsContainer(lot.ItemKind))
            throw new InvalidOperationException("A reusable vessel cannot be consumed as a production input.");
        EnsureOwnerAndAvailableQuantity(checkpoint, lot, ownerId, quantity);
        var reservation = InventoryStore.CreateInventoryReservation(Identity.ParseStored(reservationId), ownerId, lotId, quantity, purpose, expiryTick, isExclusive, InventoryReservationState.Reserved, CanonicalHoldAccess(InventoryHoldRules.For(InventoryIndex.For(checkpoint), lot).ToArray()));
        return Commit(
            checkpoint,
            reservations: checkpoint.Reservations.Append(reservation).OrderBy(item => item.Id.Value, StringComparer.Ordinal).ToArray(),
            eventKind: "inventory_reserved",
            detail: reservationId);
    }

    public static InventoryCheckpoint ConsumeReservation(
        InventoryCheckpoint checkpoint,
        string reservationId)
    {
        ValidateCheckpoint(checkpoint);
        var reservation = checkpoint.GetReservation(reservationId);
        if (reservation.State is not (InventoryReservationState.Reserved or InventoryReservationState.PartiallyConsumed) ||
            checkpoint.WorldTick > reservation.ExpiryTick)
        {
            throw new InvalidOperationException("Only a live reservation can be consumed.");
        }

        var lot = checkpoint.GetLot(reservation.LotId);
        EnsureHoldAccess(checkpoint, lot, reservation.HoldAccess);
        EnsureContainerUsableForContents(checkpoint, lot);
        EnsureOwnerAndExactQuantity(lot, reservation.OwnerId, reservation.Quantity);
        var lots = lot.Quantity == reservation.Quantity
            ? checkpoint.Lots.Where(candidate => candidate.Id != lot.Id).ToArray()
            : checkpoint.Lots.Select(candidate => candidate.Id == lot.Id
                    ? InventoryStore.PrepareQuantity(candidate, candidate.Quantity - reservation.Quantity)
                    : candidate)
                .OrderBy(candidate => candidate.Id, StringComparer.Ordinal)
                .ToArray();
        var reservations = checkpoint.Reservations.Select(candidate => candidate.Id == reservation.Id
                ? InventoryStore.PrepareReservationState(candidate, InventoryReservationState.Completed)
                : candidate)
            .OrderBy(candidate => candidate.Id.Value, StringComparer.Ordinal)
            .ToArray();
        return Commit(
            checkpoint,
            lots: lots,
            reservations: reservations,
            eventKind: "reservation_consumed",
            detail: reservationId);
    }

    public static InventoryCheckpoint ReleaseReservation(
        InventoryCheckpoint checkpoint,
        string reservationId,
        string purpose = "reservation_released")
    {
        ValidateCheckpoint(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(reservationId);
        var reservation = checkpoint.GetReservation(reservationId);
        if (reservation.State is not (InventoryReservationState.Reserved or InventoryReservationState.PartiallyConsumed or InventoryReservationState.Committed))
        {
            return checkpoint;
        }

        var reservations = checkpoint.Reservations
            .Select(candidate => candidate.Id == reservationId
                ? InventoryStore.PrepareReservationState(candidate, InventoryReservationState.Released)
                : candidate)
            .OrderBy(candidate => candidate.Id.Value, StringComparer.Ordinal)
            .ToArray();
        return Commit(
            checkpoint,
            reservations: reservations,
            eventKind: "reservation_released",
            detail: $"{reservationId}:{purpose}");
    }

    /// <summary>Releases only the requested part of a live claim, retaining protection for its remaining quantity.</summary>
    public static InventoryCheckpoint ReleaseReservationQuantity(
        InventoryCheckpoint checkpoint, string reservationId, int quantity, string purpose)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(reservationId);
        ArgumentException.ThrowIfNullOrWhiteSpace(purpose);
        var reservation = checkpoint.GetReservation(reservationId);
        if (reservation.State is not (InventoryReservationState.Reserved or InventoryReservationState.PartiallyConsumed) ||
            checkpoint.WorldTick > reservation.ExpiryTick || quantity <= 0 || quantity > reservation.Quantity)
            throw new InvalidOperationException("Only a positive quantity from a live reservation can be released.");
        if (quantity == reservation.Quantity)
            return ReleaseReservation(checkpoint, reservationId, $"{purpose}:quantity:{quantity}");
        var reservations = checkpoint.Reservations.Select(candidate => candidate.Id == reservationId
            ? InventoryStore.PrepareReservationQuantity(candidate, candidate.Quantity - quantity)
            : candidate).ToArray();
        return Commit(checkpoint, reservations: reservations, eventKind: "reservation_partly_released",
            detail: $"{reservationId}:{purpose}:quantity:{quantity}");
    }

    public static InventoryCheckpoint Transfer(
        InventoryCheckpoint checkpoint,
        string transferId,
        string senderId,
        string recipientId,
        string lotId,
        int quantity,
        string purpose,
        string? destinationStorageBuildingId = null,
        string? destinationDeliveryBuildingId = null,
        InventoryGroundPosition? destinationGroundPosition = null,
        IReadOnlyList<InventoryHold>? holdAccess = null)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(transferId);
        ArgumentException.ThrowIfNullOrWhiteSpace(senderId);
        ArgumentException.ThrowIfNullOrWhiteSpace(recipientId);
        ArgumentException.ThrowIfNullOrWhiteSpace(purpose);
        if (senderId == recipientId || quantity <= 0 ||
            checkpoint.Lots.Any(lot => string.Equals(lot.Id, DerivedId.Create($"{lotId}#transfer:{transferId}"), StringComparison.Ordinal)))
        {
            throw new InvalidOperationException("A transfer requires distinct parties, a positive quantity, and a unique ID.");
        }

        var source = checkpoint.GetLot(lotId);
        EnsureHoldAccess(checkpoint, source, holdAccess);
        // Physical transfers preserve condition and freshness. Usability is
        // checked by consumption and barter, not by moving owned stock.
        EnsureOwnerAndAvailablePhysicalQuantity(checkpoint, source, senderId, quantity);
        if (source.ContainerLotId is not null)
            throw new InvalidOperationException("Container contents require an explicit physical take before they can move.");

        if (InventoryContainerRules.IsContainer(source.ItemKind))
        {
            if (quantity != 1 || source.Quantity != 1)
                throw new InvalidOperationException("A reusable vessel must move as one indivisible container.");
            var members = checkpoint.Lots.Where(lot => lot.Id == source.Id || lot.ContainerLotId == source.Id).ToArray();
            EnsureFamilyHoldAccess(checkpoint, source, holdAccess);
            EnsureNoActiveReservations(checkpoint, members.Select(lot => lot.Id));
            var moved = members.Select(lot => InventoryStore.PrepareOwnerTransfer(lot, recipientId, null, destinationStorageBuildingId, destinationDeliveryBuildingId, lot.Id == source.Id
                    ? destinationGroundPosition ?? (source.ItemKind == InventoryContainerRules.Handcart ? source.GroundPosition : null)
                    : null))
                .ToDictionary(lot => lot.Id, StringComparer.Ordinal);
            return Commit(
                checkpoint,
                lots: checkpoint.Lots.Select(lot => moved.GetValueOrDefault(lot.Id) ?? lot)
                    .OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray(),
                eventKind: "container_transferred",
                detail: $"{transferId}:{senderId}:{recipientId}:{source.Id}:{purpose}");
        }
        var lots = quantity == source.Quantity
            ? checkpoint.Lots.Select(lot => lot.Id == source.Id
                    ? InventoryStore.PrepareOwnerTransfer(lot, recipientId, null, destinationStorageBuildingId, destinationDeliveryBuildingId, destinationGroundPosition)
                    : lot)
                .OrderBy(lot => lot.Id, StringComparer.Ordinal)
                .ToArray()
            : checkpoint.Lots.Select(lot => lot.Id == source.Id
                    ? InventoryStore.PrepareQuantity(lot, lot.Quantity - quantity)
                    : lot)
                .Append(InventoryStore.PrepareSplitTransfer(source, DerivedId.Create($"{source.Id}#transfer:{transferId}"), recipientId, null, quantity, source.Id, destinationStorageBuildingId, destinationDeliveryBuildingId, destinationGroundPosition))
                .OrderBy(lot => lot.Id, StringComparer.Ordinal)
                .ToArray();
        return Commit(
            checkpoint,
            lots: lots,
            eventKind: "inventory_transferred",
            detail: $"{transferId}:{senderId}:{recipientId}:{lotId}:{quantity}:{purpose}");
    }

    /// <summary>Stores owned goods in a colocated vessel without changing their total quantity.</summary>
    public static InventoryCheckpoint PutIntoContainer(
        InventoryCheckpoint checkpoint,
        string operationId,
        string ownerId,
        string containerLotId,
        string contentLotId,
        int quantity,
        IReadOnlyList<InventoryHold>? holdAccess = null)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(operationId);
        var container = checkpoint.GetLot(containerLotId);
        EnsureFamilyHoldAccess(checkpoint, container, holdAccess);
        var source = checkpoint.GetLot(contentLotId);
        EnsureHoldAccess(checkpoint, source, holdAccess);
        EnsureUsableContainer(container);
        EnsureOwnerAndAvailableQuantity(checkpoint, source, ownerId, quantity);
        EnsureContainerOwnerAndLocation(container, source, ownerId);
        if (source.ContainerLotId is not null || InventoryContainerRules.IsContainer(source.ItemKind) ||
            !InventoryContainerRules.Allows(container.ItemKind, source.ItemKind))
            throw new InvalidOperationException("Only compatible loose contents can be placed into this vessel.");

        var familyIds = checkpoint.Lots.Where(lot => lot.Id == container.Id || lot.ContainerLotId == container.Id)
            .Select(lot => lot.Id).ToArray();
        EnsureNoActiveReservations(checkpoint, familyIds);
        var currentContents = checkpoint.Lots.Where(lot => lot.ContainerLotId == container.Id).Sum(lot => lot.Quantity);
        if (currentContents + quantity > InventoryContainerRules.Capacity(container.ItemKind))
            throw new InvalidOperationException("The container does not have room for that much content.");

        InventoryLot[] lots;
        if (quantity == source.Quantity)
        {
            lots = checkpoint.Lots.Select(lot => lot.Id == source.Id
                    ? InventoryStore.PrepareContainerLocation(lot, container.Id, null)
                    : lot)
                .OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
        }
        else
        {
            var splitId = DerivedId.Create($"{source.Id}#contained:{container.Id}:{operationId}");
            if (checkpoint.Lots.Any(lot => lot.Id == splitId))
                throw new InvalidOperationException("The container placement ID is already in use.");
            lots = checkpoint.Lots.Select(lot => lot.Id == source.Id
                    ? InventoryStore.PrepareQuantity(lot, lot.Quantity - quantity)
                    : lot)
                .Append(InventoryStore.PrepareContainerSplit(source, splitId, quantity, source.Id, container.Id, null))
                .OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
        }

        return Commit(checkpoint, lots: lots, eventKind: "container_contents_stored",
            detail: $"{operationId}:{container.Id}:{source.Id}:{quantity}");
    }

    /// <summary>
    /// Takes a physical quantity out of a vessel. Partial takes create a new
    /// lot ID; the vessel and any remaining contents keep their identities.
    /// </summary>
    public static InventoryCheckpoint TakeFromContainer(
        InventoryCheckpoint checkpoint,
        string operationId,
        string ownerId,
        string recipientId,
        string containerLotId,
        string contentLotId,
        int quantity,
        string? destinationStorageBuildingId = null,
        string? destinationDeliveryBuildingId = null,
        IReadOnlyList<InventoryHold>? holdAccess = null)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(operationId);
        ArgumentException.ThrowIfNullOrWhiteSpace(recipientId);
        var container = checkpoint.GetLot(containerLotId);
        EnsureFamilyHoldAccess(checkpoint, container, holdAccess);
        var source = checkpoint.GetLot(contentLotId);
        EnsureHoldAccess(checkpoint, source, holdAccess);
        EnsureUsableContainer(container);
        if (source.ContainerLotId != container.Id)
            throw new InvalidOperationException("The requested lot is not stored in this vessel.");
        EnsureOwnerAndAvailablePhysicalQuantity(checkpoint, source, ownerId, quantity);
        EnsureContainerOwnerAndLocation(container, source, ownerId);
        EnsureNoActiveReservations(checkpoint,
            checkpoint.Lots.Where(lot => lot.Id == container.Id || lot.ContainerLotId == container.Id).Select(lot => lot.Id));
        if (destinationStorageBuildingId is not null && destinationDeliveryBuildingId is not null)
            throw new InvalidOperationException("A lot cannot be stored and assigned to a delivery at once.");

        // Taken goods stay with whoever carries the vessel unless they go
        // into storage, a delivery or the carrier's own hands.
        var takenCarrier = destinationStorageBuildingId is null && destinationDeliveryBuildingId is null &&
            source.CarrierId != recipientId ? source.CarrierId : null;
        var takenHolds = CanonicalHoldAccess(InventoryHoldRules.For(InventoryIndex.For(checkpoint), source).ToArray());
        InventoryLot[] lots;
        if (quantity == source.Quantity)
        {
            lots = checkpoint.Lots.Select(lot => lot.Id == source.Id
                    ? InventoryStore.PrepareUncontainedTransfer(lot, recipientId, takenCarrier, null, takenHolds, destinationStorageBuildingId, destinationDeliveryBuildingId, null)
                    : lot)
                .OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
        }
        else
        {
            var splitId = DerivedId.Create($"{source.Id}#taken:{operationId}");
            if (checkpoint.Lots.Any(lot => lot.Id == splitId))
                throw new InvalidOperationException("The container take ID is already in use.");
            lots = checkpoint.Lots.Select(lot => lot.Id == source.Id
                    ? InventoryStore.PrepareQuantity(lot, lot.Quantity - quantity)
                    : lot)
                .Append(InventoryStore.PrepareUncontainedSplit(source, splitId, recipientId, takenCarrier, quantity, source.Id, null, takenHolds, destinationStorageBuildingId, destinationDeliveryBuildingId, null))
                .OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
        }

        return Commit(checkpoint, lots: lots, eventKind: "container_contents_taken",
            detail: $"{operationId}:{container.Id}:{source.Id}:{quantity}:{recipientId}");
    }

    /// <summary>Moves physical custody without donating or changing recorded ownership.</summary>
    public static InventoryCheckpoint Relocate(InventoryCheckpoint checkpoint, string moveId,
        string lotId, string ownerId, int quantity, string? carrierId = null,
        string? storageBuildingId = null, InventoryGroundPosition? groundPosition = null,
        IReadOnlyList<InventoryHold>? holdAccess = null)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(moveId);
        var source = checkpoint.GetLot(lotId);
        EnsureHoldAccess(checkpoint, source, holdAccess);
        var movedId = DerivedId.Create($"{lotId}#move:{moveId}");
        // An owner carrying their own goods is recorded without a separate carrier.
        if (carrierId == ownerId && storageBuildingId is null && groundPosition is null) carrierId = null;
        // Whole-lot moves keep the source identity; only a split creates movedId.
        if (source.OwnerId != ownerId || quantity <= 0 || quantity > source.Quantity ||
            quantity < source.Quantity && checkpoint.Lots.Any(lot => lot.Id == movedId))
            throw new InvalidOperationException("The exact owned physical quantity is unavailable.");
        if (source.ContainerLotId is not null)
            throw new InvalidOperationException("Container contents require an explicit physical take before they can move.");
        if (InventoryContainerRules.IsContainer(source.ItemKind))
        {
            // A vessel and its contents move together and keep their owner.
            if (quantity != 1 || source.Quantity != 1)
                throw new InvalidOperationException("A reusable vessel must move as one indivisible container.");
            var members = checkpoint.Lots.Where(lot => lot.Id == source.Id || lot.ContainerLotId == source.Id).ToArray();
            EnsureFamilyHoldAccess(checkpoint, source, holdAccess);
            EnsureNoActiveReservations(checkpoint, members.Select(lot => lot.Id));
            var family = members.Select(lot => InventoryStore.PrepareRelocation(lot, carrierId, storageBuildingId, lot.Id == source.Id ? groundPosition : null, null)).ToDictionary(lot => lot.Id, StringComparer.Ordinal);
            var relocated = checkpoint.Lots.Select(lot => family.GetValueOrDefault(lot.Id) ?? lot)
                .OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
            ValidateLots(relocated);
            return Commit(checkpoint, lots: relocated,
                eventKind: "inventory_relocated", detail: $"{moveId}:{ownerId}:{lotId}:{quantity}");
        }
        EnsureUnreservedQuantity(checkpoint, source, quantity);
        var moved = InventoryStore.PrepareRelocatedSplit(source, quantity == source.Quantity ? source.Id : movedId, quantity, quantity == source.Quantity ? source.ProvenanceLotId : source.Id, carrierId, storageBuildingId, groundPosition, null);
        var lots = checkpoint.Lots.Where(lot => lot.Id != source.Id).Append(moved);
        if (quantity < source.Quantity)
            lots = lots.Append(InventoryStore.PrepareQuantity(source, source.Quantity - quantity));
        var ordered = lots.OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
        ValidateLots(ordered);
        return Commit(checkpoint, lots: ordered,
            eventKind: "inventory_relocated", detail: $"{moveId}:{ownerId}:{lotId}:{quantity}");
    }

    /// <summary>Paused shared work keeps its exact committed inputs instead of losing them at the former worker's deadline.</summary>
    public static InventoryCheckpoint HoldReservations(InventoryCheckpoint checkpoint, IReadOnlyList<Identity> reservationIds) =>
        SetReservationDeadline(checkpoint, reservationIds, long.MaxValue);

    public static InventoryCheckpoint SetReservationDeadline(InventoryCheckpoint checkpoint,
        IReadOnlyList<Identity> reservationIds, long deadline)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(deadline, checkpoint.WorldTick);
        var ids = reservationIds.ToHashSet();
        if (ids.Count != reservationIds.Count || ids.Any(id => checkpoint.Reservations.All(item => item.Id != id ||
            item.State is not (InventoryReservationState.Reserved or InventoryReservationState.PartiallyConsumed))))
            throw new InvalidOperationException("Only existing active work reservations can be held.");
        var reservations = checkpoint.Reservations.Select(item => ids.Contains(item.Id)
            ? InventoryStore.PrepareReservationDeadline(item, deadline) : item).ToArray();
        return Commit(checkpoint, reservations: reservations, eventKind: "work_reservation_deadline_changed", detail: $"{deadline}:{string.Join(',', reservationIds)}");
    }

    /// <summary>Unavailable carriers set down all custody at their last real position; ownership and reservations stay intact.</summary>
    public static InventoryCheckpoint DropCarrierGoods(InventoryCheckpoint checkpoint, string carrierId, InventoryGroundPosition position,
        IReadOnlyList<InventoryHold>? holdAccess = null)
    {
        ValidateCheckpoint(checkpoint);
        foreach (var lot in checkpoint.Lots.Where(item => item.CarrierId == carrierId))
            EnsureHoldAccess(checkpoint, lot, holdAccess);
        ArgumentException.ThrowIfNullOrWhiteSpace(carrierId);
        // A dropped vessel lands on the ground; its contents stay inside it.
        var lots = checkpoint.Lots.Select(lot => lot.CarrierId == carrierId
            ? InventoryStore.PrepareDroppedCargo(lot, null, lot.ContainerLotId is null ? position : null, null, null)
            : lot).ToArray();
        ValidateLots(lots);
        return Commit(checkpoint, lots: lots, eventKind: "carrier_goods_set_down", detail: carrierId);
    }

    public static InventoryCheckpoint ReleaseExpiredReservations(InventoryCheckpoint checkpoint, long targetTick)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentOutOfRangeException.ThrowIfLessThan(targetTick, checkpoint.WorldTick);

        var released = checkpoint.Reservations.Where(reservation =>
            reservation.State is InventoryReservationState.Reserved or InventoryReservationState.PartiallyConsumed && reservation.ExpiryTick < targetTick)
            .Select(reservation => reservation.Id.Value)
            .ToHashSet(StringComparer.Ordinal);
        var reservations = checkpoint.Reservations.Select(reservation => released.Contains(reservation.Id)
                ? InventoryStore.PrepareReservationState(reservation, InventoryReservationState.Released)
                : reservation)
            .OrderBy(reservation => reservation.Id.Value, StringComparer.Ordinal)
            .ToArray();
        var expiredOffers = checkpoint.Offers.Where(offer => offer.State == DirectBarterState.Open && offer.ExpiryTick < targetTick)
            .Select(offer => offer.Id.Value).ToHashSet(StringComparer.Ordinal);
        var offers = checkpoint.Offers.Select(offer => expiredOffers.Contains(offer.Id)
            ? InventoryStore.PrepareBarterState(offer, DirectBarterState.Cancelled) : offer).ToArray();
        var events = released.OrderBy(id => id, StringComparer.Ordinal)
            .Select(id => ("reservation_released", id))
            .Concat(expiredOffers.Order(StringComparer.Ordinal).Select(id => ("barter_expired", id)))
            .ToArray();
        return Commit(checkpoint, targetTick, reservations: reservations, offers: offers, pendingEvents: events);
    }

    public static InventoryCheckpoint CreateDirectBarterOffer(
        InventoryCheckpoint checkpoint,
        DirectBarterProposal proposal,
        IReadOnlyList<InventoryHold>? holdAccess = null)
    {
        ValidateCheckpoint(checkpoint);
        ArgumentNullException.ThrowIfNull(proposal);
        ValidateProposal(proposal, checkpoint.WorldTick);
        if (checkpoint.Offers.Any(offer => string.Equals(offer.Id, proposal.Id, StringComparison.Ordinal)))
        {
            throw new InvalidOperationException("A barter offer ID cannot be reused.");
        }

        var firstLot = checkpoint.GetLot(proposal.FirstLotId);
        var secondLot = checkpoint.GetLot(proposal.SecondLotId);
        EnsureHoldAccess(checkpoint, firstLot, holdAccess);
        EnsureHoldAccess(checkpoint, secondLot, holdAccess);
        if (IsContainerRelated(firstLot) || IsContainerRelated(secondLot))
            throw new InvalidOperationException("Vessels and their contents cannot be traded separately.");
        EnsureOwnerAndAvailableQuantity(checkpoint, firstLot, proposal.FirstPartyId, proposal.FirstQuantity);
        EnsureOwnerAndAvailableQuantity(checkpoint, secondLot, proposal.SecondPartyId, proposal.SecondQuantity);
        var firstReservation = InventoryStore.CreateInventoryReservation(Identity.Parse(DerivedId.Create($"{proposal.Id}:first")), proposal.FirstPartyId, proposal.FirstLotId, proposal.FirstQuantity, $"barter:{proposal.Id}", proposal.ExpiryTick, true, InventoryReservationState.Reserved, CanonicalHoldAccess(InventoryHoldRules.For(InventoryIndex.For(checkpoint), firstLot).ToArray()));
        var secondReservation = InventoryStore.CreateInventoryReservation(Identity.Parse(DerivedId.Create($"{proposal.Id}:second")), proposal.SecondPartyId, proposal.SecondLotId, proposal.SecondQuantity, $"barter:{proposal.Id}", proposal.ExpiryTick, true, InventoryReservationState.Reserved, CanonicalHoldAccess(InventoryHoldRules.For(InventoryIndex.For(checkpoint), secondLot).ToArray()));
        if (checkpoint.Reservations.Any(reservation =>
            string.Equals(reservation.Id, firstReservation.Id, StringComparison.Ordinal) ||
            string.Equals(reservation.Id, secondReservation.Id, StringComparison.Ordinal)))
        {
            throw new InvalidOperationException("The barter offer reservation IDs are already in use.");
        }

        var offer = InventoryStore.CreateDirectBarterOffer(proposal.Id, proposal.Revision, proposal.FirstPartyId, proposal.SecondPartyId, proposal.FirstLotId, proposal.FirstQuantity, proposal.SecondLotId, proposal.SecondQuantity, proposal.ExpiryTick, DirectBarterState.Open, []);
        return Commit(
            checkpoint,
            reservations: checkpoint.Reservations.Append(firstReservation).Append(secondReservation)
                .OrderBy(reservation => reservation.Id.Value, StringComparer.Ordinal).ToArray(),
            offers: checkpoint.Offers.Append(offer).OrderBy(candidate => candidate.Id.Value, StringComparer.Ordinal).ToArray(),
            eventKind: "barter_offered",
            detail: $"{proposal.Id}:r{proposal.Revision}");
    }

    public static InventoryCheckpoint AcceptDirectBarterOffer(
        InventoryCheckpoint checkpoint,
        string offerId,
        int revision,
        string partyId)
    {
        ValidateCheckpoint(checkpoint);
        var offer = checkpoint.GetOffer(offerId);
        if (offer.State != DirectBarterState.Open || checkpoint.WorldTick > offer.ExpiryTick || offer.Revision != revision ||
            (partyId != offer.FirstPartyId && partyId != offer.SecondPartyId))
        {
            throw new InvalidOperationException("Only an open offer's exact revision may be accepted by a party.");
        }

        if (offer.AcceptedBy.Contains(partyId, StringComparer.Ordinal))
        {
            return checkpoint;
        }

        var acceptedBy = offer.AcceptedBy.Append(partyId).OrderBy(id => id, StringComparer.Ordinal).ToArray();
        var acceptedOffer = InventoryStore.PrepareBarterAcceptance(offer, acceptedBy);
        var offers = checkpoint.Offers.Select(candidate => string.Equals(candidate.Id, offer.Id, StringComparison.Ordinal)
                ? acceptedOffer
                : candidate)
            .OrderBy(candidate => candidate.Id.Value, StringComparer.Ordinal)
            .ToArray();
        var accepted = Commit(checkpoint, offers: offers, eventKind: "barter_accepted", detail: $"{offer.Id}:{partyId}:r{revision}");
        return acceptedBy.Length == 2 ? Settle(accepted, acceptedOffer) : accepted;
    }

    public static InventoryCheckpoint CancelDirectBarterOffer(
        InventoryCheckpoint checkpoint,
        string offerId,
        int revision,
        string partyId)
    {
        ValidateCheckpoint(checkpoint);
        var offer = checkpoint.GetOffer(offerId);
        if (offer.State != DirectBarterState.Open || offer.Revision != revision ||
            (partyId != offer.FirstPartyId && partyId != offer.SecondPartyId))
        {
            throw new InvalidOperationException("Only a party to the exact open offer may decline or withdraw it.");
        }
        var reservations = checkpoint.Reservations.Select(reservation =>
            reservation.Id == DerivedId.Create(offer.Id + ":first") || reservation.Id == DerivedId.Create(offer.Id + ":second")
                ? InventoryStore.PrepareReservationState(reservation, InventoryReservationState.Released)
                : reservation).ToArray();
        return Commit(checkpoint, reservations: reservations,
            offers: checkpoint.Offers.Select(item => item.Id == offer.Id
                ? InventoryStore.PrepareBarterState(item, DirectBarterState.Cancelled) : item).ToArray(),
            eventKind: "barter_declined", detail: offer.Id + ":" + partyId);
    }

    private static InventoryCheckpoint Settle(InventoryCheckpoint checkpoint, DirectBarterOffer offer)
    {
        var firstReservation = checkpoint.GetReservation(DerivedId.Create($"{offer.Id}:first"));
        var secondReservation = checkpoint.GetReservation(DerivedId.Create($"{offer.Id}:second"));
        if (firstReservation.State != InventoryReservationState.Reserved ||
            secondReservation.State != InventoryReservationState.Reserved ||
            checkpoint.WorldTick > offer.ExpiryTick)
        {
            throw new InvalidOperationException("The barter offer no longer has two valid reservations.");
        }

        var firstLot = checkpoint.GetLot(offer.FirstLotId);
        var secondLot = checkpoint.GetLot(offer.SecondLotId);
        EnsureHoldAccess(checkpoint, firstLot, firstReservation.HoldAccess);
        EnsureHoldAccess(checkpoint, secondLot, secondReservation.HoldAccess);
        EnsureOwnerAndExactQuantity(firstLot, offer.FirstPartyId, offer.FirstQuantity);
        EnsureOwnerAndExactQuantity(secondLot, offer.SecondPartyId, offer.SecondQuantity);
        var afterFirstTransfer = TransferExact(checkpoint.Lots, firstLot, offer.FirstQuantity, offer.SecondPartyId, offer.Id);
        var afterBothTransfers = TransferExact(afterFirstTransfer, secondLot, offer.SecondQuantity, offer.FirstPartyId, offer.Id);
        var reservations = checkpoint.Reservations.Select(reservation =>
            reservation.Id == firstReservation.Id || reservation.Id == secondReservation.Id
                ? InventoryStore.PrepareReservationState(reservation, InventoryReservationState.Completed)
                : reservation).OrderBy(reservation => reservation.Id.Value, StringComparer.Ordinal).ToArray();
        var offers = checkpoint.Offers.Select(candidate => candidate.Id == offer.Id
                ? InventoryStore.PrepareBarterState(candidate, DirectBarterState.Settled)
                : candidate).OrderBy(candidate => candidate.Id.Value, StringComparer.Ordinal).ToArray();
        return Commit(checkpoint, lots: afterBothTransfers, reservations: reservations, offers: offers,
            eventKind: "barter_settled", detail: $"{offer.Id}:r{offer.Revision}");
    }

    private static InventoryLot[] TransferExact(
        IReadOnlyList<InventoryLot> lots,
        InventoryLot source,
        int quantity,
        string recipientId,
        string offerId)
    {
        if (IsContainerRelated(source))
            throw new InvalidOperationException("Vessels and their contents cannot be settled through a lot-only trade.");
        if (source.Quantity == quantity)
        {
            return lots.Select(lot => lot.Id == source.Id
                    ? InventoryStore.PrepareContainerTransfer(lot, recipientId, null, null, null) : lot)
                .OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
        }

        var transferId = DerivedId.Create($"{source.Id}#barter:{offerId}");
        if (lots.Any(lot => lot.Id == transferId))
        {
            throw new InvalidOperationException("The barter transfer lot ID is already in use.");
        }

        var transferred = InventoryStore.PrepareExactTransferSplit(source, transferId, recipientId, null, quantity, source.Id, null, null);
        return lots.Select(lot => lot.Id == source.Id ? InventoryStore.PrepareQuantity(lot, lot.Quantity - quantity) : lot)
            .Append(transferred).OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
    }

    private static void EnsureOwnerAndAvailableQuantity(
        InventoryCheckpoint checkpoint,
        InventoryLot lot,
        string expectedOwnerId,
        int requestedQuantity)
    {
        EnsureOwnerAndExactQuantity(lot, expectedOwnerId, requestedQuantity);
        EnsureUnreservedQuantity(checkpoint, lot, requestedQuantity);
    }

    private static void EnsureOwnerAndAvailablePhysicalQuantity(
        InventoryCheckpoint checkpoint,
        InventoryLot lot,
        string expectedOwnerId,
        int requestedQuantity)
    {
        if (!InventoryRules.HasOwnedPhysicalQuantity(lot, expectedOwnerId, requestedQuantity))
            throw new InvalidOperationException("The exact owned physical lot quantity is unavailable.");
        EnsureUnreservedQuantity(checkpoint, lot, requestedQuantity);
    }

    private static void EnsureUnreservedQuantity(InventoryCheckpoint checkpoint, InventoryLot lot, int requestedQuantity)
    {
        if (!InventoryRules.HasUnreservedQuantity(InventoryIndex.For(checkpoint), lot, requestedQuantity))
        {
            throw new InvalidOperationException("An active reservation already consumes the requested lot quantity.");
        }
    }

    private static void EnsureOwnerAndExactQuantity(
        InventoryLot lot,
        string expectedOwnerId,
        int requestedQuantity)
    {
        if (!InventoryRules.HasOwnedUsableQuantity(lot, expectedOwnerId, requestedQuantity))
        {
            throw new InvalidOperationException("The exact owned usable lot quantity is unavailable.");
        }
    }

    private static void EnsureContainerUsableForContents(InventoryCheckpoint checkpoint, InventoryLot lot)
    {
        if (lot.ContainerLotId is { } containerId)
            EnsureUsableContainer(checkpoint.GetLot(containerId));
    }

    private static void EnsureUsableContainer(InventoryLot container)
    {
        if (!InventoryRules.IsUsableContainer(container))
            throw new InvalidOperationException("A broken or invalid vessel cannot hold, serve, or supply contents.");
    }

    private static InventoryCheckpoint Commit(InventoryCheckpoint checkpoint, long? targetTick = null, IReadOnlyList<InventoryLot>? lots = null, IReadOnlyList<InventoryReservation>? reservations = null, IReadOnlyList<DirectBarterOffer>? offers = null, string? eventKind = null, string? detail = null, IEnumerable<(string Kind, string Detail)>? pendingEvents = null) => InventoryStore.CommitAuthorityTransition(checkpoint, targetTick, lots, reservations, offers, eventKind, detail, pendingEvents);

    private static void ValidateCheckpoint(InventoryCheckpoint checkpoint) => InventoryStore.ValidateSnapshot(checkpoint);

    internal static void ValidateCheckpointForCodec(InventoryCheckpoint checkpoint) => InventoryStore.ValidateSnapshotForCodec(checkpoint);

    private static bool IsContainerRelated(InventoryLot lot) => InventoryStore.IsContainerRelated(lot);

    private static void EnsureContainerOwnerAndLocation(InventoryLot container, InventoryLot content, string ownerId)
    {
        if (!InventoryRules.SharesContainerOwnerAndLocation(container, content, ownerId))
            throw new InvalidOperationException("The vessel and contents must share an owner and physical location.");
    }

    private static void EnsureNoActiveReservations(InventoryCheckpoint checkpoint, IEnumerable<string> lotIds)
    {
        if (!InventoryRules.AreUnreserved(InventoryIndex.For(checkpoint), lotIds))
            throw new InvalidOperationException("A vessel or its contents are reserved and cannot be moved.");
    }

    private static void ValidateContainerGroups(IReadOnlyList<InventoryLot> lots) => InventoryStore.ValidateContainerGroups(lots);

    private static void ValidateLots(IReadOnlyList<InventoryLot> lots) => InventoryStore.ValidateLots(lots);

    private static void EnsureCanonicalIds(IEnumerable<string?> ids, string collectionName) => InventoryStore.EnsureCanonicalIds(ids, collectionName);

    private static void ValidateProposal(DirectBarterProposal proposal, long worldTick)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(proposal.Id);
        ArgumentException.ThrowIfNullOrWhiteSpace(proposal.FirstPartyId);
        ArgumentException.ThrowIfNullOrWhiteSpace(proposal.SecondPartyId);
        if (proposal.Revision < 0 || proposal.FirstPartyId == proposal.SecondPartyId || proposal.FirstQuantity <= 0 ||
            proposal.SecondQuantity <= 0 || proposal.ExpiryTick < worldTick)
        {
            throw new ArgumentOutOfRangeException(nameof(proposal));
        }
    }
}

public static class InventoryCheckpointCodec
{
    private const string LegacyHeader = "clankerworld.inventory-fixture/v1";
    private const string Header = "clankerworld.inventory-fixture/v2";
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false,
        Converters = { new StoredIdentityJsonConverter() },
    };

    private sealed record InventoryCheckpointDocument(
        long WorldTick,
        InventoryLot[] Lots,
        InventoryReservation[] Reservations,
        DirectBarterOffer[] Offers,
        InventoryEvent[] Events,
        [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)] long EventHistoryFloor = 0)
    {
        [JsonRequired] public long ArchivedRepairReservationCount { get; init; }
    }

    public static byte[] Encode(InventoryCheckpoint checkpoint)
    {
        ArgumentNullException.ThrowIfNull(checkpoint);
        InventoryAuthority.ValidateCheckpointForCodec(checkpoint);
        var document = new InventoryCheckpointDocument(
            checkpoint.WorldTick,
            checkpoint.Lots.OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            checkpoint.Reservations.OrderBy(item => (string?)item.Id, StringComparer.Ordinal).ToArray(),
            checkpoint.Offers
                .OrderBy(item => (string?)item.Id, StringComparer.Ordinal)
                .Select(item => InventoryStore.PrepareBarterAcceptance(item, item.AcceptedBy.OrderBy(id => id, StringComparer.Ordinal).ToArray()))
                .ToArray(),
            checkpoint.Events.OrderBy(item => item.EventId).ToArray(), checkpoint.EventHistoryFloor)
        { ArchivedRepairReservationCount = checkpoint.ArchivedRepairReservationCount };
        return Encoding.UTF8.GetBytes($"{Header}\n{JsonSerializer.Serialize(document, JsonOptions)}");
    }

    public static InventoryCheckpoint Decode(byte[] bytes)
    {
        ArgumentNullException.ThrowIfNull(bytes);
        var text = Encoding.UTF8.GetString(bytes);
        var separator = text.IndexOf('\n');
        if (separator < 0)
        {
            throw new InvalidDataException("The inventory checkpoint format is not supported.");
        }

        var header = text[..separator];
        if (header == LegacyHeader)
        {
            try { return DecodeLegacyV1(text.Split('\n', StringSplitOptions.RemoveEmptyEntries)); }
            catch (ArgumentException exception) { throw new InvalidDataException("The saved inventory identity is invalid.", exception); }
        }

        if (header != Header)
        {
            throw new InvalidDataException("The inventory checkpoint format is not supported.");
        }

        InventoryCheckpointDocument? document;
        try
        {
            document = JsonSerializer.Deserialize<InventoryCheckpointDocument>(text[(separator + 1)..], JsonOptions);
        }
        catch (JsonException exception)
        {
            throw new InvalidDataException("The inventory checkpoint JSON is invalid.", exception);
        }

        if (document is null || document.Lots is null || document.Reservations is null ||
            document.Offers is null || document.Events is null)
        {
            throw new InvalidDataException("The inventory checkpoint JSON is incomplete.");
        }

        var checkpoint = InventoryStore.CreateInventoryCheckpoint(document.WorldTick, document.Lots.OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(), document.Reservations.OrderBy(item => (string?)item.Id, StringComparer.Ordinal).ToArray(), document.Offers
                .OrderBy(item => (string?)item.Id, StringComparer.Ordinal)
                .Select(item => InventoryStore.PrepareBarterAcceptance(item, item.AcceptedBy.OrderBy(id => id, StringComparer.Ordinal).ToArray()))
                .ToArray(), document.Events.OrderBy(item => item.EventId).ToArray(), document.EventHistoryFloor, document.ArchivedRepairReservationCount);
        InventoryAuthority.ValidateCheckpointForCodec(checkpoint);
        _ = InventoryDigest.State(checkpoint);
        return checkpoint;
    }

    private static InventoryCheckpoint DecodeLegacyV1(string[] lines)
    {
        if (lines.Length < 2)
        {
            throw new InvalidDataException("The inventory checkpoint format is not supported.");
        }

        var checkpoint = InventoryStore.CreateInventoryCheckpoint(ParseLong(ValueAfterPrefix(lines[1], "tick=")), lines.Skip(2).Where(line => line.StartsWith("lot=", StringComparison.Ordinal)).Select(ParseLot).OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray(), lines.Skip(2).Where(line => line.StartsWith("reservation=", StringComparison.Ordinal)).Select(ParseReservation).OrderBy(item => (string?)item.Id, StringComparer.Ordinal).ToArray(), lines.Skip(2).Where(line => line.StartsWith("offer=", StringComparison.Ordinal)).Select(ParseOffer).OrderBy(item => (string?)item.Id, StringComparer.Ordinal).ToArray(), lines.Skip(2).Where(line => line.StartsWith("event=", StringComparison.Ordinal)).Select(ParseEvent).OrderBy(item => item.EventId).ToArray());
        _ = InventoryDigest.State(checkpoint);
        return checkpoint;
    }

    private static InventoryLot ParseLot(string line)
    {
        var parts = ValueAfterPrefix(line, "lot=").Split('|');
        if (parts.Length != 8) throw new InvalidDataException("The saved lot is invalid.");
        return InventoryStore.CreateInventoryLot(parts[0], parts[1], parts[2], ParseInt(parts[3]), ParseInt(parts[4]), ParseInt(parts[5]), ParseLong(parts[6]), parts[7] == "-" ? null : parts[7]);
    }

    private static InventoryReservation ParseReservation(string line)
    {
        var parts = ValueAfterPrefix(line, "reservation=").Split('|');
        if (parts.Length != 8 || !Enum.TryParse<InventoryReservationState>(parts[7], out var state)) throw new InvalidDataException("The saved reservation is invalid.");
        return InventoryStore.CreateInventoryReservation(Identity.ParseStored(parts[0]), parts[1], parts[2], ParseInt(parts[3]), parts[4], ParseLong(parts[5]), parts[6] == "exclusive", state);
    }

    private static DirectBarterOffer ParseOffer(string line)
    {
        var parts = ValueAfterPrefix(line, "offer=").Split('|');
        if (parts.Length != 11 || !Enum.TryParse<DirectBarterState>(parts[9], out var state)) throw new InvalidDataException("The saved barter offer is invalid.");
        var accepted = string.IsNullOrEmpty(parts[10]) ? [] : parts[10].Split(',', StringSplitOptions.RemoveEmptyEntries).OrderBy(id => id, StringComparer.Ordinal).ToArray();
        return InventoryStore.CreateDirectBarterOffer(Identity.ParseStored(parts[0]), ParseInt(parts[1]), parts[2], parts[3], parts[4], ParseInt(parts[5]), parts[6], ParseInt(parts[7]), ParseLong(parts[8]), state, accepted);
    }

    private static InventoryEvent ParseEvent(string line)
    {
        var parts = ValueAfterPrefix(line, "event=").Split('|');
        if (parts.Length != 4) throw new InvalidDataException("The saved inventory event is invalid.");
        return InventoryStore.CreateInventoryEvent(ParseLong(parts[0]), ParseLong(parts[1]), parts[2], parts[3]);
    }

    private static string ValueAfterPrefix(string line, string prefix) => line.StartsWith(prefix, StringComparison.Ordinal) ? line[prefix.Length..] : throw new InvalidDataException("The inventory checkpoint line is invalid.");
    private static int ParseInt(string value) => int.TryParse(value, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out var result) ? result : throw new InvalidDataException("The saved inventory integer is invalid.");
    private static long ParseLong(string value) => long.TryParse(value, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out var result) ? result : throw new InvalidDataException("The saved inventory long is invalid.");
}

public static class InventoryDigest
{
    public static string State(InventoryCheckpoint checkpoint)
    {
        var canonical = Encoding.UTF8.GetString(InventoryCheckpointCodec.Encode(InventoryStore.PrepareEventWindow(checkpoint, [])));
        return Digest(canonical);
    }

    public static string Events(IEnumerable<InventoryEvent> events) => Digest(string.Join('\n', events.OrderBy(item => item.EventId)
        .Select(item => $"{item.EventId}|{item.WorldTick}|{item.Kind}|{item.Detail}" +
            (item.StorageChanges is { } changes ? "|" + JsonSerializer.Serialize(changes) : string.Empty))));

    private static string Digest(string canonical) => Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(canonical)));
}
