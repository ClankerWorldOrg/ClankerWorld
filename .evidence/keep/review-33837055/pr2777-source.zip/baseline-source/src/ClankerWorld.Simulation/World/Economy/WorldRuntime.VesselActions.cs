
namespace ClankerWorld.Simulation.World;

public sealed partial class WorldRuntime
{
    private void ApplyCheckedVesselPlan(VesselActionPlan plan)
    {
        var state = agents[plan.Actor];
        var kind = plan.Choice.Kind;
        var movement = kind switch
        {
            VesselActionKind.CollectJug => "collect_water_jug",
            VesselActionKind.FillJug => "fill_water_jug",
            VesselActionKind.ReturnJug => "return_water_jug",
            VesselActionKind.StoreFood => "store_food_in_pot",
            VesselActionKind.TakeFood => "take_food_from_pot",
            _ => "return_empty_vessel",
        };
        if (state.Position != plan.Target) { MoveToward(plan.Actor, state, plan.Target, movement, 0); return; }
        switch (kind)
        {
            case VesselActionKind.CollectJug:
                RunInventoryCommand(InventorySystem.CollectWaterJug(InventoryEconomyWorld, plan));
                AppendEvent(new WaterJugCollectedEventPayload(plan.Actor, plan.VesselId));
                break;
            case VesselActionKind.FillJug:
                RunInventoryCommand(InventorySystem.FillCarriedWaterJug(InventoryEconomyWorld, plan));
                AppendEvent(new WaterJugFilledEventPayload(plan.Actor, plan.VesselId, plan.Quantity, plan.Target.X, plan.Target.Y));
                break;
            case VesselActionKind.ReturnJug:
                RunInventoryCommand(InventorySystem.ReturnFilledWaterJug(InventoryEconomyWorld, plan));
                AppendEvent(new WaterJugReturnedEventPayload(plan.Actor, plan.VesselId, plan.HouseId));
                break;
            case VesselActionKind.ReturnEmpty:
                RunInventoryCommand(InventorySystem.CollectEmptyVessel(InventoryEconomyWorld, plan));
                AppendEvent(new EmptyVesselPickedUpEventPayload(plan.Actor, plan.VesselId, plan.SourceBuildingId!, plan.HouseId));
                break;
            case VesselActionKind.TakeFood:
                RunInventoryCommand(InventorySystem.TakeFoodFromPot(InventoryEconomyWorld, plan));
                AppendEvent(new FoodTakenFromPotEventPayload(plan.Actor, plan.VesselId, plan.Food!.StockId, plan.Quantity));
                break;
            case VesselActionKind.StoreFood:
                StorePlannedPotFood(plan);
                break;
        }
    }

    private void StorePlannedPotFood(VesselActionPlan plan)
    {
        var food = plan.Food!;
        var operationId = FoodPotTransferId(WorldTick, plan.Actor);
        RunInventoryCommand(InventorySystem.StorePlannedPotFood(food, plan, operationId));
        AppendEvent(new FoodStoredInPotEventPayload(plan.Actor, plan.VesselId, food.StockId, plan.Quantity));
    }
}
