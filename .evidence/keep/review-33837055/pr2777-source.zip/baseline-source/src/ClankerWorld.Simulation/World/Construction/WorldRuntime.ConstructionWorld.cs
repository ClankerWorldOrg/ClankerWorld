using System.Collections.ObjectModel;
using ClankerWorld.Simulation.Content;
using ClankerWorld.Simulation.Kernel;
using ClankerWorld.Simulation.Society;

namespace ClankerWorld.Simulation.World;

public sealed partial class WorldRuntime
{
    private IConstructionPlanningWorld ConstructionWorld => new ConstructionWorldAdapter(this);
    private IConstructionPlacementWorld ConstructionPlacementWorld => new ConstructionWorldAdapter(this);
    private IExpansionAdmissionWorld ExpansionAdmissionWorld => new ConstructionWorldAdapter(this);
    private IExpansionCompletionWorld ExpansionCompletionWorld => new ConstructionWorldAdapter(this);
    private IExpansionPlanningWorld ExpansionPlanningWorld => new ConstructionWorldAdapter(this);

    private sealed class ConstructionWorldAdapter(WorldRuntime runtime) : IConstructionPlacementWorld, IExpansionAdmissionWorld, IExpansionCompletionWorld, IExpansionPlanningWorld
    {
        public SocietyCheckpoint Society => runtime.society.Checkpoint;
        public int ResourceInteractionRange => WorldRuntime.ResourceInteractionRange;
        public DeclarativeWorldContentState Content => runtime.worldContent;
        public IReadOnlyDictionary<string, AgentState> Agents => runtime.agents;
        public long WorldTick => runtime.WorldTick;
        public long NextProductionJobSequence => runtime.productionSystem.State.NextSequence;
        public InventoryCheckpoint Inventory => runtime.society.Checkpoint.Inventory;
        public int StoredQuantity(string building) => runtime.StoredQuantity(building);
        public HouseResidentCapacityRules.Capacity? HouseResidentCapacity(string household) => runtime.HouseResidentCapacity(household);
        public int AnimalYardCapacity(PlacedBuilding building) => runtime.AnimalYardCapacity(building);
        public (GridPoint Position, BuildingFootprintRevision Footprint) ExpansionShapeForOrder(PlacedBuilding building, OwnerQueuedInstruction? instruction) =>
            OrderSystem.ExpansionShapeForOrder(runtime.ExpansionOrdersWorld, building, instruction);
        public ExpansionMaterialStep? PlanExpansionMaterialStep(string actor, PlacedBuilding building, IReadOnlyList<ContentQuantity> costs) =>
            runtime.PlanExpansionMaterialStep(actor, building, costs);
        public ActionCheck CheckExpansionMaterialStep(ExpansionActionPlan plan, PlacedBuilding building) => runtime.CheckExpansionMaterialStep(plan, building);
        public IEnumerable<InventoryLot> ExpansionMaterialLots(string actor, PlacedBuilding building) => runtime.ExpansionMaterialLots(actor, building);
        public int AvailableLotQuantity(InventoryLot lot) => runtime.AvailableLotQuantity(lot);
        public bool CanFitExpansion(PlacedBuilding building, GridPoint position, BuildingFootprintRevision footprint, out string failure) =>
            runtime.CanFitExpansion(building, position, footprint, out failure);
        public bool IsAdult(string actor) => runtime.IsAdult(actor);
        public OwnerQueuedInstruction? PendingInstructionFor(string actor) => runtime.PendingInstructionFor(actor);
        public PlacedBuilding? ExpansionOrderBuilding(OwnerQueuedInstruction instruction) => OrderSystem.ExpansionOrderBuilding(runtime.ExpansionOrdersWorld, instruction);
        public bool MayExpandBuilding(string actor, PlacedBuilding building, out string failure) => runtime.MayExpandBuilding(actor, building, out failure);
        public ExpansionActionPlan? PlanExpansion(string actor, PlacedBuilding building, OwnerQueuedInstruction? instruction) => runtime.PlanExpansion(actor, building, instruction);
        public ActionCheck CheckExpansion(ExpansionActionPlan plan) => runtime.CheckExpansion(plan);
        public bool HasExpansionMaterials(string actor, PlacedBuilding building, IReadOnlyList<ContentQuantity> costs) => runtime.HasExpansionMaterials(actor, building, costs);
        public ExpansionMaterialInput[]? PlanExpansionInputs(string actor, PlacedBuilding building, IReadOnlyList<ContentQuantity> costs) => runtime.PlanExpansionInputs(actor, building, costs);
        public int SkilledBuildingWorkTicks(string actor, int ticks) => runtime.SkilledWorkTicks(actor, SkillKind.Building, ticks);
        public string ExpansionJobId(long sequence) => WorldRuntime.ExpansionJobId(sequence);
        public IReadOnlyList<Identity> ReserveExpansionInputs(IReadOnlyList<ExpansionMaterialInput> inputs, string actor, string id, long expiry)
        {
            IReadOnlyList<string> ids = [];
            runtime.RunInventoryCommand(InventorySystem.ReserveExpansionInputs(InventoryConstructionWorld, inputs, actor, id, expiry, ids, inventoryResultValue => ids = inventoryResultValue));
            return ids.Select(Identity.Parse).ToArray();
        }
        public void AdvanceExpansionSequence() => runtime.productionSystem.AdvanceExpansionSequence();
        public void BindStartedExpansionOrder(OwnerQueuedInstruction instruction, BuildingExpansionJob job) => OrderSystem.BindStartedExpansionOrder(runtime.ExpansionOrdersWorld, instruction, job);
        public bool CanFitExpansion(PlacedBuilding building, GridPoint position, BuildingFootprintRevision footprint, out string failure, string jobId) =>
            runtime.CanFitExpansion(building, position, footprint, out failure, jobId);
        public void CompleteExpansionInputs(IReadOnlyList<Identity> ids) => ResolveExpansionInputs(ids, completed: true);
        public void CancelExpansionInputs(IReadOnlyList<Identity> ids) => ResolveExpansionInputs(ids, completed: false);
        private void ResolveExpansionInputs(IReadOnlyList<Identity> ids, bool completed) => runtime.RunInventoryCommand(InventorySystem.ResolveExpansionInputs(ids, completed));
        public void RecordExpandedWork(PlacedBuilding building, BuildingExpansionJob job)
        {
            if (runtime.towns.SingleOrDefault(town => town.Id == building.TownId) is { } town)
                runtime.SetTown(town with { BorderTiles = TownBorderRules.Expand(runtime.map, town, ExpansionTiles(job)) });
            runtime.CreditCompletedWork(job.WorkerId, "building");
        }
        public void CreditExpansionOrderJob(BuildingExpansionJob job) => OrderSystem.CreditExpansionOrderJob(runtime.ExpansionOrdersWorld, job);
        public IReadOnlyList<TownRuntimeState> Towns => runtime.towns;
        public string NormalizeRequiredText(string? value, string name) => WorldRuntime.NormalizeRequiredText(value, name);
        public bool CanPlaceBuilding(BuildingDefinition definition, GridPoint position, out string failure, out GridPoint? entrance, bool mayFaceRoad) =>
            runtime.CanPlaceBuilding(definition, position, out failure, out entrance, mayFaceRoad: mayFaceRoad);
        public void ConsumeConstructionInputs(IReadOnlyList<ConstructionMaterialInput> inputs, string purpose, string owner) =>
            runtime.RunInventoryCommand(InventorySystem.ConsumeConstructionInputs(InventoryConstructionWorld, inputs, purpose, owner));
        public void AssignBuildingToTown(PlacedBuilding building, BuildingDefinition definition) => runtime.AssignBuildingToTown(building, definition);
        public void AppendEvent(WorldEventPayload payload, GridPoint? position = null) => runtime.AppendEvent(payload, position);
        public ActorCapabilityState? CapabilitiesFor(string actor) => runtime.CapabilitiesFor(actor);
        public string HouseholdFor(string actor) => runtime.HouseholdFor(actor);
        public string? TownForResident(string actor) => runtime.TownForResident(actor);
        public OwnerQueuedInstruction? ConstructionInstructionForProject(string actor, AgentProject? project) => OrderSystem.ConstructionInstructionForProject(runtime.ConstructionOrdersWorld, actor, project);
        public string BuildingConstructionOwner(string actor, BuildingDefinition definition) => runtime.BuildingConstructionOwner(actor, definition);
        public string BuildInstanceId(string actor, BuildingDefinition definition) => runtime.BuildInstanceId(actor, definition);
        public bool IsHouseholdBuilding(BuildingDefinition definition) => definition.Tags.Any(IsHouseholdBuildingTag);
        public string? HouseholdBuildingKind(BuildingDefinition definition) => WorldRuntime.HouseholdBuildingKind(definition);
        public PlacedBuilding? HouseholdBuildingWithTag(string household, string tag) => runtime.HouseholdBuildingWithTag(household, tag);
        public PlacedBuilding? FarmhouseForHousehold(string household) => runtime.FarmhouseForHousehold(household);
        public bool HouseholdBuildingProjectInProgress(string household, string kind, string actor) => runtime.HouseholdBuildingProjectInProgress(household, kind, actor);
        public bool WorkBuildingHasInputs(string actor, string household, BuildingDefinition definition) => runtime.WorkBuildingHasInputs(actor, household, definition);
        public bool BuildingIdentityIsReserved(string instance, string? instruction) => OrderSystem.BuildingIdentityIsReserved(runtime.ConstructionOrdersWorld, instance, instruction);
        public TownLayoutContext CreateTownLayoutContext(string actor, GridPoint site, BuildingDefinition definition) => runtime.CreateTownLayoutContext(actor, site, definition);
        public IEnumerable<GoodsMatch> ConstructionGoods(InventoryCheckpoint inventory, GoodsRequest request) => runtime.ProductionGoods(inventory, request);
        public ReadOnlyCollection<GridPoint> Reach(string actor, GridPoint target, ReachPurpose purpose, int range, int load, SwimmingPolicy swimming) =>
            runtime.Reach(actor, target, purpose, range, load, swimming);
    }
}
