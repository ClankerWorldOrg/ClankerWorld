using DeliveryOrderPlan = ClankerWorld.Simulation.World.OrderSystem.DeliveryOrderPlan;
using ClankerWorld.Simulation.Cognition;
using ClankerWorld.Simulation.Kernel;

namespace ClankerWorld.Simulation.World;

public sealed partial class WorldRuntime
{
    private const int WarehouseLoadQuantity = 4;
    private static readonly HashSet<string> WarehouseResourceKinds =
        new(StringComparer.Ordinal) { "wood", "stone", "fiber", "tree_seed" };

    private PlacedBuilding? WarehouseForResident(string actor)
    {
        var townId = TownForResident(actor);
        return townId is null ? null : WarehousesForTown(townId).FirstOrDefault();
    }

    private IEnumerable<PlacedBuilding> WarehousesForTown(string townId)
    {
        var definitions = worldContent.Buildings.Where(definition =>
                definition.Tags.Contains("warehouse", StringComparer.Ordinal))
            .Select(definition => definition.CanonicalId).ToHashSet(StringComparer.Ordinal);
        return worldSimulation.Buildings.Where(building => building.TownId == townId &&
                definitions.Contains(building.DefinitionId))
            .OrderBy(building => building.InstanceId, StringComparer.Ordinal);
    }

    private IEnumerable<PlacedBuilding> WarehousesAccessibleTo(string actor)
    {
        if (!agents.ContainsKey(actor)) yield break;
        var residentTownId = TownForResident(actor);
        foreach (var town in towns.Where(item => item.Id == residentTownId || item.IsAbandoned)
                     .OrderBy(item => item.Id == residentTownId ? 0 : 1)
                     .ThenBy(item => item.Id, StringComparer.Ordinal))
            foreach (var warehouse in WarehousesForTown(town.Id))
                yield return warehouse;
    }

    private (PlacedBuilding Warehouse, GoodsMatch Source)? WarehouseMaterialSource(string actor, string itemKind,
        GridPoint destination, int destinationRange)
    {
        foreach (var warehouse in WarehousesAccessibleTo(actor).Where(warehouse => MayCollectWarehouseStock(actor, warehouse)))
            foreach (var match in WarehouseGoods(actor, warehouse, itemKind, GoodsUse.ReachableHoldings))
                if (PickupCarryCapacity(actor, match.Lot, destination, destinationRange) > 0)
                    return (warehouse, match);
        return null;
    }

    private bool MayCollectWarehouseStock(string actor, PlacedBuilding warehouse) =>
        agents.ContainsKey(actor) && warehouse.TownId is { } townId &&
        towns.SingleOrDefault(item => item.Id == townId) is { } town &&
        (TownForResident(actor) == townId || town.IsAbandoned) &&
        WarehousesForTown(townId).Any(item => item.InstanceId == warehouse.InstanceId);

    private IEnumerable<InventoryLot> AvailableWarehouseStock(string actor, string? itemKind = null) =>
        WarehouseStockGoods(actor, itemKind, GoodsUse.ReachableHoldings).Select(match => match.Lot);

    /// <summary>Town Warehouse stock the actor may collect, before checking for a route to it.</summary>
    private IEnumerable<InventoryLot> WarehouseStockLots(string actor, string? itemKind = null) =>
        WarehouseStockGoods(actor, itemKind, GoodsUse.Holdings).Select(match => match.Lot);

    private IEnumerable<GoodsMatch> WarehouseStockGoods(string actor, string? itemKind, GoodsUse use) =>
        WarehousesAccessibleTo(actor).Where(warehouse => MayCollectWarehouseStock(actor, warehouse))
            .SelectMany(warehouse => WarehouseGoods(actor, warehouse, itemKind, use));

    private IEnumerable<GoodsMatch> WarehouseGoods(string actor, PlacedBuilding warehouse, string? itemKind, GoodsUse use)
    {
        var kinds = itemKind is not null ? GoodsKinds.One(itemKind) : new GoodsKinds(
            InventoryIndex.For(society.Checkpoint.Inventory).StoredAt(warehouse.InstanceId)
                .Select(lot => lot.ItemKind).Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToArray());
        if (kinds.Ids.Count == 0) return [];
        return FindGoods(new GoodsRequest(use, actor, GoodsOwners.One(warehouse.TownId!), kinds,
                AtBuilding: warehouse.InstanceId)).Matches
            .Where(match => match.Lot.ContainerLotId is null);
    }

    private IEnumerable<InventoryLot> PersonalWarehouseLots(string actor, string? itemKind = null) =>
        SpendingGoods(actor, GoodsUse.Spend, [actor], itemKind).Select(match => match.Lot)
            .Where(lot => PersonalEquipmentRules.IsCarried(lot, actor) && WarehouseResourceKinds.Contains(lot.ItemKind))
            .OrderBy(lot => lot.Id, StringComparer.Ordinal);

    private long PersonalWarehouseAvailableQuantity(string actor, string itemKind) =>
        PersonalWarehouseLots(actor, itemKind).Sum(lot => (long)AvailableLotQuantity(lot));

    private (InventoryLot Lot, int Quantity)? PersonalWarehouseSurplus(string actor, string? itemKind = null,
        string? sourceLotId = null)
    {
        var lots = PersonalWarehouseLots(actor, itemKind).ToArray();
        // Keep four usable units of each kind, regardless of how storage or collection split them.
        // A bound source limits the transfer, not which carried lots can satisfy the personal reserve.
        var spareByKind = lots.GroupBy(lot => lot.ItemKind, StringComparer.Ordinal)
            .ToDictionary(group => group.Key, group => Math.Max(0L, group.Sum(lot => (long)AvailableLotQuantity(lot)) - WarehouseLoadQuantity),
                StringComparer.Ordinal);
        foreach (var lot in lots)
        {
            if (sourceLotId is not null && lot.Id != sourceLotId) continue;
            var quantity = (int)Math.Min(AvailableLotQuantity(lot), spareByKind[lot.ItemKind]);
            if (quantity > 0) return (lot, quantity);
        }
        return null;
    }

    private void AddWarehouseStockCandidate(List<CognitionCandidate> candidates, string actor, AgentState state)
    {
        var choice = new TownStockRequest(TownStockActionKind.StoreSurplus, TownStockRequest.WarehouseCandidate);
        if (WarehouseStockDefinition.Offer(this, actor, choice) is not { } plan) return;
        candidates.Add(new CognitionCandidate(WarehouseStockDefinition.Encode(choice),
            $"Carry spare {plan.ItemKind} to the Town Warehouse as communal stock for residents.",
            32, plan.WarehouseId)
        { ActionPlan = plan });
    }

    private DeliveryOrderPlan? GetTownOrderPlan(string actor, AgentState person,
        OrderTask order, int maximumQuantity)
    {
        if (!IsAdult(actor) || TownForResident(actor) is not { } townId ||
            WarehousesForTown(townId).FirstOrDefault(building => DeliveryDestinationMatches(order, building)) is not { } warehouse ||
            PersonalWarehouseSurplus(actor, order.TargetItemKind, order.DeliveryLotId) is not { } surplus)
            return null;
        var quantity = Math.Min(maximumQuantity, Math.Min(DestinationRoom(warehouse.InstanceId),
            Math.Min(WarehouseLoadQuantity, surplus.Quantity)));
        return quantity <= 0 ? null : new DeliveryOrderPlan("town_surplus", warehouse, townId,
            surplus.Lot, surplus.Lot, quantity, quantity, DirectDelivery: true);
    }
}
