using System.Text.Json.Serialization;
using ClankerWorld.Simulation.Content;
using ClankerWorld.Simulation.Kernel;

namespace ClankerWorld.Simulation.World;

public sealed record PersonalEquipment(string? ClothingLotId = null, string? CarryAidLotId = null,
    EquipmentRepairWork? Repair = null, string? OrnamentLotId = null);

public sealed record EquipmentRepairWork(string LotId, string BuildingId, long StartedTick,
    int WorkDone, IReadOnlyList<Identity> MaterialReservationIds,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] string? OrderInstructionId = null);

/// <summary>Provisional protection and capacity from real, singly equipped inventory units.</summary>
public static class PersonalEquipmentRules
{
    public const int BaseCapacity = 8;
    public const int BasketCapacity = 16;
    public const int SackCapacity = 24;
    public const int RepairWorkTicks = 8;

    public static bool IsGarment(string kind) => kind is "clothing" or "padded_coat" or "rain_cloak";
    public static bool IsCarryAid(string kind) => kind is "basket" or "sack" or "leather_sack";
    public static bool IsOrnament(string kind) => kind is "gold_ornament" or "diamond_ornament";
    public static bool IsSelected(PersonalEquipment? equipment, string lotId) => equipment is not null &&
        (equipment.ClothingLotId == lotId || equipment.CarryAidLotId == lotId ||
         equipment.OrnamentLotId == lotId || equipment.Repair?.LotId == lotId);
    public static bool IsCarried(InventoryLot lot, string actor) =>
        (lot.CarrierId == actor || lot.CarrierId is null && lot.OwnerId == actor) &&
        lot.StorageBuildingId is null && lot.GroundPosition is null && lot.ContainerLotId is null;

    public static bool IsPhysicallyCarried(InventoryCheckpoint inventory, InventoryLot lot, string actor)
    {
        ArgumentNullException.ThrowIfNull(inventory);
        ArgumentNullException.ThrowIfNull(lot);
        // Borrowed goods count for whoever carries them; vessel contents go
        // with their vessel.
        if (lot.ContainerLotId is not { } containerId)
            return IsCarried(lot, actor);
        var container = inventory.Lots.FirstOrDefault(candidate => candidate.Id == containerId);
        return container is not null && container.ContainerLotId is null && IsCarried(container, actor);
    }

    public static InventoryLot? EquippedUnit(InventoryCheckpoint inventory, string actor, string? id) =>
        id is null ? null : inventory.Lots.FirstOrDefault(lot => lot.Id == id && lot.Quantity == 1 &&
            lot.OwnerId == actor && IsCarried(lot, actor) && lot.DeliveryBuildingId is null);

    public static int Capacity(InventoryCheckpoint inventory, string actor, PersonalEquipment? equipment)
    {
        var aid = EquippedUnit(inventory, actor, equipment?.CarryAidLotId);
        return aid is null || Math.Max(0, InventoryRules.AvailableQuantity(InventoryIndex.For(inventory), aid)) == 0 ? BaseCapacity : aid.ItemKind switch
        {
            "basket" => BasketCapacity,
            "sack" => SackCapacity,
            "leather_sack" => 32,
            _ => BaseCapacity,
        };
    }

    public static int CarriedQuantity(InventoryCheckpoint inventory, string actor, PersonalEquipment? equipment)
    {
        // Delivery loads and vessel contents remain physical cargo. Flat lots
        // count each unit once; there is no recursive container multiplier.
        var clothing = EquippedUnit(inventory, actor, equipment?.ClothingLotId);
        var aid = EquippedUnit(inventory, actor, equipment?.CarryAidLotId);
        var lotsById = inventory.Lots.ToDictionary(lot => lot.Id, StringComparer.Ordinal);
        return inventory.Lots.Where(lot => IsPhysicallyCarried(lotsById, lot, actor)).Sum(lot => lot.Quantity) -
            (clothing is null ? 0 : 1) - (aid is null || aid.Id == clothing?.Id ? 0 : 1);
    }

    private static bool IsPhysicallyCarried(Dictionary<string, InventoryLot> lotsById,
        InventoryLot lot, string actor)
    {
        if (lot.ContainerLotId is not { } containerId)
            return IsCarried(lot, actor);
        return lotsById.TryGetValue(containerId, out var container) &&
            container.ContainerLotId is null && IsCarried(container, actor);
    }

    public static int FreeCapacity(InventoryCheckpoint inventory, string actor, PersonalEquipment? equipment) =>
        Math.Max(0, Capacity(inventory, actor, equipment) - CarriedQuantity(inventory, actor, equipment));

    public static int Protection(InventoryLot garment, WeatherKind weather)
    {
        var wet = weather is WeatherKind.Rain or WeatherKind.Storm;
        var full = garment.ItemKind switch
        {
            "padded_coat" => wet ? 10 : 55,
            "rain_cloak" => wet ? 55 : 15,
            "clothing" => wet ? 10 : 35,
            _ => 0,
        };
        return full * garment.ConditionBasisPoints / 10_000;
    }

    public static IReadOnlyList<ContentQuantity> RepairMaterials(string kind) => kind switch
    {
        "basket" => [new("fiber", 1), new("rope", 1)],
        "leather_sack" => [new("leather", 1)],
        "clothing" or "padded_coat" or "rain_cloak" or "sack" => [new("cloth", 1)],
        _ => [],
    };
}
