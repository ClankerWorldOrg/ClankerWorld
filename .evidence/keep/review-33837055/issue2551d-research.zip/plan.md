Codex session 33837055; issue2551; independent main835f9db1; branchcodex/2551-civic-rules-33837055; claim6377757599 at00:50UTC.

1. Recheck competing claims, all open file maps, topic duplicates. Reserve every pending member/path as needed. Previous offer-helper audit remains valid; investigate other rules/plumbing.
2. Establish coherent >=150 net removal without weaker checks, changed snapshots/publication, saved fields or authority. Baseline locked Release and source/reference inventory before edits.
3. Push meaningful source/draft within one hour. Full dependent Release; exact focused method/class/TRX reconciliation; native clean68; source/compiled proof; full format/verify; stale/diff.
4. Complete exact-head CI including actual checkout/installer/finalgate/all10timings; Ready and release Refs claim. Stop watching handed-over branch.

Finished draft2795 CI takes priority on failure or completion. No source edits/build product writes in its worktree while tests/format/native active. All16earlierReady stopped.
