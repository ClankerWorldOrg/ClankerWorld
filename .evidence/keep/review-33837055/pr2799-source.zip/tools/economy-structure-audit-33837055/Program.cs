using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
using System.Text.RegularExpressions;
var root=args[0];var output=args[1];var raw=File.ReadAllText(output+"/compiler-inputs.json");var input=JsonDocument.Parse(raw[raw.IndexOf('{')..]).RootElement;
var files=input.GetProperty("Items").GetProperty("Compile").EnumerateArray().Select(e=>e.GetProperty("FullPath").GetString()!).Concat(Directory.GetFiles(root+"/src/ClankerWorld.Simulation/obj/Release/net10.0","*.cs")).Concat(Directory.GetFiles(output+"/generated-baseline","*.cs",SearchOption.AllDirectories)).Distinct().ToArray();
var options=new CSharpParseOptions(LanguageVersion.CSharp14,preprocessorSymbols:input.GetProperty("Properties").GetProperty("DefineConstants").GetString()!.Split(';',StringSplitOptions.RemoveEmptyEntries));var trees=files.Select(f=>CSharpSyntaxTree.ParseText(File.ReadAllText(f),options,path:f)).ToArray();
var refs=input.GetProperty("Items").GetProperty("ReferencePath").EnumerateArray().Select(e=>MetadataReference.CreateFromFile(e.GetProperty("FullPath").GetString()!));var comp=CSharpCompilation.Create("ClankerWorld.Simulation",trees,refs,new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,nullableContextOptions:NullableContextOptions.Enable,allowUnsafe:true));var diagnostics=comp.GetDiagnostics();var errors=diagnostics.Where(d=>d.Severity==DiagnosticSeverity.Error).Select(d=>d.ToString()).ToArray();File.WriteAllText(output+"/semantic-errors.json",JsonSerializer.Serialize(errors,new JsonSerializerOptions{WriteIndented=true}));if(errors.Length>0)throw new Exception(string.Join('\n',errors.Take(12)));
bool Scoped(string file)=>file.Contains("/src/ClankerWorld.Simulation/World/Economy/");
var held=JsonSerializer.Deserialize<string[]>(File.ReadAllText(output+"/held-patch-identifiers.json"))!.ToHashSet();var entries=new List<Entry>();
foreach(var tree in trees.Where(t=>Scoped(t.FilePath)))
{
 var model=comp.GetSemanticModel(tree);
 foreach(var method in tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>())if(model.GetDeclaredSymbol(method) is IMethodSymbol symbol&&method.AttributeLists.Count==0&&!symbol.IsOverride&&!symbol.IsVirtual&&!symbol.IsAbstract&&symbol.ExplicitInterfaceImplementations.Length==0&&(method.Body is not null||method.ExpressionBody is not null))
 {
  var interfaceRoot=symbol.ContainingType.AllInterfaces.SelectMany(i=>i.GetMembers()).OfType<IMethodSymbol>().Any(m=>SymbolEqualityComparer.Default.Equals(symbol,symbol.ContainingType.FindImplementationForInterfaceMember(m)));
  if(interfaceRoot)continue;entries.Add(new(symbol,method,tree.FilePath,held.Contains(symbol.Name)));
 }
}
var index=new Dictionary<ISymbol,Entry>(SymbolEqualityComparer.Default);foreach(var entry in entries)index.Add(entry.Symbol.OriginalDefinition,entry);
foreach(var tree in trees){var model=comp.GetSemanticModel(tree);foreach(var name in tree.GetRoot().DescendantNodes().OfType<SimpleNameSyntax>())if(model.GetSymbolInfo(name).Symbol is IMethodSymbol method&&index.TryGetValue((method.ReducedFrom??method).OriginalDefinition,out var entry))entry.Incoming.Add(new{file=tree.FilePath,line=name.GetLocation().GetLineSpan().StartLinePosition.Line+1,from=name.Ancestors().OfType<MethodDeclarationSyntax>().FirstOrDefault()?.Identifier.ValueText});}
var external=Directory.GetFiles(root,"*",SearchOption.AllDirectories).Where(f=>!f.Contains("/.git/")&&!f.Contains("/.godot/")&&!f.Contains("/obj/")&&!f.Contains("/bin/")&&!f.Contains("/src/ClankerWorld.Simulation/")&&new[]{".cs",".js",".sh",".py",".ps1",".json",".tscn",".gd"}.Contains(Path.GetExtension(f))).Select(f=>(File:f,Text:File.ReadAllText(f))).ToArray();
var rows=new List<object>();foreach(var entry in entries.Where(e=>e.Incoming.Count==0))
{
 var name=entry.Symbol.Name;var regex=new Regex(@"\b"+Regex.Escape(name)+@"\b");var outside=external.Where(t=>regex.IsMatch(t.Text)).Select(t=>Path.GetRelativePath(root,t.File)).ToArray();rows.Add(new{name,owner=entry.Symbol.ContainingType.ToDisplayString(),file=Path.GetRelativePath(root,entry.File),lines=entry.Node.ToFullString().Count(c=>c=='\n'),source=entry.Node.ToFullString(),held=entry.Held,outside,selected=!entry.Held&&outside.Length==0});
}
var unused=diagnostics.Where(d=>d.Id=="CS8019"&&Scoped(d.Location.SourceTree?.FilePath??"")).Select(d=>new{file=Path.GetRelativePath(root,d.Location.SourceTree!.FilePath),source=d.Location.SourceTree.GetText().ToString(d.Location.SourceSpan)}).ToArray();
File.WriteAllText(output+"/unused-methods.json",JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));File.WriteAllText(output+"/unused-imports.json",JsonSerializer.Serialize(unused,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{files=files.Length,errors=0,audited=entries.Count,unreferenced=rows.Count,unusedImports=unused.Length}));
record Entry(IMethodSymbol Symbol,MethodDeclarationSyntax Node,string File,bool Held){public List<object> Incoming{get;}=[];}
