from pathlib import Path
import subprocess,os,time,json,sys
p=Path('/workspace/review-coverage-33837055/fix2552d');root=Path('/workspace/fix-2552d-33837055');env=os.environ.copy();env['PATH']='/workspace/.tools/dotnet:'+env['PATH'];env['DOTNET_PROCESSOR_COUNT']='4';env['ClankerWorld__Clock__StrictTickFailures']='true'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head==(p/'validation-head.txt').read_text().strip();rows=[]
steps=[
 ('native-equivalence',['bash','scripts/compare-tick-equivalence.sh','/workspace/base-2553b-835-33837055',str(root),str(p/'native')]),
 ('pin-native-binaries',['python3','-c',"from pathlib import Path;import shutil;p=Path('/workspace/review-coverage-33837055/fix2552d/native-binaries');p.mkdir(exist_ok=True);r=Path('/workspace/fix-2552d-33837055/src/ClankerWorld.Simulation/bin/Release/net10.0');[shutil.copy2(r/('ClankerWorld.Simulation.'+x),p/('ClankerWorld.Simulation.'+x)) for x in ['dll','pdb']]"]),
 ('full-build',['dotnet','build','tests/ClankerWorld.Tests/ClankerWorld.Tests.csproj','-c','Release','--no-restore','-nr:false','-maxcpucount:1']),
 ('focused-tests',['dotnet','test','tests/ClankerWorld.Tests/ClankerWorld.Tests.csproj','-c','Release','--no-build','--no-restore','--filter',(p/'focused-filter.txt').read_text(),'--logger','trx;LogFileName=focused.trx','--results-directory',str(p/'results')]),
 ('reconcile-tests',['python3',str(p/'reconcile-tests.py')]),
 ('compiled-inventory',['dotnet','run','--project','/workspace/economy-layout-api-proof-33837055/LayoutApi.csproj','--',str(root),str(p)]),
 ('native-test-binaries',['python3','-c',"from pathlib import Path;p=Path('/workspace/review-coverage-33837055/fix2552d/native-binaries');r=Path('/workspace/fix-2552d-33837055/tests/ClankerWorld.Tests/bin/Release/net10.0');assert all((p/('ClankerWorld.Simulation.'+x)).read_bytes()==(r/('ClankerWorld.Simulation.'+x)).read_bytes() for x in ['dll','pdb']);print('native DLL/PDB exactly equal to full-build actual test copies')"])
]
for name,args in steps:
 start=time.monotonic()
 with open(p/(name+'.log'),'w') as log:result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'head':head,'name':name,'command':args,'exit':result.returncode,'seconds':time.monotonic()-start})
 (p/'final-check-receipts.json').write_text(json.dumps({'pid':os.getpid(),'head':head,'status':'failed' if result.returncode else 'running','steps':rows},indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if result.returncode:sys.exit(result.returncode)
(p/'final-check-receipts.json').write_text(json.dumps({'pid':os.getpid(),'head':head,'status':'passed','steps':rows},indent=2)+'\n')
