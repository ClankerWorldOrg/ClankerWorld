# Economy partial consolidation

- [x] Main/rules, queue, claims, topics and all17openfilemaps checked.
- [x] Baseline Release, actual-input reference/import/structure audit.
- [x] Exact dry run:34partials->8features,174net,all methods/state/comments/bindings preserved,no budget/doc changes,zero file overlap.
- [x] Apply verified37source files.
- [ ] Full root format/verify running before commit; no other product writes.
- [ ] Compare formatted tokens/comments with preview; commit/push/draft within first hour.
- [ ] Clean native comparison, full dependent Release, existing focused92methods/TRX, compiled inventory unchanged/native-test copies equal.
- [ ] Exact-head CI, personally read actual checkout/all10timings/installer/final gate, archive proof, finalize description and Ready.
- [ ] Release Refs claim with area totals; recount and continue.
