import itertools

checked = 0
for same in (False, True):
    for length in range(7):
        for states in itertools.product(range(6), repeat=length):
            records = [(('other', 'own', 'dep')[s // 2], bool(s % 2)) for s in states]
            required = 'own' if same else 'dep'
            before = any(p == 'own' for p, active in records) or not any(
                p == required and active for p, active in records)
            dependency = False
            for package_id, active in records:
                if package_id == 'own':
                    after = True
                    break
                if package_id == required and active:
                    dependency = True
            else:
                after = not dependency
            assert after == before, (same, records)
            checked += 1
assert checked == 111974
print(checked, 'guard snapshots equivalent; algebra extends to arbitrary finite snapshots')
