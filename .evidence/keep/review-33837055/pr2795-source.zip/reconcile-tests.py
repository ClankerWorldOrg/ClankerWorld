from pathlib import Path
import json,xml.etree.ElementTree as ET,collections
p=Path('/workspace/review-coverage-33837055/fix2556');scope=json.loads((p/'focused-scope.json').read_text());expected={m['Full'] for m in scope['methods']}
root=ET.parse(p/'results/focused.trx').getroot();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
methods={}
for test in root.findall('.//t:UnitTest',ns):
 method=test.find('t:TestMethod',ns)
 methods[test.attrib['id']]=method.attrib['className']+'.'+method.attrib['name']
results=root.findall('.//t:UnitTestResult',ns);actual={methods[r.attrib['testId']] for r in results};outcomes=collections.Counter(r.attrib['outcome'] for r in results)
assert actual==expected,{'missing':sorted(expected-actual),'unexpected':sorted(actual-expected)}
assert outcomes=={'Passed':len(results)} and len(results)>=len(expected),outcomes
counters=root.find('.//t:Counters',ns).attrib
assert int(counters['passed'])==len(results)==int(counters['total']) and int(counters.get('failed','0'))==0,counters
report={'cases':len(results),'methods':len(actual),'classes':len({m['Class'] for m in scope['methods']}),'wholeClasses':len(scope['wholeClasses']),'partialClasses':scope['partialClasses'],'outcomes':dict(outcomes),'counters':counters,'missing':[],'unexpected':[],'plannedMethods':sorted(expected),'executedMethods':sorted(actual)}
(p/'focused-reconciliation.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['plannedMethods','executedMethods','counters']}))
