using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=args[0];var output=args[1];var expected=JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(output+"/core-expected-sources.json"))!;var before=JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(output+"/baseline-sources.json"))!;
var changed=new List<string>();var methodChanges=new List<object>();var fields=0;var retainedMethods=0;
foreach(var(relative,baseline)in before)
{
 var file=Path.Combine(root,relative);var actual=File.ReadAllText(file);if(!expected.TryGetValue(file,out var planned))throw new Exception("missing expected "+file);if(Tokens(actual)!=Tokens(planned))throw new Exception("unplanned source tokens "+file);if(actual!=baseline)changed.Add(relative);
 var b=CSharpSyntaxTree.ParseText(baseline).GetRoot();var a=CSharpSyntaxTree.ParseText(actual).GetRoot();
 var bf=b.DescendantNodes().Where(n=>n is FieldDeclarationSyntax or PropertyDeclarationSyntax or EventDeclarationSyntax or EnumDeclarationSyntax or ConstructorDeclarationSyntax or OperatorDeclarationSyntax or ConversionOperatorDeclarationSyntax).Select(n=>Tokens(n.ToString())).ToArray();
 var af=a.DescendantNodes().Where(n=>n is FieldDeclarationSyntax or PropertyDeclarationSyntax or EventDeclarationSyntax or EnumDeclarationSyntax or ConstructorDeclarationSyntax or OperatorDeclarationSyntax or ConversionOperatorDeclarationSyntax).Select(n=>Tokens(n.ToString())).ToArray();if(!bf.SequenceEqual(af))throw new Exception("state/constructor/operator shape changed "+file);fields+=bf.Length;
 var bm=b.DescendantNodes().OfType<MethodDeclarationSyntax>().ToDictionary(Key);var am=a.DescendantNodes().OfType<MethodDeclarationSyntax>().ToDictionary(Key);
 foreach(var k in bm.Keys.Intersect(am.Keys)){if(Tokens(bm[k].ToString())==Tokens(am[k].ToString()))retainedMethods++;else methodChanges.Add(new{file=relative,method=k});}
}
if(methodChanges.Count!=2)throw new Exception("unexpected retained method changes "+JsonSerializer.Serialize(methodChanges));
foreach(var f in Directory.GetFiles(root+"/src/ClankerWorld.Simulation","*.cs",SearchOption.AllDirectories).Where(f=>!f.Contains("/bin/")&&!f.Contains("/obj/")))if(!before.ContainsKey(Path.GetRelativePath(root,f)))throw new Exception("unplanned new source file "+f);
var report=new{files=before.Count,changedFiles=changed,exactExpectedTokens=true,stateConstructorOperatorDeclarationsUnchanged=fields,retainedMethodDefinitionsExactlyEqual=retainedMethods,changedRetainedMethods=methodChanges,testCSharpEdits=0,thirdPartyEdits=changed.Where(f=>f.Contains("/ThirdParty/")).ToArray()};File.WriteAllText(output+"/source-proof.json",JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{files=before.Count,changedFiles=changed.Count,stateConstructorOperatorDeclarationsUnchanged=fields,retainedMethodDefinitionsExactlyEqual=retainedMethods,changedRetainedMethods=methodChanges}));
static string Key(MethodDeclarationSyntax m)=>string.Join("+",m.Ancestors().OfType<TypeDeclarationSyntax>().Reverse().Select(n=>n.Identifier.ValueText+n.TypeParameterList))+"."+m.ExplicitInterfaceSpecifier+"|"+m.Identifier.ValueText+"|"+m.TypeParameterList+"|"+string.Join(";",m.ParameterList.DescendantTokens().Select(t=>t.RawKind+":"+t.Text));
static string Tokens(string s)=>string.Join("\n",CSharpSyntaxTree.ParseText(s).GetRoot().DescendantTokens(descendIntoTrivia:true).Select(t=>t.RawKind+":"+t.Text));
