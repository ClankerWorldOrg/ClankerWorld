using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);
var files=Directory.GetFiles(root+"/src/ClankerWorld.Simulation","*.cs",SearchOption.AllDirectories).Where(p=>!p.Contains("/bin/")&&!p.Contains("/obj/")).ToList();
files.Add(root+"/src/ClankerWorld.Simulation/obj/Release/net10.0/ClankerWorld.Simulation.GlobalUsings.g.cs");
foreach(var f in new[]{"AgentPlacementRules.cs","BoundedText.cs","RoutineHelperDefaults.cs","Contracts/CalendarRules.cs","Contracts/NeedStates.cs"})files.Add(root+"/src/ClankerWorld.Shared/"+f);files.AddRange(Directory.GetFiles(root+"/src/ClankerWorld.Shared/WorldEvents","*.cs"));
var trees=files.Select(f=>CSharpSyntaxTree.ParseText(File.ReadAllText(f),path:f)).ToArray();
var refs=((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator).Select(p=>MetadataReference.CreateFromFile(p));
var comp=CSharpCompilation.Create("ClankerWorld.Simulation",trees,refs,new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,nullableContextOptions:NullableContextOptions.Enable));

var result=new List<object>();
foreach(var t in trees.Where(t=>Scoped(t.FilePath))){var model=comp.GetSemanticModel(t);foreach(var n in t.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>()){
 var expression=n.ExpressionBody?.Expression??(n.Body?.Statements.Count==1?n.Body.Statements[0] is ReturnStatementSyntax ret?ret.Expression:n.Body.Statements[0] is ExpressionStatementSyntax st?st.Expression:null:null);
 if(expression is not InvocationExpressionSyntax call||model.GetDeclaredSymbol(n) is not IMethodSymbol method||model.GetSymbolInfo(call).Symbol is not IMethodSymbol target||n.AttributeLists.Count!=0)continue;
 result.Add(new{file=t.FilePath,name=method.ToDisplayString(),isStatic=method.IsStatic,target=target.ToDisplayString(),targetStatic=target.IsStatic,parameters=method.Parameters.Select(p=>new{name=p.Name,type=p.Type.ToDisplayString(),refKind=p.RefKind.ToString(),uses=call.DescendantNodesAndSelf().OfType<IdentifierNameSyntax>().Count(id=>SymbolEqualityComparer.Default.Equals(model.GetSymbolInfo(id).Symbol,p))}),source=n.ToFullString(),lines=n.ToFullString().Count(c=>c=='\n')});
}}
Directory.CreateDirectory(output);File.WriteAllText(output+"/forwarders.json",JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{count=result.Count}));
static bool Scoped(string p)=>p.Contains("/src/ClankerWorld.Simulation/Society/")||p.Contains("/src/ClankerWorld.Simulation/Kernel/")||p.Contains("/src/ClankerWorld.Simulation/Cognition/")||p.Contains("/src/ClankerWorld.Simulation/Content/")||Path.GetDirectoryName(p)=="/workspace/fix-2556-33837055/src/ClankerWorld.Simulation";
