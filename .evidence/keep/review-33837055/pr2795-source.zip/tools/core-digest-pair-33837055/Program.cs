using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
var output=args[0];var baseline=Cases(args[1]);var head=Cases(args[2]);if(!baseline.SequenceEqual(head))throw new Exception("canonical digest/validation pair differs: "+string.Join("\n",baseline.Zip(head).Select((p,i)=>(p,i)).Where(x=>x.p.First!=x.p.Second).Select(x=>x.i+":"+x.p.First+" vs "+x.p.Second)));
File.WriteAllText(output+"/digest-pair-cases.json",JsonSerializer.Serialize(baseline,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{cases=baseline.Length,buildingCases=baseline.Length/2,recipeCases=baseline.Length/2,canonicalIdsPayloadDigestsAndValidationEqual=true,baseline=args[1],head=args[2]}));
static string[] Cases(string path)
{
 var context=new AssemblyLoadContext(Guid.NewGuid().ToString(),isCollectible:true);try{var assembly=context.LoadFromAssemblyPath(Path.GetFullPath(path));var version=assembly.GetType("ClankerWorld.Simulation.Content.ContentVersion",true)!;var quantity=assembly.GetType("ClankerWorld.Simulation.Content.ContentQuantity",true)!;var results=new List<string>();
 foreach(var kind in new[]{"BuildingDefinition","RecipeDefinition"})
 for(var i=0;i<256;i++)
 {
  var type=assembly.GetType("ClankerWorld.Simulation.Content."+kind,true)!;var stage="construct";var values=new Dictionary<string,string?>{{"kind",kind},{"case",i.ToString()}};try{
   var ver=Activator.CreateInstance(version,new object[]{i%17==0?-1:i%3,i%5,i%7})!;var amounts=Array.CreateInstance(quantity,i%4);for(var j=0;j<amounts.Length;j++)amounts.SetValue(Activator.CreateInstance(quantity,new object[]{j%2==0?"wood":"stone",i%19==0?-1:j+1}),j);
   var outputs=Array.CreateInstance(quantity,1);outputs.SetValue(Activator.CreateInstance(quantity,new object[]{"flour",i%23==0?0:2}),0);var digest="sha256:"+new string((char)('a'+i%6),64);var name=i%29==0?null:i%3==0?"Zoë 🌲 e\u0301":"Definition "+i;var tags=i%7==0?null:new[]{"stable","building"};object?[] parameters;
   if(kind=="BuildingDefinition")parameters=[digest,"house-"+i,ver,name,i%31==0?0:i%4+1,i%3+1,i%8,amounts,tags,null];
   else parameters=[digest,"recipe-"+i,ver,name,amounts,outputs,i%37==0?0:i+1,i%4==0?null:digest+"/building/house@1.0.0",tags,null];
   var instance=Activator.CreateInstance(type,parameters)!;stage="payload";values["payloadDigest"]=(string?)type.GetProperty("PayloadDigest")!.GetValue(instance);stage="identity";values["canonicalId"]=(string?)type.GetProperty("CanonicalId")!.GetValue(instance);stage="validate";type.GetMethod("Validate")!.Invoke(instance,null);values["validation"]="accepted";
  }catch(Exception e){while(e is TargetInvocationException {InnerException:not null}tie)e=tie.InnerException!;values["validation"]="refused";values["stage"]=stage;values["exception"]=e.GetType().FullName;values["message"]=e.Message;if(e is ArgumentException a)values["parameter"]=a.ParamName;}
  results.Add(JsonSerializer.Serialize(values));
 }
 return results.ToArray();}finally{context.Unload();}
}
