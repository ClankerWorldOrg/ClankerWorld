using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using ClankerWorld.Simulation.Cognition;
using ClankerWorld.Simulation.Kernel;

namespace ClankerWorld.Simulation.Society;

/// <summary>
/// Authoritative Phase 4 society transitions. Every public operation validates
/// against a checkpoint and returns a replacement checkpoint with durable
/// events; callers never receive a partially-mutated world.
/// </summary>
public static partial class SocietyRules
{
    /// <summary>
    /// Creates an adult of the given age at world tick 0, or at the adult
    /// threshold when no age is given. The age must lie in the arrival range.
    /// </summary>
    public static SocietyAgent CreateFounder(
        string id,
        string name,
        string? providerBindingId = null,
        int healthBasisPoints = 10_000,
        SocietyConfig? config = null,
        int? startingAge = null)
    {
        var effectiveConfig = config ?? new SocietyConfig();
        effectiveConfig.Validate();
        var age = startingAge ?? effectiveConfig.FounderStartingAge;
        if (age < effectiveConfig.FounderStartingAge || age > LatestArrivalAge(effectiveConfig))
        {
            throw new ArgumentOutOfRangeException(nameof(startingAge));
        }

        return new SocietyAgent(
            NormalizeRequiredText(id, nameof(id)),
            NormalizeRequiredText(name, nameof(name)),
            checked(-age * effectiveConfig.TicksPerLifecycleAge),
            SocietyAgentStatus.Active,
            effectiveConfig.AgeBandAt(age),
            ValidateBasisPoints(healthBasisPoints, nameof(healthBasisPoints)),
            null,
            NormalizeOptionalText(providerBindingId),
            SocietyWorkRole.Unassigned,
            age)
        {
            DomesticFamilyUnitId = DomesticPersonUnit(id),
        };
    }

    public static SocietyCheckpoint CreateGenesis(
        string worldId,
        IEnumerable<SocietyAgent>? founders = null,
        IEnumerable<InventoryLot>? lots = null,
        SocietyConfig? config = null,
        string? worldDefaultProviderBindingId = null)
    {
        var effectiveConfig = config ?? new SocietyConfig();
        effectiveConfig.Validate();
        var agents = (founders ??
                [CreateFounder("founder-scout", "Scout", config: effectiveConfig)])
            .Select(person => person with
            {
                // Genesis assigns explicit singleton domestic units unless a
                // fixture deliberately supplies a recorded group.
                DomesticFamilyUnitId = person.DomesticFamilyUnitId ?? DomesticPersonUnit(person.Id),
            })
            .OrderBy(item => item.Id, StringComparer.Ordinal)
            .ToArray();
        ValidateAgents(agents, effectiveConfig, 0);
        var inventory = InventoryAuthority.CreateGenesis(lots ?? []);
        return new SocietyCheckpoint(
            NormalizeRequiredText(worldId, nameof(worldId)),
            0,
            0,
            false,
            effectiveConfig,
            NormalizeOptionalText(worldDefaultProviderBindingId),
            agents,
            [],
            [],
            [],
            [],
            [],
            [],
            inventory,
            []);
    }

    public static SocietyOperationResult CreateHousehold(
        SocietyCheckpoint checkpoint,
        string householdId,
        string name,
        IEnumerable<string> memberIds)
    {
        Validate(checkpoint);
        var id = NormalizeRequiredText(householdId, nameof(householdId));
        var householdName = NormalizeRequiredText(name, nameof(name));
        var requestedMembers = memberIds?.ToArray() ?? throw new ArgumentNullException(nameof(memberIds));
        var members = requestedMembers.Length == 0 && checkpoint.WorldTick == 0 &&
            checkpoint.Agents.Count == 0
                ? []
                : CanonicalIds(requestedMembers, nameof(memberIds));
        if (checkpoint.Households.Any(item => item.Id == id))
        {
            throw new InvalidOperationException("A household ID may be used only once.");
        }

        foreach (var memberId in members)
        {
            EnsureActive(checkpoint, memberId);
            if (checkpoint.GetAgent(memberId).HouseholdId is not null)
            {
                throw new InvalidOperationException("An agent cannot join a second primary household.");
            }
        }

        var household = new SocietyHousehold(id, householdName, members, []);
        var agents = checkpoint.Agents.Select(item => members.Contains(item.Id, StringComparer.Ordinal)
                ? item with { HouseholdId = id }
                : item)
            .OrderBy(item => item.Id, StringComparer.Ordinal)
            .ToArray();
        var relationships = checkpoint.Relationships.ToList();
        foreach (var memberId in members)
        {
            relationships.Add(new SocietyRelationship(
                DerivedId.Create($"{id}:membership:{memberId}"),
                1,
                SocietyRelationshipType.HouseholdMembership,
                id,
                memberId,
                SocietyRelationshipState.Accepted,
                SocietyConsentState.ProtectedLifecycle,
                checkpoint.WorldTick,
                checkpoint.WorldTick,
                "household",
                id,
                new[] { id, memberId }.OrderBy(value => value, StringComparer.Ordinal).ToArray()));
        }

        var next = checkpoint with
        {
            Agents = agents,
            Households = checkpoint.Households.Append(household)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            Relationships = relationships.OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
        };
        return Commit(next, "household_created", $"{id}:{string.Join(',', members)}", id);
    }

    public static SocietyOperationResult PlaceFounder(
        SocietyCheckpoint checkpoint,
        SocietyAgent founder,
        string householdId)
    {
        Validate(checkpoint);
        ArgumentNullException.ThrowIfNull(founder);
        if (checkpoint.WorldTick != 0 || !checkpoint.IsPaused ||
            founder.Status != SocietyAgentStatus.Active || founder.HouseholdId is not null ||
            checkpoint.Agents.Any(person => person.Id == founder.Id))
            throw new InvalidOperationException("A founder can only be placed once during paused world setup.");
        var household = checkpoint.GetHousehold(householdId);
        var memberIds = household.MemberIds.Append(founder.Id).Order(StringComparer.Ordinal).ToArray();
        var membership = new SocietyRelationship(
            DerivedId.Create($"{householdId}:membership:{founder.Id}"), 1,
            SocietyRelationshipType.HouseholdMembership,
            householdId, founder.Id, SocietyRelationshipState.Accepted,
            SocietyConsentState.ProtectedLifecycle, 0, 0,
            "household", householdId,
            new[] { householdId, founder.Id }.Order(StringComparer.Ordinal).ToArray());
        var next = checkpoint with
        {
            Agents = checkpoint.Agents.Append(founder with
            {
                HouseholdId = householdId,
                NeedsName = true,
                HasChosenName = false,
                DomesticFamilyUnitId = founder.DomesticFamilyUnitId ?? DomesticPersonUnit(founder.Id),
            })
                .OrderBy(person => person.Id, StringComparer.Ordinal).ToArray(),
            Households = checkpoint.Households.Select(item => item.Id == householdId
                ? item with { MemberIds = memberIds } : item).ToArray(),
            Relationships = checkpoint.Relationships.Append(membership)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
        };
        return Commit(next, "founder_placed", $"{founder.Id}:{householdId}", founder.Id);
    }

    public static SocietyOperationResult UndoFounderPlacement(SocietyCheckpoint checkpoint, string founderId)
    {
        Validate(checkpoint);
        if (!checkpoint.IsPaused || checkpoint.WorldTick != 0)
            throw new InvalidOperationException("Founder placement can only be undone during paused setup.");
        var founder = checkpoint.Agents.SingleOrDefault(item => item.Id == founderId);
        if (founder is null || founder.Status != SocietyAgentStatus.Active ||
            founder.HouseholdId is not { } householdId ||
            checkpoint.Relationships.Any(item =>
                (item.ProposerId == founderId || item.TargetId == founderId) &&
                item.Type != SocietyRelationshipType.HouseholdMembership) ||
            checkpoint.Inventory.Lots.Any(item => item.OwnerId == founderId))
            throw new InvalidOperationException("This founder cannot be removed from setup.");
        var next = checkpoint with
        {
            Agents = checkpoint.Agents.Where(item => item.Id != founderId).ToArray(),
            // Undo removes this not-yet-started person, including their personal setup history.
            Memories = checkpoint.Memories.Where(item => item.OwnerId != founderId && item.SubjectId != founderId).ToArray(),
            Households = checkpoint.Households.Select(item => item.Id == householdId
                ? item with { MemberIds = item.MemberIds.Where(id => id != founderId).ToArray() }
                : item).ToArray(),
            Relationships = checkpoint.Relationships.Where(item =>
                item.ProposerId != founderId && item.TargetId != founderId).ToArray(),
        };
        return Commit(next, "founder_placement_undone", $"{founderId}:{householdId}");
    }

    public static SocietyOperationResult AddAdult(
        SocietyCheckpoint checkpoint, string agentId, string? householdId)
    {
        Validate(checkpoint);
        var id = NormalizeRequiredText(agentId, nameof(agentId));
        var home = householdId is null ? null : NormalizeRequiredText(householdId, nameof(householdId));
        if (checkpoint.Agents.Any(person => person.Id == id))
            throw new InvalidOperationException("The new agent ID already exists.");
        var existingHousehold = home is null ? null :
            checkpoint.Households.FirstOrDefault(household => household.Id == home);

        var age = AddedAdultArrivalAge(checkpoint);
        var lifeBirth = checked(checkpoint.LifeTickAt(checkpoint.WorldTick) -
            age * checkpoint.Config.TicksPerLifecycleAge);
        var person = CreateFounder(id, "New agent", config: checkpoint.Config, startingAge: age) with
        {
            BirthTick = checkpoint.LifeClock is null ? lifeBirth : checkpoint.WorldTick,
            BirthLifeTick = checkpoint.LifeClock is null ? null : lifeBirth,
            HouseholdId = home,
            NeedsName = true,
            HasChosenName = false,
        };
        var households = checkpoint.Households;
        var relationships = checkpoint.Relationships;
        if (home is not null)
        {
            var household = existingHousehold is null
                ? new SocietyHousehold(home, "New household", [id], [])
                : existingHousehold with
                {
                    MemberIds = existingHousehold.MemberIds.Append(id)
                        .Order(StringComparer.Ordinal).ToArray(),
                };
            households = existingHousehold is null
                ? checkpoint.Households.Append(household).OrderBy(item => item.Id, StringComparer.Ordinal).ToArray()
                : checkpoint.Households.Select(item => item.Id == home ? household : item).ToArray();
            var membership = new SocietyRelationship(
                DerivedId.Create($"{home}:membership:{id}"), 1, SocietyRelationshipType.HouseholdMembership,
                home, id, SocietyRelationshipState.Accepted,
                SocietyConsentState.ProtectedLifecycle, checkpoint.WorldTick, checkpoint.WorldTick,
                "household", home, new[] { home, id }.Order(StringComparer.Ordinal).ToArray());
            relationships = checkpoint.Relationships.Append(membership)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray();
        }
        var next = checkpoint with
        {
            Agents = checkpoint.Agents.Append(person).OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            Households = households,
            Relationships = relationships,
        };
        return Commit(next, "agent_added", $"{id}:{home ?? "no_household"}", id);
    }

    /// <summary>
    /// Adds an active adult who has no household to a household that agreed
    /// to take them in. The caller records that agreement; this only commits
    /// the resulting membership.
    /// </summary>
    public static SocietyOperationResult JoinHousehold(
        SocietyCheckpoint checkpoint, string agentId, string householdId)
    {
        Validate(checkpoint);
        var id = NormalizeRequiredText(agentId, nameof(agentId));
        var home = NormalizeRequiredText(householdId, nameof(householdId));
        EnsureActive(checkpoint, id);
        if (checkpoint.GetAgent(id).HouseholdId is not null)
            return Reject(checkpoint, "household_join_rejected", $"{id}:existing_household");
        var household = checkpoint.Households.FirstOrDefault(item => item.Id == home);
        if (household is null)
            return Reject(checkpoint, "household_join_rejected", $"{id}:missing_household");

        var membershipKey = $"{home}:membership:{id}";
        var membershipId = DerivedId.Create(membershipKey);
        if (checkpoint.Relationships.Any(item => item.Id == membershipId))
            membershipId = DerivedId.Create($"{membershipKey}:{checkpoint.WorldTick}");
        var membership = new SocietyRelationship(
            membershipId, 1, SocietyRelationshipType.HouseholdMembership,
            home, id, SocietyRelationshipState.Accepted,
            SocietyConsentState.Accepted, checkpoint.WorldTick, checkpoint.WorldTick,
            "household", home, new[] { home, id }.Order(StringComparer.Ordinal).ToArray());
        var next = checkpoint with
        {
            Agents = checkpoint.Agents.Select(person =>
                person.Id == id ? person with { HouseholdId = home } : person).ToArray(),
            Households = checkpoint.Households.Select(item => item.Id == home
                ? item with
                {
                    MemberIds = item.MemberIds.Append(id).Distinct(StringComparer.Ordinal)
                        .Order(StringComparer.Ordinal).ToArray(),
                }
                : item).ToArray(),
            Relationships = checkpoint.Relationships.Append(membership)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
        };
        return Commit(next, "household_joined", $"{id}:{home}", id);
    }

    public static SocietyOperationResult RenameAgent(
        SocietyCheckpoint checkpoint, string agentId, string name)
    {
        Validate(checkpoint);
        var id = NormalizeRequiredText(agentId, nameof(agentId));
        var chosen = NormalizeRequiredText(name, nameof(name));
        if (chosen.Length > 48 || chosen.Any(char.IsControl))
            throw new ArgumentException("Choose a name of at most 48 characters without control characters.", nameof(name));
        var existing = checkpoint.GetAgent(id);
        if (existing.Name == chosen && existing.HasChosenName && !existing.NeedsName)
            return new SocietyOperationResult(checkpoint);
        if (AgentNameRules.CanonicalKey(chosen) is null)
            throw new ArgumentException("Choose a valid name.", nameof(name));
        if (AgentNameRules.IsTaken(checkpoint, id, chosen))
            throw new AgentNameTakenException();
        if (!AgentNameRules.IsAllowedChildName(checkpoint, id, chosen))
            throw new ArgumentException("Choose one of the child's parents' surnames.", nameof(name));
        var next = checkpoint with
        {
            Agents = checkpoint.Agents.Select(person =>
                person.Id == id ? person with { Name = chosen, NeedsName = false, HasChosenName = true } : person).ToArray(),
        };
        if (existing.HasChosenName && AgentNameRules.SurnameKey(existing.Name) is not null &&
            AgentNameRules.SurnameKey(chosen) is null &&
            next.Relationships.Any(relationship => relationship.ProposerId == id &&
                relationship.Type == SocietyRelationshipType.BiologicalParentage &&
                relationship.State is SocietyRelationshipState.Accepted or SocietyRelationshipState.EndedByDeath &&
                AgentNameRules.RequiresParentSurname(next, relationship.TargetId) &&
                AgentNameRules.AllowedChildSurnames(next, relationship.TargetId).Count == 0))
        {
            throw new ArgumentException("Keep a biological parent's surname available for each minor child.", nameof(name));
        }
        return Commit(next, "agent_renamed", id, id);
    }

    /// <summary>Ends automatic naming without promoting the retained placeholder to a chosen name.</summary>
    public static SocietyOperationResult CloseNaming(SocietyCheckpoint checkpoint, string agentId)
    {
        Validate(checkpoint);
        var id = NormalizeRequiredText(agentId, nameof(agentId));
        var existing = checkpoint.GetAgent(id);
        if (!existing.NeedsName) return new SocietyOperationResult(checkpoint);
        var next = checkpoint with
        {
            Agents = checkpoint.Agents.Select(person =>
                person.Id == id ? person with { NeedsName = false } : person).ToArray(),
        };
        return Commit(next, "agent_naming_closed", id, id);
    }

    public static SocietyOperationResult ProposeRelationship(
        SocietyCheckpoint checkpoint,
        SocietyRelationshipProposal proposal)
    {
        Validate(checkpoint);
        ArgumentNullException.ThrowIfNull(proposal);
        ValidateProposal(proposal, checkpoint.WorldTick);
        EnsureActive(checkpoint, proposal.ProposerId);
        EnsureActive(checkpoint, proposal.TargetId);
        if (checkpoint.Relationships.Any(item => item.Id == proposal.Id))
        {
            throw new InvalidOperationException("A relationship proposal ID may be used only once.");
        }

        var relationship = new SocietyRelationship(
            proposal.Id,
            proposal.Revision,
            proposal.Type,
            proposal.ProposerId,
            proposal.TargetId,
            SocietyRelationshipState.Proposed,
            SocietyConsentState.Pending,
            proposal.RequestedTick,
            0,
            proposal.PrivacyClass,
            proposal.HouseholdId,
            []);
        var next = checkpoint with
        {
            Relationships = checkpoint.Relationships.Append(relationship)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
        };
        return Commit(next, "relationship_proposed", $"{proposal.Id}:r{proposal.Revision}", proposal.Id);
    }

    public static SocietyOperationResult AcceptRelationship(
        SocietyCheckpoint checkpoint,
        string relationshipId,
        int revision,
        string acceptorId)
    {
        Validate(checkpoint);
        var relationship = checkpoint.GetRelationship(relationshipId);
        var acceptor = NormalizeRequiredText(acceptorId, nameof(acceptorId));
        if (relationship.Type == SocietyRelationshipType.BiologicalParentage)
            return Reject(checkpoint, "relationship_rejected", "parentage_requires_birth_transaction");
        if (relationship.State != SocietyRelationshipState.Proposed || relationship.Revision != revision ||
            relationship.TargetId != acceptor)
        {
            return Reject(checkpoint, "relationship_rejected", $"{relationshipId}:stale_or_wrong_acceptor");
        }

        EnsureActive(checkpoint, relationship.ProposerId);
        EnsureActive(checkpoint, relationship.TargetId);
        if (relationship.Type == SocietyRelationshipType.Partnership &&
            checkpoint.Relationships.Any(item => item.State == SocietyRelationshipState.Accepted &&
                item.Type == SocietyRelationshipType.Partnership &&
                (item.ProposerId == relationship.ProposerId || item.TargetId == relationship.ProposerId ||
                 item.ProposerId == relationship.TargetId || item.TargetId == relationship.TargetId)))
        {
            return Reject(checkpoint, "relationship_rejected", $"{relationshipId}:cardinality_conflict");
        }

        if (relationship.Type == SocietyRelationshipType.HouseholdMembership)
        {
            if (relationship.HouseholdId is null || !checkpoint.Households.Any(item => item.Id == relationship.HouseholdId))
            {
                return Reject(checkpoint, "relationship_rejected", $"{relationshipId}:missing_household");
            }

            if (checkpoint.GetAgent(relationship.TargetId).HouseholdId is not null)
            {
                return Reject(checkpoint, "relationship_rejected", $"{relationshipId}:existing_household");
            }
        }

        var accepted = relationship with
        {
            State = SocietyRelationshipState.Accepted,
            Consent = SocietyConsentState.Accepted,
            EffectiveTick = checked(checkpoint.WorldTick + 1),
            AcceptedBy = new[] { relationship.ProposerId, relationship.TargetId }
                .OrderBy(value => value, StringComparer.Ordinal).ToArray(),
        };
        var next = checkpoint with
        {
            Relationships = checkpoint.Relationships.Select(item => item.Id == relationship.Id ? accepted : item)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
        };
        next = ApplyRelationshipProjection(next, accepted);
        if (accepted.Type == SocietyRelationshipType.Partnership)
            next = ApplyPartnershipFamilyUnit(next, accepted);
        return Commit(next, "relationship_accepted", $"{relationshipId}:r{revision}", relationshipId);
    }

    public static SocietyOperationResult RefuseRelationship(
        SocietyCheckpoint checkpoint,
        string relationshipId,
        int revision,
        string targetId)
    {
        Validate(checkpoint);
        var relationship = checkpoint.GetRelationship(relationshipId);
        if (relationship.State != SocietyRelationshipState.Proposed || relationship.Revision != revision ||
            relationship.TargetId != targetId)
        {
            return Reject(checkpoint, "relationship_rejected", $"{relationshipId}:stale_or_wrong_target");
        }

        var rejected = relationship with
        {
            State = SocietyRelationshipState.Rejected,
            Consent = SocietyConsentState.Refused,
            EffectiveTick = checkpoint.WorldTick,
        };
        return Commit(
            checkpoint with
            {
                Relationships = checkpoint.Relationships.Select(item => item.Id == relationship.Id ? rejected : item)
                    .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            },
            "relationship_rejected",
            $"{relationshipId}:consent_refused",
            relationshipId);
    }

    public static SocietyOperationResult RevokeRelationship(
        SocietyCheckpoint checkpoint,
        string relationshipId,
        string actorId)
    {
        Validate(checkpoint);
        var relationship = checkpoint.GetRelationship(relationshipId);
        var actor = NormalizeRequiredText(actorId, nameof(actorId));
        if (relationship.Type == SocietyRelationshipType.BiologicalParentage)
            return Reject(checkpoint, "relationship_rejected", "parentage_is_historical");
        if (relationship.State is not (SocietyRelationshipState.Accepted or SocietyRelationshipState.Proposed) ||
            (relationship.ProposerId != actor && relationship.TargetId != actor))
        {
            return Reject(checkpoint, "relationship_rejected", $"{relationshipId}:unauthorized_revoke");
        }

        var revoked = relationship with
        {
            State = SocietyRelationshipState.Revoked,
            Consent = SocietyConsentState.Revoked,
            EffectiveTick = checkpoint.WorldTick,
        };
        var next = checkpoint with
        {
            Relationships = checkpoint.Relationships.Select(item => item.Id == relationship.Id ? revoked : item)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
        };
        next = RemoveRelationshipProjection(next, revoked,
            relationship.Type == SocietyRelationshipType.Caregiver && relationship.State == SocietyRelationshipState.Accepted);
        if (revoked.Type == SocietyRelationshipType.Partnership && relationship.State == SocietyRelationshipState.Accepted)
            next = SplitPartnershipFamilyUnit(next, revoked);
        return Commit(next, "relationship_revoked", $"{relationshipId}:{actor}", relationshipId);
    }

    public static SocietyOperationResult AssignRole(
        SocietyCheckpoint checkpoint,
        string agentId,
        SocietyWorkRole role)
    {
        Validate(checkpoint);
        EnsureActive(checkpoint, agentId);
        var next = checkpoint with
        {
            Agents = checkpoint.Agents.Select(item => item.Id == agentId
                    ? item with { CurrentRole = role }
                    : item)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
        };
        return Commit(next, "work_role_assigned", $"{agentId}:{role}", agentId);
    }

    public static SocietyOperationResult RecordSocialMemory(
        SocietyCheckpoint checkpoint,
        SocietySocialMemory memory)
    {
        Validate(checkpoint);
        ArgumentNullException.ThrowIfNull(memory);
        // A player can also rename a deceased person; their permanent history remains inspectable.
        if (memory.Permanent) _ = checkpoint.GetAgent(memory.OwnerId);
        else EnsureActive(checkpoint, memory.OwnerId);
        if (!checkpoint.Agents.Any(item => item.Id == memory.SubjectId) ||
            checkpoint.AllMemories().Any(item => item.Id == memory.Id))
        {
            throw new InvalidOperationException("A social memory requires a known subject and unique ID.");
        }

        var next = checkpoint with
        {
            Memories = checkpoint.Memories.Append(memory with
            { Summary = NormalizeRequiredText(memory.Summary, nameof(memory.Summary)) })
                .OrderBy(item => item.Id.Value, StringComparer.Ordinal).ToArray(),
        };
        return Commit(next, "social_memory_recorded", memory.Id, memory.Id);
    }

    /// <summary>
    /// Adds an agent-owned belief without appending to the authoritative event
    /// history. The public event stream remains a record of world outcomes.
    /// </summary>
    public static SocietyCheckpoint RecordAgentBelief(
        SocietyCheckpoint checkpoint,
        SocietyAgentBelief belief)
    {
        Validate(checkpoint);
        ArgumentNullException.ThrowIfNull(belief);
        var normalized = NormalizeBelief(belief);
        EnsureActive(checkpoint, normalized.OwnerId);
        ValidateBeliefInput(checkpoint, normalized, allowSupersedes: false);
        if (checkpoint.AllBeliefs().Any(item => item.Id == normalized.Id))
            throw new InvalidOperationException("The agent belief ID is already used.");

        return checkpoint with
        {
            Beliefs = (checkpoint.Beliefs ?? []).Append(normalized)
                .OrderBy(item => item.Id.Value, StringComparer.Ordinal).ToArray(),
        };
    }

    /// <summary>
    /// Keeps an agent's earlier belief as corrected history and records the
    /// replacement. This changes neither simulation facts nor public events.
    /// </summary>
    public static SocietyCheckpoint CorrectAgentBelief(
        SocietyCheckpoint checkpoint,
        string ownerId,
        string beliefId,
        SocietyAgentBelief correction)
    {
        Validate(checkpoint);
        var owner = NormalizeRequiredText(ownerId, nameof(ownerId));
        var targetId = NormalizeRequiredText(beliefId, nameof(beliefId));
        EnsureActive(checkpoint, owner);
        ArgumentNullException.ThrowIfNull(correction);
        var beliefs = checkpoint.AllBeliefs().ToArray();
        var previous = beliefs.SingleOrDefault(item => item.Id == targetId)
            ?? throw new InvalidOperationException("The belief to correct does not exist.");
        if (previous.OwnerId != owner || correction.OwnerId != owner)
            throw new InvalidOperationException("An agent can correct only their own belief.");
        if (previous.SupersededByBeliefId is not null)
            throw new InvalidOperationException("The belief has already been corrected.");
        if (correction.Id == previous.Id || beliefs.Any(item => item.Id == correction.Id))
            throw new InvalidOperationException("The correction must use a new belief ID.");

        var replacement = NormalizeBelief(correction) with
        {
            FormedTick = checkpoint.WorldTick,
            SupersedesBeliefId = previous.Id,
            SupersededByBeliefId = null,
            SupersededTick = null,
        };
        ValidateBeliefInput(checkpoint, replacement, allowSupersedes: true);
        var revised = beliefs.Select(item => item.Id == previous.Id
                ? item with { SupersededByBeliefId = replacement.Id, SupersededTick = checkpoint.WorldTick }
                : item)
            .Append(replacement)
            .OrderBy(item => item.Id.Value, StringComparer.Ordinal).ToArray();
        var archived = checkpoint.ArchivedBeliefs.Select(item => item.Belief.Id.Value).ToHashSet(StringComparer.Ordinal);
        var byId = revised.ToDictionary(item => item.Id.Value, StringComparer.Ordinal);
        return checkpoint with
        {
            Beliefs = revised.Where(item => !archived.Contains(item.Id)).ToArray(),
            ArchivedBeliefs = checkpoint.ArchivedBeliefs.Select(item => item with { Belief = byId[item.Belief.Id] }).ToArray(),
        };
    }

    /// <summary>
    /// Merges Jev's bounded salience estimates into an owner's private index.
    /// Existing experience and belief text is left untouched and no event is
    /// appended to the authoritative world history.
    /// </summary>
    public static SocietyCheckpoint RecordAgentMemoryCompaction(
        SocietyCheckpoint checkpoint,
        string ownerId,
        IReadOnlyList<SocietyAgentMemoryImportance> scores)
    {
        Validate(checkpoint);
        var owner = NormalizeRequiredText(ownerId, nameof(ownerId));
        ArgumentNullException.ThrowIfNull(scores);
        EnsureActive(checkpoint, owner);
        if (scores.Count is < 1 or > 12)
            throw new ArgumentOutOfRangeException(nameof(scores));

        var existingSources = (checkpoint.MemoryCompactions ?? [])
            .SingleOrDefault(item => item.OwnerId == owner)?.Sources ?? [];
        var combined = existingSources.ToDictionary(
            item => $"{item.Kind}:{item.SourceId}", StringComparer.Ordinal);
        foreach (var score in scores)
        {
            ArgumentNullException.ThrowIfNull(score);
            if (!BoundedText.IsValid(score.SourceId, 128, requireTrimmed: true) || !Enum.IsDefined(score.Kind) ||
                score.SourceTick < 0 || score.SourceTick > checkpoint.WorldTick ||
                score.ImportanceBasisPoints is < 0 or > 10_000 ||
                score.ImportanceConfidenceBasisPoints is < 0 or > 10_000)
                throw new InvalidDataException("An agent memory importance assessment is invalid.");

            var sourceTick = score.Kind switch
            {
                SocietyMemorySourceKind.Experience => checkpoint.AllMemories()
                    .SingleOrDefault(item => item.Id == score.SourceId && item.OwnerId == owner)?.SourceTick,
                SocietyMemorySourceKind.Belief => checkpoint.AllBeliefs()
                    .SingleOrDefault(item => item.Id == score.SourceId && item.OwnerId == owner)?.FormedTick,
                _ => null,
            };
            if (sourceTick is null || sourceTick.Value != score.SourceTick)
                throw new InvalidOperationException("An agent may compact only their own existing memory sources.");

            combined[$"{score.Kind}:{score.SourceId}"] = score with { AssessedTick = checkpoint.WorldTick };
        }

        var boundedSources = RetainedMemoryImportanceSources(combined.Values)
            .OrderBy(item => item.Kind)
            .ThenBy(item => item.SourceId.Value, StringComparer.Ordinal).ToArray();
        var compactions = (checkpoint.MemoryCompactions ?? [])
            .Where(item => item.OwnerId != owner)
            .Append(new SocietyAgentMemoryCompaction(owner, boundedSources))
            .OrderBy(item => item.OwnerId, StringComparer.Ordinal).ToArray();
        return checkpoint with { MemoryCompactions = compactions };
    }

    internal static IEnumerable<SocietyAgentMemoryImportance> RetainedMemoryImportanceSources(
        IEnumerable<SocietyAgentMemoryImportance> sources) => sources
        .OrderByDescending(item => item.SourceTick)
        .ThenBy(item => item.Kind)
        .ThenBy(item => item.SourceId.Value, StringComparer.Ordinal)
        .Take(256);

    public static SocietyOperationResult ConsumeInventory(
        SocietyCheckpoint checkpoint,
        string ownerId,
        string lotId,
        int quantity,
        string purpose = "direct_consumption")
    {
        Validate(checkpoint);
        var owner = NormalizeRequiredText(ownerId, nameof(ownerId));
        EnsureLivingParty(checkpoint, owner);
        var lot = checkpoint.Inventory.GetLot(lotId);
        if (quantity <= 0 || lot.OwnerId != owner || lot.Quantity < quantity)
        {
            throw new InvalidOperationException("Consumption requires an owned lot with sufficient quantity.");
        }

        var reservationId = DerivedId.Create($"consume:{owner}:{lotId}:{checkpoint.Inventory.EventHistoryFloor + checkpoint.Inventory.Events.Count + 1}");
        var reserved = InventoryAuthority.Reserve(
            checkpoint.Inventory,
            reservationId,
            owner,
            lotId,
            quantity,
            purpose,
            checkpoint.WorldTick);
        var consumed = InventoryAuthority.ConsumeReservation(reserved, reservationId);
        return Commit(
            checkpoint with { Inventory = consumed },
            "inventory_consumed",
            $"{owner}:{lotId}:{quantity}:{purpose}",
            owner);
    }

    public static SocietyOperationResult CreateBarterOffer(
        SocietyCheckpoint checkpoint,
        DirectBarterProposal proposal)
    {
        Validate(checkpoint);
        EnsureBarterParty(checkpoint, proposal.FirstPartyId);
        EnsureBarterParty(checkpoint, proposal.SecondPartyId);
        var inventory = InventoryAuthority.CreateDirectBarterOffer(checkpoint.Inventory, proposal);
        return Commit(checkpoint with { Inventory = inventory }, "barter_offer_created", proposal.Id, proposal.Id);
    }

    public static SocietyOperationResult AcceptBarterOffer(
        SocietyCheckpoint checkpoint,
        string offerId,
        int revision,
        string partyId)
    {
        Validate(checkpoint);
        EnsureLivingParty(checkpoint, partyId);
        var inventory = InventoryAuthority.AcceptDirectBarterOffer(checkpoint.Inventory, offerId, revision, partyId);
        var offer = inventory.GetOffer(offerId);
        return Commit(
            checkpoint with { Inventory = inventory },
            offer.State == DirectBarterState.Settled ? "barter_settled" : "barter_accepted",
            $"{offerId}:{partyId}:r{revision}",
            offerId);
    }

    public static SocietyOperationResult CommitBirth(
        SocietyCheckpoint checkpoint,
        SocietyBirthRequest request)
    {
        Validate(checkpoint);
        ArgumentNullException.ThrowIfNull(request);
        ValidateBirthRequest(request, checkpoint.WorldTick);
        var existing = checkpoint.Births.SingleOrDefault(item => item.RequestId == request.Id);
        if (existing is not null)
        {
            return existing.Revision == request.Revision &&
                existing.PrimaryCaregiverId == request.PrimaryCaregiverId &&
                existing.HouseholdId == request.HouseholdId &&
                BirthFoodRequestMatches(checkpoint.Inventory, request)
                ? new SocietyOperationResult(checkpoint, existing.ChildId, [])
                : Reject(checkpoint, "birth_rejected", $"{request.Id}:revision_conflict");
        }

        var firstParent = checkpoint.GetAgent(request.FirstParentId);
        var secondParent = checkpoint.GetAgent(request.SecondParentId);
        var household = checkpoint.GetHousehold(request.HouseholdId);
        if (!CanHaveChildren(firstParent) || !CanHaveChildren(secondParent) ||
            !request.ConsentingParentIds.OrderBy(item => item, StringComparer.Ordinal)
                .SequenceEqual(new[] { firstParent.Id, secondParent.Id }.OrderBy(item => item, StringComparer.Ordinal)) ||
            !HasActivePartnership(checkpoint, firstParent.Id, secondParent.Id) ||
            request.PrimaryCaregiverId is not { } primaryCaregiverId ||
            primaryCaregiverId != firstParent.Id && primaryCaregiverId != secondParent.Id ||
            checkpoint.GetAgent(primaryCaregiverId).HouseholdId != household.Id ||
            request.CaregiverIds.Count == 0 ||
            request.CaregiverIds.Any(id => !household.MemberIds.Contains(id, StringComparer.Ordinal) ||
                !IsAdult(checkpoint.GetAgent(id))) ||
            !request.CaregiverIds.Contains(primaryCaregiverId, StringComparer.Ordinal))
        {
            return Reject(checkpoint, "birth_rejected", $"{request.Id}:readiness_or_consent");
        }

        var childId = DerivedId.Create($"{checkpoint.WorldId}:agent:{request.Id}");
        if (request.ChildName is { } childName)
        {
            if (AgentNameRules.CanonicalKey(childName) is null)
                throw new ArgumentException("Choose a valid child name.", nameof(request));
            if (AgentNameRules.IsTaken(checkpoint, childId, childName))
                throw new AgentNameTakenException();
            if (!AgentNameRules.HasParentSurname(childName, [firstParent, secondParent]))
                throw new ArgumentException("Choose one of the child's parents' surnames.", nameof(request));
        }

        InventoryCheckpoint inventory;
        try
        {
            var food = request.FoodContributions ?? [new(request.FoodLotId, request.FoodQuantity)];
            var sources = food.Select(item => checkpoint.Inventory.GetLot(item.LotId)).ToArray();
            if (sources.Any(lot => lot.OwnerId != request.HouseholdId &&
                lot.OwnerId != firstParent.Id && lot.OwnerId != secondParent.Id))
                return Reject(checkpoint, "birth_rejected", $"{request.Id}:food_access");

            inventory = checkpoint.Inventory;
            var reservationIds = new string[food.Count];
            for (var index = 0; index < food.Count; index++)
            {
                var reservationId = DerivedId.Create(request.FoodContributions is null
                    ? $"birth:{request.Id}:food"
                    : $"birth:{request.Id}:food:{index.ToString("D2", System.Globalization.CultureInfo.InvariantCulture)}");
                reservationIds[index] = reservationId;
                inventory = InventoryAuthority.Reserve(inventory, reservationId, sources[index].OwnerId,
                    food[index].LotId, food[index].Quantity, $"birth:{request.Id}", checkpoint.WorldTick,
                    holdAccess: [InventoryStore.CreateInventoryHold(InventoryHoldPurpose.Borrowed, firstParent.Id), InventoryStore.CreateInventoryHold(InventoryHoldPurpose.Borrowed, secondParent.Id)]);
            }
            foreach (var reservationId in reservationIds)
                inventory = InventoryAuthority.ConsumeReservation(inventory, reservationId);
        }
        catch (InvalidOperationException)
        {
            return Reject(checkpoint, "birth_rejected", $"{request.Id}:reservation_failed");
        }

        var primaryCaregiver = checkpoint.GetAgent(primaryCaregiverId);
        var child = new SocietyAgent(
            childId,
            request.ChildName is null ? "Child" : NormalizeRequiredText(request.ChildName, nameof(request.ChildName)),
            checkpoint.WorldTick,
            SocietyAgentStatus.Active,
            SocietyAgeBand.Infant,
            10_000,
            household.Id,
            ResolveNewbornProvider(checkpoint, firstParent, secondParent, request),
            SocietyWorkRole.Unassigned,
            0,
            BirthLifeTick: checkpoint.LifeClock is null ? null : checkpoint.LifeTickAt(checkpoint.WorldTick),
            NeedsName: request.ChildName is null)
        {
            PrimaryCaregiverId = primaryCaregiverId,
            DomesticFamilyUnitId = primaryCaregiver.DomesticFamilyUnitId,
        };
        var relationships = checkpoint.Relationships.ToList();
        relationships.AddRange(
        [
            BirthRelationship(request, childId, SocietyRelationshipType.BiologicalParentage, firstParent.Id),
            BirthRelationship(request, childId, SocietyRelationshipType.BiologicalParentage, secondParent.Id),
            ..request.CaregiverIds.Select(caregiver => BirthRelationship(
                request,
                childId,
                SocietyRelationshipType.Caregiver,
                caregiver)),
            BirthRelationship(request, childId, SocietyRelationshipType.HouseholdMembership, household.Id),
        ]);
        var updatedHousehold = household with
        {
            MemberIds = household.MemberIds.Append(childId).Distinct(StringComparer.Ordinal)
                .OrderBy(item => item, StringComparer.Ordinal).ToArray(),
            CaregiverIds = household.CaregiverIds.Union(request.CaregiverIds, StringComparer.Ordinal)
                .OrderBy(item => item, StringComparer.Ordinal).ToArray(),
        };
        var next = checkpoint with
        {
            Agents = checkpoint.Agents.Append(child).OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            Households = checkpoint.Households.Select(item => item.Id == household.Id ? updatedHousehold : item)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            Relationships = relationships.OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            Births = checkpoint.Births.Append(new SocietyBirthRecord(request.Id, childId, request.Revision,
                    checkpoint.WorldTick, primaryCaregiverId, household.Id, primaryCaregiver.DomesticFamilyUnitId!))
                .OrderBy(item => item.RequestId, StringComparer.Ordinal).ToArray(),
            Inventory = inventory,
        };
        return Commit(next, "birth_committed", $"{request.Id}:{childId}", childId);
    }

    public static SocietyOperationResult AdvanceTo(
        SocietyCheckpoint checkpoint,
        long targetTick,
        IReadOnlyList<SocietyTownStore>? townStores = null,
        IReadOnlyList<SocietyDefaultEstateDivision>? defaultEstates = null)
    {
        Validate(checkpoint);
        ArgumentOutOfRangeException.ThrowIfLessThan(targetTick, checkpoint.WorldTick);
        if (checkpoint.IsPaused)
        {
            throw new InvalidOperationException("A paused society must resume before it can advance.");
        }

        var current = checkpoint;
        var boundaryEvents = new List<(long Tick, string AgentId, int AgeYears)>();
        foreach (var agent in checkpoint.Agents.Where(item => item.Status == SocietyAgentStatus.Active))
        {
            var oldAge = checkpoint.AgeAt(agent, checkpoint.WorldTick);
            var newAge = checkpoint.AgeAt(agent, targetTick);
            for (var age = Math.Max(oldAge + 1, agent.LastLifecycleYearChecked + 1); age <= newAge; age++)
            {
                boundaryEvents.Add((
                    checkpoint.LifeClock?.WorldTickFor(checked((agent.BirthLifeTick ?? agent.BirthTick) + age * checkpoint.Config.TicksPerLifecycleAge))
                        ?? checked(agent.BirthTick + age * checkpoint.Config.TicksPerLifecycleAge),
                    agent.Id,
                    checked((int)age)));
            }
        }

        foreach (var boundaryGroup in boundaryEvents
                     .GroupBy(item => item.Tick)
                     .OrderBy(group => group.Key))
        {
            current = current with
            {
                WorldTick = boundaryGroup.Key,
                Inventory = WithInventoryTick(current.Inventory, boundaryGroup.Key),
            };

            var transitionDetails = new List<string>();
            var mortalityIds = new List<string>();
            foreach (var boundary in boundaryGroup.OrderBy(item => item.AgentId, StringComparer.Ordinal))
            {
                var agent = current.GetAgent(boundary.AgentId);
                if (agent.Status != SocietyAgentStatus.Active)
                {
                    continue;
                }

                var nextBand = current.Config.AgeBandAt(boundary.AgeYears);
                current = current with
                {
                    Agents = current.Agents.Select(item => item.Id == agent.Id
                            ? item with
                            {
                                AgeBand = nextBand,
                                LastLifecycleYearChecked = boundary.AgeYears,
                            }
                            : item)
                        .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
                };
                if (nextBand != agent.AgeBand)
                {
                    transitionDetails.Add($"{agent.Id}:{agent.AgeBand}:{nextBand}");
                }

                var risk = current.Config.NaturalMortalityRiskBasisPoints(boundary.AgeYears);
                if (risk > 0 && MortalityRoll(current.WorldId, agent.Id, boundary.AgeYears) < risk)
                {
                    mortalityIds.Add(agent.Id);
                }
            }

            current = CommitMany(
                current,
                transitionDetails.Select(detail => ("age_band_transition", detail)));
            foreach (var agentId in mortalityIds)
            {
                if (current.GetAgent(agentId).Status == SocietyAgentStatus.Active)
                {
                    current = Kill(current, agentId, SocietyDeathCause.NaturalAge, current.WorldTick).Checkpoint;
                }
            }
        }

        current = current with
        {
            WorldTick = targetTick,
            Inventory = WithInventoryTick(current.Inventory, targetTick),
        };
        current = SettleDueEstates(current, targetTick, townStores ?? [], defaultEstates ?? []);
        return new SocietyOperationResult(
            current,
            null,
            current.Events.Skip(checkpoint.Events.Count).ToArray());
    }

    public static SocietyOperationResult Kill(
        SocietyCheckpoint checkpoint,
        string agentId,
        SocietyDeathCause cause,
        long? deathTick = null)
    {
        Validate(checkpoint);
        var agent = checkpoint.GetAgent(agentId);
        if (agent.Status == SocietyAgentStatus.Dead)
        {
            return new SocietyOperationResult(checkpoint, null, []);
        }

        var tick = deathTick ?? checkpoint.WorldTick;
        ArgumentOutOfRangeException.ThrowIfLessThan(tick, checkpoint.WorldTick);
        return Kill(checkpoint with { WorldTick = tick }, agentId, cause, tick);
    }

    public static SocietyOperationResult MarkWillStarted(SocietyCheckpoint checkpoint, string estateId)
    {
        Validate(checkpoint);
        var estate = checkpoint.GetEstate(estateId);
        if (estate.Settled || estate.WillStatus is not null)
            return new SocietyOperationResult(checkpoint, null, []);
        var next = checkpoint with
        {
            Estates = checkpoint.Estates.Select(item => item.Id == estateId
            ? item with { WillStatus = "pending" } : item).ToArray()
        };
        return Commit(next, "estate_will_started", estateId, estateId);
    }

    /// <summary>
    /// Records a will's outcome. Without a valid directive the estate keeps the
    /// household default. Heirs must be living people other than the deceased,
    /// or one of <paramref name="townHeirIds"/>; listed lots must be frozen in
    /// this estate. Final words are kept with either outcome when they are plain
    /// and short; anything else is dropped.
    /// </summary>
    public static SocietyOperationResult ResolveWill(
        SocietyCheckpoint checkpoint, string estateId, SocietyWillDirective? directive, string outcome,
        string? finalWords = null, IReadOnlySet<string>? townHeirIds = null)
    {
        Validate(checkpoint);
        var estate = checkpoint.GetEstate(estateId);
        if (estate.WillStatus != "pending" || estate.Settled)
            return new SocietyOperationResult(checkpoint, null, []);
        var validSnapshot = HasFrozenEstateInventory(checkpoint, estate);
        var words = finalWords is null ? null : CognitionWillChoice.NormalizeFinalWords(finalWords);
        var containedIn = checkpoint.Inventory.Lots
            .Where(lot => lot.OwnerId == estate.Id && lot.ContainerLotId is not null)
            .ToDictionary(lot => lot.Id, lot => lot.ContainerLotId!, StringComparer.Ordinal);
        var bequests = validSnapshot && outcome == "accepted" && directive is not null
            ? PlanBequests(checkpoint, estate, directive, townHeirIds ?? new HashSet<string>(StringComparer.Ordinal), containedIn)
            : null;
        var accepted = bequests is not null;
        var next = checkpoint with
        {
            Estates = checkpoint.Estates.Select(item => item.Id == estateId
            ? item with
            {
                WillStatus = accepted ? "accepted" : "default",
                WillHeirIds = accepted ? directive!.HeirIds.ToArray() : null,
                WillSplit = accepted ? directive!.Split : null,
                WillBequests = bequests,
                FinalWords = words,
            } : item).ToArray()
        };
        return Commit(next, accepted ? "estate_will_accepted" : "estate_will_default",
            accepted ? $"{estateId}:{directive!.Split}:{string.Join(',', directive.HeirIds)}"
                : $"{estateId}:{(outcome == "accepted" ? "invalid_will" : outcome)}", estateId);
    }

    /// <summary>
    /// The exact division of a valid will, or null when any part is invalid.
    /// "items" gives each listed lot whole to its heir. Every other lot, and
    /// every lot under "equal", is divided equally: each heir gets the same
    /// whole number of units, and the units left over go one at a time to the
    /// heirs in the order the will names them, continuing from where the
    /// previous lot's leftovers stopped. Lots are taken in lot-ID order.
    /// A vessel is one unit, and its contents go with it to the same heir.
    /// Nothing is created or lost: each lot's parts sum to its frozen quantity.
    /// </summary>
    private static List<SocietyWillBequest>? PlanBequests(
        SocietyCheckpoint checkpoint, SocietyEstate estate, SocietyWillDirective directive,
        IReadOnlySet<string> townHeirIds, Dictionary<string, string> containedIn,
        bool requireLivingHeirs = true)
    {
        var heirs = directive.HeirIds;
        if (heirs is null || heirs.Count is 0 or > CognitionWillContext.MaximumNamedHeirs ||
            heirs.Distinct(StringComparer.Ordinal).Count() != heirs.Count ||
            heirs.Any(id => id == estate.DeceasedId || !townHeirIds.Contains(id) &&
                !checkpoint.Agents.Any(person => person.Id == id &&
                    (!requireLivingHeirs || person.Status == SocietyAgentStatus.Active))) ||
            directive.Split is not (CognitionWillContext.EqualSplit or CognitionWillContext.ItemSplit) ||
            directive.Split == CognitionWillContext.EqualSplit && directive.LotHeirs is { Count: > 0 })
            return null;
        var frozen = estate.FrozenLots ?? [];
        var lotHeirs = directive.LotHeirs ?? new Dictionary<string, string>(StringComparer.Ordinal);
        if (lotHeirs.Any(item => !frozen.Any(lot => lot.LotId == item.Key) || containedIn.ContainsKey(item.Key) ||
                !heirs.Contains(item.Value, StringComparer.Ordinal)))
            return null;

        var bequests = new List<SocietyWillBequest>();
        var cursor = 0;
        void AddContents(string containerId, string heir) =>
            bequests.AddRange(frozen.Where(content => containedIn.GetValueOrDefault(content.LotId) == containerId)
                .OrderBy(content => content.LotId, StringComparer.Ordinal)
                .Select(content => new SocietyWillBequest(content.LotId, heir, content.Quantity)));
        foreach (var lot in frozen.Where(item => !containedIn.ContainsKey(item.LotId))
                     .OrderBy(item => item.LotId, StringComparer.Ordinal))
        {
            if (lotHeirs.TryGetValue(lot.LotId, out var single))
            {
                bequests.Add(new SocietyWillBequest(lot.LotId, single, lot.Quantity));
                AddContents(lot.LotId, single);
                continue;
            }
            var share = lot.Quantity / heirs.Count;
            var leftover = lot.Quantity % heirs.Count;
            var quantities = heirs.Select(_ => share).ToArray();
            for (var unit = 0; unit < leftover; unit++)
                quantities[(cursor + unit) % heirs.Count]++;
            cursor = (cursor + leftover) % heirs.Count;
            for (var index = 0; index < heirs.Count; index++)
            {
                if (quantities[index] > 0)
                    bequests.Add(new SocietyWillBequest(lot.LotId, heirs[index], quantities[index]));
            }
            // A vessel is a single unit, so exactly one heir received it above.
            if (InventoryContainerRules.IsContainer(lot.ItemKind))
                AddContents(lot.LotId, heirs[Array.FindIndex(quantities, quantity => quantity > 0)]);
        }
        return bequests;
    }

    public static SocietyOperationResult Pause(SocietyCheckpoint checkpoint)
    {
        Validate(checkpoint);
        return checkpoint.IsPaused
            ? new SocietyOperationResult(checkpoint, null, [])
            : Commit(checkpoint with { IsPaused = true }, "paused", "requested");
    }

    public static SocietyOperationResult Resume(SocietyCheckpoint checkpoint)
    {
        Validate(checkpoint);
        return !checkpoint.IsPaused
            ? new SocietyOperationResult(checkpoint, null, [])
            : Commit(
                checkpoint with
                {
                    IsPaused = false,
                    RunEpoch = checked(checkpoint.RunEpoch + 1),
                },
                "resumed",
                $"epoch:{checkpoint.RunEpoch + 1}");
    }

    public static void Validate(SocietyCheckpoint checkpoint)
    {
        ArgumentNullException.ThrowIfNull(checkpoint);
        ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.WorldId);
        if (checkpoint.WorldTick < 0 || checkpoint.RunEpoch < 0)
        {
            throw new InvalidDataException("Society clock and run epoch must be non-negative.");
        }

        checkpoint.Config.Validate();
        if (checkpoint.Inventory.WorldTick != checkpoint.WorldTick)
        {
            throw new InvalidDataException("Society and inventory clocks must agree.");
        }
        InventoryAuthority.ValidateCheckpointForCodec(checkpoint.Inventory);

        if (checkpoint.LifeClock is { } clock && (clock.Rate is not (1 or 365 or 1_460) ||
            clock.WorldAnchorTick < 0 || clock.WorldAnchorTick > checkpoint.WorldTick || clock.LifeAnchorTick < clock.WorldAnchorTick ||
            checkpoint.Config.ContractVersion < 2))
        {
            throw new InvalidDataException("The biological life clock is invalid.");
        }
        ValidateAgents(checkpoint.Agents, checkpoint.Config, checkpoint.WorldTick, checkpoint.LifeClock);
        EnsureCanonicalIds(checkpoint.Households.Select(item => item.Id), "households");
        EnsureCanonicalIds(checkpoint.Relationships.Select(item => item.Id), "relationships");
        EnsureCanonicalIds(checkpoint.Organizations.Select(item => item.Id), "organizations");
        EnsureCanonicalIds(checkpoint.Memories.Select(item => (string?)item.Id), "memories");
        ValidateMemoryArchive(checkpoint);
        foreach (var memory in checkpoint.AllMemories().Where(item => item.Permanent || item.Id.Value.StartsWith("player-rename:", StringComparison.Ordinal)))
        {
            if (!memory.Permanent || !checkpoint.Agents.Any(person => person.Id == memory.OwnerId) || memory.SubjectId != memory.OwnerId ||
                memory.Visibility != "private" || memory.TombstonedTick is not null ||
                memory.SourceTick < 0 || memory.SourceTick > checkpoint.WorldTick ||
                !BoundedText.IsValid(memory.Summary, 256, requireTrimmed: true))
                throw new InvalidDataException("A permanent personal memory must retain its owner, source date and private contents.");
        }
        ValidateAgentBeliefs(checkpoint);
        ValidateAgentMemoryCompactions(checkpoint);
        ValidateMemorySummaries(checkpoint);
        EnsureCanonicalIds(checkpoint.Estates.Select(item => item.Id), "estates");
        EnsureCanonicalIds(checkpoint.Births.Select(item => item.RequestId), "births");
        foreach (var birth in checkpoint.Births)
        {
            var child = checkpoint.Agents.SingleOrDefault(person => person.Id == birth.ChildId);
            if (birth.Revision <= 0 || birth.CommittedTick < 0 || birth.CommittedTick > checkpoint.WorldTick ||
                string.IsNullOrWhiteSpace(birth.PrimaryCaregiverId) ||
                string.IsNullOrWhiteSpace(birth.HouseholdId) ||
                string.IsNullOrWhiteSpace(birth.DomesticFamilyUnitId) || child is null ||
                !checkpoint.Agents.Any(person => person.Id == birth.PrimaryCaregiverId) ||
                !checkpoint.Households.Any(household => household.Id == birth.HouseholdId) ||
                !checkpoint.Relationships.Any(relationship =>
                    relationship.Type == SocietyRelationshipType.BiologicalParentage &&
                    relationship.TargetId == birth.ChildId && relationship.ProposerId == birth.PrimaryCaregiverId))
                throw new InvalidDataException("A saved birth caregiver or home record is malformed.");
        }
        foreach (var estate in checkpoint.Estates)
        {
            if (estate.CreatedTick < 0 || estate.ExpiryTick < estate.CreatedTick ||
                !checkpoint.Agents.Any(item => item.Id == estate.DeceasedId &&
                    item.Status == SocietyAgentStatus.Dead) ||
                estate.WillStatus is not (null or "pending" or "accepted" or "default") ||
                !IsValidWill(checkpoint, estate))
                throw new InvalidDataException("An estate record is malformed.");
            if (estate.FrozenLots is { } frozen)
            {
                EnsureCanonicalIds(frozen.Select(item => item.LotId), $"estate:{estate.Id}:lots");
                if (frozen.Any(item => string.IsNullOrWhiteSpace(item.ItemKind) || item.Quantity <= 0 ||
                    item.StorageBuildingId is { } storage &&
                    (string.IsNullOrWhiteSpace(storage) || storage != storage.Trim())))
                    throw new InvalidDataException("An estate snapshot is malformed.");
            }
        }
        foreach (var household in checkpoint.Households)
        {
            EnsureCanonicalIds(household.MemberIds, $"household:{household.Id}:members");
            EnsureCanonicalIds(household.CaregiverIds, $"household:{household.Id}:caregivers");
            if (household.MemberIds.Any(id => !checkpoint.Agents.Any(item => item.Id == id)))
            {
                throw new InvalidDataException("Households cannot reference unknown agents.");
            }
        }

        foreach (var relationship in checkpoint.Relationships)
        {
            if (relationship.Revision <= 0 || relationship.ProposedTick < 0 || relationship.EffectiveTick < 0 ||
                string.IsNullOrWhiteSpace(relationship.ProposerId) ||
                string.IsNullOrWhiteSpace(relationship.TargetId) ||
                (relationship.State == SocietyRelationshipState.Accepted &&
                    relationship.Consent is not (SocietyConsentState.Accepted or SocietyConsentState.ProtectedLifecycle)))
            {
                throw new InvalidDataException("A relationship record is malformed.");
            }
        }

        if (checkpoint.EventHistoryFloor < 0)
        {
            throw new InvalidDataException("The society event history floor is invalid.");
        }
        var expectedEventId = checked(checkpoint.EventHistoryFloor + 1);
        var previousTick = 0L;
        foreach (var societyEvent in checkpoint.Events)
        {
            if (societyEvent.EventId != expectedEventId || societyEvent.WorldTick < previousTick ||
                societyEvent.WorldTick > checkpoint.WorldTick)
            {
                throw new InvalidDataException("Society events must be a canonical committed sequence.");
            }

            expectedEventId++;
            previousTick = societyEvent.WorldTick;
        }
    }

    private static void ValidateAgentBeliefs(SocietyCheckpoint checkpoint)
    {
        EnsureCanonicalIds((checkpoint.Beliefs ?? []).Select(item => (string?)item.Id), "agent beliefs");
        var beliefs = checkpoint.AllBeliefs().OrderBy(item => item.Id.Value, StringComparer.Ordinal).ToArray();
        EnsureCanonicalIds(beliefs.Select(item => (string?)item.Id), "agent beliefs");
        if (beliefs.Length == 0) return;
        var byId = beliefs.ToDictionary(item => item.Id.Value, StringComparer.Ordinal);
        var index = new SocietyBeliefValidationIndex(checkpoint, byId);
        foreach (var belief in beliefs)
        {
            ValidateBeliefInput(checkpoint, belief, allowSupersedes: true, index);
            if (belief.SupersedesBeliefId is { } priorId)
            {
                if (!byId.TryGetValue(priorId, out var prior) || prior.OwnerId != belief.OwnerId ||
                    prior.SupersededByBeliefId != belief.Id || prior.SupersededTick != belief.FormedTick ||
                    prior.FormedTick > belief.FormedTick)
                    throw new InvalidDataException("An agent belief correction has no matching owner-private predecessor.");
            }

            if ((belief.SupersededByBeliefId is null) != (belief.SupersededTick is null))
                throw new InvalidDataException("An agent belief correction link is incomplete.");
            if (belief.SupersededByBeliefId is { } replacementId &&
                (!byId.TryGetValue(replacementId, out var replacement) || replacement.OwnerId != belief.OwnerId ||
                 replacement.SupersedesBeliefId != belief.Id || replacement.FormedTick != belief.SupersededTick))
                throw new InvalidDataException("An agent belief correction link is inconsistent.");
        }
    }

    private static void ValidateAgentMemoryCompactions(SocietyCheckpoint checkpoint)
    {
        var compactions = checkpoint.MemoryCompactions ?? [];
        EnsureCanonicalIds(compactions.Select(item => item.OwnerId), "agent memory compactions");
        var memoryById = checkpoint.AllMemories().ToDictionary(item => item.Id.Value, StringComparer.Ordinal);
        var beliefById = checkpoint.AllBeliefs().ToDictionary(item => item.Id.Value, StringComparer.Ordinal);
        foreach (var compaction in compactions)
        {
            if (string.IsNullOrWhiteSpace(compaction.OwnerId) || compaction.OwnerId != compaction.OwnerId.Trim() ||
                compaction.OwnerId.Any(char.IsControl) || compaction.Sources is null ||
                compaction.Sources.Count is < 1 or > 256 ||
                !checkpoint.Agents.Any(item => item.Id == compaction.OwnerId))
                throw new InvalidDataException("An agent memory compaction is malformed.");

            var expected = compaction.Sources.OrderBy(item => item.Kind)
                .ThenBy(item => (string?)item.SourceId, StringComparer.Ordinal).ToArray();
            if (!compaction.Sources.SequenceEqual(expected) ||
                compaction.Sources.Select(item => $"{item.Kind}:{item.SourceId}")
                    .Distinct(StringComparer.Ordinal).Count() != compaction.Sources.Count)
                throw new InvalidDataException("Agent memory compaction sources must be unique and canonical.");

            foreach (var source in compaction.Sources)
            {
                if (!BoundedText.IsValid(source.SourceId, 128, requireTrimmed: true) || !Enum.IsDefined(source.Kind) ||
                    source.SourceTick < 0 || source.SourceTick > checkpoint.WorldTick ||
                    source.AssessedTick < source.SourceTick || source.AssessedTick > checkpoint.WorldTick ||
                    source.ImportanceBasisPoints is < 0 or > 10_000 ||
                    source.ImportanceConfidenceBasisPoints is < 0 or > 10_000)
                    throw new InvalidDataException("An agent memory compaction assessment is malformed.");

                var validOwnerSource = source.Kind switch
                {
                    SocietyMemorySourceKind.Experience => memoryById.TryGetValue(source.SourceId, out var memory) &&
                        memory.OwnerId == compaction.OwnerId && memory.SourceTick == source.SourceTick,
                    SocietyMemorySourceKind.Belief => beliefById.TryGetValue(source.SourceId, out var belief) &&
                        belief.OwnerId == compaction.OwnerId && belief.FormedTick == source.SourceTick,
                    _ => false,
                };
                if (!validOwnerSource)
                    throw new InvalidDataException("An agent memory compaction references another agent or an unknown source.");
            }
        }
    }

    private static void ValidateBeliefInput(
        SocietyCheckpoint checkpoint,
        SocietyAgentBelief belief,
        bool allowSupersedes,
        SocietyBeliefValidationIndex? index = null)
    {
        if (!IdentityRules.Belief(belief.Id) || string.IsNullOrWhiteSpace(belief.OwnerId) ||
            belief.OwnerId != belief.OwnerId.Trim() || belief.OwnerId.Any(char.IsControl) ||
            !BoundedText.IsValid(belief.Statement, 512, requireTrimmed: true) ||
            belief.Statement.Any(char.IsControl) || !Enum.IsDefined(belief.Provenance) || !Enum.IsDefined(belief.Kind) ||
            belief.ConfidenceBasisPoints is < 0 or > 10_000 || belief.FormedTick < 0 ||
            belief.FormedTick > checkpoint.WorldTick || belief.SourceEventId is <= 0 ||
            belief.SourceTurnId is { } sourceTurnId && !BoundedText.IsValid(sourceTurnId, 600, requireTrimmed: true) ||
            belief.SupersededTick is < 0 || belief.SupersededTick > checkpoint.WorldTick ||
            belief.SupersededByBeliefId is { } superseding && !IdentityRules.Belief(superseding) ||
            belief.SupersedesBeliefId is { } superseded && !IdentityRules.Belief(superseded))
            throw new InvalidDataException("An agent belief has invalid bounded fields.");

        index ??= new SocietyBeliefValidationIndex(checkpoint);
        if (!index.KnowsAgent(belief.OwnerId) ||
            belief.SourceAgentId is { } sourceAgent && !index.KnowsAgent(sourceAgent) ||
            belief.AboutAgentId is { } subject && !index.KnowsAgent(subject))
            throw new InvalidDataException("An agent belief references an unknown agent.");

        if ((belief.Provenance == SocietyBeliefProvenance.Hearsay &&
             (belief.SourceAgentId is null || belief.SourceAgentId == belief.OwnerId)) ||
            (belief.Provenance == SocietyBeliefProvenance.Firsthand &&
             belief.SourceAgentId is not null && belief.SourceAgentId != belief.OwnerId))
            throw new InvalidDataException("An agent belief's provenance does not match its witness or reporter.");

        if (belief.SourceTurnId is not null &&
            (belief.Provenance != SocietyBeliefProvenance.Hearsay || belief.SourceAgentId is null ||
             !index.AllowsSourceTurn(belief)))
            throw new InvalidDataException("An agent belief source turn is invalid or already recorded for this owner.");

        if ((!allowSupersedes && (belief.SupersedesBeliefId is not null ||
                                  belief.SupersededByBeliefId is not null || belief.SupersededTick is not null)) ||
            belief.SupersededByBeliefId is null && belief.SupersededTick is not null)
            throw new InvalidDataException("Only a correction may link a belief to its predecessor.");
    }

    private static SocietyAgentBelief NormalizeBelief(SocietyAgentBelief belief) => belief with
    {
        Id = Identity.Parse(NormalizeRequiredText(belief.Id, nameof(belief.Id))),
        OwnerId = NormalizeRequiredText(belief.OwnerId, nameof(belief.OwnerId)),
        Statement = NormalizeBeliefStatement(belief.Statement),
        SourceAgentId = NormalizeOptionalText(belief.SourceAgentId),
        SourceTurnId = NormalizeOptionalText(belief.SourceTurnId),
        AboutAgentId = NormalizeOptionalText(belief.AboutAgentId),
        SupersedesBeliefId = Identity.ParseOptional(NormalizeOptionalText(belief.SupersedesBeliefId)),
        SupersededByBeliefId = Identity.ParseOptional(NormalizeOptionalText(belief.SupersededByBeliefId)),
    };

    private static string NormalizeBeliefStatement(string statement)
    {
        ArgumentNullException.ThrowIfNull(statement);
        var normalized = statement.Trim();
        if (normalized.Length is 0 or > 512 || normalized.Any(char.IsControl))
            throw new ArgumentOutOfRangeException(nameof(statement), "A belief must be bounded single-line text.");
        return normalized;
    }

    /// <summary>
    /// Only an accepted will carries heirs and an exact plan that covers every
    /// frozen lot; final words follow a resolved will of either outcome.
    /// Town heirs are checked against the world's Towns by the world.
    /// </summary>
    private static bool IsValidWill(SocietyCheckpoint checkpoint, SocietyEstate estate)
    {
        if (estate.FinalWords is { } words && (estate.WillStatus is not ("accepted" or "default") ||
            CognitionWillChoice.NormalizeFinalWords(words) != words))
            return false;
        if (estate.WillStatus != "accepted")
            return estate.WillHeirIds is null && estate.WillSplit is null && estate.WillBequests is null;
        if (estate.WillHeirIds is not { Count: > 0 and <= CognitionWillContext.MaximumNamedHeirs } heirs ||
            heirs.Distinct(StringComparer.Ordinal).Count() != heirs.Count ||
            heirs.Any(id => string.IsNullOrWhiteSpace(id) || id == estate.DeceasedId ||
                !id.StartsWith("town:", StringComparison.Ordinal) && !checkpoint.Agents.Any(person => person.Id == id)) ||
            estate.WillSplit is not (CognitionWillContext.EqualSplit or CognitionWillContext.ItemSplit) ||
            estate.FrozenLots is not { } frozen || estate.WillBequests is not { } bequests ||
            bequests.Any(item => item.Quantity <= 0 || !heirs.Contains(item.HeirId, StringComparer.Ordinal)) ||
            bequests.Select(item => (item.LotId, item.HeirId)).Distinct().Count() != bequests.Count)
            return false;
        // A resolved plan cannot authorize different or missing stock when restored.
        // Location changes at death may place carried goods on the ground, but
        // personal goods frozen in House storage remain in that same building.
        if (!estate.Settled && !HasFrozenEstateInventory(checkpoint, estate))
            return false;
        var containedIn = checkpoint.Inventory.Lots
            .Where(lot => lot.OwnerId == estate.Id && lot.ContainerLotId is not null)
            .ToDictionary(lot => lot.Id, lot => lot.ContainerLotId!, StringComparer.Ordinal);
        if (!estate.Settled && estate.WillSplit == CognitionWillContext.EqualSplit)
        {
            // A named heir may die after admission. Revalidate the saved division,
            // not their current ability to receive it; settlement applies the default.
            var expected = PlanBequests(checkpoint, estate,
                new SocietyWillDirective(heirs, CognitionWillContext.EqualSplit),
                heirs.Where(id => id.StartsWith("town:", StringComparison.Ordinal))
                    .ToHashSet(StringComparer.Ordinal), containedIn, requireLivingHeirs: false);
            if (expected is null || !expected.OrderBy(item => item.LotId, StringComparer.Ordinal)
                    .ThenBy(item => item.HeirId, StringComparer.Ordinal)
                    .SequenceEqual(bequests.OrderBy(item => item.LotId, StringComparer.Ordinal)
                        .ThenBy(item => item.HeirId, StringComparer.Ordinal)))
                return false;
        }
        // While the estate is held, a vessel's contents must go to the vessel's heir.
        var containersStayWhole = estate.Settled || checkpoint.Inventory.Lots
            .Where(lot => lot.OwnerId == estate.Id && lot.ContainerLotId is not null)
            .All(content => bequests.Where(item => item.LotId == content.Id).Select(item => item.HeirId)
                .Concat(bequests.Where(item => item.LotId == content.ContainerLotId).Select(item => item.HeirId))
                .Distinct(StringComparer.Ordinal).Count() == 1);
        return containersStayWhole &&
            frozen.All(lot => bequests.Where(item => item.LotId == lot.LotId).Sum(item => (long)item.Quantity) == lot.Quantity) &&
            bequests.All(item => frozen.Any(lot => lot.LotId == item.LotId));
    }

    private static bool HasFrozenEstateInventory(SocietyCheckpoint checkpoint, SocietyEstate estate) =>
        estate.FrozenLots is { } frozen &&
        frozen.All(item => checkpoint.Inventory.Lots.Any(lot =>
            lot.Id == item.LotId && lot.OwnerId == estate.Id && lot.ItemKind == item.ItemKind &&
            lot.Quantity == item.Quantity && lot.StorageBuildingId == item.StorageBuildingId)) &&
        checkpoint.Inventory.Lots.Count(lot => lot.OwnerId == estate.Id) == frozen.Count;

    private static SocietyOperationResult Kill(
        SocietyCheckpoint checkpoint,
        string agentId,
        SocietyDeathCause cause,
        long deathTick)
    {
        var agent = checkpoint.GetAgent(agentId);
        var estateId = EstateId(agent.Id, deathTick);
        var householdBeneficiaries = checkpoint.Households
            .Where(household => household.MemberIds.Contains(agent.Id, StringComparer.Ordinal))
            .SelectMany(household => household.MemberIds.Concat(household.CaregiverIds))
            .Where(id => id != agent.Id)
            .Where(id => checkpoint.GetAgent(id).Status == SocietyAgentStatus.Active)
            .Distinct(StringComparer.Ordinal)
            .OrderBy(id => id, StringComparer.Ordinal)
            .ToArray();
        var frozenLots = checkpoint.Inventory.Lots.Where(lot => lot.OwnerId == agent.Id)
            .OrderBy(lot => lot.Id, StringComparer.Ordinal)
            .Select(lot => new SocietyEstateLot(lot.Id, lot.ItemKind, lot.Quantity, lot.StorageBuildingId)).ToArray();
        var inventory = MoveOwnedLotsToEstate(checkpoint.Inventory, agent.Id, estateId, deathTick);
        var relationships = checkpoint.Relationships.Select(relationship =>
                relationship.ProposerId == agent.Id || relationship.TargetId == agent.Id
                    ? relationship with
                    {
                        State = relationship.State switch
                        {
                            SocietyRelationshipState.Accepted => SocietyRelationshipState.EndedByDeath,
                            SocietyRelationshipState.Proposed => SocietyRelationshipState.Revoked,
                            _ => relationship.State,
                        },
                        Consent = relationship.State is SocietyRelationshipState.Accepted or SocietyRelationshipState.Proposed
                            ? SocietyConsentState.Revoked
                            : relationship.Consent,
                        EffectiveTick = deathTick,
                    }
                    : relationship)
            .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray();
        var next = checkpoint with
        {
            WorldTick = deathTick,
            Agents = checkpoint.Agents.Select(item => item.Id == agent.Id
                    ? item with
                    {
                        Status = SocietyAgentStatus.Dead,
                        HealthBasisPoints = 0,
                        DeathTick = deathTick,
                        DeathCause = cause,
                    }
                    : item.PrimaryCaregiverId == agent.Id
                        ? item with { PrimaryCaregiverId = null }
                        : item)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            Relationships = relationships,
            Estates = checkpoint.Estates.Append(new SocietyEstate(
                    estateId,
                    agent.Id,
                    deathTick,
                    checked(deathTick + checkpoint.Config.EstateEscrowDays *
                        (long)checkpoint.Config.TicksPerWorldDay),
                    householdBeneficiaries,
                    FrozenLots: frozenLots))
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            Inventory = inventory,
        };
        var result = Commit(next, "death_committed", $"{agent.Id}:{cause}:{deathTick}", agent.Id);
        foreach (var relationship in relationships.Where(item =>
                     (item.ProposerId == agent.Id || item.TargetId == agent.Id) &&
                     item.State == SocietyRelationshipState.EndedByDeath))
        {
            result = Commit(result.Checkpoint, "relationship_ended_by_death", relationship.Id);
        }

        return Commit(
            result.Checkpoint,
            "estate_created",
            $"{estateId}:{string.Join(',', householdBeneficiaries)}",
            estateId);
    }

    /// <summary>
    /// Carries out due estates once. An accepted will gives each named heir
    /// their exact parts: a living person owns them where they lie (goods the
    /// dead agent carried remain at their last tile), and a Town keeps them in
    /// its Warehouse while there is room for that kind. Anything the will
    /// cannot deliver, such as a share for an heir who has since died, food or
    /// goods the Warehouse cannot take, follows the household default: an equal
    /// split between the living household beneficiaries, or the deceased's
    /// recorded Town when none remain. Without a will, a derived prospective
    /// Town law can allocate a bounded share before that household split.
    /// A vessel and its contents always move together, keeping
    /// their IDs. People who inherit hear any final words as a private memory.
    /// </summary>
    private static SocietyCheckpoint SettleDueEstates(
        SocietyCheckpoint checkpoint,
        long targetTick,
        IReadOnlyList<SocietyTownStore> townStores,
        IReadOnlyList<SocietyDefaultEstateDivision> defaultEstates)
    {
        var current = checkpoint;
        if (defaultEstates.Any(division => division is null || division.TownSharePercent is < 0 or > 100 ||
            string.IsNullOrWhiteSpace(division.TownId) || !checkpoint.Estates.Any(estate => estate.Id == division.EstateId)) ||
            defaultEstates.Select(division => division.EstateId).Distinct(StringComparer.Ordinal).Count() != defaultEstates.Count)
            throw new InvalidOperationException("Derived default estate divisions must name actual estates, a Town and one bounded share.");
        var room = townStores.ToDictionary(item => item.TownId, item => item.FreeRoom, StringComparer.Ordinal);
        foreach (var estate in checkpoint.Estates.Where(item => !item.Settled &&
                     item.WillStatus != "pending" && item.ExpiryTick <= targetTick)
                     .OrderBy(item => item.Id, StringComparer.Ordinal))
        {
            bool IsLiving(string id) => current.Agents.Any(item =>
                item.Id == id && item.Status == SocietyAgentStatus.Active);
            var beneficiaries = estate.BeneficiaryIds
                .Where(IsLiving)
                .OrderBy(id => id, StringComparer.Ordinal).ToArray();
            var lots = current.Inventory.Lots.Where(lot => lot.OwnerId == estate.Id)
                .OrderBy(lot => lot.Id, StringComparer.Ordinal).ToArray();
            var nextLots = current.Inventory.Lots.Where(lot => lot.OwnerId != estate.Id).ToList();
            var listeners = new SortedSet<string>(StringComparer.Ordinal);
            var bequests = estate.WillBequests ?? [];
            var division = defaultEstates.SingleOrDefault(item => item.EstateId == estate.Id);
            var townShare = estate.WillStatus == "accepted" ? 0 : division?.TownSharePercent ?? 0;
            var fallbackOwner = division?.TownId ?? "settlement:communal";
            var containerOrdinal = 0;
            foreach (var lot in lots.Where(lot => lot.ContainerLotId is null))
            {
                if (InventoryContainerRules.IsContainer(lot.ItemKind))
                {
                    // A vessel and its contents are a single physical estate
                    // family. Keep their IDs and quantities together instead
                    // of splitting a child lot away from the vessel.
                    var family = lots.Where(member => member.Id == lot.Id || member.ContainerLotId == lot.Id).ToArray();
                    var heir = bequests.FirstOrDefault(item => item.LotId == lot.Id)?.HeirId;
                    string? owner = null;
                    string? storage = lot.StorageBuildingId;
                    if (heir is null && (beneficiaries.Length == 0 || townShare == 100) && division is not null)
                        heir = division.TownId;
                    if (heir is not null && IsLiving(heir))
                    {
                        owner = heir;
                    }
                    else if (heir is not null && townStores.FirstOrDefault(store => store.TownId == heir) is { } store &&
                             family.All(member => !store.RefusedItemKinds.Contains(member.ItemKind)) &&
                             room[store.TownId] >= family.Sum(member => member.Quantity))
                    {
                        room[store.TownId] -= family.Sum(member => member.Quantity);
                        (owner, storage) = (store.TownId, store.WarehouseId);
                    }
                    owner ??= beneficiaries.Length == 0
                        ? fallbackOwner
                        : beneficiaries[containerOrdinal++ % beneficiaries.Length];
                    if (IsLiving(owner)) listeners.Add(owner);
                    nextLots.AddRange(family.Select(member => InventoryHoldRules.WithCustody(member, InventoryStore.PrepareOwnerTransfer(member, owner, storage is null && member.CarrierId != owner ? member.CarrierId : null, storage, null, storage is null ? member.GroundPosition : null))));
                    continue;
                }

                var parts = new List<(string OwnerId, string? StorageId, int Quantity)>();
                var undelivered = lot.Quantity;
                if (bequests.Count == 0 && division is not null &&
                    townStores.FirstOrDefault(store => store.TownId == division.TownId) is { } defaultStore &&
                    !defaultStore.RefusedItemKinds.Contains(lot.ItemKind))
                {
                    var wanted = beneficiaries.Length == 0 ? undelivered : (int)((long)undelivered * townShare / 100);
                    var delivered = Math.Min(wanted, Math.Max(0, room[defaultStore.TownId]));
                    if (delivered > 0)
                    {
                        parts.Add((defaultStore.TownId, defaultStore.WarehouseId, delivered));
                        room[defaultStore.TownId] -= delivered;
                        undelivered -= delivered;
                    }
                }
                foreach (var bequest in bequests.Where(item => item.LotId == lot.Id))
                {
                    var quantity = Math.Min(bequest.Quantity, undelivered);
                    if (IsLiving(bequest.HeirId))
                    {
                        parts.Add((bequest.HeirId, lot.StorageBuildingId, quantity));
                    }
                    else if (townStores.FirstOrDefault(store => store.TownId == bequest.HeirId) is { } store &&
                             !store.RefusedItemKinds.Contains(lot.ItemKind))
                    {
                        quantity = Math.Min(quantity, Math.Max(0, room[store.TownId]));
                        room[store.TownId] -= quantity;
                        parts.Add((store.TownId, store.WarehouseId, quantity));
                    }
                    else
                    {
                        quantity = 0;
                    }
                    undelivered -= quantity;
                }

                if (undelivered > 0 && beneficiaries.Length == 0)
                {
                    parts.Add((fallbackOwner, lot.StorageBuildingId, undelivered));
                }
                else if (undelivered > 0)
                {
                    var baseShare = undelivered / beneficiaries.Length;
                    var remainder = undelivered % beneficiaries.Length;
                    for (var index = 0; index < beneficiaries.Length; index++)
                        parts.Add((beneficiaries[index], lot.StorageBuildingId, baseShare + (index < remainder ? 1 : 0)));
                }

                var merged = parts.Where(part => part.Quantity > 0)
                    .GroupBy(part => (part.OwnerId, part.StorageId))
                    .Select(group => (group.Key.OwnerId, group.Key.StorageId, Quantity: group.Sum(part => part.Quantity)))
                    .OrderBy(part => part.OwnerId, StringComparer.Ordinal).ThenBy(part => part.StorageId, StringComparer.Ordinal).ToArray();
                foreach (var part in merged)
                {
                    if (part.OwnerId == fallbackOwner && part.StorageId == lot.StorageBuildingId && part.Quantity == lot.Quantity)
                    {
                        nextLots.Add(InventoryHoldRules.WithCustody(lot, InventoryStore.PrepareContainerTransfer(lot, part.OwnerId, lot.CarrierId, part.StorageId, null)));
                        continue;
                    }
                    if (IsLiving(part.OwnerId))
                        listeners.Add(part.OwnerId);

                    // Physical knowledge artifacts are indivisible and their saved
                    // ledger references this lot ID. Ownership changes, identity does not.
                    var preserveIdentity = lot.Quantity == 1 && lot.ItemKind is "field_map" or "field_record" or "book";
                    nextLots.Add(InventoryHoldRules.WithCustody(lot, InventoryStore.PrepareSplitTransfer(lot, preserveIdentity ? lot.Id : EstateSplitLotId(lot.Id, estate.Id, part.OwnerId,
                            merged.Count(candidate => candidate.OwnerId == part.OwnerId) > 1 ? part.StorageId ?? "ground" : null), part.OwnerId, part.StorageId is null && lot.CarrierId != part.OwnerId ? lot.CarrierId : null, part.Quantity, preserveIdentity ? lot.ProvenanceLotId : lot.Id, part.StorageId, null, part.StorageId is null ? lot.GroundPosition : null)));
                }
            }

            var inventoryEvents = current.Inventory.Events.ToList();
            inventoryEvents.Add(InventoryStore.PrepareStorageHistory(InventoryStore.CreateInventoryEvent(checked(current.Inventory.EventHistoryFloor + inventoryEvents.Count + 1L), targetTick, "estate_settled", estate.Id), InventoryStorageHistory.Changes(current.Inventory.Lots, nextLots)));
            current = current with
            {
                WorldTick = targetTick,
                Inventory = InventoryStore.CreateInventoryCheckpoint(targetTick, nextLots.OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(), current.Inventory.Reservations, current.Inventory.Offers, inventoryEvents, current.Inventory.EventHistoryFloor, current.Inventory.ArchivedRepairReservationCount),
                Estates = current.Estates.Select(item =>
                        item.Id == estate.Id ? item with { Settled = true } : item)
                    .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
            };
            current = Commit(current, "estate_settled", estate.Id).Checkpoint;
            if (estate.FinalWords is not { } words) continue;
            var speaker = current.GetAgent(estate.DeceasedId).Name;
            foreach (var listener in listeners)
            {
                var memoryId = FinalWordsMemoryId(estate.Id, listener);
                current = RecordSocialMemory(current, new SocietySocialMemory(
                    Identity.Parse(memoryId), listener, estate.DeceasedId,
                    $"{speaker}'s final words were: '{words}'", "private", targetTick)
                { Kind = SocietyMemoryKind.LifeEvent }).Checkpoint;
            }
        }

        return current;
    }

    private static InventoryCheckpoint MoveOwnedLotsToEstate(
        InventoryCheckpoint inventory,
        string ownerId,
        string estateId,
        long targetTick)
    {
        // Use the normal cancellation transition so both parties' reservations
        // are released. Completed exchanges are not retroactively cancelled.
        foreach (var offer in inventory.Offers.Where(offer => offer.State == DirectBarterState.Open &&
                     (offer.FirstPartyId == ownerId || offer.SecondPartyId == ownerId)).ToArray())
            inventory = InventoryAuthority.CancelDirectBarterOffer(inventory, offer.Id, offer.Revision, ownerId);
        // Ownership freezes without moving stored goods or a living custodian's load.
        // The world drops a deceased owner's carried estate at their last tile.
        var lots = inventory.Lots.Select(lot => lot.OwnerId == ownerId
                ? InventoryHoldRules.WithCustody(lot, InventoryStore.PrepareEstateCustody(lot, estateId, lot.CarrierId == ownerId ? null : lot.CarrierId, null))
                : lot)
            .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray();
        var reservations = inventory.Reservations.Select(reservation => reservation.OwnerId == ownerId &&
                reservation.State is InventoryReservationState.Reserved or InventoryReservationState.PartiallyConsumed or
                    InventoryReservationState.Committed
                ? InventoryStore.PrepareReservationState(reservation, InventoryReservationState.Released)
                : reservation)
            .OrderBy(item => item.Id.Value, StringComparer.Ordinal).ToArray();
        var offers = inventory.Offers.OrderBy(item => item.Id.Value, StringComparer.Ordinal).ToArray();
        var events = inventory.Events.ToList();
        events.Add(InventoryStore.CreateInventoryEvent(checked(inventory.EventHistoryFloor + events.Count + 1L), targetTick, "estate_escrow_created", estateId));
        return InventoryStore.CreateInventoryCheckpoint(targetTick, lots, reservations, offers, events, inventory.EventHistoryFloor, inventory.ArchivedRepairReservationCount);
    }

    private static InventoryCheckpoint WithInventoryTick(
        InventoryCheckpoint inventory,
        long targetTick) =>
        inventory.WorldTick == targetTick
            ? inventory
            : InventoryAuthority.ReleaseExpiredReservations(inventory, targetTick);

    private static SocietyRelationship BirthRelationship(
        SocietyBirthRequest request,
        string childId,
        SocietyRelationshipType type,
        string sourceId)
    {
        return new SocietyRelationship(
            DerivedId.Create($"birth:{request.Id}:{type}:{sourceId}"),
            1,
            type,
            sourceId,
            childId,
            SocietyRelationshipState.Accepted,
            SocietyConsentState.ProtectedLifecycle,
            request.RequestedTick,
            request.RequestedTick,
            type == SocietyRelationshipType.HouseholdMembership ? "household" : "family",
            request.HouseholdId,
            new[] { sourceId, childId }.OrderBy(item => item, StringComparer.Ordinal).ToArray());
    }

    private static string? ResolveNewbornProvider(
        SocietyCheckpoint checkpoint,
        SocietyAgent firstParent,
        SocietyAgent secondParent,
        SocietyBirthRequest request) =>
        request.ProviderPolicy switch
        {
            NewbornProviderPolicy.PerChild => NormalizeOptionalText(request.RequestedProviderBindingId),
            NewbornProviderPolicy.ParentInheritance =>
                firstParent.ProviderBindingId == secondParent.ProviderBindingId
                    ? firstParent.ProviderBindingId
                    : null,
            NewbornProviderPolicy.WorldDefault => checkpoint.WorldDefaultProviderBindingId,
            NewbornProviderPolicy.Hybrid =>
                firstParent.ProviderBindingId is not null &&
                firstParent.ProviderBindingId == secondParent.ProviderBindingId
                    ? firstParent.ProviderBindingId
                    : checkpoint.WorldDefaultProviderBindingId,
            _ => throw new ArgumentOutOfRangeException(nameof(request)),
        };

    private static SocietyCheckpoint ApplyRelationshipProjection(
        SocietyCheckpoint checkpoint,
        SocietyRelationship relationship)
    {
        if (relationship.Type == SocietyRelationshipType.Partnership)
            return checkpoint;
        if (relationship.Type != SocietyRelationshipType.HouseholdMembership &&
            relationship.Type != SocietyRelationshipType.Caregiver)
        {
            return checkpoint;
        }

        if (relationship.HouseholdId is null)
        {
            return checkpoint;
        }

        var household = checkpoint.GetHousehold(relationship.HouseholdId);
        var members = relationship.Type == SocietyRelationshipType.HouseholdMembership
            ? household.MemberIds.Append(relationship.TargetId)
                .Distinct(StringComparer.Ordinal)
                .OrderBy(id => id, StringComparer.Ordinal).ToArray()
            : household.MemberIds;
        var caregivers = relationship.Type == SocietyRelationshipType.Caregiver
            ? household.CaregiverIds.Append(relationship.ProposerId)
                .Distinct(StringComparer.Ordinal)
                .OrderBy(id => id, StringComparer.Ordinal).ToArray()
            : household.CaregiverIds;
        if (relationship.Type == SocietyRelationshipType.Caregiver &&
            relationship.State == SocietyRelationshipState.Accepted &&
            checkpoint.GetAgent(relationship.TargetId) is { } dependent && IsYoungerDependent(dependent) &&
            dependent.HouseholdId == household.Id && checkpoint.GetAgent(relationship.ProposerId).HouseholdId == household.Id &&
            !HasActivePrimaryCaregiver(checkpoint, dependent.Id))
            checkpoint = SetPrimaryCaregiver(checkpoint, relationship.ProposerId, dependent.Id);
        return checkpoint with
        {
            Agents = relationship.Type == SocietyRelationshipType.HouseholdMembership
                ? checkpoint.Agents.Select(item => item.Id == relationship.TargetId
                        ? item with { HouseholdId = household.Id }
                        : item)
                    .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray()
                : checkpoint.Agents,
            Households = checkpoint.Households.Select(item => item.Id == household.Id
                    ? item with { MemberIds = members, CaregiverIds = caregivers }
                    : item)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
        };
    }

    private static SocietyCheckpoint RemoveRelationshipProjection(
        SocietyCheckpoint checkpoint,
        SocietyRelationship relationship,
        bool revokedAcceptedCare)
    {
        if (relationship.Type == SocietyRelationshipType.Partnership)
            return checkpoint;
        if (relationship.Type != SocietyRelationshipType.HouseholdMembership &&
            relationship.Type != SocietyRelationshipType.Caregiver)
        {
            return checkpoint;
        }

        var clearPrimaryCaregiver = revokedAcceptedCare && relationship.Type == SocietyRelationshipType.Caregiver &&
            checkpoint.GetAgent(relationship.TargetId).PrimaryCaregiverId == relationship.ProposerId &&
            !checkpoint.Relationships.Any(other => other.Type == SocietyRelationshipType.Caregiver &&
                other.State == SocietyRelationshipState.Accepted && other.ProposerId == relationship.ProposerId &&
                other.TargetId == relationship.TargetId);
        var agents = relationship.Type == SocietyRelationshipType.HouseholdMembership
            ? checkpoint.Agents.Select(item => item.Id == relationship.TargetId
                    ? item with { HouseholdId = null }
                    : item)
                .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray()
            : clearPrimaryCaregiver
                ? checkpoint.Agents.Select(item => item.Id == relationship.TargetId
                        ? item with { PrimaryCaregiverId = null }
                        : item)
                    .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray()
                : checkpoint.Agents;
        if (relationship.HouseholdId is not { } householdId)
            return clearPrimaryCaregiver ? checkpoint with { Agents = agents } : checkpoint;

        var household = checkpoint.GetHousehold(householdId);
        return checkpoint with
        {
            Agents = agents,
            Households = checkpoint.Households.Select(item => item.Id == household.Id
                    ? item with
                    {
                        MemberIds = relationship.Type == SocietyRelationshipType.HouseholdMembership
                            ? household.MemberIds.Where(id => id != relationship.TargetId).ToArray()
                            : household.MemberIds,
                        CaregiverIds = relationship.Type == SocietyRelationshipType.Caregiver
                            ? household.CaregiverIds.Where(id => id != relationship.ProposerId ||
                                checkpoint.Relationships.Any(other => other.Id != relationship.Id &&
                                    other.Type == SocietyRelationshipType.Caregiver && other.State == SocietyRelationshipState.Accepted &&
                                    other.ProposerId == id && other.HouseholdId == household.Id)).ToArray()
                            : household.CaregiverIds,
                    }
                    : item)
            .OrderBy(item => item.Id, StringComparer.Ordinal).ToArray(),
        };
    }

    private static SocietyCheckpoint ApplyPartnershipFamilyUnit(
        SocietyCheckpoint checkpoint,
        SocietyRelationship relationship)
    {
        var participants = new HashSet<string>([relationship.ProposerId, relationship.TargetId], StringComparer.Ordinal);
        var unitId = DomesticPartnershipId(relationship.Id);
        return checkpoint with
        {
            Agents = checkpoint.Agents.Select(person =>
                participants.Contains(person.Id) || IsYoungerDependent(person) &&
                    person.PrimaryCaregiverId is { } caregiver && participants.Contains(caregiver)
                    ? person with { DomesticFamilyUnitId = unitId }
                    : person).ToArray(),
        };
    }

    private static SocietyCheckpoint SplitPartnershipFamilyUnit(
        SocietyCheckpoint checkpoint,
        SocietyRelationship relationship)
    {
        var participants = new HashSet<string>([relationship.ProposerId, relationship.TargetId], StringComparer.Ordinal);
        var unitByCaregiver = participants.ToDictionary(
            id => id,
            id => DomesticSeparatedId(relationship.Id, id),
            StringComparer.Ordinal);
        return checkpoint with
        {
            Agents = checkpoint.Agents.Select(person =>
                participants.Contains(person.Id)
                    ? person with { DomesticFamilyUnitId = unitByCaregiver[person.Id] }
                    : IsYoungerDependent(person) && person.PrimaryCaregiverId is { } caregiver &&
                        unitByCaregiver.TryGetValue(caregiver, out var unitId)
                        ? person with { DomesticFamilyUnitId = unitId }
                        : person).ToArray(),
        };
    }

    private static bool IsYoungerDependent(SocietyAgent person) =>
        person.Status == SocietyAgentStatus.Active &&
        person.AgeBand is SocietyAgeBand.Infant or SocietyAgeBand.Child or SocietyAgeBand.Adolescent;

    private static string DomesticPersonUnit(string agentId) => DerivedId.Create($"domestic:person:{agentId}");

    private static SocietyOperationResult Commit(
        SocietyCheckpoint checkpoint,
        string kind,
        string detail,
        string? createdId = null)
    {
        var next = CommitMany(checkpoint, [(kind, detail)]);
        return new SocietyOperationResult(next, createdId, [next.Events[^1]]);
    }

    private static SocietyCheckpoint CommitMany(
        SocietyCheckpoint checkpoint,
        IEnumerable<(string Kind, string Detail)> pending)
    {
        var events = checkpoint.Events.ToList();
        foreach (var item in pending)
        {
            events.Add(new SocietyEvent(
                checked(checkpoint.EventHistoryFloor + events.Count + 1L),
                checkpoint.WorldTick,
                NormalizeRequiredText(item.Kind, nameof(item.Kind)),
                NormalizeRequiredText(item.Detail, nameof(item.Detail))));
        }

        var next = checkpoint with { Events = events };
        Validate(next);
        return next;
    }

    private static SocietyOperationResult Reject(
        SocietyCheckpoint checkpoint,
        string kind,
        string detail) =>
        Commit(checkpoint, kind, detail);

    private static bool HasActivePartnership(
        SocietyCheckpoint checkpoint,
        string firstId,
        string secondId) =>
        checkpoint.Relationships.Any(item =>
            item.Type == SocietyRelationshipType.Partnership &&
            item.State == SocietyRelationshipState.Accepted &&
            ((item.ProposerId == firstId && item.TargetId == secondId) ||
             (item.ProposerId == secondId && item.TargetId == firstId)));

    private static bool IsAdult(SocietyAgent agent) =>
        agent.Status == SocietyAgentStatus.Active &&
        agent.AgeBand is SocietyAgeBand.Adult or SocietyAgeBand.Elder;

    // Elders may care for a child but cannot be its parents.
    private static bool CanHaveChildren(SocietyAgent agent) =>
        agent.Status == SocietyAgentStatus.Active && agent.AgeBand == SocietyAgeBand.Adult;

    private static void EnsureActive(SocietyCheckpoint checkpoint, string id)
    {
        if (checkpoint.GetAgent(id).Status != SocietyAgentStatus.Active)
        {
            throw new InvalidOperationException($"Agent '{id}' is not active.");
        }
    }

    private static void EnsureBarterParty(SocietyCheckpoint checkpoint, string id)
    {
        EnsureLivingParty(checkpoint, id);
        var agent = checkpoint.Agents.FirstOrDefault(item => item.Id == id);
        if (agent is not null && agent.AgeBand is not (SocietyAgeBand.Adult or SocietyAgeBand.Elder))
        {
            throw new InvalidOperationException("Only adults and elders can participate in barter offers.");
        }
    }

    private static void EnsureLivingParty(
        SocietyCheckpoint checkpoint,
        string id)
    {
        if (!checkpoint.Agents.Any(item =>
                item.Id == id && item.Status == SocietyAgentStatus.Active) &&
            !checkpoint.Households.Any(item => item.Id == id) &&
            !checkpoint.Organizations.Any(item => item.Id == id))
        {
            throw new InvalidOperationException($"Party '{id}' is not an active society participant.");
        }
    }

    private static void ValidateProposal(
        SocietyRelationshipProposal proposal,
        long worldTick)
    {
        NormalizeRequiredText(proposal.Id, nameof(proposal.Id));
        NormalizeRequiredText(proposal.ProposerId, nameof(proposal.ProposerId));
        NormalizeRequiredText(proposal.TargetId, nameof(proposal.TargetId));
        NormalizeRequiredText(proposal.PrivacyClass, nameof(proposal.PrivacyClass));
        if (proposal.Revision <= 0 || proposal.ProposerId == proposal.TargetId ||
            proposal.RequestedTick < 0 || proposal.RequestedTick > worldTick ||
            proposal.Type is SocietyRelationshipType.BiologicalParentage)
        {
            throw new ArgumentOutOfRangeException(nameof(proposal));
        }
    }

    private static void ValidateBirthRequest(
        SocietyBirthRequest request,
        long worldTick)
    {
        NormalizeRequiredText(request.Id, nameof(request.Id));
        NormalizeRequiredText(request.FirstParentId, nameof(request.FirstParentId));
        NormalizeRequiredText(request.SecondParentId, nameof(request.SecondParentId));
        NormalizeRequiredText(request.HouseholdId, nameof(request.HouseholdId));
        NormalizeRequiredText(request.PrimaryCaregiverId ?? string.Empty, nameof(request.PrimaryCaregiverId));
        if (request.ChildName is not null && (string.IsNullOrWhiteSpace(request.ChildName) || request.ChildName.Length > 80))
        {
            throw new ArgumentException("A child name must contain between 1 and 80 characters.", nameof(request));
        }
        if (request.Revision <= 0 || request.FirstParentId == request.SecondParentId ||
            request.FoodQuantity <= 0 || request.RequestedTick < 0 ||
            request.RequestedTick > worldTick || request.CaregiverIds.Count == 0 ||
            request.ConsentingParentIds.Count == 0)
        {
            throw new ArgumentOutOfRangeException(nameof(request));
        }
        if (request.FoodContributions is { } food &&
            (food.Count is < 1 or > 4 || food.Any(item => item is null ||
                string.IsNullOrWhiteSpace(item.LotId) || item.Quantity <= 0) ||
             food.Select(item => item.LotId).Distinct(StringComparer.Ordinal).Count() != food.Count ||
             !food.Select(item => item.LotId).SequenceEqual(food.Select(item => item.LotId).Order(StringComparer.Ordinal)) ||
             food[0].LotId != request.FoodLotId || food.Sum(item => (long)item.Quantity) != request.FoodQuantity))
            throw new ArgumentException("Birth food contributions must be distinct, ordered, positive and total the requested quantity.", nameof(request));
    }

    private static bool BirthFoodRequestMatches(InventoryCheckpoint inventory, SocietyBirthRequest request)
    {
        var purpose = $"birth:{request.Id}";
        var legacyId = DerivedId.Create(purpose + ":food");
        var receipts = inventory.Reservations.Where(item => item.Purpose == purpose).ToArray();
        if (request.FoodContributions is not { } food)
            return receipts.All(receipt => receipt.Id == legacyId);
        if (receipts.Any(item => item.Id == legacyId) || receipts.Length != food.Count)
            return false;
        for (var index = 0; index < food.Count; index++)
        {
            var id = DerivedId.Create(purpose + ":food:" + index.ToString("D2", CultureInfo.InvariantCulture));
            var receipt = receipts.SingleOrDefault(item => item.Id == id);
            if (receipt is null || receipt.State != InventoryReservationState.Completed ||
                receipt.LotId != food[index].LotId || receipt.Quantity != food[index].Quantity)
                return false;
        }
        return true;
    }

    private static void ValidateAgents(
        IReadOnlyList<SocietyAgent> agents,
        SocietyConfig config,
        long worldTick,
        SocietyLifeClock? lifeClock = null)
    {
        EnsureCanonicalIds(agents.Select(item => item.Id), "agents");
        var chosenNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var agent in agents)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(agent.Name);
            if (agent.HasChosenName &&
                (agent.NeedsName || AgentNameRules.FirstNameKey(agent.Name) is not { } firstName ||
                 !chosenNames.Add(firstName)))
                throw new InvalidDataException("Chosen first names must be valid, unique and no longer awaiting naming.");
            if (string.IsNullOrWhiteSpace(agent.DomesticFamilyUnitId) ||
                agent.PrimaryCaregiverId is { } caregiverId &&
                    (caregiverId == agent.Id || !agents.Any(person => person.Id == caregiverId)))
                throw new InvalidDataException("An agent's domestic family unit or primary caregiver is invalid.");
            if (agent.BirthTick > worldTick ||
                agent.BirthLifeTick is { } birthLife && (lifeClock is null || birthLife > lifeClock.At(worldTick)) ||
                agent.HealthBasisPoints is < 0 or > 10_000 ||
                agent.LastLifecycleYearChecked < 0 ||
                agent.Status == SocietyAgentStatus.Active && agent.DeathTick is not null ||
                agent.Status == SocietyAgentStatus.Dead && agent.DeathTick is null)
            {
                throw new InvalidDataException("An agent lifecycle record is malformed.");
            }

            var birth = agent.BirthLifeTick ?? agent.BirthTick;
            var lifeTick = lifeClock?.At(worldTick) ?? worldTick;
            var expectedBand = config.AgeBandAt(birth, lifeTick);
            if (agent.Status == SocietyAgentStatus.Active &&
                agent.AgeBand != expectedBand &&
                birth + config.TicksPerLifecycleAge * agent.LastLifecycleYearChecked <= lifeTick)
            {
                throw new InvalidDataException(
                    $"An active agent has a stale age band: {agent.Id}:{agent.AgeBand}:{expectedBand}:" +
                    $"tick={worldTick}:birth={agent.BirthTick}:last={agent.LastLifecycleYearChecked}.");
            }
        }
    }

    private static int MortalityRoll(
        string worldId,
        string agentId,
        int ageYears)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(
            $"clankerworld.society-mortality/v1|{worldId}|{agentId}|{ageYears}"));
        return checked((int)(BitConverter.ToUInt32(bytes, 0) % 10_000));
    }

    private static string[] CanonicalIds(
        IEnumerable<string> ids,
        string name)
    {
        ArgumentNullException.ThrowIfNull(ids);
        var actual = ids.Select(id => NormalizeRequiredText(id, name))
            .Distinct(StringComparer.Ordinal)
            .OrderBy(id => id, StringComparer.Ordinal).ToArray();
        if (actual.Length == 0)
        {
            throw new ArgumentException("At least one ID is required.", name);
        }

        return actual;
    }

    private static void EnsureCanonicalIds(
        IEnumerable<string?> ids,
        string name)
    {
        var actual = ids.ToArray();
        if (actual.Any(string.IsNullOrWhiteSpace) ||
            actual.Distinct(StringComparer.Ordinal).Count() != actual.Length ||
            !actual.SequenceEqual(actual.OrderBy(id => id, StringComparer.Ordinal)))
        {
            throw new InvalidDataException($"Society {name} must contain unique canonical IDs.");
        }
    }

    private static int ValidateBasisPoints(int value, string name)
    {
        if (value is < 0 or > 10_000)
        {
            throw new ArgumentOutOfRangeException(name);
        }

        return value;
    }

    private static string NormalizeRequiredText(string value, string name)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(value, name);
        return value.Trim();
    }

    private static string? NormalizeOptionalText(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
