from pathlib import Path
import json, zipfile, hashlib
p=Path('/workspace/review-coverage-33837055/fix2556')
target=Path('/workspace/review-evidence-33837055/.evidence/keep/review-33837055')
native=Path('/workspace/native-2795-final-33837055')
r=json.loads((p/'focused-reconciliation.json').read_text())
assert r['cases']==290 and r['methods']==180 and r['wholeClasses']==32 and not r['partialClasses'] and r['outcomes']=={'Passed':290}
sets={
 'source':[(f,f.relative_to(p)) for f in sorted(p.rglob('*')) if f.is_file() and f.name!='archive-manifest.json' and not ({'baseline-binaries','native-binaries','first-head-d496','ci'}&set(f.relative_to(p).parts)) and f.suffix not in {'.dll','.pdb','.zip'}],
 'binaries':[(f,f.relative_to(p)) for folder in ['baseline-binaries','native-binaries'] for f in sorted((p/folder).rglob('*')) if f.is_file()],
 'native':[(f,f.relative_to(native)) for f in sorted(native.rglob('*')) if f.is_file()]
}
rows=[]
for label,files in sets.items():
 path=target/f'pr2795-{label}.zip'
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,9) as z:
  for f,name in files:z.write(f,name)
 assert path.stat().st_size<32*1024*1024
 rows.append({'kind':label,'file':path.name,'bytes':path.stat().st_size,'files':len(files),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(p/'archive-manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
