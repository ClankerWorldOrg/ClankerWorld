import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

DOTNET = '/workspace/.tools/dotnet/dotnet'
PROJECT = 'tests/ClankerWorld.Tests/ClankerWorld.Tests.csproj'
SETTINGS = 'skills/test-audit/references/coverage.runsettings'
OUTPUT = 'tests/ClankerWorld.Tests/bin/Release/net10.0'
PINS = ['ClankerWorld.' + assembly + suffix for assembly in ('Simulation', 'Server') for suffix in ('.dll', '.pdb')]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def invoke(args, cwd, log):
    with open(log, 'w') as stream:
        subprocess.run(args, cwd=cwd, env=dict(os.environ, DOTNET_PROCESSOR_COUNT='4', ClankerWorld__Clock__StrictTickFailures='true'),
                       stdout=stream, stderr=subprocess.STDOUT, check=True)

def collect(checkout, destination, selected):
    destination.mkdir(parents=True, exist_ok=False)
    command = [DOTNET, 'test', PROJECT, '-c', 'Release', '--no-build', '--filter', selected]
    invoke(command + ['--list-tests'], checkout, destination / 'discovery.log')
    invoke(command + ['--settings', SETTINGS, '--collect', 'XPlat Code Coverage',
                     '--results-directory', str(destination), '--logger', 'trx;LogFileName=coverage.trx',
                     '--', 'xUnit.MaxParallelThreads=4',
                     'DataCollectionRunSettings.DataCollectors.DataCollector.Configuration.Format=cobertura,json'],
           checkout, destination / 'coverage.log')

def read_report(directory, expected, skip_names=()):
    reports = list(directory.glob('*/coverage.json'))
    assert len(reports) == 1, reports
    xml = ET.parse(reports[0].with_name('coverage.cobertura.xml')).getroot()
    trx = ET.parse(directory / 'coverage.trx').getroot()
    counters = trx.find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib
    assert int(counters['executed']) == int(counters['passed']) == expected, counters
    assert int(counters['failed']) == 0, counters
    results = trx.findall('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}UnitTestResult')
    assert len(results) == int(counters['total']) == expected + len(skip_names), counters
    assert sum(item.attrib['outcome'] == 'Passed' for item in results) == expected
    actual_skips = sorted(item.attrib['testName'] for item in results if item.attrib['outcome'] == 'NotExecuted')
    assert actual_skips == sorted(skip_names), actual_skips
    assert all(item.attrib['outcome'] in ['Passed', 'NotExecuted'] for item in results)
    counters['verified_native_skip_names'] = actual_skips
    modules = json.loads(reports[0].read_text())
    result = {}
    for module, files in modules.items():
        lines, branches = {}, {}
        for filename, classes in files.items():
            assert '/src/' in filename and '/tests/' not in filename, filename
            filename = 'src/' + filename.split('/src/', 1)[1]
            for classname, methods in classes.items():
                for method, points in methods.items():
                    for line, hits in points['Lines'].items():
                        key = (filename, int(line))
                        lines[key] = lines.get(key, False) or hits > 0
                    for branch in points['Branches']:
                        key = (filename, classname, method) + tuple(branch[field] for field in ('Line', 'Offset', 'EndOffset', 'Path', 'Ordinal'))
                        assert key not in branches, key
                        branches[key] = branch['Hits'] > 0
        result[module] = {'lines': lines, 'branches': branches}
    for label, attr in [('lines', 'lines'), ('branches', 'branches')]:
        assert sum(len(value[label]) for value in result.values()) == int(xml.attrib[attr + '-valid'])
        assert sum(sum(value[label].values()) for value in result.values()) == int(xml.attrib[attr + '-covered'])
    return result, reports[0].with_name('coverage.cobertura.xml'), counters

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('base', type=Path)
    parser.add_argument('head', type=Path)
    parser.add_argument('filter')
    parser.add_argument('evidence', type=Path)
    parser.add_argument('--before-count', type=int, required=True)
    parser.add_argument('--after-count', type=int, required=True)
    parser.add_argument('--head-existing', type=Path)
    parser.add_argument('--expected-skips', type=int, default=0)
    parser.add_argument('--expected-skip-name', action='append', default=[])
    parser.add_argument('--reuse-existing', action='store_true')
    args = parser.parse_args()
    assert len(args.expected_skip_name) == args.expected_skips
    args.evidence.mkdir(parents=True, exist_ok=args.reuse_existing)
    expected_paths = ['src', 'Directory.Build.props', 'Directory.Packages.props', 'global.json', PROJECT, SETTINGS]
    base_sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=args.base, text=True).strip()
    head_sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=args.head, text=True).strip()
    source_diff = subprocess.check_output(['git', 'diff', base_sha, head_sha, '--'] + expected_paths, cwd=args.head)
    assert not source_diff, 'Production/configuration inputs differ'
    settings = [(checkout / SETTINGS).read_bytes() for checkout in [args.base, args.head]]
    assert settings[0] == settings[1]
    original = {name: (args.base / OUTPUT / name).read_bytes() for name in PINS}
    frozen = {name: (args.head / OUTPUT / name).read_bytes() for name in PINS}
    manifest = {'base': base_sha, 'head': head_sha, 'filter': args.filter, 'processor_count': 4,
                'xunit_threads': 4, 'strict_tick_failures': True, 'expected_native_skips': args.expected_skips, 'settings_sha256': digest(settings[0]),
                'production_pins': {name: digest(data) for name, data in frozen.items()},
                'test_dll_sha256': {str(checkout): digest((checkout / OUTPUT / 'ClankerWorld.Tests.dll').read_bytes()) for checkout in [args.base, args.head]}}
    if args.reuse_existing:
        assert json.loads((args.evidence / 'manifest.json').read_text()) == manifest, 'Measurement inputs changed'
    else:
        (args.evidence / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    try:
        for name, data in frozen.items():
            (args.base / OUTPUT / name).write_bytes(data)
        before_dir = args.evidence / 'before'
        after_dir = args.head_existing or args.evidence / 'after'
        if not args.reuse_existing:
            collect(args.base, before_dir, args.filter)
        if not args.head_existing and not args.reuse_existing:
            collect(args.head, after_dir, args.filter)
        for checkout in [args.base, args.head]:
            assert all((checkout / OUTPUT / name).read_bytes() == data for name, data in frozen.items()), 'Collector failed to restore pinned production bytes'
        before, before_xml, before_counts = read_report(before_dir, args.before_count, args.expected_skip_name)
        after, after_xml, after_counts = read_report(after_dir, args.after_count, args.expected_skip_name)
        assert before.keys() == after.keys()
        report = {'cases_before': before_counts, 'cases_after': after_counts, 'assemblies': {}}
        losses = []
        for module in before:
            summary = {}
            for label in ['lines', 'branches']:
                left, right = before[module][label], after[module][label]
                assert left.keys() == right.keys(), (module, label, 'coverage scope changed')
                lost = [key for key, hit in left.items() if hit and not right[key]]
                gained = [key for key, hit in right.items() if hit and not left[key]]
                summary[label] = {'valid': len(left), 'before': sum(left.values()), 'after': sum(right.values()),
                                  'lost': lost, 'gained': gained, 'unoffset_loss_pp': 100 * len(lost) / len(left) if left else 0}
                losses.extend((module, label, key) for key in lost)
            report['assemblies'][module] = summary
        (args.evidence / 'branch-identity-comparison.json').write_text(json.dumps(report, indent=2))
        assert all(value['unoffset_loss_pp'] <= 2 for assembly in report['assemblies'].values() for value in assembly.values()), 'Conservative unoffset loss exceeds 2 percentage points'
        invoke(['python3', '/workspace/ClankerWorld/skills/test-audit/scripts/compare_coverage.py', str(before_xml), str(after_xml),
                '--repo', str(args.head), '--threshold-scope', 'each'], args.head, args.evidence / 'official-comparison.log')
        print(json.dumps({'evidence': str(args.evidence), 'lost': len(losses),
                          'assemblies': {m: {k: {a: b for a, b in v.items() if a not in ['lost', 'gained']} |
                                                   {'lost_count': len(v['lost']), 'gained_count': len(v['gained'])}
                                            for k, v in data.items()} for m, data in report['assemblies'].items()}}), flush=True)
    finally:
        for name, data in original.items():
            (args.base / OUTPUT / name).write_bytes(data)
        assert all((args.base / OUTPUT / name).read_bytes() == data for name, data in original.items())

if __name__ == '__main__':
    main()
