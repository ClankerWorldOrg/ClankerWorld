using System.Collections.Concurrent;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
using ClankerWorld.Simulation.World;

AssemblyLoadContext.Default.Resolving += (_, name) =>
{
    var path = "/workspace/fix-2785-33837055/tests/ClankerWorld.Tests/bin/Release/net10.0/" + name.Name + ".dll";
    return File.Exists(path) ? AssemblyLoadContext.Default.LoadFromAssemblyPath(path) : null;
};
Probe.Mode = args[0];
Probe.Dedicated = args[1] == "dedicated";
var context = new PumpContext();
SynchronizationContext.SetSynchronizationContext(context);
var task = new ClankerWorld.Tests.PauseProbeFixture().PauseIsResponsiveAndInvalidatesPendingProviderWork();
Exception? failure = null;
try
{
    while (!task.IsCompleted) context.Pump();
    task.GetAwaiter().GetResult();
}
catch (Exception error) { failure = error; }
finally
{
    Probe.Cleanup();
    SynchronizationContext.SetSynchronizationContext(null);
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    mode = Probe.Mode,
    worker = Probe.Dedicated ? "dedicated" : "thread-pool",
    fullOriginalFixturePassed = failure is null,
    failure = failure?.ToString(),
    events = Probe.Events.ToArray()
}, new JsonSerializerOptions { WriteIndented = true }));

sealed class PumpContext : SynchronizationContext
{
    private readonly BlockingCollection<(SendOrPostCallback Callback, object? State)> queue = new();
    public override void Post(SendOrPostCallback callback, object? state) => queue.Add((callback, state));
    public void Pump()
    {
        if (queue.TryTake(out var item, 20)) item.Callback(item.State);
    }
}

static class Probe
{
    public static string Mode = "pool";
    public static bool Dedicated;
    public static ConcurrentQueue<object> Events = new();
    private static readonly Stopwatch watch = new();
    private static readonly ManualResetEventSlim entered = new();
    private static readonly ManualResetEventSlim release = new();
    private static readonly ManualResetEventSlim workerExited = new();
    private static Thread? releaser;
    private static Task? pause;
    private static int oldMaxWorkers, oldMaxIo, oldMinWorkers, oldMinIo;
    private static bool changedPool;
    private static int pauseEntered;

    private static void Trace(string name, object? detail = null) => Events.Enqueue(new
    {
        name,
        elapsedMilliseconds = watch.Elapsed.TotalMilliseconds,
        thread = Environment.CurrentManagedThreadId,
        poolThread = Thread.CurrentThread.IsThreadPoolThread,
        detail
    });

    public static void Poison(WorldRuntime runtime)
    {
        var gate = (SemaphoreSlim)typeof(WorldRuntime).GetField("gate", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(runtime)!;
        watch.Start();
        Trace("before-pause", new { originalRuntimeGateAvailable = gate.CurrentCount == 1 });
        if (Mode == "normal") return;
        if (Mode == "pool")
        {
            ThreadPool.GetMaxThreads(out oldMaxWorkers, out oldMaxIo);
            ThreadPool.GetMinThreads(out oldMinWorkers, out oldMinIo);
            if (!ThreadPool.SetMinThreads(1, oldMinIo) || !ThreadPool.SetMaxThreads(1, oldMaxIo))
                throw new InvalidOperationException("Cannot isolate one thread-pool worker.");
            changedPool = true;
            ThreadPool.QueueUserWorkItem(_ =>
            {
                entered.Set();
                release.Wait();
                workerExited.Set();
            });
        }
        else if (Mode == "gate")
        {
            new Thread(() =>
            {
                gate.Wait();
                entered.Set();
                release.Wait();
                gate.Release();
                workerExited.Set();
            }) { IsBackground = true }.Start();
        }
        else throw new ArgumentException("Unknown mode.");
        if (!entered.Wait(TimeSpan.FromSeconds(5))) throw new TimeoutException("Load worker did not start.");
        Trace("load-established");
        releaser = new Thread(() =>
        {
            Thread.Sleep(3100);
            Trace("after-three-seconds", new { pauseEntered = Volatile.Read(ref pauseEntered) == 1, status = pause?.Status.ToString() });
            Thread.Sleep(900);
            Trace("release-load");
            release.Set();
        }) { IsBackground = true };
        releaser.Start();
    }

    public static void InvokePause(WorldRuntime runtime)
    {
        Interlocked.Exchange(ref pauseEntered, 1);
        Trace("pause-entered");
        runtime.Pause();
        Trace("pause-returned");
    }
    public static void Track(Task task) { pause = task; Trace("pause-submitted"); }

    public static Task StartPause(WorldRuntime runtime)
    {
        void Invoke()
        {
            Interlocked.Exchange(ref pauseEntered, 1);
            Trace("pause-entered");
            runtime.Pause();
            Trace("pause-returned");
        }
        Trace("pause-submitted");
        pause = Dedicated
            ? Task.Factory.StartNew(Invoke, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default)
            : Task.Run(Invoke);
        return pause;
    }

    public static async Task RecordBoundAsync(Task task)
    {
        try { await task; Trace("bound-passed"); }
        catch (Exception error) { Trace("bound-failed", error.GetType().Name); release.Set(); if (pause is not null) await pause.WaitAsync(TimeSpan.FromSeconds(5)); throw; }
    }

    public static void Cleanup()
    {
        release.Set();
        releaser?.Join();
        if (Mode != "normal") workerExited.Wait(TimeSpan.FromSeconds(5));
        if (changedPool)
        {
            ThreadPool.SetMaxThreads(oldMaxWorkers, oldMaxIo);
            ThreadPool.SetMinThreads(oldMinWorkers, oldMinIo);
        }
    }
}
