using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;
using System.Reflection;
using System.Reflection.Emit;
var root=args[0];var output=args[1];var reports=new List<object>();
var psi=new System.Diagnostics.ProcessStartInfo("git"){RedirectStandardOutput=true};psi.ArgumentList.Add("-C");psi.ArgumentList.Add(root);psi.ArgumentList.Add("rev-parse");psi.ArgumentList.Add("HEAD");var headProcess=System.Diagnostics.Process.Start(psi)!;var expectedHead=headProcess.StandardOutput.ReadToEnd().Trim();headProcess.WaitForExit();if(headProcess.ExitCode!=0)throw new Exception("git head failed");
foreach(var name in new[]{"ClankerWorld.Server","ClankerWorld.Simulation"})
{
 var before=Read(output+"/baseline-binaries/"+name+".dll");var path=root+"/src/"+name+"/bin/Release/net10.0/"+name+".dll";var after=Read(path);
 var removed=before.Keys.Except(after.Keys).ToArray();var added=after.Keys.Except(before.Keys).ToArray();var changed=before.Keys.Intersect(after.Keys).Where(k=>before[k]!=after[k]).ToArray();
 var detail=new{assembly=name,before=before.Count,after=after.Count,removed,added,changed};File.WriteAllText(output+"/"+name+"-compiled-inventory.json",JsonSerializer.Serialize(detail,new JsonSerializerOptions{WriteIndented=true}));
 if(removed.Length+added.Length+changed.Length>0)throw new Exception(name+" compiled inventory differs: "+JsonSerializer.Serialize(detail));
 var beforeVersion=InformationalVersion(output+"/baseline-binaries/"+name+".dll");var afterVersion=InformationalVersion(path);if(!beforeVersion.EndsWith("835f9db1155bfb03fb741b2d5bcde9de50031316")||!afterVersion.EndsWith(expectedHead))throw new Exception("compiled build revision mismatch "+name+" "+beforeVersion+" "+afterVersion);
 var testPath=root+"/tests/ClankerWorld.Tests/bin/Release/net10.0/"+name+".dll";if(!File.ReadAllBytes(path).SequenceEqual(File.ReadAllBytes(testPath)))throw new Exception("test copy differs: "+name);
 reports.Add(new{assembly=name,entries=after.Count,bodyAndMetadataExactlyEqual=true,testCopyByteEqual=true,beforeVersion,afterVersion,sha256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path)))});
}
File.WriteAllText(output+"/compiled-proof.json",JsonSerializer.Serialize(reports,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(reports));
static SortedDictionary<string,string> Read(string path)
{
 using var pe=new PEReader(File.OpenRead(path));var r=pe.GetMetadataReader();var result=new SortedDictionary<string,string>();
 string TypeName(TypeDefinitionHandle h){var t=r.GetTypeDefinition(h);return t.GetDeclaringType().IsNil?r.GetString(t.Namespace)+"."+r.GetString(t.Name):TypeName(t.GetDeclaringType())+"+"+r.GetString(t.Name);}
 string Hex(BlobHandle h)=>Convert.ToHexString(r.GetBlobBytes(h));
 string Strings(byte[] il){var ops=typeof(OpCodes).GetFields(BindingFlags.Public|BindingFlags.Static).Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)!).ToDictionary(o=>unchecked((ushort)o.Value));var values=new List<string>();for(int i=0;i<il.Length;){ushort code=il[i++];if(code==0xfe)code=(ushort)(0xfe00|il[i++]);var op=ops[code];if(op.OperandType==OperandType.InlineString)values.Add(r.GetUserString(MetadataTokens.UserStringHandle(BitConverter.ToInt32(il,i)&0xffffff)));var size=op.OperandType switch{OperandType.InlineNone=>0,OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar=>1,OperandType.InlineVar=>2,OperandType.InlineI8 or OperandType.InlineR=>8,OperandType.InlineSwitch=>4+4*BitConverter.ToInt32(il,i),_=>4};i+=size;}return JsonSerializer.Serialize(values);}
 string Attr(CustomAttributeHandleCollection hs)=>string.Join(";",hs.Select(h=>{var a=r.GetCustomAttribute(h);return MetadataTokens.GetToken(a.Constructor)+":"+Hex(a.Value);}));
 foreach(var th in r.TypeDefinitions)
 {
  var t=r.GetTypeDefinition(th);var tn=TypeName(th);result["type|"+tn]=$"{t.Attributes}|{MetadataTokens.GetToken(t.BaseType)}|{Attr(t.GetCustomAttributes())}|"+string.Join(";",t.GetInterfaceImplementations().Select(h=>MetadataTokens.GetToken(r.GetInterfaceImplementation(h).Interface)));
  foreach(var mh in t.GetMethods())
  {
   var m=r.GetMethodDefinition(mh);var key="method|"+tn+"|"+r.GetString(m.Name)+"|"+Hex(m.Signature);var value=$"{m.Attributes}|{m.ImplAttributes}|{Attr(m.GetCustomAttributes())}|";
   value+=string.Join(";",m.GetParameters().Select(ph=>{var p=r.GetParameter(ph);var c=p.GetDefaultValue();return $"{p.SequenceNumber}:{r.GetString(p.Name)}:{p.Attributes}:{Attr(p.GetCustomAttributes())}:"+(c.IsNil?"":Hex(r.GetConstant(c).Value));}));
   if(m.RelativeVirtualAddress!=0){var b=pe.GetMethodBody(m.RelativeVirtualAddress);value+=$"|{b.MaxStack}|{b.LocalVariablesInitialized}|{MetadataTokens.GetToken(b.LocalSignature)}|"+Convert.ToHexString(b.GetILBytes()??[])+"|"+Strings(b.GetILBytes()??[])+"|"+string.Join(";",b.ExceptionRegions.Select(e=>$"{e.Kind}:{e.TryOffset}:{e.TryLength}:{e.HandlerOffset}:{e.HandlerLength}:{MetadataTokens.GetToken(e.CatchType)}:{e.FilterOffset}"));}
   result.Add(key,value);
  }
  foreach(var fh in t.GetFields()){var f=r.GetFieldDefinition(fh);var c=f.GetDefaultValue();result.Add("field|"+tn+"|"+r.GetString(f.Name),$"{f.Attributes}|{Hex(f.Signature)}|{Attr(f.GetCustomAttributes())}|"+(c.IsNil?"":Hex(r.GetConstant(c).Value)));}
  foreach(var ph in t.GetProperties()){var p=r.GetPropertyDefinition(ph);result.Add("property|"+tn+"|"+r.GetString(p.Name),$"{p.Attributes}|{Hex(p.Signature)}|{Attr(p.GetCustomAttributes())}");}
  foreach(var eh in t.GetEvents()){var e=r.GetEventDefinition(eh);result.Add("event|"+tn+"|"+r.GetString(e.Name),$"{e.Attributes}|{MetadataTokens.GetToken(e.Type)}|{Attr(e.GetCustomAttributes())}");}
 }
 foreach(var h in r.TypeReferences){var t=r.GetTypeReference(h);result.Add("type-reference|"+MetadataTokens.GetToken(h),r.GetString(t.Namespace)+"."+r.GetString(t.Name)+"|"+MetadataTokens.GetToken(t.ResolutionScope));}
 foreach(var h in r.MemberReferences){var m=r.GetMemberReference(h);result.Add("member-reference|"+MetadataTokens.GetToken(h),r.GetString(m.Name)+"|"+Hex(m.Signature)+"|"+MetadataTokens.GetToken(m.Parent));}
 for(var i=1;i<=r.GetTableRowCount(TableIndex.TypeSpec);i++){var h=MetadataTokens.TypeSpecificationHandle(i);result.Add("type-specification|"+i,Hex(r.GetTypeSpecification(h).Signature));}
 for(var i=1;i<=r.GetTableRowCount(TableIndex.MethodSpec);i++){var h=MetadataTokens.MethodSpecificationHandle(i);var m=r.GetMethodSpecification(h);result.Add("method-specification|"+i,Hex(m.Signature)+"|"+MetadataTokens.GetToken(m.Method));}
 for(var i=1;i<=r.GetTableRowCount(TableIndex.StandAloneSig);i++){var h=MetadataTokens.StandaloneSignatureHandle(i);result.Add("standalone-signature|"+i,Hex(r.GetStandaloneSignature(h).Signature));}
 return result;
}

static string InformationalVersion(string path){using var pe=new PEReader(File.OpenRead(path));var r=pe.GetMetadataReader();foreach(var h in r.GetAssemblyDefinition().GetCustomAttributes()){var a=r.GetCustomAttribute(h);if(a.Constructor.Kind!=HandleKind.MemberReference)continue;var m=r.GetMemberReference((MemberReferenceHandle)a.Constructor);if(m.Parent.Kind!=HandleKind.TypeReference)continue;var t=r.GetTypeReference((TypeReferenceHandle)m.Parent);if(r.GetString(t.Name)!="AssemblyInformationalVersionAttribute")continue;var b=r.GetBlobReader(a.Value);if(b.ReadUInt16()!=1)throw new Exception("attribute format");return b.ReadSerializedString()!;}throw new Exception("missing build identity "+path);}
