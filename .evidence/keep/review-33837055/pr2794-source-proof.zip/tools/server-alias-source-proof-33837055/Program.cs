using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=args[0];var output=args[1];
var expected=JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(output+"/expected-sources.json"))!;
foreach(var (k,v) in JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(output+"/test-expected-sources.json"))!){if(expected.TryGetValue(k,out var prior)&&Tokens(prior)!=Tokens(v))throw new Exception("inconsistent expected source "+k);expected[k]=v;}
var before=JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(output+"/baseline-sources.json"))!.ToDictionary(x=>Path.Combine(root,x.Key),x=>x.Value);
foreach(var (k,v) in JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(output+"/baseline-test-sources.json"))!){if(!before.ContainsKey(k))before[k]=v;}
var checks=new List<object>();var totalAsserts=0;var methodsBefore=new HashSet<string>();var methodsAfter=new HashSet<string>();
foreach(var (file,content) in expected)
{
 var actual=File.ReadAllText(file);if(Tokens(content)!=Tokens(actual))throw new Exception("unplanned tokens "+file);
 if(!before.TryGetValue(file,out var original))throw new Exception("missing baseline "+file);
 var b=CSharpSyntaxTree.ParseText(original).GetRoot();var a=CSharpSyntaxTree.ParseText(actual).GetRoot();
 var comments=b.DescendantTrivia().Where(t=>t.IsKind(SyntaxKind.SingleLineCommentTrivia)||t.IsKind(SyntaxKind.MultiLineCommentTrivia)).Select(t=>t.ToFullString()).ToArray();
 var ac=a.DescendantTrivia().Where(t=>t.IsKind(SyntaxKind.SingleLineCommentTrivia)||t.IsKind(SyntaxKind.MultiLineCommentTrivia)).Select(t=>t.ToFullString()).ToArray();if(!comments.SequenceEqual(ac))throw new Exception("ordinary comments changed "+file);
 var literals=b.DescendantTokens().Where(t=>t.IsKind(SyntaxKind.StringLiteralToken)||t.IsKind(SyntaxKind.Utf8StringLiteralToken)||t.IsKind(SyntaxKind.InterpolatedStringTextToken)||t.IsKind(SyntaxKind.NumericLiteralToken)||t.IsKind(SyntaxKind.CharacterLiteralToken)).Select(t=>t.Text).ToArray();
 var al=a.DescendantTokens().Where(t=>t.IsKind(SyntaxKind.StringLiteralToken)||t.IsKind(SyntaxKind.Utf8StringLiteralToken)||t.IsKind(SyntaxKind.InterpolatedStringTextToken)||t.IsKind(SyntaxKind.NumericLiteralToken)||t.IsKind(SyntaxKind.CharacterLiteralToken)).Select(t=>t.Text).ToArray();if(!literals.SequenceEqual(al))throw new Exception("literal sequence changed "+file);
 var asserts=b.DescendantNodes().OfType<InvocationExpressionSyntax>().Where(n=>n.Expression is MemberAccessExpressionSyntax m&&m.Expression.ToString()=="Assert").Select(n=>((MemberAccessExpressionSyntax)n.Expression).Name.Identifier.ValueText).ToArray();
 var aa=a.DescendantNodes().OfType<InvocationExpressionSyntax>().Where(n=>n.Expression is MemberAccessExpressionSyntax m&&m.Expression.ToString()=="Assert").Select(n=>((MemberAccessExpressionSyntax)n.Expression).Name.Identifier.ValueText).ToArray();if(!asserts.SequenceEqual(aa))throw new Exception("assertion inventory changed "+file);totalAsserts+=asserts.Length;
 foreach(var node in new[]{b,a})foreach(var m in node.DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>m.AttributeLists.SelectMany(x=>x.Attributes).Any(x=>x.Name.ToString().Split('.').Last() is "Fact" or "Theory"))){var key=file+"|"+string.Join("+",m.Ancestors().OfType<ClassDeclarationSyntax>().Reverse().Select(c=>c.Identifier.ValueText))+"|"+m.Identifier.ValueText; (ReferenceEquals(node,b)?methodsBefore:methodsAfter).Add(key);}
 checks.Add(new{file=Path.GetRelativePath(root,file),comments=comments.Length,literals=literals.Length,assertions=asserts.Length});
}
if(!methodsBefore.SetEquals(methodsAfter))throw new Exception("Fact/Theory inventory changed");
var report=new{files=expected.Count,assertionsPreserved=totalAsserts,factTheoryMethodsPreserved=methodsBefore.Count,exactExpectedTokens=true,literalsAndOrdinaryCommentsPreserved=true,checks};File.WriteAllText(output+"/source-proof.json",JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{files=expected.Count,assertionsPreserved=totalAsserts,factTheoryMethodsPreserved=methodsBefore.Count,exactExpectedTokens=true}));
static string Tokens(string s)=>string.Join("\n",CSharpSyntaxTree.ParseText(s).GetRoot().DescendantTokens(descendIntoTrivia:true).Select(t=>t.RawKind+":"+t.Text));
