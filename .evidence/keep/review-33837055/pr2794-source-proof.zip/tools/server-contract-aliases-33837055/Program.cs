using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);
var input=JsonSerializer.Deserialize<Input>(File.ReadAllText(output+"/compiler-input.json"))!;
var trees=input.Files.Select(f=>CSharpSyntaxTree.ParseText(File.ReadAllText(f),new CSharpParseOptions(LanguageVersion.CSharp14,preprocessorSymbols:input.Defines),path:f)).ToArray();
var refs=input.References.Select(p=>MetadataReference.CreateFromFile(p));
var comp=CSharpCompilation.Create("ClankerWorld.Server",trees,refs,new CSharpCompilationOptions(OutputKind.ConsoleApplication,nullableContextOptions:NullableContextOptions.Enable));

var aliasFile=Path.Combine(root,"src/ClankerWorld.Server/Contracts/ContractNames.cs");
var aliasTree=trees.Single(t=>t.FilePath==aliasFile);var aliasModel=comp.GetSemanticModel(aliasTree);
var declarations=aliasTree.GetRoot().DescendantNodes().OfType<UsingDirectiveSyntax>().Where(n=>n.Alias is not null).ToArray();
var aliases=declarations.Select(n=>(IAliasSymbol)aliasModel.GetDeclaredSymbol(n)!).ToArray();
if(aliases.Length!=135)throw new Exception("unexpected alias count");
var errors=comp.GetDiagnostics().Where(d=>d.Severity==DiagnosticSeverity.Error&&d.Id!="CS8795").ToArray();if(errors.Length>0)throw new Exception(string.Join("\n",errors.Select(e=>e.ToString())));
var records=new List<object>();var expected=new Dictionary<string,string>();var imports=new List<object>();
foreach(var t in trees.Where(t=>!t.FilePath.Contains("/obj/")))
{
 var model=comp.GetSemanticModel(t);var syntax=t.GetRoot();var replacements=new Dictionary<SyntaxNode,SyntaxNode>();
 foreach(var n in syntax.DescendantNodes(descendIntoTrivia:true).OfType<IdentifierNameSyntax>())
 {
  var alias=model.GetAliasInfo(n);if(alias is null||!aliases.Any(a=>SymbolEqualityComparer.Default.Equals(a,alias)))continue;
  if(alias.Target is not INamedTypeSymbol target||target.Arity!=0)throw new Exception("unsupported alias target");
  if(n.Ancestors().OfType<InvocationExpressionSyntax>().Any(i=>i.Expression.ToString()=="nameof"))throw new Exception("nameof must be preserved explicitly: "+n);
  var replace=SyntaxFactory.IdentifierName(target.Name).WithTriviaFrom(n);replacements.Add(n,replace);
  records.Add(new{file=t.FilePath,line=n.GetLocation().GetLineSpan().StartLinePosition.Line+1,old=n.Identifier.ValueText,replacement=target.Name,target=target.ToDisplayString(SymbolDisplayFormat.FullyQualifiedFormat),assembly=target.ContainingAssembly.Identity.ToString()});
 }
 foreach(var u in syntax.DescendantNodes().OfType<UsingDirectiveSyntax>())
 {
  if(t.FilePath==aliasFile&&u.Alias is not null)continue;
  if(comp.GetDiagnostics().Any(d=>d.Id=="CS8019"&&d.Location.SourceTree==t&&d.Location.SourceSpan==u.Span))
  {replacements.Add(u,SyntaxFactory.EmptyStatement());imports.Add(new{file=t.FilePath,source=u.ToFullString()});}
 }
 // Process identifier replacements first; remove only individually diagnosed using directives afterwards.
 var rewritten=syntax.ReplaceNodes(replacements.Keys.Where(n=>n is IdentifierNameSyntax),(old,_)=>replacements[old]);
 var remove=rewritten.DescendantNodes().OfType<UsingDirectiveSyntax>().Where(u=>
  t.FilePath==aliasFile&&u.Alias is not null || imports.Any(o=>{var j=JsonSerializer.SerializeToElement(o);return j.GetProperty("file").GetString()==t.FilePath&&j.GetProperty("source").GetString()==u.ToFullString();})).ToArray();
 rewritten=rewritten.RemoveNodes(remove,SyntaxRemoveOptions.KeepNoTrivia)!;
 expected[t.FilePath]=rewritten.ToFullString();
}
var afterTrees=trees.Select(t=>expected.TryGetValue(t.FilePath,out var content)?CSharpSyntaxTree.ParseText(content,(CSharpParseOptions)t.Options,t.FilePath):t).ToArray();
var afterComp=comp.RemoveAllSyntaxTrees().AddSyntaxTrees(afterTrees);var afterErrors=afterComp.GetDiagnostics().Where(d=>d.Severity==DiagnosticSeverity.Error&&d.Id!="CS8795").ToArray();if(afterErrors.Length>0)throw new Exception(string.Join("\n",afterErrors.Select(e=>e.ToString())));
// Every rewritten identifier has the same resolved runtime type and assembly.
foreach(var t in trees.Where(t=>expected.ContainsKey(t.FilePath)))
{
 var a=afterTrees.Single(x=>x.FilePath==t.FilePath);var model=comp.GetSemanticModel(t);var am=afterComp.GetSemanticModel(a);
 var before=t.GetRoot().DescendantNodes().OfType<IdentifierNameSyntax>().Where(n=>model.GetAliasInfo(n) is { } x&&aliases.Any(y=>SymbolEqualityComparer.Default.Equals(x,y))).ToArray();
 var targets=before.Select(n=>(INamedTypeSymbol)model.GetAliasInfo(n)!.Target).ToArray();
 // Bind rewritten identifiers by corresponding occurrence among all remaining ordered tokens, excluding using directives.
 var bn=t.GetRoot().DescendantNodes().OfType<IdentifierNameSyntax>().Where(n=>!n.Ancestors().OfType<UsingDirectiveSyntax>().Any()).ToArray();
 var an=a.GetRoot().DescendantNodes().OfType<IdentifierNameSyntax>().Where(n=>!n.Ancestors().OfType<UsingDirectiveSyntax>().Any()).ToArray();
 if(bn.Length!=an.Length)throw new Exception("identifier inventory changed "+t.FilePath);
 for(var i=0;i<bn.Length;i++)
 {
  var alias=model.GetAliasInfo(bn[i]);if(alias is null||!aliases.Any(x=>SymbolEqualityComparer.Default.Equals(x,alias)))continue;
  if(am.GetSymbolInfo(an[i]).Symbol is not INamedTypeSymbol at||at.ToDisplayString(SymbolDisplayFormat.FullyQualifiedFormat)!=alias.Target.ToDisplayString(SymbolDisplayFormat.FullyQualifiedFormat)||at.ContainingAssembly.Identity.ToString()!=alias.Target.ContainingAssembly.Identity.ToString())throw new Exception("binding changed "+an[i]);
 }
}
File.WriteAllText(output+"/alias-replacements.json",JsonSerializer.Serialize(records,new JsonSerializerOptions{WriteIndented=true}));
File.WriteAllText(output+"/removed-imports.json",JsonSerializer.Serialize(imports,new JsonSerializerOptions{WriteIndented=true}));
File.WriteAllText(output+"/expected-sources.json",JsonSerializer.Serialize(expected,new JsonSerializerOptions{WriteIndented=true}));
File.WriteAllText(output+"/selected-aliases.json",JsonSerializer.Serialize(aliases.Select(a=>new{name=a.Name,target=a.Target.ToDisplayString(SymbolDisplayFormat.FullyQualifiedFormat)}),new JsonSerializerOptions{WriteIndented=true}));
var changedFiles=expected.Count(x=>x.Value!=File.ReadAllText(x.Key));
foreach(var (file,content) in expected)if(File.ReadAllText(file)!=content)File.WriteAllText(file,content);
Console.WriteLine(JsonSerializer.Serialize(new{aliases=aliases.Length,references=records.Count,unusedImports=imports.Count,filesChanged=changedFiles}));
record Input(string[] Files,string[] References,string[] Defines);
