using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
using System.Diagnostics;
var root=args[0];var output=args[1];var expected=JsonDocument.Parse(File.ReadAllText(output+"/expected-sources.json")).RootElement.EnumerateArray().ToArray();
string Git(params string[] args){var info=new ProcessStartInfo("git"){WorkingDirectory=root,RedirectStandardOutput=true};foreach(var arg in args)info.ArgumentList.Add(arg);using var p=Process.Start(info)!;var text=p.StandardOutput.ReadToEnd();p.WaitForExit();if(p.ExitCode!=0)throw new Exception("git failed");return text;}
static string Tokens(SyntaxNode n)=>string.Join("\n",n.DescendantTokens().Select(t=>t.RawKind+":"+t.Text));
static string[] Comments(SyntaxNode n)=>n.DescendantTrivia(descendIntoTrivia:true).Where(t=>t.IsKind(SyntaxKind.SingleLineCommentTrivia)||t.IsKind(SyntaxKind.MultiLineCommentTrivia)||t.IsKind(SyntaxKind.SingleLineDocumentationCommentTrivia)).Select(t=>t.ToString()).ToArray();
var retainedMethods=0;var stateDeclarations=0;
foreach(var row in expected)
{
 var file=row.GetProperty("file").GetString()!;var before=row.GetProperty("before").GetString()!;if(Git("show","835f9db1155bfb03fb741b2d5bcde9de50031316:"+file)!=before)throw new Exception("baseline source mismatch "+file);
 var a=CSharpSyntaxTree.ParseText(row.GetProperty("after").GetString()!).GetRoot();var b=CSharpSyntaxTree.ParseText(File.ReadAllText(root+"/"+file)).GetRoot();if(Tokens(a)!=Tokens(b)||!Comments(a).SequenceEqual(Comments(b)))throw new Exception("unexpected retained tokens/comments "+file);
 var original=CSharpSyntaxTree.ParseText(before).GetRoot();var removed=row.GetProperty("removedMethods").EnumerateArray().Select(e=>e.GetString()).ToHashSet();
 foreach(var method in original.DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>!removed.Contains(m.Identifier.ValueText)))
 {
  var key=method.Identifier.ValueText;var candidates=b.DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>m.Identifier.ValueText==key&&Tokens(m.ParameterList)==Tokens(method.ParameterList)).ToArray();if(candidates.Length!=1||Tokens(candidates[0])!=Tokens(method))throw new Exception("retained method changed "+file+" "+key);retainedMethods++;
 }
 var oldState=original.DescendantNodes().Where(n=>n is FieldDeclarationSyntax or PropertyDeclarationSyntax or ConstructorDeclarationSyntax or OperatorDeclarationSyntax).Select(Tokens).ToArray();var newState=b.DescendantNodes().Where(n=>n is FieldDeclarationSyntax or PropertyDeclarationSyntax or ConstructorDeclarationSyntax or OperatorDeclarationSyntax).Select(Tokens).ToArray();if(!oldState.SequenceEqual(newState))throw new Exception("state/constructor declarations changed");stateDeclarations+=oldState.Length;
}
var changed=Git("diff","--name-only","835f9db1155bfb03fb741b2d5bcde9de50031316","HEAD").Split('\n',StringSplitOptions.RemoveEmptyEntries);if(!changed.Order().SequenceEqual(expected.Select(e=>e.GetProperty("file").GetString()!).Order()))throw new Exception("unexpected changed files");
var report=new{changedFiles=changed.Length,expectedDeletionTokensAndCommentsExactlyEqual=true,retainedMethods,stateDeclarations,allOtherProductAndTestSourcesUnchanged=true,sharedContractsAndSimulationUnchanged=true};File.WriteAllText(output+"/source-proof.json",JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(report));
