using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
using System.Text.RegularExpressions;
var root=args[0];var output=args[1];var files=Directory.GetFiles(root,"*",SearchOption.AllDirectories).Where(f=>!f.Contains("/.git/")&&!f.Contains("/.godot/")&&!f.Contains("/bin/")&&!f.Contains("/obj/")&&!f.Contains("/.evidence/")&&new[]{".cs",".tscn",".tres",".godot",".gd",".py",".sh",".js",".json"}.Contains(Path.GetExtension(f))).ToArray();
var texts=files.Select(f=>(File:f,Text:File.ReadAllText(f))).ToArray();var scoped=new[]{"Screens","Launcher","Networking","Pairing","ClientState","Protocol","Diagnostics"}.Select(d=>root+"/src/ClankerWorld.GodotClient/"+d+"/").ToArray();var reports=new List<object>();
foreach(var (file,text) in texts.Where(t=>t.File.EndsWith(".cs")&&scoped.Any(d=>t.File.StartsWith(d))))
{
 var syntax=CSharpSyntaxTree.ParseText(text).GetRoot();
 foreach(var method in syntax.DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>!m.Modifiers.Any(SyntaxKind.OverrideKeyword)&&!m.Modifiers.Any(SyntaxKind.PartialKeyword)&&m.AttributeLists.Count==0&&(m.Body is not null||m.ExpressionBody is not null)))
 {
  var name=method.Identifier.ValueText;var pattern=new Regex(@"\b"+Regex.Escape(name)+@"\b");var refs=texts.Select(t=>new{file=t.File,count=pattern.Matches(t.Text).Count}).Where(t=>t.count>0).ToArray();
  if(refs.Sum(r=>r.count)!=1)continue;
  reports.Add(new{name,file=Path.GetRelativePath(root,file),owner=string.Join(".",method.Ancestors().OfType<TypeDeclarationSyntax>().Reverse().Select(c=>c.Identifier.ValueText)),lines=method.ToFullString().Count(c=>c=='\n'),source=method.ToFullString(),modifiers=method.Modifiers.ToString()});
 }
}
File.WriteAllText(output+"/unused-name-candidates.json",JsonSerializer.Serialize(reports,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{candidates=reports.Count,reports},new JsonSerializerOptions{WriteIndented=true}));
