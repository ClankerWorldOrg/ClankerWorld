using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=args[0];var output=args[1];var targets=JsonDocument.Parse(File.ReadAllText(output+"/dead-targets.json")).RootElement.EnumerateArray().ToArray();
var imports=JsonDocument.Parse(File.ReadAllText(output+"/dead-reference-proof.json")).RootElement.GetProperty("unusedImports").EnumerateArray().ToArray();
var results=new List<object>();var writes=new Dictionary<string,string>();var removedLines=0;
foreach(var file in targets.Select(t=>t.GetProperty("file").GetString()!).Distinct())
{
 var before=File.ReadAllText(root+"/"+file);var tree=CSharpSyntaxTree.ParseText(before);var node=tree.GetRoot();var selected=new List<MethodDeclarationSyntax>();
 foreach(var target in targets.Where(t=>t.GetProperty("file").GetString()==file))
 {
  var name=target.GetProperty("name").GetString();var matches=node.DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>m.Identifier.ValueText==name).ToArray();if(matches.Length!=1||matches[0].ToFullString()!=target.GetProperty("source").GetString())throw new Exception("target changed "+name);
  selected.Add(matches[0]);
 }
 var after=node.RemoveNodes(selected,SyntaxRemoveOptions.KeepNoTrivia)!;
 var unused=imports.Where(i=>i.GetProperty("file").GetString()==file).Select(i=>i.GetProperty("source").GetString()).ToHashSet();var usingNodes=after.DescendantNodes().OfType<UsingDirectiveSyntax>().Where(u=>unused.Contains(u.ToString())).ToArray();if(usingNodes.Length!=unused.Count)throw new Exception("import match failed");
 after=after.RemoveNodes(usingNodes,SyntaxRemoveOptions.KeepNoTrivia)!;var text=after.ToFullString();var net=before.Count(c=>c=='\n')-text.Count(c=>c=='\n');removedLines+=net;writes.Add(file,text);results.Add(new{file,before,after=text,removedMethods=selected.Select(m=>m.Identifier.ValueText),removedImports=unused,netFewer=net});
}
if(removedLines<150||writes.Count!=2)throw new Exception("unsupported batch size "+removedLines);
File.WriteAllText(output+"/expected-sources.json",JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true}));
foreach(var (file,text) in writes)File.WriteAllText(root+"/"+file,text);
Console.WriteLine(JsonSerializer.Serialize(new{methods=targets.Length,imports=imports.Length,files=writes.Count,netFewer=removedLines}));
