using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;
var root=args[0];var output=args[1];var targets=JsonDocument.Parse(File.ReadAllText(output+"/dead-targets.json")).RootElement.EnumerateArray().Select(t=>t.GetProperty("owner").GetString()+"|"+t.GetProperty("name").GetString()+"|").ToArray();var reports=new List<object>();
foreach(var (name,beforePath,afterPath,beforeCommit) in new[]{
 ("Game",output+"/baseline-binaries/ClankerWorld.GodotClient.dll",root+"/src/ClankerWorld.GodotClient/.godot/mono/temp/bin/Release/ClankerWorld.GodotClient.dll","835f9db1155bfb03fb741b2d5bcde9de50031316"),
 ("Tests",output+"/baseline-test-binaries/ClankerWorld.Tests.dll",root+"/tests/ClankerWorld.Tests/bin/Release/net10.0/ClankerWorld.Tests.dll","a35189525ff212fceaa743e908960784fafceb5a")})
{
 var before=NormalizeRegexFileNames(Read(beforePath));var after=NormalizeRegexFileNames(Read(afterPath));var removed=before.Methods.Except(after.Methods).Order().ToArray();var added=after.Methods.Except(before.Methods).ToArray();var removedFields=before.Fields.Except(after.Fields).ToArray();var addedFields=after.Fields.Except(before.Fields).ToArray();
 if(removed.Length!=11||added.Length!=0||removedFields.Length+addedFields.Length!=0||before.Bodies-after.Bodies!=11)throw new Exception(JsonSerializer.Serialize(new{name,removed,added,removedFields,addedFields,beforeBodies=before.Bodies,afterBodies=after.Bodies}));
 foreach(var target in targets)if(removed.Count(m=>m.StartsWith(target))!=1)throw new Exception("missing/unexpected removed method "+target);
 var beforeVersion=Versions.InformationalVersion(beforePath);var afterVersion=Versions.InformationalVersion(afterPath);if(!beforeVersion.EndsWith(beforeCommit)||!afterVersion.EndsWith("90cae3cb5cde33b3e09e683e7dad875dc1b2d03f"))throw new Exception("build identity mismatch "+name);
 reports.Add(new{assembly=name,beforeBodies=before.Bodies,afterBodies=after.Bodies,removedUserMethods=removed,addedUserMethods=added,allStateFieldsUnchanged=true,normalization="Only compiler-generated RegexGenerator file-local worktree hash; pattern names, ordinals, signatures and counts preserved without collisions.",beforeVersion,afterVersion,sha256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(afterPath)))});
}
File.WriteAllText(output+"/compiled-api-proof.json",JsonSerializer.Serialize(reports,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(reports));
static Inventory NormalizeRegexFileNames(Inventory input)
{
 string Normalize(string value)=>System.Text.RegularExpressions.Regex.Replace(value,@"System\.Text\.RegularExpressions\.Generated\.<RegexGenerator_g>F[0-9A-F]{64}__","System.Text.RegularExpressions.Generated.<RegexGenerator_g>WORKTREE__");
 var methods=input.Methods.Select(Normalize).ToHashSet();var fields=input.Fields.Select(Normalize).ToHashSet();if(methods.Count!=input.Methods.Count||fields.Count!=input.Fields.Count)throw new Exception("file-hash normalization collided");return new(methods,fields,input.Bodies);
}
static Inventory Read(string path){using var pe=new PEReader(File.OpenRead(path));var r=pe.GetMetadataReader();var names=new Names();var methods=new HashSet<string>();var fields=new HashSet<string>();var bodies=0;
foreach(var th in r.TypeDefinitions){var t=r.GetTypeDefinition(th);var name=names.GetTypeFromDefinition(r,th,0);foreach(var mh in t.GetMethods())if(r.GetMethodDefinition(mh).RelativeVirtualAddress!=0)bodies++;
 if(t.GetDeclaringType().IsNil?name.Split('.').Last().StartsWith("<"):name.Split('+').Last().StartsWith("<"))continue;
 foreach(var mh in t.GetMethods()){var m=r.GetMethodDefinition(mh);if(Generated(r,m.GetCustomAttributes()))continue;var s=m.DecodeSignature(names,(object?)null);methods.Add(name+"|"+r.GetString(m.Name)+"|"+s.ReturnType+"("+string.Join(",",s.ParameterTypes)+")");}
 foreach(var fh in t.GetFields()){var f=r.GetFieldDefinition(fh);var c=f.GetDefaultValue();fields.Add(name+"|"+r.GetString(f.Name)+"|"+f.Attributes+"|"+f.DecodeSignature(names,(object?)null)+"|"+(c.IsNil?"":Convert.ToHexString(r.GetBlobBytes(r.GetConstant(c).Value))));}
}return new(methods,fields,bodies);}
static bool Generated(MetadataReader r,CustomAttributeHandleCollection hs){foreach(var h in hs){var a=r.GetCustomAttribute(h);if(a.Constructor.Kind!=HandleKind.MemberReference)continue;var p=r.GetMemberReference((MemberReferenceHandle)a.Constructor).Parent;if(p.Kind==HandleKind.TypeReference&&r.GetString(r.GetTypeReference((TypeReferenceHandle)p).Name)=="CompilerGeneratedAttribute")return true;}return false;}
record Inventory(HashSet<string> Methods,HashSet<string> Fields,int Bodies);
sealed class Names:ISignatureTypeProvider<string,object?>
{
 public string GetArrayType(string e,ArrayShape s)=>e+"["+s.Rank+"]";public string GetByReferenceType(string e)=>e+"&";public string GetFunctionPointerType(MethodSignature<string>s)=>"fn("+string.Join(",",s.ParameterTypes)+")->"+s.ReturnType;public string GetGenericInstantiation(string t,System.Collections.Immutable.ImmutableArray<string>a)=>t+"<"+string.Join(",",a)+">";public string GetGenericMethodParameter(object?c,int i)=>"!!"+i;public string GetGenericTypeParameter(object?c,int i)=>"!"+i;public string GetModifiedType(string m,string u,bool q)=>u+"mod("+m+","+q+")";public string GetPinnedType(string e)=>e+" pinned";public string GetPointerType(string e)=>e+"*";public string GetPrimitiveType(PrimitiveTypeCode c)=>c.ToString();public string GetSZArrayType(string e)=>e+"[]";
 public string GetTypeFromDefinition(MetadataReader r,TypeDefinitionHandle h,byte k){var t=r.GetTypeDefinition(h);return t.GetDeclaringType().IsNil?r.GetString(t.Namespace)+"."+r.GetString(t.Name):GetTypeFromDefinition(r,t.GetDeclaringType(),0)+"+"+r.GetString(t.Name);}
 public string GetTypeFromReference(MetadataReader r,TypeReferenceHandle h,byte k){var t=r.GetTypeReference(h);return r.GetString(t.Namespace)+"."+r.GetString(t.Name);}
 public string GetTypeFromSpecification(MetadataReader r,object?c,TypeSpecificationHandle h,byte k)=>r.GetTypeSpecification(h).DecodeSignature(this,c);
}
