using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
static class Versions { public static string InformationalVersion(string path){using var pe=new PEReader(File.OpenRead(path));var r=pe.GetMetadataReader();foreach(var h in r.GetAssemblyDefinition().GetCustomAttributes()){var a=r.GetCustomAttribute(h);if(a.Constructor.Kind!=HandleKind.MemberReference)continue;var m=r.GetMemberReference((MemberReferenceHandle)a.Constructor);if(m.Parent.Kind!=HandleKind.TypeReference)continue;var t=r.GetTypeReference((TypeReferenceHandle)m.Parent);if(r.GetString(t.Name)!="AssemblyInformationalVersionAttribute")continue;var b=r.GetBlobReader(a.Value);if(b.ReadUInt16()!=1)throw new Exception("attribute format");return b.ReadSerializedString()!;}throw new Exception("missing build identity "+path);}
}
