using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=args[0];var output=args[1];var raw=File.ReadAllText(output+"/compiler-inputs.json");var inputs=JsonDocument.Parse(raw[raw.IndexOf('{')..]).RootElement;var props=inputs.GetProperty("Properties");
var files=inputs.GetProperty("Items").GetProperty("Compile").EnumerateArray().Select(e=>e.GetProperty("FullPath").GetString()!).Concat(Directory.GetFiles(root+"/src/ClankerWorld.GodotClient/.godot/mono/temp/obj/Release","*.cs")).Concat(Directory.GetFiles(output+"/generated-baseline","*.cs",SearchOption.AllDirectories)).Distinct().ToArray();
var options=new CSharpParseOptions(LanguageVersion.CSharp14,preprocessorSymbols:props.GetProperty("DefineConstants").GetString()!.Split(';',StringSplitOptions.RemoveEmptyEntries));
var trees=files.Select(f=>CSharpSyntaxTree.ParseText(File.ReadAllText(f),options,path:f)).ToArray();
var refs=inputs.GetProperty("Items").GetProperty("ReferencePath").EnumerateArray().Select(e=>MetadataReference.CreateFromFile(e.GetProperty("FullPath").GetString()!));
var comp=CSharpCompilation.Create("ClankerWorld.GodotClient",trees,refs,new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,nullableContextOptions:NullableContextOptions.Enable,allowUnsafe:true));
var diagnostics=comp.GetDiagnostics();var errors=diagnostics.Where(d=>d.Severity==DiagnosticSeverity.Error).Select(d=>d.ToString()).ToArray();File.WriteAllText(output+"/semantic-errors.json",JsonSerializer.Serialize(errors,new JsonSerializerOptions{WriteIndented=true}));if(errors.Length>0)throw new Exception("Actual-input baseline compilation has errors: "+string.Join('\n',errors.Take(12)));
if(args.Contains("--head"))
{
 var headUnused=diagnostics.Where(d=>d.Id=="CS8019"&&(d.Location.SourceTree?.FilePath.EndsWith("/Networking/OwnerWorldApi.cs")==true||d.Location.SourceTree?.FilePath.EndsWith("/Pairing/OwnerPairingClient.cs")==true)).Select(d=>d.ToString()).ToArray();
 var headReport=new{files=files.Length,errors=0,unusedImports=headUnused};File.WriteAllText(output+"/head-compile-proof.json",JsonSerializer.Serialize(headReport,new JsonSerializerOptions{WriteIndented=true}));if(headUnused.Length>0)throw new Exception("remaining imports "+string.Join('\n',headUnused));Console.WriteLine(JsonSerializer.Serialize(headReport));return;
}
var plan=JsonDocument.Parse(File.ReadAllText(output+"/dead-plan.json")).RootElement.EnumerateArray().Select(e=>(Owner:e.GetProperty("owner").GetString()!,Name:e.GetProperty("name").GetString()!)).ToHashSet();var selected=new List<(IMethodSymbol Symbol,MethodDeclarationSyntax Node,string File)>();
foreach(var tree in trees){var model=comp.GetSemanticModel(tree);foreach(var method in tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>())if(model.GetDeclaredSymbol(method) is IMethodSymbol symbol&&plan.Contains((symbol.ContainingType.Name,symbol.Name)))
{
 if(symbol.ContainingType.BaseType?.SpecialType!=SpecialType.System_Object||symbol.IsVirtual||symbol.IsOverride||symbol.ExplicitInterfaceImplementations.Length>0||symbol.GetAttributes().Length>0)throw new Exception("special callback/API root "+symbol);
 selected.Add((symbol,method,tree.FilePath));
}}
if(selected.Count!=11)throw new Exception("Expected11selecteddefinitions,actual"+selected.Count);
var incoming=new List<object>();
foreach(var tree in trees){var model=comp.GetSemanticModel(tree);foreach(var name in tree.GetRoot().DescendantNodes().OfType<SimpleNameSyntax>())if(model.GetSymbolInfo(name).Symbol is IMethodSymbol referenced)
{
 var target=selected.FirstOrDefault(s=>SymbolEqualityComparer.Default.Equals(s.Symbol.OriginalDefinition,referenced.OriginalDefinition));if(target.Symbol is null)continue;
 var callerNode=name.Ancestors().OfType<MethodDeclarationSyntax>().FirstOrDefault();var caller=callerNode is null?null:model.GetDeclaredSymbol(callerNode);var allowed=caller is not null&&plan.Contains((caller.ContainingType.Name,caller.Name));
 incoming.Add(new{target=target.Symbol.ToDisplayString(),caller=caller?.ToDisplayString(),file=tree.FilePath,line=name.GetLocation().GetLineSpan().StartLinePosition.Line+1,withinRemovedCluster=allowed});if(!allowed)throw new Exception("Live incoming reference "+name+" in "+tree.FilePath);
}}
var targets=selected.Select(s=>new{owner=s.Symbol.ContainingType.ToDisplayString(),name=s.Symbol.Name,parameters=s.Symbol.Parameters.Length,arity=s.Symbol.Arity,file=Path.GetRelativePath(root,s.File),lines=s.Node.ToFullString().Count(c=>c=='\n'),source=s.Node.ToFullString()}).ToArray();
var unused=diagnostics.Where(d=>d.Id=="CS8019"&&selected.Any(s=>s.File==d.Location.SourceTree?.FilePath)).Select(d=>new{file=Path.GetRelativePath(root,d.Location.SourceTree!.FilePath),source=d.Location.SourceTree.GetText().ToString(d.Location.SourceSpan)}).ToArray();
File.WriteAllText(output+"/dead-targets.json",JsonSerializer.Serialize(targets,new JsonSerializerOptions{WriteIndented=true}));File.WriteAllText(output+"/dead-reference-proof.json",JsonSerializer.Serialize(new{files=files.Length,errors=0,selected=targets.Length,incoming,unusedImports=unused},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{files=files.Length,errors=0,selected=targets.Length,lines=targets.Sum(t=>t.lines),incoming,unusedImports=unused}));
