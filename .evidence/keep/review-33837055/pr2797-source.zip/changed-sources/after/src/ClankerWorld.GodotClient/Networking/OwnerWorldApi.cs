using ClankerWorld.GodotClient.Pairing;
using ClankerWorld.GodotClient.Protocol;

namespace ClankerWorld.GodotClient.Networking;

/// <summary>
/// Uses an owner device key to issue a one-use challenge and sign every
/// operation. It stores no bearer token and has no local mutation fallback.
/// </summary>
public sealed class OwnerWorldApi
{
    private readonly OwnerPairingClient pairing;
    private readonly TimeProvider timeProvider;

    public OwnerWorldApi(HttpClient httpClient, TimeProvider? timeProvider = null)
    {
        this.timeProvider = timeProvider ?? TimeProvider.System;
        pairing = new OwnerPairingClient(httpClient, timeProvider: this.timeProvider);
    }

    public Task<OwnerPairingStart> StartPairingAsync(
        Uri serverUri,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.StartPairingAsync(serverUri, deviceKey, cancellationToken);

    public Task<OwnerPairingStatus> GetPairingStatusAsync(
        Uri serverUri,
        string pairingId,
        CancellationToken cancellationToken) =>
        pairing.GetPairingStatusAsync(serverUri, pairingId, cancellationToken);

    public Task<OwnerDevice> ActivatePairingAsync(
        Uri serverUri,
        OwnerPairingStart pairingStart,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.ActivatePairingAsync(serverUri, pairingStart, deviceKey, cancellationToken);

    public async Task<OwnerWorldReconnect> ReconnectAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        long afterEventId,
        string? knownTerrainWorldId,
        string? knownTerrainDigest,
        string? knownMapLayersDigest,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken)
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(4), timeProvider);
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, timeout.Token);
        var action = new OwnerReconnectAction(afterEventId, knownTerrainWorldId, knownTerrainDigest,
            knownMapLayersDigest);
        return await pairing.SendSignedActionAsync<OwnerReconnectAction, OwnerWorldReconnect>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerReconnect,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.Reconnect(action),
            action,
            deviceKey,
            deadline.Token).ConfigureAwait(false);
    }

    public Task<OwnerControlReceipt> SetPausedAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        bool paused,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken)
    {
        var operation = paused ? "pause" : "resume";
        var action = new OwnerControlAction(operation);
        var path = paused ? OwnerPairingEndpoints.OwnerPause : OwnerPairingEndpoints.OwnerResume;
        return pairing.SendSignedActionAsync<OwnerControlAction, OwnerControlReceipt>(
            serverUri,
            authority,
            deviceId,
            path,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.Control(operation),
            action,
            deviceKey,
            cancellationToken);
    }

    public Task<OwnerControlReceipt> StartWorldAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerControlAction("start-world");
        return pairing.SendSignedActionAsync<OwnerControlAction, OwnerControlReceipt>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerStartWorld,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.Control("start-world"),
            action, deviceKey, cancellationToken);
    }

    public Task<OwnerDeletionReceipt> DeleteAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerDeletionAction action, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerDeletionAction, OwnerDeletionReceipt>(
            serverUri, authority, deviceId, "/api/v1/owner/delete",
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.Deletion(action),
            action, deviceKey, cancellationToken);

    public Task<RecoveryCleanupPreview> PreviewRecoveryCleanupAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId, OwnerRecoveryCleanupAction action,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerRecoveryCleanupAction, RecoveryCleanupPreview>(
            serverUri, authority, deviceId, "/api/v1/owner/saves/recovery-cleanup",
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.RecoveryCleanup(action), action, deviceKey, cancellationToken);

    public Task<OwnerRecoveryCleanupReceipt> CleanRecoveryHistoryAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId, OwnerRecoveryCleanupAction action,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerRecoveryCleanupAction, OwnerRecoveryCleanupReceipt>(
            serverUri, authority, deviceId, "/api/v1/owner/saves/recovery-cleanup",
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.RecoveryCleanup(action), action, deviceKey, cancellationToken);

    public Task<ManualWorldSave[]> ListManualSavesAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerControlAction("list-saves");
        return pairing.SendSignedActionAsync<OwnerControlAction, ManualWorldSave[]>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerSaveList,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.Control("list-saves"),
            action, deviceKey, cancellationToken);
    }

    public Task<StartupRecoveryStatus> GetStartupRecoveryAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerControlAction, StartupRecoveryStatus>(
            serverUri, authority, deviceId, "/api/v1/owner/recovery/status",
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.Control("recovery-status"),
            new("recovery-status"), deviceKey, cancellationToken);

    public Task<StartupRecoveryReceipt> RecoverAutosaveAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId, string id,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerManualSaveAction("recover", id);
        return pairing.SendSignedActionAsync<OwnerManualSaveAction, StartupRecoveryReceipt>(
            serverUri, authority, deviceId, "/api/v1/owner/recovery/restore",
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.ManualSave(action),
            action, deviceKey, cancellationToken);
    }

    public Task<SaveTimelinePosition> GetSaveTimelinePositionAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerControlAction("save-timeline");
        return pairing.SendSignedActionAsync<OwnerControlAction, SaveTimelinePosition>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerSaveTimeline,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.Control("save-timeline"),
            action, deviceKey, cancellationToken);
    }

    public Task<WorldAutosaveSettings> GetAutosaveSettingsAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerControlAction("autosave-status");
        return pairing.SendSignedActionAsync<OwnerControlAction, WorldAutosaveSettings>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerAutosaveStatus,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.Control("autosave-status"),
            action, deviceKey, cancellationToken);
    }

    public Task<SaveDiskSpaceStatus> GetSaveDiskSpaceAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerControlAction, SaveDiskSpaceStatus>(
            serverUri, authority, deviceId, "/api/v1/owner/saves/disk-status",
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.Control("save-disk-status"),
            new OwnerControlAction("save-disk-status"), deviceKey, cancellationToken);

    public Task<WorldAutosaveSettings> ConfigureAutosaveAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerAutosaveConfigurationAction action, IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerAutosaveConfigurationAction, WorldAutosaveSettings>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerAutosaveConfigure,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.AutosaveConfiguration(action),
            action, deviceKey, cancellationToken,
            requiredPayloadDomain: OwnerWorldActionPayload.AutosaveConfigurationPayloadDomain);

    public Task<ManualWorldSave> CreateManualSaveAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        string name, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerManualSaveAction("create", name);
        return pairing.SendSignedActionAsync<OwnerManualSaveAction, ManualWorldSave>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerSaveCreate,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.ManualSave(action),
            action, deviceKey, cancellationToken);
    }

    public Task<ManualSaveOverwriteReceipt> OverwriteManualSaveAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        string id, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerManualSaveAction("overwrite", id);
        return pairing.SendSignedActionAsync<OwnerManualSaveAction, ManualSaveOverwriteReceipt>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerSaveOverwrite,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.ManualSave(action),
            action, deviceKey, cancellationToken);
    }

    public Task<WorldSaveHistory> ReadWorldSaveHistoryAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId, string worldId,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerManualSaveAction("world-saves", worldId);
        return pairing.SendSignedActionAsync<OwnerManualSaveAction, WorldSaveHistory>(
            serverUri, authority, deviceId, "/api/v1/owner/worlds/saves",
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.ManualSave(action),
            action, deviceKey, cancellationToken);
    }

    public Task<WorldCatalogSnapshot> ListWorldsAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerControlAction("list-worlds");
        return pairing.SendSignedActionAsync<OwnerControlAction, WorldCatalogSnapshot>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerWorldList,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.Control("list-worlds"),
            // Listing checks every checkpoint. A cold catalog can take longer
            // than an ordinary control action; Back still cancels this request.
            action, deviceKey, cancellationToken, maximumDuration: TimeSpan.FromSeconds(60));
    }

    public Task<CatalogWorld> CreateWorldAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerWorldCreationAction action, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerWorldCreationAction, CatalogWorld>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerWorldCreate,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.WorldCreation(action),
            action, deviceKey, cancellationToken, OwnerWorldActionPayload.WorldCreationPayloadDomain);

    public Task<OwnerWorldPreview> PreviewWorldAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerWorldCreationAction action, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerWorldCreationAction, OwnerWorldPreview>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerWorldPreview,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.WorldCreation(action),
            action, deviceKey, cancellationToken, OwnerWorldActionPayload.WorldCreationPayloadDomain);

    public Task<CatalogWorld> SelectWorldAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        string id, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken, string? modelSettingsApproval = null)
    {
        var action = new OwnerManualSaveAction("select-world", id, modelSettingsApproval);
        return pairing.SendSignedActionAsync<OwnerManualSaveAction, CatalogWorld>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerWorldSelect,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.ManualSave(action),
            action, deviceKey, cancellationToken);
    }

    public Task<ManualSaveLoadReceipt> LoadManualSaveAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        string id, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken, string? modelSettingsApproval = null)
    {
        var action = new OwnerManualSaveAction("load", id, modelSettingsApproval);
        return pairing.SendSignedActionAsync<OwnerManualSaveAction, ManualSaveLoadReceipt>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerSaveLoad,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.ManualSave(action),
            action, deviceKey, cancellationToken);
    }

    public Task<OwnerModelSettingsPreview> InspectLoadModelsAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId, string id, bool world,
        IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerManualSaveAction(world ? "inspect-world-models" : "inspect-save-models", id);
        return pairing.SendSignedActionAsync<OwnerManualSaveAction, OwnerModelSettingsPreview>(
            serverUri, authority, deviceId, world ? OwnerPairingEndpoints.OwnerWorldSelect : OwnerPairingEndpoints.OwnerSaveLoad,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.ManualSave(action),
            action, deviceKey, cancellationToken);
    }

    public Task<OwnerFounderPlacementReceipt> PlaceFounderAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerFounderPlacementAction action, IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerFounderPlacementAction, OwnerFounderPlacementReceipt>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerFounderPlace,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.FounderPlacement(action),
            action, deviceKey, cancellationToken,
            OwnerWorldActionPayload.NeedsModelThinkingHost(action.Cognition.Provider, action.Cognition.Thinking)
                ? OwnerWorldActionPayload.ModelThinkingPayloadDomain : null);

    public Task<OwnerFirstTownLayoutReceipt> AcceptFirstTownLayoutAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerFirstTownLayoutAction action, IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerFirstTownLayoutAction, OwnerFirstTownLayoutReceipt>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerFirstTownLayout,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.FirstTownLayout(action),
            action, deviceKey, cancellationToken);

    public Task<OwnerFounderMoveReceipt> MoveFounderAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerFounderMoveAction action, IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerFounderMoveAction, OwnerFounderMoveReceipt>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerFounderMove,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.FounderMove(action),
            action, deviceKey, cancellationToken);

    public Task<OwnerFounderUndoReceipt> UndoFounderAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerFounderUndoAction action, IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerFounderUndoAction, OwnerFounderUndoReceipt>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerFounderUndo,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.FounderUndo(action),
            action, deviceKey, cancellationToken);

    public Task<OwnerAgentPlacementReceipt> PlaceAgentAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerAgentPlacementAction action, IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerAgentPlacementAction, OwnerAgentPlacementReceipt>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerAgentPlace,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.AgentPlacement(action),
            action, deviceKey, cancellationToken,
            // A host that accepts thinking also accepts this placement format.
            OwnerWorldActionPayload.NeedsModelThinkingHost(action.Cognition.Provider, action.Cognition.Thinking)
                ? OwnerWorldActionPayload.ModelThinkingPayloadDomain : OwnerWorldActionPayload.AgentPlacementPayloadDomain);

    public Task<OwnerAgentRenameReceipt> RenameAgentAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerAgentRenameAction action, IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerAgentRenameAction, OwnerAgentRenameReceipt>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerAgentRename,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.AgentRename(action),
            action, deviceKey, cancellationToken);

    public Task<OwnerControlReceipt> ApplyDeveloperEditAsync(Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerDeveloperEditAction action, IOwnerDeviceSigner signer, CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerDeveloperEditAction, OwnerControlReceipt>(serverUri, authority, deviceId,
            OwnerPairingEndpoints.OwnerDeveloperEdit, OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.DeveloperEdit(action),
            action, signer, cancellationToken);

    public Task<OwnerControlReceipt> SetAgingOverrideAsync(Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        int rate, string worldId, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerAgingOverrideAction(rate, worldId);
        return pairing.SendSignedActionAsync<OwnerAgingOverrideAction, OwnerControlReceipt>(serverUri, authority, deviceId,
            OwnerPairingEndpoints.OwnerAgingOverride, OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.AgingOverride(action),
            action, deviceKey, cancellationToken, requiredPayloadDomain: OwnerWorldActionPayload.AgingOverridePayloadDomain);
    }

    public Task<OwnerControlReceipt> SetRoutineHelperAsync(Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerRoutineHelperAction action, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerRoutineHelperAction, OwnerControlReceipt>(serverUri, authority, deviceId,
            OwnerPairingEndpoints.OwnerRoutineHelper, OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.RoutineHelper(action), action, deviceKey, cancellationToken,
            requiredPayloadDomain: "clankerworld.owner-routine-helper.v1");

    public Task<OwnerControlReceipt> SetJevAssistanceAsync(Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        bool enabled, string worldId, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerJevAssistanceAction(enabled, worldId);
        return pairing.SendSignedActionAsync<OwnerJevAssistanceAction, OwnerControlReceipt>(serverUri, authority, deviceId,
            OwnerPairingEndpoints.OwnerJevAssistance, OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.JevAssistance(action), action, deviceKey, cancellationToken,
            requiredPayloadDomain: OwnerWorldActionPayload.JevAssistancePayloadDomain);
    }

    public Task<OwnerInstructionReceipt> SubmitInstructionAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerInstructionAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerInstructionAction, OwnerInstructionReceipt>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerInstructions,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.Instruction(action),
            action,
            deviceKey,
            cancellationToken);

    public Task<OwnerOrderControlReceipt> CancelOrderAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerOrderCancelAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerOrderCancelAction, OwnerOrderControlReceipt>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerOrderCancel,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.OrderCancel(action),
            action,
            deviceKey,
            cancellationToken);

    public Task<OwnerAuthoringBatchReceipt> SubmitAuthoringAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerAuthoringBatchAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerAuthoringBatchAction, OwnerAuthoringBatchReceipt>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerAuthoring,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.Authoring(action),
            action,
            deviceKey,
            cancellationToken);

    public Task<OwnerBuildingManagementResult> RemoveBuildingAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerBuildingRemovalAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerBuildingRemovalAction, OwnerBuildingManagementResult>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerBuildingRemoval,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.BuildingRemoval(action),
            action, deviceKey, cancellationToken);

    public Task<OwnerBuildingManagementResult> ReassignBuildingAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerBuildingReassignmentAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerBuildingReassignmentAction, OwnerBuildingManagementResult>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerBuildingReassignment,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.BuildingReassignment(action),
            action, deviceKey, cancellationToken);

    public Task<OwnerPairingApproval> ApprovePairingAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerPairingApprovalAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerPairingApprovalAction, OwnerPairingApproval>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerPairingApproval,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.PairingApproval(action),
            action,
            deviceKey,
            cancellationToken);

    public Task<OwnerDevice> RevokeDeviceAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerDeviceManagementAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerDeviceManagementAction, OwnerDevice>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerDeviceRevoke,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.DeviceManagement(action),
            action,
            deviceKey,
            cancellationToken);

    public Task<OwnerDevice[]> ListDevicesAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken)
    {
        var action = new OwnerDeviceListAction();
        return pairing.SendSignedActionAsync<OwnerDeviceListAction, OwnerDevice[]>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerDeviceList,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.DeviceList(),
            action,
            deviceKey,
            cancellationToken);
    }

    public Task<OwnerProviderConfigurationStatus> GetProviderStatusAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken)
    {
        var action = new OwnerProviderStatusAction();
        return pairing.SendSignedActionAsync<OwnerProviderStatusAction, OwnerProviderConfigurationStatus>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerProviderStatus,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.ProviderStatus(),
            action,
            deviceKey,
            cancellationToken);
    }

    public Task<OwnerUsageStatus> GetUsageStatusAsync(Uri serverUri, OwnerAuthorityIdentity authority,
        string deviceId, IOwnerDeviceSigner deviceKey, CancellationToken cancellationToken)
    {
        var action = new OwnerUsageStatusAction();
        return pairing.SendSignedActionAsync<OwnerUsageStatusAction, OwnerUsageStatus>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerUsageStatus,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.UsageStatus(),
            action, deviceKey, cancellationToken);
    }

    public Task<OwnerUsageStatus> ConfigureUsageLimitAsync(Uri serverUri, OwnerAuthorityIdentity authority,
        string deviceId, OwnerUsageLimitAction action, IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerUsageLimitAction, OwnerUsageStatus>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerUsageLimit,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.UsageLimit(action),
            action, deviceKey, cancellationToken);

    public Task<OwnerProviderConfigurationStatus> ConfigureProviderAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerProviderConfigurationAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerProviderConfigurationAction, OwnerProviderConfigurationStatus>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerProviderConfigure,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.ProviderConfiguration(action),
            action,
            deviceKey,
            cancellationToken,
            OwnerWorldActionPayload.NeedsModelThinkingHost(action.Provider, action.Thinking)
                ? OwnerWorldActionPayload.ModelThinkingPayloadDomain : null);

    public Task<OwnerProviderConfigurationStatus> CreateCredentialSlotAsync(
        Uri serverUri, OwnerAuthorityIdentity authority, string deviceId,
        OwnerCredentialSlotCreationAction action, IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerCredentialSlotCreationAction, OwnerProviderConfigurationStatus>(
            serverUri, authority, deviceId, OwnerPairingEndpoints.OwnerCredentialSlotCreate,
            OwnerPairingProtocol.CreateRequestId(), OwnerWorldActionPayload.CredentialSlotCreation(action),
            action, deviceKey, cancellationToken,
            OwnerWorldActionPayload.NeedsModelThinkingHost(action.Provider) ? OwnerWorldActionPayload.ModelThinkingPayloadDomain : null);

    public Task<OwnerProviderConfigurationStatus> DeleteCredentialSlotAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        string credentialSlotId,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken)
    {
        var action = new OwnerCredentialSlotDeletionAction(credentialSlotId);
        return pairing.SendSignedActionAsync<OwnerCredentialSlotDeletionAction, OwnerProviderConfigurationStatus>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerCredentialSlotDelete,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.CredentialSlotDeletion(action),
            action,
            deviceKey,
            cancellationToken);
    }

    public Task<OwnerProviderModelList> ListProviderModelsAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerProviderModelListAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerProviderModelListAction, OwnerProviderModelList>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerProviderModels,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.ProviderModelList(action),
            action,
            deviceKey,
            cancellationToken,
            OwnerWorldActionPayload.NeedsModelThinkingHost(action.Provider) ? OwnerWorldActionPayload.ModelThinkingPayloadDomain : null);

    public Task<OwnerProviderSetupCheckResult> CheckProviderSetupAsync(
        Uri serverUri,
        OwnerAuthorityIdentity authority,
        string deviceId,
        OwnerProviderSetupCheckAction action,
        IOwnerDeviceSigner deviceKey,
        CancellationToken cancellationToken) =>
        pairing.SendSignedActionAsync<OwnerProviderSetupCheckAction, OwnerProviderSetupCheckResult>(
            serverUri,
            authority,
            deviceId,
            OwnerPairingEndpoints.OwnerProviderSetupCheck,
            OwnerPairingProtocol.CreateRequestId(),
            OwnerWorldActionPayload.ProviderSetupCheck(action),
            action,
            deviceKey,
            cancellationToken,
            action.Provider?.Trim().ToLowerInvariant() is "jev" or "decisions" ? OwnerWorldActionPayload.HelperSetupCheckPayloadDomain :
            OwnerWorldActionPayload.NeedsModelThinkingHost(action.Provider, action.Thinking)
                ? OwnerWorldActionPayload.ModelThinkingPayloadDomain : null);
}
