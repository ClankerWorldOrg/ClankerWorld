Codex session33837055, claim6378099175 at01:21UTC, branchcodex/2558-client-cleanup-33837055, main835. Deadline draft02:21. Allowed second claim while finished draft2796 waits only on CI; return there first on failure/green handoff. All17earlierReady stopped.

1. All15open file maps/topic duplicates checked: no scoped client overlap. Minute reread only our claim. Baseline locked Godot Release and pinned binaries before edits.
2. Audit private/internal/public unused entry points, unused imports with actual compiler references, repeated blocks/request-status plumbing. First conservative all-source/asset-name private method scan found0. Preserve security, deadlines, fields, callbacks, text/layout and every assertion/check. Coherent >=150net batch or documented supported research; no superficial renames/formatting for quota.
3. Push meaningful changes/draft promptly. Actual full dependent/client builds, exact existing focused test scope/TRX, source/binary/native UI proof as relevant; fullformat/verify, stale/diff, exact-head CI.
4. Finish CI/actualcheckout/installer/finalgate, Ready and release Refs claim; record area totals here, protected2296 untouched.
