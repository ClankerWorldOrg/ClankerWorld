from pathlib import Path
import json,zipfile,hashlib,shutil,subprocess
p=Path('/workspace/review-coverage-33837055/fix2558');root=Path('/workspace/fix-2558-33837055');target=Path('/workspace/review-evidence-33837055/.evidence/keep/review-33837055')
assert json.loads((p/'final-check-receipts.json').read_text())['status']=='passed'
r=json.loads((p/'focused-reconciliation.json').read_text());assert r['cases']==72 and r['methods']==35 and r['wholeClasses']==9 and not r['partialClasses'] and r['outcomes']=={'Passed':72}
for report in json.loads((p/'compiled-api-proof.json').read_text()):assert len(report['removedUserMethods'])==11 and not report['addedUserMethods'] and report['allStateFieldsUnchanged']
for name in ['client-unused-audit-33837055','client-dead-proof-33837055','client-dead-transform-33837055','client-dead-incoming-proof-33837055','client-api-proof-33837055','client-source-proof-33837055','towns-test-scope-33837055']:
 for f in (Path('/workspace')/name).iterdir():
  if f.is_file() and f.suffix in {'.cs','.csproj'}:
   dest=p/'tools'/name/f.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
base='835f9db1155bfb03fb741b2d5bcde9de50031316';(p/'final-product.patch').write_bytes(subprocess.check_output(['git','diff',base,'HEAD'],cwd=root))
for name in subprocess.check_output(['git','diff','--name-only',base,'HEAD'],cwd=root,text=True).splitlines():
 for kind,data in [('before',subprocess.check_output(['git','show',base+':'+name],cwd=root)),('after',(root/name).read_bytes())]:
  dest=p/'changed-sources'/kind/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
binaryFolders={'baseline-binaries','baseline-test-binaries','head-binaries'}
source=[(f,f.relative_to(p)) for f in sorted(p.rglob('*')) if f.is_file() and not ((binaryFolders|{'ci','scratch'})&set(f.relative_to(p).parts)) and f.name!='archive-manifest.json' and f.suffix not in {'.dll','.pdb','.zip'}]
binaries=[(f,f.relative_to(p)) for folder in sorted(binaryFolders) for f in sorted((p/folder).iterdir()) if f.is_file()];rows=[]
for kind,files in [('source',source),('binaries',binaries)]:
 out=target/f'pr2797-{kind}.zip'
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,9) as z:
  for f,name in files:z.write(f,name)
 assert out.stat().st_size<32*1024*1024
 rows.append({'kind':kind,'file':out.name,'bytes':out.stat().st_size,'files':len(files),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
(p/'archive-manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
