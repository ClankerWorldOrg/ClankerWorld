﻿namespace ClankerWorld.GodotClient {

partial class Main
{
}

}
