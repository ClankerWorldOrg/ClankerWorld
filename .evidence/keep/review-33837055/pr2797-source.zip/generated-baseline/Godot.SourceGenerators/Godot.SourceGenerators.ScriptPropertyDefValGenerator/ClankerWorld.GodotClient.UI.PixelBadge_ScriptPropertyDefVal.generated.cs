﻿namespace ClankerWorld.GodotClient.UI {

partial class PixelBadge
{
}

}
