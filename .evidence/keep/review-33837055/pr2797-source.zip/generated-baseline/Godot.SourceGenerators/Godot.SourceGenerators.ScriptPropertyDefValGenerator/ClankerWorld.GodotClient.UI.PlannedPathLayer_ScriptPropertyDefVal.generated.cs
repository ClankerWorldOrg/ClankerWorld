﻿namespace ClankerWorld.GodotClient.UI {

partial class PlannedPathLayer
{
}

}
