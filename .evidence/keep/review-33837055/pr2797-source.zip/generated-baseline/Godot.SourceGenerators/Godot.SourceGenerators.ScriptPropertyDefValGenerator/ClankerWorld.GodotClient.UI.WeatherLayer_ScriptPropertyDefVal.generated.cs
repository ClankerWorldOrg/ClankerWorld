﻿namespace ClankerWorld.GodotClient.UI {

partial class WeatherLayer
{
}

}
