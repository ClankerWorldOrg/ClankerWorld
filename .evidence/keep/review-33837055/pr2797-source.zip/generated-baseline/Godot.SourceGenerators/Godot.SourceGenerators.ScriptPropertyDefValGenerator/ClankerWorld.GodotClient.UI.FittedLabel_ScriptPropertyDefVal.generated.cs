﻿namespace ClankerWorld.GodotClient.UI {

partial class FittedLabel
{
}

}
