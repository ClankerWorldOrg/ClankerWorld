﻿namespace ClankerWorld.GodotClient.UI {

partial class ItemStorage
{
}

}
