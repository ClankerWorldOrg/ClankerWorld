﻿namespace ClankerWorld.GodotClient.UI {

partial class BuildingHeader
{
}

}
