﻿namespace ClankerWorld.GodotClient.UI {

partial class PixelMeter
{
}

}
