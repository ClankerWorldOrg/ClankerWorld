﻿namespace ClankerWorld.GodotClient.UI {

partial class WorldMapAtlas
{
}

}
