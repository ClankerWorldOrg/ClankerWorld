﻿namespace ClankerWorld.GodotClient.UI {

partial class SmokeLayer
{
}

}
