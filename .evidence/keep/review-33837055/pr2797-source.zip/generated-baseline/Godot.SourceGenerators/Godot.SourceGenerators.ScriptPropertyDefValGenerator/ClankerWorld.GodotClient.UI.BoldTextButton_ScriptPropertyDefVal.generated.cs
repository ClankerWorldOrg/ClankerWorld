﻿namespace ClankerWorld.GodotClient.UI {

partial class BoldTextButton
{
}

}
