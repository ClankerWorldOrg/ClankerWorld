﻿namespace ClankerWorld.GodotClient.UI {

partial class OccupancyBadge
{
}

}
