﻿namespace ClankerWorld.GodotClient.UI {

partial class SegmentedChoice
{
}

}
