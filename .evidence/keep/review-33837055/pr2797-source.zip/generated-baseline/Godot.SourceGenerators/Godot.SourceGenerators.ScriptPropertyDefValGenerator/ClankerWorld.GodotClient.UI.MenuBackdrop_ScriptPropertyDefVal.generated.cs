﻿namespace ClankerWorld.GodotClient.UI {

partial class MenuBackdrop
{
}

}
