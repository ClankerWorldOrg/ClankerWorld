﻿namespace ClankerWorld.GodotClient.UI {

partial class BuildingCompletionLayer
{
}

}
