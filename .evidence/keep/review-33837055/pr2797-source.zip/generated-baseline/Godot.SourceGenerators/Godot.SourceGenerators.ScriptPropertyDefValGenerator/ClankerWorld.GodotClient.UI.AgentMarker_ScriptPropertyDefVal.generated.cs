﻿namespace ClankerWorld.GodotClient.UI {

partial class AgentMarker
{
}

}
