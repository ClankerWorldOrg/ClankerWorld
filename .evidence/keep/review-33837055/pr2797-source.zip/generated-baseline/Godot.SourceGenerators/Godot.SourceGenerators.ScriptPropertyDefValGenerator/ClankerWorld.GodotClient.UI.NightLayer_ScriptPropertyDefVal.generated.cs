﻿namespace ClankerWorld.GodotClient.UI {

partial class NightLayer
{
}

}
