﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/StoredStockLayer.cs")]
partial class StoredStockLayer
{
}

}
