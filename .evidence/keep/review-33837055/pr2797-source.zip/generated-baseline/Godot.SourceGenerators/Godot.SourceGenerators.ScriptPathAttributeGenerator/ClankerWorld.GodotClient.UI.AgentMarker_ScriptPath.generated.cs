﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/AgentMarker.cs")]
partial class AgentMarker
{
}

}
