﻿using Godot;
namespace ClankerWorld.GodotClient.Launcher {

[ScriptPathAttribute("res://Launcher/Launcher.cs")]
partial class Launcher
{
}

}
