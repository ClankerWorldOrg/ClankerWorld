﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/AnimalMapSprite.cs")]
partial class AnimalMapSprite
{
}

}
