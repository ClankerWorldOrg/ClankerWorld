﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/ItemStorage.cs")]
partial class ItemStorage
{
}

}
