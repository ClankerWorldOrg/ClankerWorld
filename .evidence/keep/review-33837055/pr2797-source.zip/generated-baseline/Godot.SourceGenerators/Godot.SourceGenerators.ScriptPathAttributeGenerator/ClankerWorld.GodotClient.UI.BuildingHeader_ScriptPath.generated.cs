﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/BuildingHeader.cs")]
partial class BuildingHeader
{
}

}
