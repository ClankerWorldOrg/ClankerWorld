﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/WorldTerrainLayer.cs")]
partial class WorldTerrainLayer
{
}

}
