﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/WorldEditPreviewLayer.cs")]
partial class WorldEditPreviewLayer
{
}

}
