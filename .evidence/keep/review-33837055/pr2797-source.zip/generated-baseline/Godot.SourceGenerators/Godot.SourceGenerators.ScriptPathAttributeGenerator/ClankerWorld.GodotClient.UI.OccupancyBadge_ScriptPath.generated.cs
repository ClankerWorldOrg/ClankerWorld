﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/OccupancyBadge.cs")]
partial class OccupancyBadge
{
}

}
