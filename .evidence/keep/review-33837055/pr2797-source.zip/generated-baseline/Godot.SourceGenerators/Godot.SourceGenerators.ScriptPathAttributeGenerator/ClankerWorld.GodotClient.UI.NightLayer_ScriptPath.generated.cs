﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/NightLayer.cs")]
partial class NightLayer
{
}

}
