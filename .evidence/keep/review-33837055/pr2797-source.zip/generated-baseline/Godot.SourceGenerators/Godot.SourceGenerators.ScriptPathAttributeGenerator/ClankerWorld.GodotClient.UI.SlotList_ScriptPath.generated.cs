﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/SlotList.cs")]
partial class SlotList
{
}

}
