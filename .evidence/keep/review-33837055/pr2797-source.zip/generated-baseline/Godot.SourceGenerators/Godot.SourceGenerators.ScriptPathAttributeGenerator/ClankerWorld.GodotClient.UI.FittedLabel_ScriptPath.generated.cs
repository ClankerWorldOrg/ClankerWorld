﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/FittedLabel.cs")]
partial class FittedLabel
{
}

}
