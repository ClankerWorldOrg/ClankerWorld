﻿using Godot;
namespace ClankerWorld.GodotClient {

[ScriptPathAttribute("res://Screens/Main/Main.cs")]
partial class Main
{
}

}
