﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/GoldenHourLayer.cs")]
partial class GoldenHourLayer
{
}

}
