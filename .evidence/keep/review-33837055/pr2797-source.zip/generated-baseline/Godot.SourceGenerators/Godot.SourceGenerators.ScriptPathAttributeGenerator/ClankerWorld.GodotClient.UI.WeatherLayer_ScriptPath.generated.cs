﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/WeatherLayer.cs")]
partial class WeatherLayer
{
}

}
