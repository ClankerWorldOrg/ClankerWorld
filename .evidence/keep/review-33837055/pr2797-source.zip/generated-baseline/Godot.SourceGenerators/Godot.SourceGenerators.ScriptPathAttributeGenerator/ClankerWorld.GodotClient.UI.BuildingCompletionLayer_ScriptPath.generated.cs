﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/BuildingCompletionLayer.cs")]
partial class BuildingCompletionLayer
{
}

}
