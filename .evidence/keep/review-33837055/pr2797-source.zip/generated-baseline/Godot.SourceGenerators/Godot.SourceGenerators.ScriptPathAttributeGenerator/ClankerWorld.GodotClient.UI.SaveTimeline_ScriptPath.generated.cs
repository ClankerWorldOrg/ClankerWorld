﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/SaveTimeline.cs")]
partial class SaveTimeline
{
}

}
