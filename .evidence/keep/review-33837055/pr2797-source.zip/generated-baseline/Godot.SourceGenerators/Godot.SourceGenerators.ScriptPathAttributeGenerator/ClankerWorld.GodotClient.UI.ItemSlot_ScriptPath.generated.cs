﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/ItemSlot.cs")]
partial class ItemSlot
{
}

}
