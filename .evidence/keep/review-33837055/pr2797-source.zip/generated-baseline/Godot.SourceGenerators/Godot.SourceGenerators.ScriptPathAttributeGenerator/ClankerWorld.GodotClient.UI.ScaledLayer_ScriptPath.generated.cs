﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/ScaledLayer.cs")]
partial class ScaledLayer
{
}

}
