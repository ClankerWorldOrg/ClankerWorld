﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/SmokeLayer.cs")]
partial class SmokeLayer
{
}

}
