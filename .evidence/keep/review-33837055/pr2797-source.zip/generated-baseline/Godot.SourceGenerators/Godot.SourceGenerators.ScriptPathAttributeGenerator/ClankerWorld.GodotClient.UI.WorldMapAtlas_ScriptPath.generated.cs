﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/WorldMapAtlas.cs")]
partial class WorldMapAtlas
{
}

}
