﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/PixelMeter.cs")]
partial class PixelMeter
{
}

}
