﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/PlannedPathLayer.cs")]
partial class PlannedPathLayer
{
}

}
