﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/SegmentedChoice.cs")]
partial class SegmentedChoice
{
}

}
