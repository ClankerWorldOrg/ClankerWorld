﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/BoldTextButton.cs")]
partial class BoldTextButton
{
}

}
