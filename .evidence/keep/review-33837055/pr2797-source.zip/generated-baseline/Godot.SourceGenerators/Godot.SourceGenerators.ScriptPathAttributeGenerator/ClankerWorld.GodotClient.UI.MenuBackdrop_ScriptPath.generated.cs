﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Menu/MenuBackdrop.cs")]
partial class MenuBackdrop
{
}

}
