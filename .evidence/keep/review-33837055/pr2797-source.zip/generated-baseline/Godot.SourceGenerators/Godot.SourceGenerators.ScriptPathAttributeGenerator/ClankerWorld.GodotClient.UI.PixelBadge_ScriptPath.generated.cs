﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/PixelBadge.cs")]
partial class PixelBadge
{
}

}
