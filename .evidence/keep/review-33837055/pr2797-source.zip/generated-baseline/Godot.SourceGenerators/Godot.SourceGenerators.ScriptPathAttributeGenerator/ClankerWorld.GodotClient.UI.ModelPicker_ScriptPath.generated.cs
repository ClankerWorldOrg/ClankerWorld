﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/ModelPicker.cs")]
partial class ModelPicker
{
}

}
