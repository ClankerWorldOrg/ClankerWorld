﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Components/FamilyTreeView.cs")]
partial class FamilyTreeView
{
}

}
