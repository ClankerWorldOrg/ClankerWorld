﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/NightLightsLayer.cs")]
partial class NightLightsLayer
{
}

}
