﻿using Godot;
namespace ClankerWorld.GodotClient.UI {

[ScriptPathAttribute("res://UI/Map/GraveLayer.cs")]
partial class GraveLayer
{
}

}
