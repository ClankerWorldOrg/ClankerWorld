﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class PixelBadge
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Text, global::Godot.Variant.From<string>(this.@Text));
        info.AddProperty(PropertyName.@text, global::Godot.Variant.From<string>(this.@text));
        info.AddProperty(PropertyName.@diameter, global::Godot.Variant.From<int>(this.@diameter));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Text, out var _value_Text))
            this.@Text = _value_Text.As<string>();
        if (info.TryGetProperty(PropertyName.@text, out var _value_text))
            this.@text = _value_text.As<string>();
        if (info.TryGetProperty(PropertyName.@diameter, out var _value_diameter))
            this.@diameter = _value_diameter.As<int>();
    }
}

}
