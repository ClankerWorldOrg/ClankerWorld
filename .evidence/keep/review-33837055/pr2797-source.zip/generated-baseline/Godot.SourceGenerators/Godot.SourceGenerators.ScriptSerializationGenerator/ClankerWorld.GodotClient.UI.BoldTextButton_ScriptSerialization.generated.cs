﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class BoldTextButton
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Caption, global::Godot.Variant.From<string>(this.@Caption));
        info.AddProperty(PropertyName.@Glyph, global::Godot.Variant.From<global::Godot.Texture2D>(this.@Glyph));
        info.AddProperty(PropertyName.@Captions, global::Godot.Variant.From<string[]>(this.@Captions));
        info.AddProperty(PropertyName.@caption, global::Godot.Variant.From<string>(this.@caption));
        info.AddProperty(PropertyName.@glyph, global::Godot.Variant.From<global::Godot.Texture2D>(this.@glyph));
        info.AddProperty(PropertyName.@captions, global::Godot.Variant.From<string[]>(this.@captions));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Caption, out var _value_Caption))
            this.@Caption = _value_Caption.As<string>();
        if (info.TryGetProperty(PropertyName.@Glyph, out var _value_Glyph))
            this.@Glyph = _value_Glyph.As<global::Godot.Texture2D>();
        if (info.TryGetProperty(PropertyName.@Captions, out var _value_Captions))
            this.@Captions = _value_Captions.As<string[]>();
        if (info.TryGetProperty(PropertyName.@caption, out var _value_caption))
            this.@caption = _value_caption.As<string>();
        if (info.TryGetProperty(PropertyName.@glyph, out var _value_glyph))
            this.@glyph = _value_glyph.As<global::Godot.Texture2D>();
        if (info.TryGetProperty(PropertyName.@captions, out var _value_captions))
            this.@captions = _value_captions.As<string[]>();
    }
}

}
