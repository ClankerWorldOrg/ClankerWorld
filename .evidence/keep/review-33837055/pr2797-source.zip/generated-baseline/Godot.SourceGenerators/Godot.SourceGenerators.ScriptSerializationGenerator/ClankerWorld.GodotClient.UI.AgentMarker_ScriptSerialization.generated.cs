﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class AgentMarker
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Caption, global::Godot.Variant.From<string>(this.@Caption));
        info.AddProperty(PropertyName.@Selected, global::Godot.Variant.From<bool>(this.@Selected));
        info.AddProperty(PropertyName.@ConversationBadgeVisible, global::Godot.Variant.From<bool>(this.@ConversationBadgeVisible));
        info.AddProperty(PropertyName.@ConversationUnread, global::Godot.Variant.From<bool>(this.@ConversationUnread));
        info.AddProperty(PropertyName.@Variant, global::Godot.Variant.From<int>(this.@Variant));
        info.AddProperty(PropertyName.@Stage, global::Godot.Variant.From<int>(this.@Stage));
        info.AddProperty(PropertyName.@Activity, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.AgentFrame>(this.@Activity));
        info.AddProperty(PropertyName.@Swimming, global::Godot.Variant.From<bool>(this.@Swimming));
        info.AddProperty(PropertyName.@caption, global::Godot.Variant.From<string>(this.@caption));
        info.AddProperty(PropertyName.@selected, global::Godot.Variant.From<bool>(this.@selected));
        info.AddProperty(PropertyName.@hovered, global::Godot.Variant.From<bool>(this.@hovered));
        info.AddProperty(PropertyName.@conversationBadgeVisible, global::Godot.Variant.From<bool>(this.@conversationBadgeVisible));
        info.AddProperty(PropertyName.@conversationUnread, global::Godot.Variant.From<bool>(this.@conversationUnread));
        info.AddProperty(PropertyName.@variant, global::Godot.Variant.From<int>(this.@variant));
        info.AddProperty(PropertyName.@stage, global::Godot.Variant.From<int>(this.@stage));
        info.AddProperty(PropertyName.@facing, global::Godot.Variant.From<int>(this.@facing));
        info.AddProperty(PropertyName.@activity, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.AgentFrame>(this.@activity));
        info.AddProperty(PropertyName.@swimming, global::Godot.Variant.From<bool>(this.@swimming));
        info.AddProperty(PropertyName.@swimmingSeconds, global::Godot.Variant.From<double>(this.@swimmingSeconds));
        info.AddProperty(PropertyName.@step, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.AgentFrame>(this.@step));
        info.AddProperty(PropertyName.@motionWorldId, global::Godot.Variant.From<string>(this.@motionWorldId));
        info.AddProperty(PropertyName.@modelWaiting, global::Godot.Variant.From<bool>(this.@modelWaiting));
        info.AddProperty(PropertyName.@modelWaitSeconds, global::Godot.Variant.From<double>(this.@modelWaitSeconds));
        info.AddProperty(PropertyName.@modelWaitWorldId, global::Godot.Variant.From<string>(this.@modelWaitWorldId));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Caption, out var _value_Caption))
            this.@Caption = _value_Caption.As<string>();
        if (info.TryGetProperty(PropertyName.@Selected, out var _value_Selected))
            this.@Selected = _value_Selected.As<bool>();
        if (info.TryGetProperty(PropertyName.@ConversationBadgeVisible, out var _value_ConversationBadgeVisible))
            this.@ConversationBadgeVisible = _value_ConversationBadgeVisible.As<bool>();
        if (info.TryGetProperty(PropertyName.@ConversationUnread, out var _value_ConversationUnread))
            this.@ConversationUnread = _value_ConversationUnread.As<bool>();
        if (info.TryGetProperty(PropertyName.@Variant, out var _value_Variant))
            this.@Variant = _value_Variant.As<int>();
        if (info.TryGetProperty(PropertyName.@Stage, out var _value_Stage))
            this.@Stage = _value_Stage.As<int>();
        if (info.TryGetProperty(PropertyName.@Activity, out var _value_Activity))
            this.@Activity = _value_Activity.As<global::ClankerWorld.GodotClient.UI.AgentFrame>();
        if (info.TryGetProperty(PropertyName.@Swimming, out var _value_Swimming))
            this.@Swimming = _value_Swimming.As<bool>();
        if (info.TryGetProperty(PropertyName.@caption, out var _value_caption))
            this.@caption = _value_caption.As<string>();
        if (info.TryGetProperty(PropertyName.@selected, out var _value_selected))
            this.@selected = _value_selected.As<bool>();
        if (info.TryGetProperty(PropertyName.@hovered, out var _value_hovered))
            this.@hovered = _value_hovered.As<bool>();
        if (info.TryGetProperty(PropertyName.@conversationBadgeVisible, out var _value_conversationBadgeVisible))
            this.@conversationBadgeVisible = _value_conversationBadgeVisible.As<bool>();
        if (info.TryGetProperty(PropertyName.@conversationUnread, out var _value_conversationUnread))
            this.@conversationUnread = _value_conversationUnread.As<bool>();
        if (info.TryGetProperty(PropertyName.@variant, out var _value_variant))
            this.@variant = _value_variant.As<int>();
        if (info.TryGetProperty(PropertyName.@stage, out var _value_stage))
            this.@stage = _value_stage.As<int>();
        if (info.TryGetProperty(PropertyName.@facing, out var _value_facing))
            this.@facing = _value_facing.As<int>();
        if (info.TryGetProperty(PropertyName.@activity, out var _value_activity))
            this.@activity = _value_activity.As<global::ClankerWorld.GodotClient.UI.AgentFrame>();
        if (info.TryGetProperty(PropertyName.@swimming, out var _value_swimming))
            this.@swimming = _value_swimming.As<bool>();
        if (info.TryGetProperty(PropertyName.@swimmingSeconds, out var _value_swimmingSeconds))
            this.@swimmingSeconds = _value_swimmingSeconds.As<double>();
        if (info.TryGetProperty(PropertyName.@step, out var _value_step))
            this.@step = _value_step.As<global::ClankerWorld.GodotClient.UI.AgentFrame>();
        if (info.TryGetProperty(PropertyName.@motionWorldId, out var _value_motionWorldId))
            this.@motionWorldId = _value_motionWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@modelWaiting, out var _value_modelWaiting))
            this.@modelWaiting = _value_modelWaiting.As<bool>();
        if (info.TryGetProperty(PropertyName.@modelWaitSeconds, out var _value_modelWaitSeconds))
            this.@modelWaitSeconds = _value_modelWaitSeconds.As<double>();
        if (info.TryGetProperty(PropertyName.@modelWaitWorldId, out var _value_modelWaitWorldId))
            this.@modelWaitWorldId = _value_modelWaitWorldId.As<string>();
    }
}

}
