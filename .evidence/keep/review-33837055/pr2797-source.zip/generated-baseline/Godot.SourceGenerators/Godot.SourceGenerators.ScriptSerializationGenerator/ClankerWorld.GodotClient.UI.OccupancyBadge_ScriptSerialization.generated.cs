﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class OccupancyBadge
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Count, global::Godot.Variant.From<int>(this.@Count));
        info.AddProperty(PropertyName.@count, global::Godot.Variant.From<int>(this.@count));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Count, out var _value_Count))
            this.@Count = _value_Count.As<int>();
        if (info.TryGetProperty(PropertyName.@count, out var _value_count))
            this.@count = _value_count.As<int>();
    }
}

}
