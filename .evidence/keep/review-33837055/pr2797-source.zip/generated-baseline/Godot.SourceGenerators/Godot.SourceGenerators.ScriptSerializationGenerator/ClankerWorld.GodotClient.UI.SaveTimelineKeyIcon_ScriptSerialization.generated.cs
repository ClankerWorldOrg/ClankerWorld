﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SaveTimelineKeyIcon
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Kind, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.SaveTimelineKeyKind>(this.@Kind));
        info.AddProperty(PropertyName.@kind, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.SaveTimelineKeyKind>(this.@kind));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Kind, out var _value_Kind))
            this.@Kind = _value_Kind.As<global::ClankerWorld.GodotClient.UI.SaveTimelineKeyKind>();
        if (info.TryGetProperty(PropertyName.@kind, out var _value_kind))
            this.@kind = _value_kind.As<global::ClankerWorld.GodotClient.UI.SaveTimelineKeyKind>();
    }
}

}
