﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class ModelPicker
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Editable, global::Godot.Variant.From<bool>(this.@Editable));
        info.AddProperty(PropertyName.@defaultModel, global::Godot.Variant.From<string>(this.@defaultModel));
        info.AddProperty(PropertyName.@current, global::Godot.Variant.From<string>(this.@current));
        info.AddProperty(PropertyName.@error, global::Godot.Variant.From<string>(this.@error));
        info.AddProperty(PropertyName.@loading, global::Godot.Variant.From<bool>(this.@loading));
        info.AddProperty(PropertyName.@listed, global::Godot.Variant.From<bool>(this.@listed));
        info.AddProperty(PropertyName.@typing, global::Godot.Variant.From<bool>(this.@typing));
        info.AddProperty(PropertyName.@mustChoose, global::Godot.Variant.From<bool>(this.@mustChoose));
        info.AddProperty(PropertyName.@newAgent, global::Godot.Variant.From<bool>(this.@newAgent));
        info.AddProperty(PropertyName.@request, global::Godot.Variant.From<int>(this.@request));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Editable, out var _value_Editable))
            this.@Editable = _value_Editable.As<bool>();
        if (info.TryGetProperty(PropertyName.@defaultModel, out var _value_defaultModel))
            this.@defaultModel = _value_defaultModel.As<string>();
        if (info.TryGetProperty(PropertyName.@current, out var _value_current))
            this.@current = _value_current.As<string>();
        if (info.TryGetProperty(PropertyName.@error, out var _value_error))
            this.@error = _value_error.As<string>();
        if (info.TryGetProperty(PropertyName.@loading, out var _value_loading))
            this.@loading = _value_loading.As<bool>();
        if (info.TryGetProperty(PropertyName.@listed, out var _value_listed))
            this.@listed = _value_listed.As<bool>();
        if (info.TryGetProperty(PropertyName.@typing, out var _value_typing))
            this.@typing = _value_typing.As<bool>();
        if (info.TryGetProperty(PropertyName.@mustChoose, out var _value_mustChoose))
            this.@mustChoose = _value_mustChoose.As<bool>();
        if (info.TryGetProperty(PropertyName.@newAgent, out var _value_newAgent))
            this.@newAgent = _value_newAgent.As<bool>();
        if (info.TryGetProperty(PropertyName.@request, out var _value_request))
            this.@request = _value_request.As<int>();
    }
}

}
