﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SegmentedChoice
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddSignalEventDelegate(SignalName.@ItemSelected, this.backing_ItemSelected);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetSignalEventDelegate<global::ClankerWorld.GodotClient.UI.SegmentedChoice.ItemSelectedEventHandler>(SignalName.@ItemSelected, out var _value_ItemSelected))
            this.backing_ItemSelected = _value_ItemSelected;
    }
}

}
