﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.Launcher {

partial class Launcher
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@releasesReached, global::Godot.Variant.From<bool>(this.@releasesReached));
        info.AddProperty(PropertyName.@requestedVersion, global::Godot.Variant.From<string>(this.@requestedVersion));
        info.AddProperty(PropertyName.@requestedWorld, global::Godot.Variant.From<string>(this.@requestedWorld));
        info.AddProperty(PropertyName.@busy, global::Godot.Variant.From<bool>(this.@busy));
        info.AddProperty(PropertyName.@hostingRunning, global::Godot.Variant.From<bool>(this.@hostingRunning));
        info.AddProperty(PropertyName.@refreshingHost, global::Godot.Variant.From<bool>(this.@refreshingHost));
        info.AddProperty(PropertyName.@joining, global::Godot.Variant.From<bool>(this.@joining));
        info.AddProperty(PropertyName.@joinRegistrationPath, global::Godot.Variant.From<string>(this.@joinRegistrationPath));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@releasesReached, out var _value_releasesReached))
            this.@releasesReached = _value_releasesReached.As<bool>();
        if (info.TryGetProperty(PropertyName.@requestedVersion, out var _value_requestedVersion))
            this.@requestedVersion = _value_requestedVersion.As<string>();
        if (info.TryGetProperty(PropertyName.@requestedWorld, out var _value_requestedWorld))
            this.@requestedWorld = _value_requestedWorld.As<string>();
        if (info.TryGetProperty(PropertyName.@busy, out var _value_busy))
            this.@busy = _value_busy.As<bool>();
        if (info.TryGetProperty(PropertyName.@hostingRunning, out var _value_hostingRunning))
            this.@hostingRunning = _value_hostingRunning.As<bool>();
        if (info.TryGetProperty(PropertyName.@refreshingHost, out var _value_refreshingHost))
            this.@refreshingHost = _value_refreshingHost.As<bool>();
        if (info.TryGetProperty(PropertyName.@joining, out var _value_joining))
            this.@joining = _value_joining.As<bool>();
        if (info.TryGetProperty(PropertyName.@joinRegistrationPath, out var _value_joinRegistrationPath))
            this.@joinRegistrationPath = _value_joinRegistrationPath.As<string>();
    }
}

}
