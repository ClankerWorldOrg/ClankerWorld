﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient {

partial class Main
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@conversationReadWorldId, global::Godot.Variant.From<string>(this.@conversationReadWorldId));
        info.AddProperty(PropertyName.@openConversationId, global::Godot.Variant.From<string>(this.@openConversationId));
        info.AddProperty(PropertyName.@openConversationAgentId, global::Godot.Variant.From<string>(this.@openConversationAgentId));
        info.AddProperty(PropertyName.@conversationHistoryExpanded, global::Godot.Variant.From<bool>(this.@conversationHistoryExpanded));
        info.AddProperty(PropertyName.@renderedAgentListWorldId, global::Godot.Variant.From<string>(this.@renderedAgentListWorldId));
        info.AddProperty(PropertyName.@renderedAgentListTheme, global::Godot.Variant.From<string>(this.@renderedAgentListTheme));
        info.AddProperty(PropertyName.@agentProfileFitQueued, global::Godot.Variant.From<bool>(this.@agentProfileFitQueued));
        info.AddProperty(PropertyName.@renderedThoughtsReader, global::Godot.Variant.From<string>(this.@renderedThoughtsReader));
        info.AddProperty(PropertyName.@agentProfileRequested, global::Godot.Variant.From<bool>(this.@agentProfileRequested));
        info.AddProperty(PropertyName.@measuredFirstAgentProfile, global::Godot.Variant.From<bool>(this.@measuredFirstAgentProfile));
        info.AddProperty(PropertyName.@renderedAgentCardTheme, global::Godot.Variant.From<global::Godot.Theme>(this.@renderedAgentCardTheme));
        info.AddProperty(PropertyName.@apiKeysRead, global::Godot.Variant.From<int>(this.@apiKeysRead));
        info.AddProperty(PropertyName.@renderedBuildingRecipes, global::Godot.Variant.From<string>(this.@renderedBuildingRecipes));
        info.AddProperty(PropertyName.@pendingBuildingRemovalWorldId, global::Godot.Variant.From<string>(this.@pendingBuildingRemovalWorldId));
        info.AddProperty(PropertyName.@renderedBuildingManagementWorldId, global::Godot.Variant.From<string>(this.@renderedBuildingManagementWorldId));
        info.AddProperty(PropertyName.@renderedBuildingManagementId, global::Godot.Variant.From<string>(this.@renderedBuildingManagementId));
        info.AddProperty(PropertyName.@selectedBuildingId, global::Godot.Variant.From<string>(this.@selectedBuildingId));
        info.AddProperty(PropertyName.@buildingDetailsRequested, global::Godot.Variant.From<bool>(this.@buildingDetailsRequested));
        info.AddProperty(PropertyName.@renderedBuildingStatus, global::Godot.Variant.From<string>(this.@renderedBuildingStatus));
        info.AddProperty(PropertyName.@renderedBuildingWork, global::Godot.Variant.From<string>(this.@renderedBuildingWork));
        info.AddProperty(PropertyName.@renderedBuildingStorageHistory, global::Godot.Variant.From<string>(this.@renderedBuildingStorageHistory));
        info.AddProperty(PropertyName.@cameraGliding, global::Godot.Variant.From<bool>(this.@cameraGliding));
        info.AddProperty(PropertyName.@cameraGlideFrom, global::Godot.Variant.From<global::Godot.Vector2>(this.@cameraGlideFrom));
        info.AddProperty(PropertyName.@cameraGlideTo, global::Godot.Variant.From<global::Godot.Vector2>(this.@cameraGlideTo));
        info.AddProperty(PropertyName.@cameraGlideElapsed, global::Godot.Variant.From<double>(this.@cameraGlideElapsed));
        info.AddProperty(PropertyName.@cameraZooming, global::Godot.Variant.From<bool>(this.@cameraZooming));
        info.AddProperty(PropertyName.@cameraZoomFrom, global::Godot.Variant.From<float>(this.@cameraZoomFrom));
        info.AddProperty(PropertyName.@cameraZoomTo, global::Godot.Variant.From<float>(this.@cameraZoomTo));
        info.AddProperty(PropertyName.@cameraZoomElapsed, global::Godot.Variant.From<double>(this.@cameraZoomElapsed));
        info.AddProperty(PropertyName.@cameraZoomAnchor, global::Godot.Variant.From<global::Godot.Vector2>(this.@cameraZoomAnchor));
        info.AddProperty(PropertyName.@cameraZoomPoint, global::Godot.Variant.From<global::Godot.Vector2>(this.@cameraZoomPoint));
        info.AddProperty(PropertyName.@renderedObservationGeneration, global::Godot.Variant.From<long>(this.@renderedObservationGeneration));
        info.AddProperty(PropertyName.@settingUpLocalDevice, global::Godot.Variant.From<bool>(this.@settingUpLocalDevice));
        info.AddProperty(PropertyName.@terrainWorldId, global::Godot.Variant.From<string>(this.@terrainWorldId));
        info.AddProperty(PropertyName.@observedRoutineHelperContext, global::Godot.Variant.From<string>(this.@observedRoutineHelperContext));
        info.AddProperty(PropertyName.@lastAgingOverrideWorldId, global::Godot.Variant.From<string>(this.@lastAgingOverrideWorldId));
        info.AddProperty(PropertyName.@usagePauseWorldId, global::Godot.Variant.From<string>(this.@usagePauseWorldId));
        info.AddProperty(PropertyName.@wasObservedPaused, global::Godot.Variant.From<bool>(this.@wasObservedPaused));
        info.AddProperty(PropertyName.@selectedAgentId, global::Godot.Variant.From<string>(this.@selectedAgentId));
        info.AddProperty(PropertyName.@renamingAgentId, global::Godot.Variant.From<string>(this.@renamingAgentId));
        info.AddProperty(PropertyName.@isRefreshing, global::Godot.Variant.From<bool>(this.@isRefreshing));
        info.AddProperty(PropertyName.@successfulRefreshCount, global::Godot.Variant.From<int>(this.@successfulRefreshCount));
        info.AddProperty(PropertyName.@isOwnerAction, global::Godot.Variant.From<bool>(this.@isOwnerAction));
        info.AddProperty(PropertyName.@registeredEndpointInvalid, global::Godot.Variant.From<bool>(this.@registeredEndpointInvalid));
        info.AddProperty(PropertyName.@menuPausedWorld, global::Godot.Variant.From<bool>(this.@menuPausedWorld));
        info.AddProperty(PropertyName.@menuPauseConfirmed, global::Godot.Variant.From<bool>(this.@menuPauseConfirmed));
        info.AddProperty(PropertyName.@pendingMenuResumes, global::Godot.Variant.From<int>(this.@pendingMenuResumes));
        info.AddProperty(PropertyName.@pendingMenuResumeGeneration, global::Godot.Variant.From<long>(this.@pendingMenuResumeGeneration));
        info.AddProperty(PropertyName.@currentTileSize, global::Godot.Variant.From<int>(this.@currentTileSize));
        info.AddProperty(PropertyName.@cameraZoom, global::Godot.Variant.From<float>(this.@cameraZoom));
        info.AddProperty(PropertyName.@minimumCameraZoom, global::Godot.Variant.From<float>(this.@minimumCameraZoom));
        info.AddProperty(PropertyName.@maximumCameraZoom, global::Godot.Variant.From<float>(this.@maximumCameraZoom));
        info.AddProperty(PropertyName.@cameraCenterTiles, global::Godot.Variant.From<global::Godot.Vector2>(this.@cameraCenterTiles));
        info.AddProperty(PropertyName.@cameraWorldId, global::Godot.Variant.From<string>(this.@cameraWorldId));
        info.AddProperty(PropertyName.@draggingMap, global::Godot.Variant.From<bool>(this.@draggingMap));
        info.AddProperty(PropertyName.@renderedEventLog, global::Godot.Variant.From<string>(this.@renderedEventLog));
        info.AddProperty(PropertyName.@statusToastKind, global::Godot.Variant.From<global::ClankerWorld.GodotClient.Main.StatusToastKind>(this.@statusToastKind));
        info.AddProperty(PropertyName.@statusToastShownAtMsec, global::Godot.Variant.From<long>(this.@statusToastShownAtMsec));
        info.AddProperty(PropertyName.@developerEditPeopleKey, global::Godot.Variant.From<string>(this.@developerEditPeopleKey));
        info.AddProperty(PropertyName.@developerFrameMilliseconds, global::Godot.Variant.From<double>(this.@developerFrameMilliseconds));
        info.AddProperty(PropertyName.@developerReadoutAge, global::Godot.Variant.From<double>(this.@developerReadoutAge));
        info.AddProperty(PropertyName.@developerAgentListKey, global::Godot.Variant.From<string>(this.@developerAgentListKey));
        info.AddProperty(PropertyName.@placingAddedAgent, global::Godot.Variant.From<bool>(this.@placingAddedAgent));
        info.AddProperty(PropertyName.@choosingFirstTownSite, global::Godot.Variant.From<bool>(this.@choosingFirstTownSite));
        info.AddProperty(PropertyName.@movingFounderId, global::Godot.Variant.From<string>(this.@movingFounderId));
        info.AddProperty(PropertyName.@renderedTownList, global::Godot.Variant.From<string>(this.@renderedTownList));
        info.AddProperty(PropertyName.@eventLogWorldId, global::Godot.Variant.From<string>(this.@eventLogWorldId));
        info.AddProperty(PropertyName.@lastSeenEventId, global::Godot.Variant.From<long>(this.@lastSeenEventId));
        info.AddProperty(PropertyName.@newEventsAfter, global::Godot.Variant.From<long>(this.@newEventsAfter));
        info.AddProperty(PropertyName.@unreadEvents, global::Godot.Variant.From<int>(this.@unreadEvents));
        info.AddProperty(PropertyName.@keyboardNavigation, global::Godot.Variant.From<bool>(this.@keyboardNavigation));
        info.AddProperty(PropertyName.@keyboardNavigationKey, global::Godot.Variant.From<global::Godot.Key>(this.@keyboardNavigationKey));
        info.AddProperty(PropertyName.@refreshingKeyboardMapSelection, global::Godot.Variant.From<bool>(this.@refreshingKeyboardMapSelection));
        info.AddProperty(PropertyName.@pendingOpenVersion, global::Godot.Variant.From<string>(this.@pendingOpenVersion));
        info.AddProperty(PropertyName.@pendingOpenWorld, global::Godot.Variant.From<string>(this.@pendingOpenWorld));
        info.AddProperty(PropertyName.@failedLauncherVersion, global::Godot.Variant.From<string>(this.@failedLauncherVersion));
        info.AddProperty(PropertyName.@failedLauncherWorld, global::Godot.Variant.From<string>(this.@failedLauncherWorld));
        info.AddProperty(PropertyName.@requestedWorldToSelect, global::Godot.Variant.From<string>(this.@requestedWorldToSelect));
        info.AddProperty(PropertyName.@launcherPath, global::Godot.Variant.From<string>(this.@launcherPath));
        info.AddProperty(PropertyName.@launcherPathRead, global::Godot.Variant.From<bool>(this.@launcherPathRead));
        info.AddProperty(PropertyName.@localServerStarting, global::Godot.Variant.From<bool>(this.@localServerStarting));
        info.AddProperty(PropertyName.@isQuittingGame, global::Godot.Variant.From<bool>(this.@isQuittingGame));
        info.AddProperty(PropertyName.@retryLauncherVersion, global::Godot.Variant.From<string>(this.@retryLauncherVersion));
        info.AddProperty(PropertyName.@retryLauncherWorld, global::Godot.Variant.From<string>(this.@retryLauncherWorld));
        info.AddProperty(PropertyName.@retryChooseCurrentWorld, global::Godot.Variant.From<bool>(this.@retryChooseCurrentWorld));
        info.AddProperty(PropertyName.@mainMenuNavigationRevision, global::Godot.Variant.From<int>(this.@mainMenuNavigationRevision));
        info.AddProperty(PropertyName.@listedActiveWorldId, global::Godot.Variant.From<string>(this.@listedActiveWorldId));
        info.AddProperty(PropertyName.@worldMenuBusy, global::Godot.Variant.From<bool>(this.@worldMenuBusy));
        info.AddProperty(PropertyName.@worldPreviewRevision, global::Godot.Variant.From<int>(this.@worldPreviewRevision));
        info.AddProperty(PropertyName.@isInWorld, global::Godot.Variant.From<bool>(this.@isInWorld));
        info.AddProperty(PropertyName.@returnToMainMenu, global::Godot.Variant.From<bool>(this.@returnToMainMenu));
        info.AddProperty(PropertyName.@resumeWorldOnContinue, global::Godot.Variant.From<bool>(this.@resumeWorldOnContinue));
        info.AddProperty(PropertyName.@isQuittingToMenu, global::Godot.Variant.From<bool>(this.@isQuittingToMenu));
        info.AddProperty(PropertyName.@hoverReadoutTownSiteMode, global::Godot.Variant.From<bool>(this.@hoverReadoutTownSiteMode));
        info.AddProperty(PropertyName.@renderedMemoryCards, global::Godot.Variant.From<string>(this.@renderedMemoryCards));
        info.AddProperty(PropertyName.@usageReads, global::Godot.Variant.From<int>(this.@usageReads));
        info.AddProperty(PropertyName.@usageLimitEdited, global::Godot.Variant.From<bool>(this.@usageLimitEdited));
        info.AddProperty(PropertyName.@routineHelperSetupCheckRevision, global::Godot.Variant.From<int>(this.@routineHelperSetupCheckRevision));
        info.AddProperty(PropertyName.@founderKeyEdits, global::Godot.Variant.From<int>(this.@founderKeyEdits));
        info.AddProperty(PropertyName.@agentModelKeyEdits, global::Godot.Variant.From<int>(this.@agentModelKeyEdits));
        info.AddProperty(PropertyName.@agentModelContext, global::Godot.Variant.From<string>(this.@agentModelContext));
        info.AddProperty(PropertyName.@agentModelLookup, global::Godot.Variant.From<string>(this.@agentModelLookup));
        info.AddProperty(PropertyName.@renderedOrdersReader, global::Godot.Variant.From<string>(this.@renderedOrdersReader));
        info.AddProperty(PropertyName.@pendingRecoveryInProgress, global::Godot.Variant.From<bool>(this.@pendingRecoveryInProgress));
        info.AddProperty(PropertyName.@unloadedPendingSubmission, global::Godot.Variant.From<bool>(this.@unloadedPendingSubmission));
        info.AddProperty(PropertyName.@renderedProfilePeople, global::Godot.Variant.From<string>(this.@renderedProfilePeople));
        info.AddProperty(PropertyName.@agentModelSetupCheckContext, global::Godot.Variant.From<string>(this.@agentModelSetupCheckContext));
        info.AddProperty(PropertyName.@founderModelSetupCheckRevision, global::Godot.Variant.From<int>(this.@founderModelSetupCheckRevision));
        info.AddProperty(PropertyName.@agentModelSetupCheckRevision, global::Godot.Variant.From<int>(this.@agentModelSetupCheckRevision));
        info.AddProperty(PropertyName.@agentListWantedHeight, global::Godot.Variant.From<float>(this.@agentListWantedHeight));
        info.AddProperty(PropertyName.@eventLogWantedHeight, global::Godot.Variant.From<float>(this.@eventLogWantedHeight));
        info.AddProperty(PropertyName.@hudListsRefitQueued, global::Godot.Variant.From<bool>(this.@hudListsRefitQueued));
        info.AddProperty(PropertyName.@lastDiskSpaceReadMsec, global::Godot.Variant.From<long>(this.@lastDiskSpaceReadMsec));
        info.AddProperty(PropertyName.@diskSpaceReadPending, global::Godot.Variant.From<bool>(this.@diskSpaceReadPending));
        info.AddProperty(PropertyName.@manualSaveBody, global::Godot.Variant.From<global::Godot.VBoxContainer>(this.@manualSaveBody));
        info.AddProperty(PropertyName.@worldHistoryLoading, global::Godot.Variant.From<bool>(this.@worldHistoryLoading));
        info.AddProperty(PropertyName.@worldHistoryLoaded, global::Godot.Variant.From<bool>(this.@worldHistoryLoaded));
        info.AddProperty(PropertyName.@listedSaveWorldId, global::Godot.Variant.From<string>(this.@listedSaveWorldId));
        info.AddProperty(PropertyName.@pendingOverwriteSaveId, global::Godot.Variant.From<string>(this.@pendingOverwriteSaveId));
        info.AddProperty(PropertyName.@manualSaveLoadMode, global::Godot.Variant.From<bool>(this.@manualSaveLoadMode));
        info.AddProperty(PropertyName.@manualSaveShowsList, global::Godot.Variant.From<bool>(this.@manualSaveShowsList));
        info.AddProperty(PropertyName.@autosaveSettingsLoaded, global::Godot.Variant.From<bool>(this.@autosaveSettingsLoaded));
        info.AddProperty(PropertyName.@autosaveSettingsWorldId, global::Godot.Variant.From<string>(this.@autosaveSettingsWorldId));
        info.AddProperty(PropertyName.@autosaveSettingsGeneration, global::Godot.Variant.From<long>(this.@autosaveSettingsGeneration));
        info.AddProperty(PropertyName.@renderedControlsTheme, global::Godot.Variant.From<string>(this.@renderedControlsTheme));
        info.AddProperty(PropertyName.@startupRecoveryReadRevision, global::Godot.Variant.From<int>(this.@startupRecoveryReadRevision));
        info.AddProperty(PropertyName.@startupRecoveryBusy, global::Godot.Variant.From<bool>(this.@startupRecoveryBusy));
        info.AddProperty(PropertyName.@worldEditWorldId, global::Godot.Variant.From<string>(this.@worldEditWorldId));
        info.AddProperty(PropertyName.@renderedWorldStats, global::Godot.Variant.From<string>(this.@renderedWorldStats));
        info.AddProperty(PropertyName.@renderedWorldToday, global::Godot.Variant.From<string>(this.@renderedWorldToday));
        info.AddProperty(PropertyName.@worldTodayCard, global::Godot.Variant.From<global::Godot.PanelContainer>(this.@worldTodayCard));
        info.AddProperty(PropertyName.@worldCounts, global::Godot.Variant.From<global::Godot.VBoxContainer>(this.@worldCounts));
        info.AddProperty(PropertyName.@renderedTownExtras, global::Godot.Variant.From<string>(this.@renderedTownExtras));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@conversationReadWorldId, out var _value_conversationReadWorldId))
            this.@conversationReadWorldId = _value_conversationReadWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@openConversationId, out var _value_openConversationId))
            this.@openConversationId = _value_openConversationId.As<string>();
        if (info.TryGetProperty(PropertyName.@openConversationAgentId, out var _value_openConversationAgentId))
            this.@openConversationAgentId = _value_openConversationAgentId.As<string>();
        if (info.TryGetProperty(PropertyName.@conversationHistoryExpanded, out var _value_conversationHistoryExpanded))
            this.@conversationHistoryExpanded = _value_conversationHistoryExpanded.As<bool>();
        if (info.TryGetProperty(PropertyName.@renderedAgentListWorldId, out var _value_renderedAgentListWorldId))
            this.@renderedAgentListWorldId = _value_renderedAgentListWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@renderedAgentListTheme, out var _value_renderedAgentListTheme))
            this.@renderedAgentListTheme = _value_renderedAgentListTheme.As<string>();
        if (info.TryGetProperty(PropertyName.@agentProfileFitQueued, out var _value_agentProfileFitQueued))
            this.@agentProfileFitQueued = _value_agentProfileFitQueued.As<bool>();
        if (info.TryGetProperty(PropertyName.@renderedThoughtsReader, out var _value_renderedThoughtsReader))
            this.@renderedThoughtsReader = _value_renderedThoughtsReader.As<string>();
        if (info.TryGetProperty(PropertyName.@agentProfileRequested, out var _value_agentProfileRequested))
            this.@agentProfileRequested = _value_agentProfileRequested.As<bool>();
        if (info.TryGetProperty(PropertyName.@measuredFirstAgentProfile, out var _value_measuredFirstAgentProfile))
            this.@measuredFirstAgentProfile = _value_measuredFirstAgentProfile.As<bool>();
        if (info.TryGetProperty(PropertyName.@renderedAgentCardTheme, out var _value_renderedAgentCardTheme))
            this.@renderedAgentCardTheme = _value_renderedAgentCardTheme.As<global::Godot.Theme>();
        if (info.TryGetProperty(PropertyName.@apiKeysRead, out var _value_apiKeysRead))
            this.@apiKeysRead = _value_apiKeysRead.As<int>();
        if (info.TryGetProperty(PropertyName.@renderedBuildingRecipes, out var _value_renderedBuildingRecipes))
            this.@renderedBuildingRecipes = _value_renderedBuildingRecipes.As<string>();
        if (info.TryGetProperty(PropertyName.@pendingBuildingRemovalWorldId, out var _value_pendingBuildingRemovalWorldId))
            this.@pendingBuildingRemovalWorldId = _value_pendingBuildingRemovalWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@renderedBuildingManagementWorldId, out var _value_renderedBuildingManagementWorldId))
            this.@renderedBuildingManagementWorldId = _value_renderedBuildingManagementWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@renderedBuildingManagementId, out var _value_renderedBuildingManagementId))
            this.@renderedBuildingManagementId = _value_renderedBuildingManagementId.As<string>();
        if (info.TryGetProperty(PropertyName.@selectedBuildingId, out var _value_selectedBuildingId))
            this.@selectedBuildingId = _value_selectedBuildingId.As<string>();
        if (info.TryGetProperty(PropertyName.@buildingDetailsRequested, out var _value_buildingDetailsRequested))
            this.@buildingDetailsRequested = _value_buildingDetailsRequested.As<bool>();
        if (info.TryGetProperty(PropertyName.@renderedBuildingStatus, out var _value_renderedBuildingStatus))
            this.@renderedBuildingStatus = _value_renderedBuildingStatus.As<string>();
        if (info.TryGetProperty(PropertyName.@renderedBuildingWork, out var _value_renderedBuildingWork))
            this.@renderedBuildingWork = _value_renderedBuildingWork.As<string>();
        if (info.TryGetProperty(PropertyName.@renderedBuildingStorageHistory, out var _value_renderedBuildingStorageHistory))
            this.@renderedBuildingStorageHistory = _value_renderedBuildingStorageHistory.As<string>();
        if (info.TryGetProperty(PropertyName.@cameraGliding, out var _value_cameraGliding))
            this.@cameraGliding = _value_cameraGliding.As<bool>();
        if (info.TryGetProperty(PropertyName.@cameraGlideFrom, out var _value_cameraGlideFrom))
            this.@cameraGlideFrom = _value_cameraGlideFrom.As<global::Godot.Vector2>();
        if (info.TryGetProperty(PropertyName.@cameraGlideTo, out var _value_cameraGlideTo))
            this.@cameraGlideTo = _value_cameraGlideTo.As<global::Godot.Vector2>();
        if (info.TryGetProperty(PropertyName.@cameraGlideElapsed, out var _value_cameraGlideElapsed))
            this.@cameraGlideElapsed = _value_cameraGlideElapsed.As<double>();
        if (info.TryGetProperty(PropertyName.@cameraZooming, out var _value_cameraZooming))
            this.@cameraZooming = _value_cameraZooming.As<bool>();
        if (info.TryGetProperty(PropertyName.@cameraZoomFrom, out var _value_cameraZoomFrom))
            this.@cameraZoomFrom = _value_cameraZoomFrom.As<float>();
        if (info.TryGetProperty(PropertyName.@cameraZoomTo, out var _value_cameraZoomTo))
            this.@cameraZoomTo = _value_cameraZoomTo.As<float>();
        if (info.TryGetProperty(PropertyName.@cameraZoomElapsed, out var _value_cameraZoomElapsed))
            this.@cameraZoomElapsed = _value_cameraZoomElapsed.As<double>();
        if (info.TryGetProperty(PropertyName.@cameraZoomAnchor, out var _value_cameraZoomAnchor))
            this.@cameraZoomAnchor = _value_cameraZoomAnchor.As<global::Godot.Vector2>();
        if (info.TryGetProperty(PropertyName.@cameraZoomPoint, out var _value_cameraZoomPoint))
            this.@cameraZoomPoint = _value_cameraZoomPoint.As<global::Godot.Vector2>();
        if (info.TryGetProperty(PropertyName.@renderedObservationGeneration, out var _value_renderedObservationGeneration))
            this.@renderedObservationGeneration = _value_renderedObservationGeneration.As<long>();
        if (info.TryGetProperty(PropertyName.@settingUpLocalDevice, out var _value_settingUpLocalDevice))
            this.@settingUpLocalDevice = _value_settingUpLocalDevice.As<bool>();
        if (info.TryGetProperty(PropertyName.@terrainWorldId, out var _value_terrainWorldId))
            this.@terrainWorldId = _value_terrainWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@observedRoutineHelperContext, out var _value_observedRoutineHelperContext))
            this.@observedRoutineHelperContext = _value_observedRoutineHelperContext.As<string>();
        if (info.TryGetProperty(PropertyName.@lastAgingOverrideWorldId, out var _value_lastAgingOverrideWorldId))
            this.@lastAgingOverrideWorldId = _value_lastAgingOverrideWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@usagePauseWorldId, out var _value_usagePauseWorldId))
            this.@usagePauseWorldId = _value_usagePauseWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@wasObservedPaused, out var _value_wasObservedPaused))
            this.@wasObservedPaused = _value_wasObservedPaused.As<bool>();
        if (info.TryGetProperty(PropertyName.@selectedAgentId, out var _value_selectedAgentId))
            this.@selectedAgentId = _value_selectedAgentId.As<string>();
        if (info.TryGetProperty(PropertyName.@renamingAgentId, out var _value_renamingAgentId))
            this.@renamingAgentId = _value_renamingAgentId.As<string>();
        if (info.TryGetProperty(PropertyName.@isRefreshing, out var _value_isRefreshing))
            this.@isRefreshing = _value_isRefreshing.As<bool>();
        if (info.TryGetProperty(PropertyName.@successfulRefreshCount, out var _value_successfulRefreshCount))
            this.@successfulRefreshCount = _value_successfulRefreshCount.As<int>();
        if (info.TryGetProperty(PropertyName.@isOwnerAction, out var _value_isOwnerAction))
            this.@isOwnerAction = _value_isOwnerAction.As<bool>();
        if (info.TryGetProperty(PropertyName.@registeredEndpointInvalid, out var _value_registeredEndpointInvalid))
            this.@registeredEndpointInvalid = _value_registeredEndpointInvalid.As<bool>();
        if (info.TryGetProperty(PropertyName.@menuPausedWorld, out var _value_menuPausedWorld))
            this.@menuPausedWorld = _value_menuPausedWorld.As<bool>();
        if (info.TryGetProperty(PropertyName.@menuPauseConfirmed, out var _value_menuPauseConfirmed))
            this.@menuPauseConfirmed = _value_menuPauseConfirmed.As<bool>();
        if (info.TryGetProperty(PropertyName.@pendingMenuResumes, out var _value_pendingMenuResumes))
            this.@pendingMenuResumes = _value_pendingMenuResumes.As<int>();
        if (info.TryGetProperty(PropertyName.@pendingMenuResumeGeneration, out var _value_pendingMenuResumeGeneration))
            this.@pendingMenuResumeGeneration = _value_pendingMenuResumeGeneration.As<long>();
        if (info.TryGetProperty(PropertyName.@currentTileSize, out var _value_currentTileSize))
            this.@currentTileSize = _value_currentTileSize.As<int>();
        if (info.TryGetProperty(PropertyName.@cameraZoom, out var _value_cameraZoom))
            this.@cameraZoom = _value_cameraZoom.As<float>();
        if (info.TryGetProperty(PropertyName.@minimumCameraZoom, out var _value_minimumCameraZoom))
            this.@minimumCameraZoom = _value_minimumCameraZoom.As<float>();
        if (info.TryGetProperty(PropertyName.@maximumCameraZoom, out var _value_maximumCameraZoom))
            this.@maximumCameraZoom = _value_maximumCameraZoom.As<float>();
        if (info.TryGetProperty(PropertyName.@cameraCenterTiles, out var _value_cameraCenterTiles))
            this.@cameraCenterTiles = _value_cameraCenterTiles.As<global::Godot.Vector2>();
        if (info.TryGetProperty(PropertyName.@cameraWorldId, out var _value_cameraWorldId))
            this.@cameraWorldId = _value_cameraWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@draggingMap, out var _value_draggingMap))
            this.@draggingMap = _value_draggingMap.As<bool>();
        if (info.TryGetProperty(PropertyName.@renderedEventLog, out var _value_renderedEventLog))
            this.@renderedEventLog = _value_renderedEventLog.As<string>();
        if (info.TryGetProperty(PropertyName.@statusToastKind, out var _value_statusToastKind))
            this.@statusToastKind = _value_statusToastKind.As<global::ClankerWorld.GodotClient.Main.StatusToastKind>();
        if (info.TryGetProperty(PropertyName.@statusToastShownAtMsec, out var _value_statusToastShownAtMsec))
            this.@statusToastShownAtMsec = _value_statusToastShownAtMsec.As<long>();
        if (info.TryGetProperty(PropertyName.@developerEditPeopleKey, out var _value_developerEditPeopleKey))
            this.@developerEditPeopleKey = _value_developerEditPeopleKey.As<string>();
        if (info.TryGetProperty(PropertyName.@developerFrameMilliseconds, out var _value_developerFrameMilliseconds))
            this.@developerFrameMilliseconds = _value_developerFrameMilliseconds.As<double>();
        if (info.TryGetProperty(PropertyName.@developerReadoutAge, out var _value_developerReadoutAge))
            this.@developerReadoutAge = _value_developerReadoutAge.As<double>();
        if (info.TryGetProperty(PropertyName.@developerAgentListKey, out var _value_developerAgentListKey))
            this.@developerAgentListKey = _value_developerAgentListKey.As<string>();
        if (info.TryGetProperty(PropertyName.@placingAddedAgent, out var _value_placingAddedAgent))
            this.@placingAddedAgent = _value_placingAddedAgent.As<bool>();
        if (info.TryGetProperty(PropertyName.@choosingFirstTownSite, out var _value_choosingFirstTownSite))
            this.@choosingFirstTownSite = _value_choosingFirstTownSite.As<bool>();
        if (info.TryGetProperty(PropertyName.@movingFounderId, out var _value_movingFounderId))
            this.@movingFounderId = _value_movingFounderId.As<string>();
        if (info.TryGetProperty(PropertyName.@renderedTownList, out var _value_renderedTownList))
            this.@renderedTownList = _value_renderedTownList.As<string>();
        if (info.TryGetProperty(PropertyName.@eventLogWorldId, out var _value_eventLogWorldId))
            this.@eventLogWorldId = _value_eventLogWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@lastSeenEventId, out var _value_lastSeenEventId))
            this.@lastSeenEventId = _value_lastSeenEventId.As<long>();
        if (info.TryGetProperty(PropertyName.@newEventsAfter, out var _value_newEventsAfter))
            this.@newEventsAfter = _value_newEventsAfter.As<long>();
        if (info.TryGetProperty(PropertyName.@unreadEvents, out var _value_unreadEvents))
            this.@unreadEvents = _value_unreadEvents.As<int>();
        if (info.TryGetProperty(PropertyName.@keyboardNavigation, out var _value_keyboardNavigation))
            this.@keyboardNavigation = _value_keyboardNavigation.As<bool>();
        if (info.TryGetProperty(PropertyName.@keyboardNavigationKey, out var _value_keyboardNavigationKey))
            this.@keyboardNavigationKey = _value_keyboardNavigationKey.As<global::Godot.Key>();
        if (info.TryGetProperty(PropertyName.@refreshingKeyboardMapSelection, out var _value_refreshingKeyboardMapSelection))
            this.@refreshingKeyboardMapSelection = _value_refreshingKeyboardMapSelection.As<bool>();
        if (info.TryGetProperty(PropertyName.@pendingOpenVersion, out var _value_pendingOpenVersion))
            this.@pendingOpenVersion = _value_pendingOpenVersion.As<string>();
        if (info.TryGetProperty(PropertyName.@pendingOpenWorld, out var _value_pendingOpenWorld))
            this.@pendingOpenWorld = _value_pendingOpenWorld.As<string>();
        if (info.TryGetProperty(PropertyName.@failedLauncherVersion, out var _value_failedLauncherVersion))
            this.@failedLauncherVersion = _value_failedLauncherVersion.As<string>();
        if (info.TryGetProperty(PropertyName.@failedLauncherWorld, out var _value_failedLauncherWorld))
            this.@failedLauncherWorld = _value_failedLauncherWorld.As<string>();
        if (info.TryGetProperty(PropertyName.@requestedWorldToSelect, out var _value_requestedWorldToSelect))
            this.@requestedWorldToSelect = _value_requestedWorldToSelect.As<string>();
        if (info.TryGetProperty(PropertyName.@launcherPath, out var _value_launcherPath))
            this.@launcherPath = _value_launcherPath.As<string>();
        if (info.TryGetProperty(PropertyName.@launcherPathRead, out var _value_launcherPathRead))
            this.@launcherPathRead = _value_launcherPathRead.As<bool>();
        if (info.TryGetProperty(PropertyName.@localServerStarting, out var _value_localServerStarting))
            this.@localServerStarting = _value_localServerStarting.As<bool>();
        if (info.TryGetProperty(PropertyName.@isQuittingGame, out var _value_isQuittingGame))
            this.@isQuittingGame = _value_isQuittingGame.As<bool>();
        if (info.TryGetProperty(PropertyName.@retryLauncherVersion, out var _value_retryLauncherVersion))
            this.@retryLauncherVersion = _value_retryLauncherVersion.As<string>();
        if (info.TryGetProperty(PropertyName.@retryLauncherWorld, out var _value_retryLauncherWorld))
            this.@retryLauncherWorld = _value_retryLauncherWorld.As<string>();
        if (info.TryGetProperty(PropertyName.@retryChooseCurrentWorld, out var _value_retryChooseCurrentWorld))
            this.@retryChooseCurrentWorld = _value_retryChooseCurrentWorld.As<bool>();
        if (info.TryGetProperty(PropertyName.@mainMenuNavigationRevision, out var _value_mainMenuNavigationRevision))
            this.@mainMenuNavigationRevision = _value_mainMenuNavigationRevision.As<int>();
        if (info.TryGetProperty(PropertyName.@listedActiveWorldId, out var _value_listedActiveWorldId))
            this.@listedActiveWorldId = _value_listedActiveWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@worldMenuBusy, out var _value_worldMenuBusy))
            this.@worldMenuBusy = _value_worldMenuBusy.As<bool>();
        if (info.TryGetProperty(PropertyName.@worldPreviewRevision, out var _value_worldPreviewRevision))
            this.@worldPreviewRevision = _value_worldPreviewRevision.As<int>();
        if (info.TryGetProperty(PropertyName.@isInWorld, out var _value_isInWorld))
            this.@isInWorld = _value_isInWorld.As<bool>();
        if (info.TryGetProperty(PropertyName.@returnToMainMenu, out var _value_returnToMainMenu))
            this.@returnToMainMenu = _value_returnToMainMenu.As<bool>();
        if (info.TryGetProperty(PropertyName.@resumeWorldOnContinue, out var _value_resumeWorldOnContinue))
            this.@resumeWorldOnContinue = _value_resumeWorldOnContinue.As<bool>();
        if (info.TryGetProperty(PropertyName.@isQuittingToMenu, out var _value_isQuittingToMenu))
            this.@isQuittingToMenu = _value_isQuittingToMenu.As<bool>();
        if (info.TryGetProperty(PropertyName.@hoverReadoutTownSiteMode, out var _value_hoverReadoutTownSiteMode))
            this.@hoverReadoutTownSiteMode = _value_hoverReadoutTownSiteMode.As<bool>();
        if (info.TryGetProperty(PropertyName.@renderedMemoryCards, out var _value_renderedMemoryCards))
            this.@renderedMemoryCards = _value_renderedMemoryCards.As<string>();
        if (info.TryGetProperty(PropertyName.@usageReads, out var _value_usageReads))
            this.@usageReads = _value_usageReads.As<int>();
        if (info.TryGetProperty(PropertyName.@usageLimitEdited, out var _value_usageLimitEdited))
            this.@usageLimitEdited = _value_usageLimitEdited.As<bool>();
        if (info.TryGetProperty(PropertyName.@routineHelperSetupCheckRevision, out var _value_routineHelperSetupCheckRevision))
            this.@routineHelperSetupCheckRevision = _value_routineHelperSetupCheckRevision.As<int>();
        if (info.TryGetProperty(PropertyName.@founderKeyEdits, out var _value_founderKeyEdits))
            this.@founderKeyEdits = _value_founderKeyEdits.As<int>();
        if (info.TryGetProperty(PropertyName.@agentModelKeyEdits, out var _value_agentModelKeyEdits))
            this.@agentModelKeyEdits = _value_agentModelKeyEdits.As<int>();
        if (info.TryGetProperty(PropertyName.@agentModelContext, out var _value_agentModelContext))
            this.@agentModelContext = _value_agentModelContext.As<string>();
        if (info.TryGetProperty(PropertyName.@agentModelLookup, out var _value_agentModelLookup))
            this.@agentModelLookup = _value_agentModelLookup.As<string>();
        if (info.TryGetProperty(PropertyName.@renderedOrdersReader, out var _value_renderedOrdersReader))
            this.@renderedOrdersReader = _value_renderedOrdersReader.As<string>();
        if (info.TryGetProperty(PropertyName.@pendingRecoveryInProgress, out var _value_pendingRecoveryInProgress))
            this.@pendingRecoveryInProgress = _value_pendingRecoveryInProgress.As<bool>();
        if (info.TryGetProperty(PropertyName.@unloadedPendingSubmission, out var _value_unloadedPendingSubmission))
            this.@unloadedPendingSubmission = _value_unloadedPendingSubmission.As<bool>();
        if (info.TryGetProperty(PropertyName.@renderedProfilePeople, out var _value_renderedProfilePeople))
            this.@renderedProfilePeople = _value_renderedProfilePeople.As<string>();
        if (info.TryGetProperty(PropertyName.@agentModelSetupCheckContext, out var _value_agentModelSetupCheckContext))
            this.@agentModelSetupCheckContext = _value_agentModelSetupCheckContext.As<string>();
        if (info.TryGetProperty(PropertyName.@founderModelSetupCheckRevision, out var _value_founderModelSetupCheckRevision))
            this.@founderModelSetupCheckRevision = _value_founderModelSetupCheckRevision.As<int>();
        if (info.TryGetProperty(PropertyName.@agentModelSetupCheckRevision, out var _value_agentModelSetupCheckRevision))
            this.@agentModelSetupCheckRevision = _value_agentModelSetupCheckRevision.As<int>();
        if (info.TryGetProperty(PropertyName.@agentListWantedHeight, out var _value_agentListWantedHeight))
            this.@agentListWantedHeight = _value_agentListWantedHeight.As<float>();
        if (info.TryGetProperty(PropertyName.@eventLogWantedHeight, out var _value_eventLogWantedHeight))
            this.@eventLogWantedHeight = _value_eventLogWantedHeight.As<float>();
        if (info.TryGetProperty(PropertyName.@hudListsRefitQueued, out var _value_hudListsRefitQueued))
            this.@hudListsRefitQueued = _value_hudListsRefitQueued.As<bool>();
        if (info.TryGetProperty(PropertyName.@lastDiskSpaceReadMsec, out var _value_lastDiskSpaceReadMsec))
            this.@lastDiskSpaceReadMsec = _value_lastDiskSpaceReadMsec.As<long>();
        if (info.TryGetProperty(PropertyName.@diskSpaceReadPending, out var _value_diskSpaceReadPending))
            this.@diskSpaceReadPending = _value_diskSpaceReadPending.As<bool>();
        if (info.TryGetProperty(PropertyName.@manualSaveBody, out var _value_manualSaveBody))
            this.@manualSaveBody = _value_manualSaveBody.As<global::Godot.VBoxContainer>();
        if (info.TryGetProperty(PropertyName.@worldHistoryLoading, out var _value_worldHistoryLoading))
            this.@worldHistoryLoading = _value_worldHistoryLoading.As<bool>();
        if (info.TryGetProperty(PropertyName.@worldHistoryLoaded, out var _value_worldHistoryLoaded))
            this.@worldHistoryLoaded = _value_worldHistoryLoaded.As<bool>();
        if (info.TryGetProperty(PropertyName.@listedSaveWorldId, out var _value_listedSaveWorldId))
            this.@listedSaveWorldId = _value_listedSaveWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@pendingOverwriteSaveId, out var _value_pendingOverwriteSaveId))
            this.@pendingOverwriteSaveId = _value_pendingOverwriteSaveId.As<string>();
        if (info.TryGetProperty(PropertyName.@manualSaveLoadMode, out var _value_manualSaveLoadMode))
            this.@manualSaveLoadMode = _value_manualSaveLoadMode.As<bool>();
        if (info.TryGetProperty(PropertyName.@manualSaveShowsList, out var _value_manualSaveShowsList))
            this.@manualSaveShowsList = _value_manualSaveShowsList.As<bool>();
        if (info.TryGetProperty(PropertyName.@autosaveSettingsLoaded, out var _value_autosaveSettingsLoaded))
            this.@autosaveSettingsLoaded = _value_autosaveSettingsLoaded.As<bool>();
        if (info.TryGetProperty(PropertyName.@autosaveSettingsWorldId, out var _value_autosaveSettingsWorldId))
            this.@autosaveSettingsWorldId = _value_autosaveSettingsWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@autosaveSettingsGeneration, out var _value_autosaveSettingsGeneration))
            this.@autosaveSettingsGeneration = _value_autosaveSettingsGeneration.As<long>();
        if (info.TryGetProperty(PropertyName.@renderedControlsTheme, out var _value_renderedControlsTheme))
            this.@renderedControlsTheme = _value_renderedControlsTheme.As<string>();
        if (info.TryGetProperty(PropertyName.@startupRecoveryReadRevision, out var _value_startupRecoveryReadRevision))
            this.@startupRecoveryReadRevision = _value_startupRecoveryReadRevision.As<int>();
        if (info.TryGetProperty(PropertyName.@startupRecoveryBusy, out var _value_startupRecoveryBusy))
            this.@startupRecoveryBusy = _value_startupRecoveryBusy.As<bool>();
        if (info.TryGetProperty(PropertyName.@worldEditWorldId, out var _value_worldEditWorldId))
            this.@worldEditWorldId = _value_worldEditWorldId.As<string>();
        if (info.TryGetProperty(PropertyName.@renderedWorldStats, out var _value_renderedWorldStats))
            this.@renderedWorldStats = _value_renderedWorldStats.As<string>();
        if (info.TryGetProperty(PropertyName.@renderedWorldToday, out var _value_renderedWorldToday))
            this.@renderedWorldToday = _value_renderedWorldToday.As<string>();
        if (info.TryGetProperty(PropertyName.@worldTodayCard, out var _value_worldTodayCard))
            this.@worldTodayCard = _value_worldTodayCard.As<global::Godot.PanelContainer>();
        if (info.TryGetProperty(PropertyName.@worldCounts, out var _value_worldCounts))
            this.@worldCounts = _value_worldCounts.As<global::Godot.VBoxContainer>();
        if (info.TryGetProperty(PropertyName.@renderedTownExtras, out var _value_renderedTownExtras))
            this.@renderedTownExtras = _value_renderedTownExtras.As<string>();
    }
}

}
