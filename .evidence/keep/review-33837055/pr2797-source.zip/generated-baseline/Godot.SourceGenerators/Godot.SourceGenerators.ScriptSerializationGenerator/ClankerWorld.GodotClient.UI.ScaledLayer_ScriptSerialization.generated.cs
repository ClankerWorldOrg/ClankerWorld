﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class ScaledLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Factor, global::Godot.Variant.From<int>(this.@Factor));
        info.AddProperty(PropertyName.@factor, global::Godot.Variant.From<int>(this.@factor));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Factor, out var _value_Factor))
            this.@Factor = _value_Factor.As<int>();
        if (info.TryGetProperty(PropertyName.@factor, out var _value_factor))
            this.@factor = _value_factor.As<int>();
    }
}

}
