﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class MenuBackdrop
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Night, global::Godot.Variant.From<bool>(this.@Night));
        info.AddProperty(PropertyName.@night, global::Godot.Variant.From<bool>(this.@night));
        info.AddProperty(PropertyName.@elapsed, global::Godot.Variant.From<double>(this.@elapsed));
        info.AddProperty(PropertyName.@drawnFrame, global::Godot.Variant.From<int>(this.@drawnFrame));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Night, out var _value_Night))
            this.@Night = _value_Night.As<bool>();
        if (info.TryGetProperty(PropertyName.@night, out var _value_night))
            this.@night = _value_night.As<bool>();
        if (info.TryGetProperty(PropertyName.@elapsed, out var _value_elapsed))
            this.@elapsed = _value_elapsed.As<double>();
        if (info.TryGetProperty(PropertyName.@drawnFrame, out var _value_drawnFrame))
            this.@drawnFrame = _value_drawnFrame.As<int>();
    }
}

}
