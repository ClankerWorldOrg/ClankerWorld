﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class NightLightsLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@source, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@source));
        info.AddProperty(PropertyName.@night, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.NightLayer>(this.@night));
        info.AddProperty(PropertyName.@wrapsEastWest, global::Godot.Variant.From<bool>(this.@wrapsEastWest));
        info.AddProperty(PropertyName.@drawnCamera, global::Godot.Variant.From<global::Godot.Rect2>(this.@drawnCamera));
        info.AddProperty(PropertyName.@drawnTileSize, global::Godot.Variant.From<int>(this.@drawnTileSize));
        info.AddProperty(PropertyName.@drawnDarkness, global::Godot.Variant.From<float>(this.@drawnDarkness));
        info.AddProperty(PropertyName.@clock, global::Godot.Variant.From<double>(this.@clock));
        info.AddProperty(PropertyName.@drawnTime, global::Godot.Variant.From<float>(this.@drawnTime));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@source, out var _value_source))
            this.@source = _value_source.As<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>();
        if (info.TryGetProperty(PropertyName.@night, out var _value_night))
            this.@night = _value_night.As<global::ClankerWorld.GodotClient.UI.NightLayer>();
        if (info.TryGetProperty(PropertyName.@wrapsEastWest, out var _value_wrapsEastWest))
            this.@wrapsEastWest = _value_wrapsEastWest.As<bool>();
        if (info.TryGetProperty(PropertyName.@drawnCamera, out var _value_drawnCamera))
            this.@drawnCamera = _value_drawnCamera.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@drawnTileSize, out var _value_drawnTileSize))
            this.@drawnTileSize = _value_drawnTileSize.As<int>();
        if (info.TryGetProperty(PropertyName.@drawnDarkness, out var _value_drawnDarkness))
            this.@drawnDarkness = _value_drawnDarkness.As<float>();
        if (info.TryGetProperty(PropertyName.@clock, out var _value_clock))
            this.@clock = _value_clock.As<double>();
        if (info.TryGetProperty(PropertyName.@drawnTime, out var _value_drawnTime))
            this.@drawnTime = _value_drawnTime.As<float>();
    }
}

}
