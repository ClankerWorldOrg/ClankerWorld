﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SaveTimeline
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@maximumHeight, global::Godot.Variant.From<float>(this.@maximumHeight));
        info.AddProperty(PropertyName.@scrollsSideways, global::Godot.Variant.From<bool>(this.@scrollsSideways));
        info.AddProperty(PropertyName.@revealing, global::Godot.Variant.From<string>(this.@revealing));
        info.AddProperty(PropertyName.@revealQueued, global::Godot.Variant.From<bool>(this.@revealQueued));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@maximumHeight, out var _value_maximumHeight))
            this.@maximumHeight = _value_maximumHeight.As<float>();
        if (info.TryGetProperty(PropertyName.@scrollsSideways, out var _value_scrollsSideways))
            this.@scrollsSideways = _value_scrollsSideways.As<bool>();
        if (info.TryGetProperty(PropertyName.@revealing, out var _value_revealing))
            this.@revealing = _value_revealing.As<string>();
        if (info.TryGetProperty(PropertyName.@revealQueued, out var _value_revealQueued))
            this.@revealQueued = _value_revealQueued.As<bool>();
    }
}

}
