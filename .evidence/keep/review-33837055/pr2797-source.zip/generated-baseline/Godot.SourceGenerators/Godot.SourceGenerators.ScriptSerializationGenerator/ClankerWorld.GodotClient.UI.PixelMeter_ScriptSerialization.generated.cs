﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class PixelMeter
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Percent, global::Godot.Variant.From<int>(this.@Percent));
        info.AddProperty(PropertyName.@percent, global::Godot.Variant.From<int>(this.@percent));
        info.AddProperty(PropertyName.@captionWidth, global::Godot.Variant.From<int>(this.@captionWidth));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Percent, out var _value_Percent))
            this.@Percent = _value_Percent.As<int>();
        if (info.TryGetProperty(PropertyName.@percent, out var _value_percent))
            this.@percent = _value_percent.As<int>();
        if (info.TryGetProperty(PropertyName.@captionWidth, out var _value_captionWidth))
            this.@captionWidth = _value_captionWidth.As<int>();
    }
}

}
