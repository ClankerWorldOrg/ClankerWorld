﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class GraveLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@terrain, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@terrain));
        info.AddProperty(PropertyName.@drawnCamera, global::Godot.Variant.From<global::Godot.Rect2>(this.@drawnCamera));
        info.AddProperty(PropertyName.@drawnSize, global::Godot.Variant.From<int>(this.@drawnSize));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@terrain, out var _value_terrain))
            this.@terrain = _value_terrain.As<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>();
        if (info.TryGetProperty(PropertyName.@drawnCamera, out var _value_drawnCamera))
            this.@drawnCamera = _value_drawnCamera.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@drawnSize, out var _value_drawnSize))
            this.@drawnSize = _value_drawnSize.As<int>();
    }
}

}
