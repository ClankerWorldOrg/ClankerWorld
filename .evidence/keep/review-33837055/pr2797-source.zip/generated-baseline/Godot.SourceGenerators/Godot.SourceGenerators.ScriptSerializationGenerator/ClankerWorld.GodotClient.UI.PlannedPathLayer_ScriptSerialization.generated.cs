﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class PlannedPathLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@points, global::Godot.Variant.From<global::Godot.Vector2[]>(this.@points));
        info.AddProperty(PropertyName.@tileSize, global::Godot.Variant.From<float>(this.@tileSize));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@points, out var _value_points))
            this.@points = _value_points.As<global::Godot.Vector2[]>();
        if (info.TryGetProperty(PropertyName.@tileSize, out var _value_tileSize))
            this.@tileSize = _value_tileSize.As<float>();
    }
}

}
