﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SlotList
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Compact, global::Godot.Variant.From<bool>(this.@Compact));
        info.AddProperty(PropertyName.@Placeholder, global::Godot.Variant.From<string>(this.@Placeholder));
        info.AddProperty(PropertyName.@selected, global::Godot.Variant.From<int>(this.@selected));
        info.AddProperty(PropertyName.@hovered, global::Godot.Variant.From<int>(this.@hovered));
        info.AddProperty(PropertyName.@compact, global::Godot.Variant.From<bool>(this.@compact));
        info.AddSignalEventDelegate(SignalName.@ItemSelected, this.backing_ItemSelected);
        info.AddSignalEventDelegate(SignalName.@ItemClicked, this.backing_ItemClicked);
        info.AddSignalEventDelegate(SignalName.@ItemNavigated, this.backing_ItemNavigated);
        info.AddSignalEventDelegate(SignalName.@ItemActivated, this.backing_ItemActivated);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Compact, out var _value_Compact))
            this.@Compact = _value_Compact.As<bool>();
        if (info.TryGetProperty(PropertyName.@Placeholder, out var _value_Placeholder))
            this.@Placeholder = _value_Placeholder.As<string>();
        if (info.TryGetProperty(PropertyName.@selected, out var _value_selected))
            this.@selected = _value_selected.As<int>();
        if (info.TryGetProperty(PropertyName.@hovered, out var _value_hovered))
            this.@hovered = _value_hovered.As<int>();
        if (info.TryGetProperty(PropertyName.@compact, out var _value_compact))
            this.@compact = _value_compact.As<bool>();
        if (info.TryGetSignalEventDelegate<global::ClankerWorld.GodotClient.UI.SlotList.ItemSelectedEventHandler>(SignalName.@ItemSelected, out var _value_ItemSelected))
            this.backing_ItemSelected = _value_ItemSelected;
        if (info.TryGetSignalEventDelegate<global::ClankerWorld.GodotClient.UI.SlotList.ItemClickedEventHandler>(SignalName.@ItemClicked, out var _value_ItemClicked))
            this.backing_ItemClicked = _value_ItemClicked;
        if (info.TryGetSignalEventDelegate<global::ClankerWorld.GodotClient.UI.SlotList.ItemNavigatedEventHandler>(SignalName.@ItemNavigated, out var _value_ItemNavigated))
            this.backing_ItemNavigated = _value_ItemNavigated;
        if (info.TryGetSignalEventDelegate<global::ClankerWorld.GodotClient.UI.SlotList.ItemActivatedEventHandler>(SignalName.@ItemActivated, out var _value_ItemActivated))
            this.backing_ItemActivated = _value_ItemActivated;
    }
}

}
