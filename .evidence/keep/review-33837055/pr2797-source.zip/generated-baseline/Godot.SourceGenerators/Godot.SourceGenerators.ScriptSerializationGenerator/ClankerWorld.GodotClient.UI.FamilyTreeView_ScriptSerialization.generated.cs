﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class FamilyTreeView
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@currentSignature, global::Godot.Variant.From<string>(this.@currentSignature));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@currentSignature, out var _value_currentSignature))
            this.@currentSignature = _value_currentSignature.As<string>();
    }
}

}
