﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class WeatherLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@CloudsEnabled, global::Godot.Variant.From<bool>(this.@CloudsEnabled));
        info.AddProperty(PropertyName.@LightningEnabled, global::Godot.Variant.From<bool>(this.@LightningEnabled));
        info.AddProperty(PropertyName.@Paused, global::Godot.Variant.From<bool>(this.@Paused));
        info.AddProperty(PropertyName.@PrecipitationMilliseconds, global::Godot.Variant.From<double>(this.@PrecipitationMilliseconds));
        info.AddProperty(PropertyName.@DrawnParticleCount, global::Godot.Variant.From<int>(this.@DrawnParticleCount));
        info.AddProperty(PropertyName.@source, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@source));
        info.AddProperty(PropertyName.@fieldVersion, global::Godot.Variant.From<int>(this.@fieldVersion));
        info.AddProperty(PropertyName.@fieldCamera, global::Godot.Variant.From<global::Godot.Rect2>(this.@fieldCamera));
        info.AddProperty(PropertyName.@fieldTileSize, global::Godot.Variant.From<int>(this.@fieldTileSize));
        info.AddProperty(PropertyName.@fieldTime, global::Godot.Variant.From<double>(this.@fieldTime));
        info.AddProperty(PropertyName.@fieldLeft, global::Godot.Variant.From<int>(this.@fieldLeft));
        info.AddProperty(PropertyName.@fieldTop, global::Godot.Variant.From<int>(this.@fieldTop));
        info.AddProperty(PropertyName.@fieldWidth, global::Godot.Variant.From<int>(this.@fieldWidth));
        info.AddProperty(PropertyName.@fieldHeight, global::Godot.Variant.From<int>(this.@fieldHeight));
        info.AddProperty(PropertyName.@fieldResolution, global::Godot.Variant.From<int>(this.@fieldResolution));
        info.AddProperty(PropertyName.@rain, global::Godot.Variant.From<float[]>(this.@rain));
        info.AddProperty(PropertyName.@storm, global::Godot.Variant.From<float[]>(this.@storm));
        info.AddProperty(PropertyName.@snow, global::Godot.Variant.From<float[]>(this.@snow));
        info.AddProperty(PropertyName.@cloudy, global::Godot.Variant.From<float[]>(this.@cloudy));
        info.AddProperty(PropertyName.@rainSupport, global::Godot.Variant.From<float[]>(this.@rainSupport));
        info.AddProperty(PropertyName.@stormSupport, global::Godot.Variant.From<float[]>(this.@stormSupport));
        info.AddProperty(PropertyName.@snowSupport, global::Godot.Variant.From<float[]>(this.@snowSupport));
        info.AddProperty(PropertyName.@tintImage, global::Godot.Variant.From<global::Godot.Image>(this.@tintImage));
        info.AddProperty(PropertyName.@tintTexture, global::Godot.Variant.From<global::Godot.ImageTexture>(this.@tintTexture));
        info.AddProperty(PropertyName.@stormImage, global::Godot.Variant.From<global::Godot.Image>(this.@stormImage));
        info.AddProperty(PropertyName.@stormTexture, global::Godot.Variant.From<global::Godot.ImageTexture>(this.@stormTexture));
        info.AddProperty(PropertyName.@cloudiness, global::Godot.Variant.From<float>(this.@cloudiness));
        info.AddProperty(PropertyName.@animationTime, global::Godot.Variant.From<double>(this.@animationTime));
        info.AddProperty(PropertyName.@drawnCamera, global::Godot.Variant.From<global::Godot.Rect2>(this.@drawnCamera));
        info.AddProperty(PropertyName.@drawnTileSize, global::Godot.Variant.From<int>(this.@drawnTileSize));
        info.AddProperty(PropertyName.@drawnCloudiness, global::Godot.Variant.From<float>(this.@drawnCloudiness));
        info.AddProperty(PropertyName.@paused, global::Godot.Variant.From<bool>(this.@paused));
        info.AddProperty(PropertyName.@regionVersion, global::Godot.Variant.From<int>(this.@regionVersion));
        info.AddProperty(PropertyName.@regionSize, global::Godot.Variant.From<int>(this.@regionSize));
        info.AddProperty(PropertyName.@fading, global::Godot.Variant.From<bool>(this.@fading));
        info.AddProperty(PropertyName.@displayedWeather, global::Godot.Variant.From<bool>(this.@displayedWeather));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@CloudsEnabled, out var _value_CloudsEnabled))
            this.@CloudsEnabled = _value_CloudsEnabled.As<bool>();
        if (info.TryGetProperty(PropertyName.@LightningEnabled, out var _value_LightningEnabled))
            this.@LightningEnabled = _value_LightningEnabled.As<bool>();
        if (info.TryGetProperty(PropertyName.@Paused, out var _value_Paused))
            this.@Paused = _value_Paused.As<bool>();
        if (info.TryGetProperty(PropertyName.@PrecipitationMilliseconds, out var _value_PrecipitationMilliseconds))
            this.@PrecipitationMilliseconds = _value_PrecipitationMilliseconds.As<double>();
        if (info.TryGetProperty(PropertyName.@DrawnParticleCount, out var _value_DrawnParticleCount))
            this.@DrawnParticleCount = _value_DrawnParticleCount.As<int>();
        if (info.TryGetProperty(PropertyName.@source, out var _value_source))
            this.@source = _value_source.As<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>();
        if (info.TryGetProperty(PropertyName.@fieldVersion, out var _value_fieldVersion))
            this.@fieldVersion = _value_fieldVersion.As<int>();
        if (info.TryGetProperty(PropertyName.@fieldCamera, out var _value_fieldCamera))
            this.@fieldCamera = _value_fieldCamera.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@fieldTileSize, out var _value_fieldTileSize))
            this.@fieldTileSize = _value_fieldTileSize.As<int>();
        if (info.TryGetProperty(PropertyName.@fieldTime, out var _value_fieldTime))
            this.@fieldTime = _value_fieldTime.As<double>();
        if (info.TryGetProperty(PropertyName.@fieldLeft, out var _value_fieldLeft))
            this.@fieldLeft = _value_fieldLeft.As<int>();
        if (info.TryGetProperty(PropertyName.@fieldTop, out var _value_fieldTop))
            this.@fieldTop = _value_fieldTop.As<int>();
        if (info.TryGetProperty(PropertyName.@fieldWidth, out var _value_fieldWidth))
            this.@fieldWidth = _value_fieldWidth.As<int>();
        if (info.TryGetProperty(PropertyName.@fieldHeight, out var _value_fieldHeight))
            this.@fieldHeight = _value_fieldHeight.As<int>();
        if (info.TryGetProperty(PropertyName.@fieldResolution, out var _value_fieldResolution))
            this.@fieldResolution = _value_fieldResolution.As<int>();
        if (info.TryGetProperty(PropertyName.@rain, out var _value_rain))
            this.@rain = _value_rain.As<float[]>();
        if (info.TryGetProperty(PropertyName.@storm, out var _value_storm))
            this.@storm = _value_storm.As<float[]>();
        if (info.TryGetProperty(PropertyName.@snow, out var _value_snow))
            this.@snow = _value_snow.As<float[]>();
        if (info.TryGetProperty(PropertyName.@cloudy, out var _value_cloudy))
            this.@cloudy = _value_cloudy.As<float[]>();
        if (info.TryGetProperty(PropertyName.@rainSupport, out var _value_rainSupport))
            this.@rainSupport = _value_rainSupport.As<float[]>();
        if (info.TryGetProperty(PropertyName.@stormSupport, out var _value_stormSupport))
            this.@stormSupport = _value_stormSupport.As<float[]>();
        if (info.TryGetProperty(PropertyName.@snowSupport, out var _value_snowSupport))
            this.@snowSupport = _value_snowSupport.As<float[]>();
        if (info.TryGetProperty(PropertyName.@tintImage, out var _value_tintImage))
            this.@tintImage = _value_tintImage.As<global::Godot.Image>();
        if (info.TryGetProperty(PropertyName.@tintTexture, out var _value_tintTexture))
            this.@tintTexture = _value_tintTexture.As<global::Godot.ImageTexture>();
        if (info.TryGetProperty(PropertyName.@stormImage, out var _value_stormImage))
            this.@stormImage = _value_stormImage.As<global::Godot.Image>();
        if (info.TryGetProperty(PropertyName.@stormTexture, out var _value_stormTexture))
            this.@stormTexture = _value_stormTexture.As<global::Godot.ImageTexture>();
        if (info.TryGetProperty(PropertyName.@cloudiness, out var _value_cloudiness))
            this.@cloudiness = _value_cloudiness.As<float>();
        if (info.TryGetProperty(PropertyName.@animationTime, out var _value_animationTime))
            this.@animationTime = _value_animationTime.As<double>();
        if (info.TryGetProperty(PropertyName.@drawnCamera, out var _value_drawnCamera))
            this.@drawnCamera = _value_drawnCamera.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@drawnTileSize, out var _value_drawnTileSize))
            this.@drawnTileSize = _value_drawnTileSize.As<int>();
        if (info.TryGetProperty(PropertyName.@drawnCloudiness, out var _value_drawnCloudiness))
            this.@drawnCloudiness = _value_drawnCloudiness.As<float>();
        if (info.TryGetProperty(PropertyName.@paused, out var _value_paused))
            this.@paused = _value_paused.As<bool>();
        if (info.TryGetProperty(PropertyName.@regionVersion, out var _value_regionVersion))
            this.@regionVersion = _value_regionVersion.As<int>();
        if (info.TryGetProperty(PropertyName.@regionSize, out var _value_regionSize))
            this.@regionSize = _value_regionSize.As<int>();
        if (info.TryGetProperty(PropertyName.@fading, out var _value_fading))
            this.@fading = _value_fading.As<bool>();
        if (info.TryGetProperty(PropertyName.@displayedWeather, out var _value_displayedWeather))
            this.@displayedWeather = _value_displayedWeather.As<bool>();
    }
}

}
