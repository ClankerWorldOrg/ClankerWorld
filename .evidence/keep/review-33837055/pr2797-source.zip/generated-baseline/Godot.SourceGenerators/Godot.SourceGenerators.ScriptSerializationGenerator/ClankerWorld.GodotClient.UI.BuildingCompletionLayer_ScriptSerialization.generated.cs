﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class BuildingCompletionLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@DrawnMomentCount, global::Godot.Variant.From<int>(this.@DrawnMomentCount));
        info.AddProperty(PropertyName.@DrawnSpanCount, global::Godot.Variant.From<int>(this.@DrawnSpanCount));
        info.AddProperty(PropertyName.@terrain, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@terrain));
        info.AddProperty(PropertyName.@paused, global::Godot.Variant.From<bool>(this.@paused));
        info.AddProperty(PropertyName.@lastVisible, global::Godot.Variant.From<global::Godot.Rect2>(this.@lastVisible));
        info.AddProperty(PropertyName.@lastSize, global::Godot.Variant.From<int>(this.@lastSize));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@DrawnMomentCount, out var _value_DrawnMomentCount))
            this.@DrawnMomentCount = _value_DrawnMomentCount.As<int>();
        if (info.TryGetProperty(PropertyName.@DrawnSpanCount, out var _value_DrawnSpanCount))
            this.@DrawnSpanCount = _value_DrawnSpanCount.As<int>();
        if (info.TryGetProperty(PropertyName.@terrain, out var _value_terrain))
            this.@terrain = _value_terrain.As<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>();
        if (info.TryGetProperty(PropertyName.@paused, out var _value_paused))
            this.@paused = _value_paused.As<bool>();
        if (info.TryGetProperty(PropertyName.@lastVisible, out var _value_lastVisible))
            this.@lastVisible = _value_lastVisible.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@lastSize, out var _value_lastSize))
            this.@lastSize = _value_lastSize.As<int>();
    }
}

}
