﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SaveTimelineRows
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@NowTick, global::Godot.Variant.From<long>(this.@NowTick));
        info.AddProperty(PropertyName.@SelectedId, global::Godot.Variant.From<string>(this.@SelectedId));
        info.AddProperty(PropertyName.@PixelsPerDay, global::Godot.Variant.From<float>(this.@PixelsPerDay));
        info.AddProperty(PropertyName.@ViewLeft, global::Godot.Variant.From<float>(this.@ViewLeft));
        info.AddProperty(PropertyName.@ViewTop, global::Godot.Variant.From<float>(this.@ViewTop));
        info.AddProperty(PropertyName.@ViewWidth, global::Godot.Variant.From<float>(this.@ViewWidth));
        info.AddProperty(PropertyName.@firstDay, global::Godot.Variant.From<float>(this.@firstDay));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@NowTick, out var _value_NowTick))
            this.@NowTick = _value_NowTick.As<long>();
        if (info.TryGetProperty(PropertyName.@SelectedId, out var _value_SelectedId))
            this.@SelectedId = _value_SelectedId.As<string>();
        if (info.TryGetProperty(PropertyName.@PixelsPerDay, out var _value_PixelsPerDay))
            this.@PixelsPerDay = _value_PixelsPerDay.As<float>();
        if (info.TryGetProperty(PropertyName.@ViewLeft, out var _value_ViewLeft))
            this.@ViewLeft = _value_ViewLeft.As<float>();
        if (info.TryGetProperty(PropertyName.@ViewTop, out var _value_ViewTop))
            this.@ViewTop = _value_ViewTop.As<float>();
        if (info.TryGetProperty(PropertyName.@ViewWidth, out var _value_ViewWidth))
            this.@ViewWidth = _value_ViewWidth.As<float>();
        if (info.TryGetProperty(PropertyName.@firstDay, out var _value_firstDay))
            this.@firstDay = _value_firstDay.As<float>();
    }
}

}
