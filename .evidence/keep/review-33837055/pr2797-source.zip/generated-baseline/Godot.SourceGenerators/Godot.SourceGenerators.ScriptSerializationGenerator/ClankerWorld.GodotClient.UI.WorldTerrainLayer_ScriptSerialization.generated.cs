﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class WorldTerrainLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@AutumnLeavesEnabled, global::Godot.Variant.From<bool>(this.@AutumnLeavesEnabled));
        info.AddProperty(PropertyName.@AutumnLeafDrawCount, global::Godot.Variant.From<int>(this.@AutumnLeafDrawCount));
        info.AddProperty(PropertyName.@Season, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.LandscapeSeason>(this.@Season));
        info.AddProperty(PropertyName.@VisibleTileCount, global::Godot.Variant.From<int>(this.@VisibleTileCount));
        info.AddProperty(PropertyName.@OverviewNaturalObjectDrawCount, global::Godot.Variant.From<int>(this.@OverviewNaturalObjectDrawCount));
        info.AddProperty(PropertyName.@MeasureDrawCost, global::Godot.Variant.From<bool>(this.@MeasureDrawCost));
        info.AddProperty(PropertyName.@LastDrawMilliseconds, global::Godot.Variant.From<double>(this.@LastDrawMilliseconds));
        info.AddProperty(PropertyName.@DrawSampleCount, global::Godot.Variant.From<long>(this.@DrawSampleCount));
        info.AddProperty(PropertyName.@WeatherVersion, global::Godot.Variant.From<int>(this.@WeatherVersion));
        info.AddProperty(PropertyName.@HasActiveWeather, global::Godot.Variant.From<bool>(this.@HasActiveWeather));
        info.AddProperty(PropertyName.@CactusSpriteCount, global::Godot.Variant.From<int>(this.@CactusSpriteCount));
        info.AddProperty(PropertyName.@DrawnSnowTileCount, global::Godot.Variant.From<int>(this.@DrawnSnowTileCount));
        info.AddProperty(PropertyName.@DrawnSnowFootprintCount, global::Godot.Variant.From<int>(this.@DrawnSnowFootprintCount));
        info.AddProperty(PropertyName.@SnowOverviewDrawCount, global::Godot.Variant.From<int>(this.@SnowOverviewDrawCount));
        info.AddProperty(PropertyName.@HillOverlayTileCount, global::Godot.Variant.From<int>(this.@HillOverlayTileCount));
        info.AddProperty(PropertyName.@FadingReliefChunkCount, global::Godot.Variant.From<int>(this.@FadingReliefChunkCount));
        info.AddProperty(PropertyName.@PrefetchedReliefChunkCount, global::Godot.Variant.From<int>(this.@PrefetchedReliefChunkCount));
        info.AddProperty(PropertyName.@DrawnSnowRoofCount, global::Godot.Variant.From<int>(this.@DrawnSnowRoofCount));
        info.AddProperty(PropertyName.@DrawnSnowRoofRegionCount, global::Godot.Variant.From<int>(this.@DrawnSnowRoofRegionCount));
        info.AddProperty(PropertyName.@LastSnowRoofRegion, global::Godot.Variant.From<global::Godot.Rect2>(this.@LastSnowRoofRegion));
        info.AddProperty(PropertyName.@paletteTexture, global::Godot.Variant.From<global::Godot.Texture2D>(this.@paletteTexture));
        info.AddProperty(PropertyName.@townSiteGuidanceTexture, global::Godot.Variant.From<global::Godot.ImageTexture>(this.@townSiteGuidanceTexture));
        info.AddProperty(PropertyName.@visibleTiles, global::Godot.Variant.From<global::Godot.Rect2>(this.@visibleTiles));
        info.AddProperty(PropertyName.@tileSize, global::Godot.Variant.From<int>(this.@tileSize));
        info.AddProperty(PropertyName.@tileGap, global::Godot.Variant.From<int>(this.@tileGap));
        info.AddProperty(PropertyName.@wrapsEastWest, global::Godot.Variant.From<bool>(this.@wrapsEastWest));
        info.AddProperty(PropertyName.@trees, global::Godot.Variant.From<byte[]>(this.@trees));
        info.AddProperty(PropertyName.@naturalObjects, global::Godot.Variant.From<byte[]>(this.@naturalObjects));
        info.AddProperty(PropertyName.@naturalStages, global::Godot.Variant.From<byte[]>(this.@naturalStages));
        info.AddProperty(PropertyName.@weatherRegionSize, global::Godot.Variant.From<int>(this.@weatherRegionSize));
        info.AddProperty(PropertyName.@groundSnowRegionSize, global::Godot.Variant.From<int>(this.@groundSnowRegionSize));
        info.AddProperty(PropertyName.@snowTicksPerHour, global::Godot.Variant.From<float>(this.@snowTicksPerHour));
        info.AddProperty(PropertyName.@reliefTextureBytes, global::Godot.Variant.From<long>(this.@reliefTextureBytes));
        info.AddProperty(PropertyName.@reliefDrawSerial, global::Godot.Variant.From<long>(this.@reliefDrawSerial));
        info.AddProperty(PropertyName.@lastReliefCovers, global::Godot.Variant.From<bool>(this.@lastReliefCovers));
        info.AddProperty(PropertyName.@reliefDrawAtMs, global::Godot.Variant.From<ulong>(this.@reliefDrawAtMs));
        info.AddProperty(PropertyName.@naturalAppearanceTrees, global::Godot.Variant.From<byte[]>(this.@naturalAppearanceTrees));
        info.AddProperty(PropertyName.@resourceKindAppearanceTrees, global::Godot.Variant.From<byte[]>(this.@resourceKindAppearanceTrees));
        info.AddProperty(PropertyName.@resourceKindAppearanceNaturalObjects, global::Godot.Variant.From<byte[]>(this.@resourceKindAppearanceNaturalObjects));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@AutumnLeavesEnabled, out var _value_AutumnLeavesEnabled))
            this.@AutumnLeavesEnabled = _value_AutumnLeavesEnabled.As<bool>();
        if (info.TryGetProperty(PropertyName.@AutumnLeafDrawCount, out var _value_AutumnLeafDrawCount))
            this.@AutumnLeafDrawCount = _value_AutumnLeafDrawCount.As<int>();
        if (info.TryGetProperty(PropertyName.@Season, out var _value_Season))
            this.@Season = _value_Season.As<global::ClankerWorld.GodotClient.UI.LandscapeSeason>();
        if (info.TryGetProperty(PropertyName.@VisibleTileCount, out var _value_VisibleTileCount))
            this.@VisibleTileCount = _value_VisibleTileCount.As<int>();
        if (info.TryGetProperty(PropertyName.@OverviewNaturalObjectDrawCount, out var _value_OverviewNaturalObjectDrawCount))
            this.@OverviewNaturalObjectDrawCount = _value_OverviewNaturalObjectDrawCount.As<int>();
        if (info.TryGetProperty(PropertyName.@MeasureDrawCost, out var _value_MeasureDrawCost))
            this.@MeasureDrawCost = _value_MeasureDrawCost.As<bool>();
        if (info.TryGetProperty(PropertyName.@LastDrawMilliseconds, out var _value_LastDrawMilliseconds))
            this.@LastDrawMilliseconds = _value_LastDrawMilliseconds.As<double>();
        if (info.TryGetProperty(PropertyName.@DrawSampleCount, out var _value_DrawSampleCount))
            this.@DrawSampleCount = _value_DrawSampleCount.As<long>();
        if (info.TryGetProperty(PropertyName.@WeatherVersion, out var _value_WeatherVersion))
            this.@WeatherVersion = _value_WeatherVersion.As<int>();
        if (info.TryGetProperty(PropertyName.@HasActiveWeather, out var _value_HasActiveWeather))
            this.@HasActiveWeather = _value_HasActiveWeather.As<bool>();
        if (info.TryGetProperty(PropertyName.@CactusSpriteCount, out var _value_CactusSpriteCount))
            this.@CactusSpriteCount = _value_CactusSpriteCount.As<int>();
        if (info.TryGetProperty(PropertyName.@DrawnSnowTileCount, out var _value_DrawnSnowTileCount))
            this.@DrawnSnowTileCount = _value_DrawnSnowTileCount.As<int>();
        if (info.TryGetProperty(PropertyName.@DrawnSnowFootprintCount, out var _value_DrawnSnowFootprintCount))
            this.@DrawnSnowFootprintCount = _value_DrawnSnowFootprintCount.As<int>();
        if (info.TryGetProperty(PropertyName.@SnowOverviewDrawCount, out var _value_SnowOverviewDrawCount))
            this.@SnowOverviewDrawCount = _value_SnowOverviewDrawCount.As<int>();
        if (info.TryGetProperty(PropertyName.@HillOverlayTileCount, out var _value_HillOverlayTileCount))
            this.@HillOverlayTileCount = _value_HillOverlayTileCount.As<int>();
        if (info.TryGetProperty(PropertyName.@FadingReliefChunkCount, out var _value_FadingReliefChunkCount))
            this.@FadingReliefChunkCount = _value_FadingReliefChunkCount.As<int>();
        if (info.TryGetProperty(PropertyName.@PrefetchedReliefChunkCount, out var _value_PrefetchedReliefChunkCount))
            this.@PrefetchedReliefChunkCount = _value_PrefetchedReliefChunkCount.As<int>();
        if (info.TryGetProperty(PropertyName.@DrawnSnowRoofCount, out var _value_DrawnSnowRoofCount))
            this.@DrawnSnowRoofCount = _value_DrawnSnowRoofCount.As<int>();
        if (info.TryGetProperty(PropertyName.@DrawnSnowRoofRegionCount, out var _value_DrawnSnowRoofRegionCount))
            this.@DrawnSnowRoofRegionCount = _value_DrawnSnowRoofRegionCount.As<int>();
        if (info.TryGetProperty(PropertyName.@LastSnowRoofRegion, out var _value_LastSnowRoofRegion))
            this.@LastSnowRoofRegion = _value_LastSnowRoofRegion.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@paletteTexture, out var _value_paletteTexture))
            this.@paletteTexture = _value_paletteTexture.As<global::Godot.Texture2D>();
        if (info.TryGetProperty(PropertyName.@townSiteGuidanceTexture, out var _value_townSiteGuidanceTexture))
            this.@townSiteGuidanceTexture = _value_townSiteGuidanceTexture.As<global::Godot.ImageTexture>();
        if (info.TryGetProperty(PropertyName.@visibleTiles, out var _value_visibleTiles))
            this.@visibleTiles = _value_visibleTiles.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@tileSize, out var _value_tileSize))
            this.@tileSize = _value_tileSize.As<int>();
        if (info.TryGetProperty(PropertyName.@tileGap, out var _value_tileGap))
            this.@tileGap = _value_tileGap.As<int>();
        if (info.TryGetProperty(PropertyName.@wrapsEastWest, out var _value_wrapsEastWest))
            this.@wrapsEastWest = _value_wrapsEastWest.As<bool>();
        if (info.TryGetProperty(PropertyName.@trees, out var _value_trees))
            this.@trees = _value_trees.As<byte[]>();
        if (info.TryGetProperty(PropertyName.@naturalObjects, out var _value_naturalObjects))
            this.@naturalObjects = _value_naturalObjects.As<byte[]>();
        if (info.TryGetProperty(PropertyName.@naturalStages, out var _value_naturalStages))
            this.@naturalStages = _value_naturalStages.As<byte[]>();
        if (info.TryGetProperty(PropertyName.@weatherRegionSize, out var _value_weatherRegionSize))
            this.@weatherRegionSize = _value_weatherRegionSize.As<int>();
        if (info.TryGetProperty(PropertyName.@groundSnowRegionSize, out var _value_groundSnowRegionSize))
            this.@groundSnowRegionSize = _value_groundSnowRegionSize.As<int>();
        if (info.TryGetProperty(PropertyName.@snowTicksPerHour, out var _value_snowTicksPerHour))
            this.@snowTicksPerHour = _value_snowTicksPerHour.As<float>();
        if (info.TryGetProperty(PropertyName.@reliefTextureBytes, out var _value_reliefTextureBytes))
            this.@reliefTextureBytes = _value_reliefTextureBytes.As<long>();
        if (info.TryGetProperty(PropertyName.@reliefDrawSerial, out var _value_reliefDrawSerial))
            this.@reliefDrawSerial = _value_reliefDrawSerial.As<long>();
        if (info.TryGetProperty(PropertyName.@lastReliefCovers, out var _value_lastReliefCovers))
            this.@lastReliefCovers = _value_lastReliefCovers.As<bool>();
        if (info.TryGetProperty(PropertyName.@reliefDrawAtMs, out var _value_reliefDrawAtMs))
            this.@reliefDrawAtMs = _value_reliefDrawAtMs.As<ulong>();
        if (info.TryGetProperty(PropertyName.@naturalAppearanceTrees, out var _value_naturalAppearanceTrees))
            this.@naturalAppearanceTrees = _value_naturalAppearanceTrees.As<byte[]>();
        if (info.TryGetProperty(PropertyName.@resourceKindAppearanceTrees, out var _value_resourceKindAppearanceTrees))
            this.@resourceKindAppearanceTrees = _value_resourceKindAppearanceTrees.As<byte[]>();
        if (info.TryGetProperty(PropertyName.@resourceKindAppearanceNaturalObjects, out var _value_resourceKindAppearanceNaturalObjects))
            this.@resourceKindAppearanceNaturalObjects = _value_resourceKindAppearanceNaturalObjects.As<byte[]>();
    }
}

}
