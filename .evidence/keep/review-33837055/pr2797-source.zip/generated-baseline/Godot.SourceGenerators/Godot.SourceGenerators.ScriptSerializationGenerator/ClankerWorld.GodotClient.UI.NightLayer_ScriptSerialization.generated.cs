﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class NightLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Darkness, global::Godot.Variant.From<float>(this.@Darkness));
        info.AddProperty(PropertyName.@DrawnArea, global::Godot.Variant.From<global::Godot.Rect2>(this.@DrawnArea));
        info.AddProperty(PropertyName.@source, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@source));
        info.AddProperty(PropertyName.@target, global::Godot.Variant.From<float>(this.@target));
        info.AddProperty(PropertyName.@shown, global::Godot.Variant.From<float>(this.@shown));
        info.AddProperty(PropertyName.@drawnCamera, global::Godot.Variant.From<global::Godot.Rect2>(this.@drawnCamera));
        info.AddProperty(PropertyName.@drawnTileSize, global::Godot.Variant.From<int>(this.@drawnTileSize));
        info.AddProperty(PropertyName.@drawnDarkness, global::Godot.Variant.From<float>(this.@drawnDarkness));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Darkness, out var _value_Darkness))
            this.@Darkness = _value_Darkness.As<float>();
        if (info.TryGetProperty(PropertyName.@DrawnArea, out var _value_DrawnArea))
            this.@DrawnArea = _value_DrawnArea.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@source, out var _value_source))
            this.@source = _value_source.As<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>();
        if (info.TryGetProperty(PropertyName.@target, out var _value_target))
            this.@target = _value_target.As<float>();
        if (info.TryGetProperty(PropertyName.@shown, out var _value_shown))
            this.@shown = _value_shown.As<float>();
        if (info.TryGetProperty(PropertyName.@drawnCamera, out var _value_drawnCamera))
            this.@drawnCamera = _value_drawnCamera.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@drawnTileSize, out var _value_drawnTileSize))
            this.@drawnTileSize = _value_drawnTileSize.As<int>();
        if (info.TryGetProperty(PropertyName.@drawnDarkness, out var _value_drawnDarkness))
            this.@drawnDarkness = _value_drawnDarkness.As<float>();
    }
}

}
