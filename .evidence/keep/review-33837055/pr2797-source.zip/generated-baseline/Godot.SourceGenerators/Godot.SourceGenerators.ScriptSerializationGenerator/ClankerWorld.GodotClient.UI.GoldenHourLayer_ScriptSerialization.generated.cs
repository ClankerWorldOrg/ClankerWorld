﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class GoldenHourLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@DrawnArea, global::Godot.Variant.From<global::Godot.Rect2>(this.@DrawnArea));
        info.AddProperty(PropertyName.@source, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@source));
        info.AddProperty(PropertyName.@worldId, global::Godot.Variant.From<string>(this.@worldId));
        info.AddProperty(PropertyName.@target, global::Godot.Variant.From<float>(this.@target));
        info.AddProperty(PropertyName.@shown, global::Godot.Variant.From<float>(this.@shown));
        info.AddProperty(PropertyName.@dawn, global::Godot.Variant.From<bool>(this.@dawn));
        info.AddProperty(PropertyName.@paused, global::Godot.Variant.From<bool>(this.@paused));
        info.AddProperty(PropertyName.@drawnCamera, global::Godot.Variant.From<global::Godot.Rect2>(this.@drawnCamera));
        info.AddProperty(PropertyName.@drawnTileSize, global::Godot.Variant.From<int>(this.@drawnTileSize));
        info.AddProperty(PropertyName.@drawnMultiplier, global::Godot.Variant.From<global::Godot.Color>(this.@drawnMultiplier));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@DrawnArea, out var _value_DrawnArea))
            this.@DrawnArea = _value_DrawnArea.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@source, out var _value_source))
            this.@source = _value_source.As<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>();
        if (info.TryGetProperty(PropertyName.@worldId, out var _value_worldId))
            this.@worldId = _value_worldId.As<string>();
        if (info.TryGetProperty(PropertyName.@target, out var _value_target))
            this.@target = _value_target.As<float>();
        if (info.TryGetProperty(PropertyName.@shown, out var _value_shown))
            this.@shown = _value_shown.As<float>();
        if (info.TryGetProperty(PropertyName.@dawn, out var _value_dawn))
            this.@dawn = _value_dawn.As<bool>();
        if (info.TryGetProperty(PropertyName.@paused, out var _value_paused))
            this.@paused = _value_paused.As<bool>();
        if (info.TryGetProperty(PropertyName.@drawnCamera, out var _value_drawnCamera))
            this.@drawnCamera = _value_drawnCamera.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@drawnTileSize, out var _value_drawnTileSize))
            this.@drawnTileSize = _value_drawnTileSize.As<int>();
        if (info.TryGetProperty(PropertyName.@drawnMultiplier, out var _value_drawnMultiplier))
            this.@drawnMultiplier = _value_drawnMultiplier.As<global::Godot.Color>();
    }
}

}
