﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SmokeLayer
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@terrain, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@terrain));
        info.AddProperty(PropertyName.@weather, global::Godot.Variant.From<global::ClankerWorld.GodotClient.UI.WeatherLayer>(this.@weather));
        info.AddProperty(PropertyName.@drawnCamera, global::Godot.Variant.From<global::Godot.Rect2>(this.@drawnCamera));
        info.AddProperty(PropertyName.@drawnSize, global::Godot.Variant.From<int>(this.@drawnSize));
        info.AddProperty(PropertyName.@drawnTime, global::Godot.Variant.From<double>(this.@drawnTime));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@terrain, out var _value_terrain))
            this.@terrain = _value_terrain.As<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>();
        if (info.TryGetProperty(PropertyName.@weather, out var _value_weather))
            this.@weather = _value_weather.As<global::ClankerWorld.GodotClient.UI.WeatherLayer>();
        if (info.TryGetProperty(PropertyName.@drawnCamera, out var _value_drawnCamera))
            this.@drawnCamera = _value_drawnCamera.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@drawnSize, out var _value_drawnSize))
            this.@drawnSize = _value_drawnSize.As<int>();
        if (info.TryGetProperty(PropertyName.@drawnTime, out var _value_drawnTime))
            this.@drawnTime = _value_drawnTime.As<double>();
    }
}

}
