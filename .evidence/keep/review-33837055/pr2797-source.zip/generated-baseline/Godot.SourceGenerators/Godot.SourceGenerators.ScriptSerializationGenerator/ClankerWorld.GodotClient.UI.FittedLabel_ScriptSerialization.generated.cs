﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class FittedLabel
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Text, global::Godot.Variant.From<string>(this.@Text));
        info.AddProperty(PropertyName.@FullText, global::Godot.Variant.From<string>(this.@FullText));
        info.AddProperty(PropertyName.@fullText, global::Godot.Variant.From<string>(this.@fullText));
        info.AddProperty(PropertyName.@automaticTooltip, global::Godot.Variant.From<string>(this.@automaticTooltip));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Text, out var _value_Text))
            this.@Text = _value_Text.As<string>();
        if (info.TryGetProperty(PropertyName.@FullText, out var _value_FullText))
            this.@FullText = _value_FullText.As<string>();
        if (info.TryGetProperty(PropertyName.@fullText, out var _value_fullText))
            this.@fullText = _value_fullText.As<string>();
        if (info.TryGetProperty(PropertyName.@automaticTooltip, out var _value_automaticTooltip))
            this.@automaticTooltip = _value_automaticTooltip.As<string>();
    }
}

}
