﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class WorldMapAtlas
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@WrapsEastWest, global::Godot.Variant.From<bool>(this.@WrapsEastWest));
        info.AddProperty(PropertyName.@ShowCameraBounds, global::Godot.Variant.From<bool>(this.@ShowCameraBounds));
        info.AddProperty(PropertyName.@Backdrop, global::Godot.Variant.From<global::Godot.Color>(this.@Backdrop));
        info.AddProperty(PropertyName.@AtlasEdge, global::Godot.Variant.From<global::Godot.Color>(this.@AtlasEdge));
        info.AddProperty(PropertyName.@atlasTexture, global::Godot.Variant.From<global::Godot.Texture2D>(this.@atlasTexture));
        info.AddProperty(PropertyName.@mapWidth, global::Godot.Variant.From<int>(this.@mapWidth));
        info.AddProperty(PropertyName.@mapHeight, global::Godot.Variant.From<int>(this.@mapHeight));
        info.AddProperty(PropertyName.@visibleTiles, global::Godot.Variant.From<global::Godot.Rect2>(this.@visibleTiles));
        info.AddProperty(PropertyName.@dragging, global::Godot.Variant.From<bool>(this.@dragging));
        info.AddProperty(PropertyName.@dragOffset, global::Godot.Variant.From<global::Godot.Vector2>(this.@dragOffset));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@WrapsEastWest, out var _value_WrapsEastWest))
            this.@WrapsEastWest = _value_WrapsEastWest.As<bool>();
        if (info.TryGetProperty(PropertyName.@ShowCameraBounds, out var _value_ShowCameraBounds))
            this.@ShowCameraBounds = _value_ShowCameraBounds.As<bool>();
        if (info.TryGetProperty(PropertyName.@Backdrop, out var _value_Backdrop))
            this.@Backdrop = _value_Backdrop.As<global::Godot.Color>();
        if (info.TryGetProperty(PropertyName.@AtlasEdge, out var _value_AtlasEdge))
            this.@AtlasEdge = _value_AtlasEdge.As<global::Godot.Color>();
        if (info.TryGetProperty(PropertyName.@atlasTexture, out var _value_atlasTexture))
            this.@atlasTexture = _value_atlasTexture.As<global::Godot.Texture2D>();
        if (info.TryGetProperty(PropertyName.@mapWidth, out var _value_mapWidth))
            this.@mapWidth = _value_mapWidth.As<int>();
        if (info.TryGetProperty(PropertyName.@mapHeight, out var _value_mapHeight))
            this.@mapHeight = _value_mapHeight.As<int>();
        if (info.TryGetProperty(PropertyName.@visibleTiles, out var _value_visibleTiles))
            this.@visibleTiles = _value_visibleTiles.As<global::Godot.Rect2>();
        if (info.TryGetProperty(PropertyName.@dragging, out var _value_dragging))
            this.@dragging = _value_dragging.As<bool>();
        if (info.TryGetProperty(PropertyName.@dragOffset, out var _value_dragOffset))
            this.@dragOffset = _value_dragOffset.As<global::Godot.Vector2>();
    }
}

}
