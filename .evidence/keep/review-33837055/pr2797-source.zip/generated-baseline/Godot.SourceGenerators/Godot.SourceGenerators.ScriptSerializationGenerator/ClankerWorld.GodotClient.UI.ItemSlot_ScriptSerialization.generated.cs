﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class ItemSlot
{
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void SaveGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.SaveGodotObjectData(info);
        info.AddProperty(PropertyName.@Kind, global::Godot.Variant.From<string>(this.@Kind));
        info.AddProperty(PropertyName.@Quantity, global::Godot.Variant.From<int>(this.@Quantity));
        info.AddProperty(PropertyName.@DisplayName, global::Godot.Variant.From<string>(this.@DisplayName));
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RestoreGodotObjectData(global::Godot.Bridge.GodotSerializationInfo info)
    {
        base.RestoreGodotObjectData(info);
        if (info.TryGetProperty(PropertyName.@Kind, out var _value_Kind))
            this.@Kind = _value_Kind.As<string>();
        if (info.TryGetProperty(PropertyName.@Quantity, out var _value_Quantity))
            this.@Quantity = _value_Quantity.As<int>();
        if (info.TryGetProperty(PropertyName.@DisplayName, out var _value_DisplayName))
            this.@DisplayName = _value_DisplayName.As<string>();
    }
}

}
