﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SlotList
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the signals contained in this class, for fast lookup.
    /// </summary>
    public new class SignalName : global::Godot.ScrollContainer.SignalName {
        /// <summary>
        /// Cached name for the 'ItemSelected' signal.
        /// </summary>
        public new static readonly global::Godot.StringName @ItemSelected = "ItemSelected";
        /// <summary>
        /// Cached name for the 'ItemClicked' signal.
        /// </summary>
        public new static readonly global::Godot.StringName @ItemClicked = "ItemClicked";
        /// <summary>
        /// Cached name for the 'ItemNavigated' signal.
        /// </summary>
        public new static readonly global::Godot.StringName @ItemNavigated = "ItemNavigated";
        /// <summary>
        /// Cached name for the 'ItemActivated' signal.
        /// </summary>
        public new static readonly global::Godot.StringName @ItemActivated = "ItemActivated";
    }
    /// <summary>
    /// Get the signal information for all the signals declared in this class.
    /// This method is used by Godot to register the available signals in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotSignalList()
    {
        var signals = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(4);
        signals.Add(new(name: SignalName.@ItemSelected, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        signals.Add(new(name: SignalName.@ItemClicked, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        signals.Add(new(name: SignalName.@ItemNavigated, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        signals.Add(new(name: SignalName.@ItemActivated, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        return signals;
    }
#pragma warning restore CS0109
    private global::ClankerWorld.GodotClient.UI.SlotList.ItemSelectedEventHandler backing_ItemSelected;
    /// <inheritdoc cref="global::ClankerWorld.GodotClient.UI.SlotList.ItemSelectedEventHandler"/>
    public event global::ClankerWorld.GodotClient.UI.SlotList.ItemSelectedEventHandler @ItemSelected {
        add => backing_ItemSelected += value;
        remove => backing_ItemSelected -= value;
}
    protected void EmitSignalItemSelected(long @index)
    {
        EmitSignal(SignalName.ItemSelected, [@index]);
    }
    private global::ClankerWorld.GodotClient.UI.SlotList.ItemClickedEventHandler backing_ItemClicked;
    /// <inheritdoc cref="global::ClankerWorld.GodotClient.UI.SlotList.ItemClickedEventHandler"/>
    public event global::ClankerWorld.GodotClient.UI.SlotList.ItemClickedEventHandler @ItemClicked {
        add => backing_ItemClicked += value;
        remove => backing_ItemClicked -= value;
}
    protected void EmitSignalItemClicked(long @index)
    {
        EmitSignal(SignalName.ItemClicked, [@index]);
    }
    private global::ClankerWorld.GodotClient.UI.SlotList.ItemNavigatedEventHandler backing_ItemNavigated;
    /// <inheritdoc cref="global::ClankerWorld.GodotClient.UI.SlotList.ItemNavigatedEventHandler"/>
    public event global::ClankerWorld.GodotClient.UI.SlotList.ItemNavigatedEventHandler @ItemNavigated {
        add => backing_ItemNavigated += value;
        remove => backing_ItemNavigated -= value;
}
    protected void EmitSignalItemNavigated(long @index)
    {
        EmitSignal(SignalName.ItemNavigated, [@index]);
    }
    private global::ClankerWorld.GodotClient.UI.SlotList.ItemActivatedEventHandler backing_ItemActivated;
    /// <inheritdoc cref="global::ClankerWorld.GodotClient.UI.SlotList.ItemActivatedEventHandler"/>
    public event global::ClankerWorld.GodotClient.UI.SlotList.ItemActivatedEventHandler @ItemActivated {
        add => backing_ItemActivated += value;
        remove => backing_ItemActivated -= value;
}
    protected void EmitSignalItemActivated(long @index)
    {
        EmitSignal(SignalName.ItemActivated, [@index]);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RaiseGodotClassSignalCallbacks(in godot_string_name signal, NativeVariantPtrArgs args)
    {
        if (signal == SignalName.@ItemSelected && args.Count == 1) {
            backing_ItemSelected?.Invoke(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            return;
        }
        if (signal == SignalName.@ItemClicked && args.Count == 1) {
            backing_ItemClicked?.Invoke(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            return;
        }
        if (signal == SignalName.@ItemNavigated && args.Count == 1) {
            backing_ItemNavigated?.Invoke(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            return;
        }
        if (signal == SignalName.@ItemActivated && args.Count == 1) {
            backing_ItemActivated?.Invoke(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            return;
        }
        base.RaiseGodotClassSignalCallbacks(signal, args);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassSignal(in godot_string_name signal)
    {
        if (signal == SignalName.@ItemSelected) {
           return true;
        }
        if (signal == SignalName.@ItemClicked) {
           return true;
        }
        if (signal == SignalName.@ItemNavigated) {
           return true;
        }
        if (signal == SignalName.@ItemActivated) {
           return true;
        }
        return base.HasGodotClassSignal(signal);
    }
}

}
