﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SegmentedChoice
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the signals contained in this class, for fast lookup.
    /// </summary>
    public new class SignalName : global::Godot.PanelContainer.SignalName {
        /// <summary>
        /// Cached name for the 'ItemSelected' signal.
        /// </summary>
        public new static readonly global::Godot.StringName @ItemSelected = "ItemSelected";
    }
    /// <summary>
    /// Get the signal information for all the signals declared in this class.
    /// This method is used by Godot to register the available signals in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotSignalList()
    {
        var signals = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(1);
        signals.Add(new(name: SignalName.@ItemSelected, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        return signals;
    }
#pragma warning restore CS0109
    private global::ClankerWorld.GodotClient.UI.SegmentedChoice.ItemSelectedEventHandler backing_ItemSelected;
    /// <inheritdoc cref="global::ClankerWorld.GodotClient.UI.SegmentedChoice.ItemSelectedEventHandler"/>
    public event global::ClankerWorld.GodotClient.UI.SegmentedChoice.ItemSelectedEventHandler @ItemSelected {
        add => backing_ItemSelected += value;
        remove => backing_ItemSelected -= value;
}
    protected void EmitSignalItemSelected(long @index)
    {
        EmitSignal(SignalName.ItemSelected, [@index]);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override void RaiseGodotClassSignalCallbacks(in godot_string_name signal, NativeVariantPtrArgs args)
    {
        if (signal == SignalName.@ItemSelected && args.Count == 1) {
            backing_ItemSelected?.Invoke(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            return;
        }
        base.RaiseGodotClassSignalCallbacks(signal, args);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassSignal(in godot_string_name signal)
    {
        if (signal == SignalName.@ItemSelected) {
           return true;
        }
        return base.HasGodotClassSignal(signal);
    }
}

}
