﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class WeatherLayer
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'CloudsEnabled' property.
        /// </summary>
        public new static readonly global::Godot.StringName @CloudsEnabled = "CloudsEnabled";
        /// <summary>
        /// Cached name for the 'LightningEnabled' property.
        /// </summary>
        public new static readonly global::Godot.StringName @LightningEnabled = "LightningEnabled";
        /// <summary>
        /// Cached name for the 'Paused' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Paused = "Paused";
        /// <summary>
        /// Cached name for the 'AnimationTime' property.
        /// </summary>
        public new static readonly global::Godot.StringName @AnimationTime = "AnimationTime";
        /// <summary>
        /// Cached name for the 'PrecipitationMilliseconds' property.
        /// </summary>
        public new static readonly global::Godot.StringName @PrecipitationMilliseconds = "PrecipitationMilliseconds";
        /// <summary>
        /// Cached name for the 'DrawnParticleCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawnParticleCount = "DrawnParticleCount";
        /// <summary>
        /// Cached name for the 'source' field.
        /// </summary>
        public new static readonly global::Godot.StringName @source = "source";
        /// <summary>
        /// Cached name for the 'fieldVersion' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fieldVersion = "fieldVersion";
        /// <summary>
        /// Cached name for the 'fieldCamera' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fieldCamera = "fieldCamera";
        /// <summary>
        /// Cached name for the 'fieldTileSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fieldTileSize = "fieldTileSize";
        /// <summary>
        /// Cached name for the 'fieldTime' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fieldTime = "fieldTime";
        /// <summary>
        /// Cached name for the 'fieldLeft' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fieldLeft = "fieldLeft";
        /// <summary>
        /// Cached name for the 'fieldTop' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fieldTop = "fieldTop";
        /// <summary>
        /// Cached name for the 'fieldWidth' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fieldWidth = "fieldWidth";
        /// <summary>
        /// Cached name for the 'fieldHeight' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fieldHeight = "fieldHeight";
        /// <summary>
        /// Cached name for the 'fieldResolution' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fieldResolution = "fieldResolution";
        /// <summary>
        /// Cached name for the 'rain' field.
        /// </summary>
        public new static readonly global::Godot.StringName @rain = "rain";
        /// <summary>
        /// Cached name for the 'storm' field.
        /// </summary>
        public new static readonly global::Godot.StringName @storm = "storm";
        /// <summary>
        /// Cached name for the 'snow' field.
        /// </summary>
        public new static readonly global::Godot.StringName @snow = "snow";
        /// <summary>
        /// Cached name for the 'cloudy' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cloudy = "cloudy";
        /// <summary>
        /// Cached name for the 'rainSupport' field.
        /// </summary>
        public new static readonly global::Godot.StringName @rainSupport = "rainSupport";
        /// <summary>
        /// Cached name for the 'stormSupport' field.
        /// </summary>
        public new static readonly global::Godot.StringName @stormSupport = "stormSupport";
        /// <summary>
        /// Cached name for the 'snowSupport' field.
        /// </summary>
        public new static readonly global::Godot.StringName @snowSupport = "snowSupport";
        /// <summary>
        /// Cached name for the 'tintImage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tintImage = "tintImage";
        /// <summary>
        /// Cached name for the 'tintTexture' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tintTexture = "tintTexture";
        /// <summary>
        /// Cached name for the 'stormImage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @stormImage = "stormImage";
        /// <summary>
        /// Cached name for the 'stormTexture' field.
        /// </summary>
        public new static readonly global::Godot.StringName @stormTexture = "stormTexture";
        /// <summary>
        /// Cached name for the 'cloudiness' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cloudiness = "cloudiness";
        /// <summary>
        /// Cached name for the 'animationTime' field.
        /// </summary>
        public new static readonly global::Godot.StringName @animationTime = "animationTime";
        /// <summary>
        /// Cached name for the 'drawnCamera' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnCamera = "drawnCamera";
        /// <summary>
        /// Cached name for the 'drawnTileSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnTileSize = "drawnTileSize";
        /// <summary>
        /// Cached name for the 'drawnCloudiness' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnCloudiness = "drawnCloudiness";
        /// <summary>
        /// Cached name for the 'paused' field.
        /// </summary>
        public new static readonly global::Godot.StringName @paused = "paused";
        /// <summary>
        /// Cached name for the 'regionVersion' field.
        /// </summary>
        public new static readonly global::Godot.StringName @regionVersion = "regionVersion";
        /// <summary>
        /// Cached name for the 'regionSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @regionSize = "regionSize";
        /// <summary>
        /// Cached name for the 'fading' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fading = "fading";
        /// <summary>
        /// Cached name for the 'displayedWeather' field.
        /// </summary>
        public new static readonly global::Godot.StringName @displayedWeather = "displayedWeather";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@CloudsEnabled) {
            this.@CloudsEnabled = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@LightningEnabled) {
            this.@LightningEnabled = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@Paused) {
            this.@Paused = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@PrecipitationMilliseconds) {
            this.@PrecipitationMilliseconds = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@DrawnParticleCount) {
            this.@DrawnParticleCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@source) {
            this.@source = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(value);
            return true;
        }
        if (name == PropertyName.@fieldVersion) {
            this.@fieldVersion = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@fieldCamera) {
            this.@fieldCamera = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(value);
            return true;
        }
        if (name == PropertyName.@fieldTileSize) {
            this.@fieldTileSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@fieldTime) {
            this.@fieldTime = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@fieldLeft) {
            this.@fieldLeft = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@fieldTop) {
            this.@fieldTop = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@fieldWidth) {
            this.@fieldWidth = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@fieldHeight) {
            this.@fieldHeight = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@fieldResolution) {
            this.@fieldResolution = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@rain) {
            this.@rain = global::Godot.NativeInterop.VariantUtils.ConvertTo<float[]>(value);
            return true;
        }
        if (name == PropertyName.@storm) {
            this.@storm = global::Godot.NativeInterop.VariantUtils.ConvertTo<float[]>(value);
            return true;
        }
        if (name == PropertyName.@snow) {
            this.@snow = global::Godot.NativeInterop.VariantUtils.ConvertTo<float[]>(value);
            return true;
        }
        if (name == PropertyName.@cloudy) {
            this.@cloudy = global::Godot.NativeInterop.VariantUtils.ConvertTo<float[]>(value);
            return true;
        }
        if (name == PropertyName.@rainSupport) {
            this.@rainSupport = global::Godot.NativeInterop.VariantUtils.ConvertTo<float[]>(value);
            return true;
        }
        if (name == PropertyName.@stormSupport) {
            this.@stormSupport = global::Godot.NativeInterop.VariantUtils.ConvertTo<float[]>(value);
            return true;
        }
        if (name == PropertyName.@snowSupport) {
            this.@snowSupport = global::Godot.NativeInterop.VariantUtils.ConvertTo<float[]>(value);
            return true;
        }
        if (name == PropertyName.@tintImage) {
            this.@tintImage = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Image>(value);
            return true;
        }
        if (name == PropertyName.@tintTexture) {
            this.@tintTexture = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.ImageTexture>(value);
            return true;
        }
        if (name == PropertyName.@stormImage) {
            this.@stormImage = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Image>(value);
            return true;
        }
        if (name == PropertyName.@stormTexture) {
            this.@stormTexture = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.ImageTexture>(value);
            return true;
        }
        if (name == PropertyName.@cloudiness) {
            this.@cloudiness = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@animationTime) {
            this.@animationTime = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@drawnCamera) {
            this.@drawnCamera = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(value);
            return true;
        }
        if (name == PropertyName.@drawnTileSize) {
            this.@drawnTileSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@drawnCloudiness) {
            this.@drawnCloudiness = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@paused) {
            this.@paused = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@regionVersion) {
            this.@regionVersion = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@regionSize) {
            this.@regionSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@fading) {
            this.@fading = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@displayedWeather) {
            this.@displayedWeather = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@CloudsEnabled) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@CloudsEnabled);
            return true;
        }
        if (name == PropertyName.@LightningEnabled) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@LightningEnabled);
            return true;
        }
        if (name == PropertyName.@Paused) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@Paused);
            return true;
        }
        if (name == PropertyName.@AnimationTime) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@AnimationTime);
            return true;
        }
        if (name == PropertyName.@PrecipitationMilliseconds) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@PrecipitationMilliseconds);
            return true;
        }
        if (name == PropertyName.@DrawnParticleCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@DrawnParticleCount);
            return true;
        }
        if (name == PropertyName.@source) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@source);
            return true;
        }
        if (name == PropertyName.@fieldVersion) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@fieldVersion);
            return true;
        }
        if (name == PropertyName.@fieldCamera) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@fieldCamera);
            return true;
        }
        if (name == PropertyName.@fieldTileSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@fieldTileSize);
            return true;
        }
        if (name == PropertyName.@fieldTime) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@fieldTime);
            return true;
        }
        if (name == PropertyName.@fieldLeft) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@fieldLeft);
            return true;
        }
        if (name == PropertyName.@fieldTop) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@fieldTop);
            return true;
        }
        if (name == PropertyName.@fieldWidth) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@fieldWidth);
            return true;
        }
        if (name == PropertyName.@fieldHeight) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@fieldHeight);
            return true;
        }
        if (name == PropertyName.@fieldResolution) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@fieldResolution);
            return true;
        }
        if (name == PropertyName.@rain) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float[]>(this.@rain);
            return true;
        }
        if (name == PropertyName.@storm) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float[]>(this.@storm);
            return true;
        }
        if (name == PropertyName.@snow) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float[]>(this.@snow);
            return true;
        }
        if (name == PropertyName.@cloudy) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float[]>(this.@cloudy);
            return true;
        }
        if (name == PropertyName.@rainSupport) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float[]>(this.@rainSupport);
            return true;
        }
        if (name == PropertyName.@stormSupport) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float[]>(this.@stormSupport);
            return true;
        }
        if (name == PropertyName.@snowSupport) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float[]>(this.@snowSupport);
            return true;
        }
        if (name == PropertyName.@tintImage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Image>(this.@tintImage);
            return true;
        }
        if (name == PropertyName.@tintTexture) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ImageTexture>(this.@tintTexture);
            return true;
        }
        if (name == PropertyName.@stormImage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Image>(this.@stormImage);
            return true;
        }
        if (name == PropertyName.@stormTexture) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ImageTexture>(this.@stormTexture);
            return true;
        }
        if (name == PropertyName.@cloudiness) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@cloudiness);
            return true;
        }
        if (name == PropertyName.@animationTime) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@animationTime);
            return true;
        }
        if (name == PropertyName.@drawnCamera) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@drawnCamera);
            return true;
        }
        if (name == PropertyName.@drawnTileSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@drawnTileSize);
            return true;
        }
        if (name == PropertyName.@drawnCloudiness) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@drawnCloudiness);
            return true;
        }
        if (name == PropertyName.@paused) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@paused);
            return true;
        }
        if (name == PropertyName.@regionVersion) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@regionVersion);
            return true;
        }
        if (name == PropertyName.@regionSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@regionSize);
            return true;
        }
        if (name == PropertyName.@fading) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@fading);
            return true;
        }
        if (name == PropertyName.@displayedWeather) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@displayedWeather);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@source, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@fieldVersion, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@fieldCamera, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@fieldTileSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@fieldTime, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@fieldLeft, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@fieldTop, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@fieldWidth, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@fieldHeight, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@fieldResolution, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)32, name: PropertyName.@rain, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)32, name: PropertyName.@storm, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)32, name: PropertyName.@snow, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)32, name: PropertyName.@cloudy, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)32, name: PropertyName.@rainSupport, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)32, name: PropertyName.@stormSupport, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)32, name: PropertyName.@snowSupport, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tintImage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tintTexture, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@stormImage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@stormTexture, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@cloudiness, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@animationTime, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@drawnCamera, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@drawnTileSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@drawnCloudiness, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@paused, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@regionVersion, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@regionSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@fading, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@displayedWeather, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@CloudsEnabled, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@LightningEnabled, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@Paused, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@AnimationTime, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@PrecipitationMilliseconds, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@DrawnParticleCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
