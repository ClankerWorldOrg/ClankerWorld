﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SaveTimelineRows
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'NowTick' property.
        /// </summary>
        public new static readonly global::Godot.StringName @NowTick = "NowTick";
        /// <summary>
        /// Cached name for the 'SelectedId' property.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedId = "SelectedId";
        /// <summary>
        /// Cached name for the 'PixelsPerDay' property.
        /// </summary>
        public new static readonly global::Godot.StringName @PixelsPerDay = "PixelsPerDay";
        /// <summary>
        /// Cached name for the 'ViewLeft' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ViewLeft = "ViewLeft";
        /// <summary>
        /// Cached name for the 'ViewTop' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ViewTop = "ViewTop";
        /// <summary>
        /// Cached name for the 'ViewWidth' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ViewWidth = "ViewWidth";
        /// <summary>
        /// Cached name for the 'firstDay' field.
        /// </summary>
        public new static readonly global::Godot.StringName @firstDay = "firstDay";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@NowTick) {
            this.@NowTick = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@SelectedId) {
            this.@SelectedId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@PixelsPerDay) {
            this.@PixelsPerDay = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@ViewLeft) {
            this.@ViewLeft = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@ViewTop) {
            this.@ViewTop = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@ViewWidth) {
            this.@ViewWidth = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@firstDay) {
            this.@firstDay = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@NowTick) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@NowTick);
            return true;
        }
        if (name == PropertyName.@SelectedId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@SelectedId);
            return true;
        }
        if (name == PropertyName.@PixelsPerDay) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@PixelsPerDay);
            return true;
        }
        if (name == PropertyName.@ViewLeft) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@ViewLeft);
            return true;
        }
        if (name == PropertyName.@ViewTop) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@ViewTop);
            return true;
        }
        if (name == PropertyName.@ViewWidth) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@ViewWidth);
            return true;
        }
        if (name == PropertyName.@firstDay) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@firstDay);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@firstDay, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@NowTick, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@SelectedId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@PixelsPerDay, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@ViewLeft, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@ViewTop, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@ViewWidth, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
