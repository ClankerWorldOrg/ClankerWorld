﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class ItemStorage
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.VBoxContainer.PropertyName {
        /// <summary>
        /// Cached name for the 'Title' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Title = "Title";
        /// <summary>
        /// Cached name for the 'Columns' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Columns = "Columns";
        /// <summary>
        /// Cached name for the 'Named' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Named = "Named";
        /// <summary>
        /// Cached name for the 'SlotCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @SlotCount = "SlotCount";
        /// <summary>
        /// Cached name for the 'Summary' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Summary = "Summary";
        /// <summary>
        /// Cached name for the 'titleLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @titleLabel = "titleLabel";
        /// <summary>
        /// Cached name for the 'summaryLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @summaryLabel = "summaryLabel";
        /// <summary>
        /// Cached name for the 'slots' field.
        /// </summary>
        public new static readonly global::Godot.StringName @slots = "slots";
        /// <summary>
        /// Cached name for the 'emptyLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @emptyLabel = "emptyLabel";
        /// <summary>
        /// Cached name for the 'capacityRow' field.
        /// </summary>
        public new static readonly global::Godot.StringName @capacityRow = "capacityRow";
        /// <summary>
        /// Cached name for the 'capacityMeter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @capacityMeter = "capacityMeter";
        /// <summary>
        /// Cached name for the 'capacityText' field.
        /// </summary>
        public new static readonly global::Godot.StringName @capacityText = "capacityText";
        /// <summary>
        /// Cached name for the 'renderedItems' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedItems = "renderedItems";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@renderedItems) {
            this.@renderedItems = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Title) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Title);
            return true;
        }
        if (name == PropertyName.@Columns) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Columns);
            return true;
        }
        if (name == PropertyName.@Named) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@Named);
            return true;
        }
        if (name == PropertyName.@SlotCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@SlotCount);
            return true;
        }
        if (name == PropertyName.@Summary) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Summary);
            return true;
        }
        if (name == PropertyName.@titleLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@titleLabel);
            return true;
        }
        if (name == PropertyName.@summaryLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@summaryLabel);
            return true;
        }
        if (name == PropertyName.@slots) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.GridContainer>(this.@slots);
            return true;
        }
        if (name == PropertyName.@emptyLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@emptyLabel);
            return true;
        }
        if (name == PropertyName.@capacityRow) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@capacityRow);
            return true;
        }
        if (name == PropertyName.@capacityMeter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelMeter>(this.@capacityMeter);
            return true;
        }
        if (name == PropertyName.@capacityText) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@capacityText);
            return true;
        }
        if (name == PropertyName.@renderedItems) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedItems);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@titleLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@summaryLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@slots, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@emptyLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@capacityRow, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@capacityMeter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@capacityText, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedItems, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Title, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Columns, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@Named, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@SlotCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Summary, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
