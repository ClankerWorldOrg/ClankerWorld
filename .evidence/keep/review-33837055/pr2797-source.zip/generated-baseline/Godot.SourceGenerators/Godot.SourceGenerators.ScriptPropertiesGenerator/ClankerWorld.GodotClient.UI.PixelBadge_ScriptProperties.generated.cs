﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class PixelBadge
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'Diameter' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Diameter = "Diameter";
        /// <summary>
        /// Cached name for the 'Warning' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Warning = "Warning";
        /// <summary>
        /// Cached name for the 'Text' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Text = "Text";
        /// <summary>
        /// Cached name for the 'text' field.
        /// </summary>
        public new static readonly global::Godot.StringName @text = "text";
        /// <summary>
        /// Cached name for the 'diameter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @diameter = "diameter";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@Text) {
            this.@Text = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@text) {
            this.@text = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@diameter) {
            this.@diameter = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Diameter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Diameter);
            return true;
        }
        if (name == PropertyName.@Warning) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@Warning);
            return true;
        }
        if (name == PropertyName.@Text) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Text);
            return true;
        }
        if (name == PropertyName.@text) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@text);
            return true;
        }
        if (name == PropertyName.@diameter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@diameter);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@text, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@diameter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Diameter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@Warning, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Text, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
