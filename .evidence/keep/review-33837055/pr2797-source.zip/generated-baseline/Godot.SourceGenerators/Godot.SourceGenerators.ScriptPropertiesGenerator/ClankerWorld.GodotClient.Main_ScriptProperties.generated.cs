﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient {

partial class Main
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'CameraMoving' property.
        /// </summary>
        public new static readonly global::Godot.StringName @CameraMoving = "CameraMoving";
        /// <summary>
        /// Cached name for the 'DeveloperEditOperation' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DeveloperEditOperation = "DeveloperEditOperation";
        /// <summary>
        /// Cached name for the 'DatesShowSeason' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DatesShowSeason = "DatesShowSeason";
        /// <summary>
        /// Cached name for the 'ShowsPlacementOverlays' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowsPlacementOverlays = "ShowsPlacementOverlays";
        /// <summary>
        /// Cached name for the 'HudTop' property.
        /// </summary>
        public new static readonly global::Godot.StringName @HudTop = "HudTop";
        /// <summary>
        /// Cached name for the 'WorldInfoShowsTowns' property.
        /// </summary>
        public new static readonly global::Godot.StringName @WorldInfoShowsTowns = "WorldInfoShowsTowns";
        /// <summary>
        /// Cached name for the 'DeveloperMode' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DeveloperMode = "DeveloperMode";
        /// <summary>
        /// Cached name for the 'LauncherPath' property.
        /// </summary>
        public new static readonly global::Godot.StringName @LauncherPath = "LauncherPath";
        /// <summary>
        /// Cached name for the 'PauseMenuPageOpen' property.
        /// </summary>
        public new static readonly global::Godot.StringName @PauseMenuPageOpen = "PauseMenuPageOpen";
        /// <summary>
        /// Cached name for the 'UiSize' property.
        /// </summary>
        public new static readonly global::Godot.StringName @UiSize = "UiSize";
        /// <summary>
        /// Cached name for the 'WorldHistoryEmbedded' property.
        /// </summary>
        public new static readonly global::Godot.StringName @WorldHistoryEmbedded = "WorldHistoryEmbedded";
        /// <summary>
        /// Cached name for the 'ManualSaveTimelineShown' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ManualSaveTimelineShown = "ManualSaveTimelineShown";
        /// <summary>
        /// Cached name for the 'ListedSaveWorldIsActive' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ListedSaveWorldIsActive = "ListedSaveWorldIsActive";
        /// <summary>
        /// Cached name for the 'CanPickWorldEditTile' property.
        /// </summary>
        public new static readonly global::Godot.StringName @CanPickWorldEditTile = "CanPickWorldEditTile";
        /// <summary>
        /// Cached name for the 'conversationPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationPanel = "conversationPanel";
        /// <summary>
        /// Cached name for the 'conversationReaderTitle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationReaderTitle = "conversationReaderTitle";
        /// <summary>
        /// Cached name for the 'conversationReaderStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationReaderStatus = "conversationReaderStatus";
        /// <summary>
        /// Cached name for the 'conversationReaderSummary' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationReaderSummary = "conversationReaderSummary";
        /// <summary>
        /// Cached name for the 'conversationHistoryButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationHistoryButton = "conversationHistoryButton";
        /// <summary>
        /// Cached name for the 'conversationHistoryText' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationHistoryText = "conversationHistoryText";
        /// <summary>
        /// Cached name for the 'conversationReadWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationReadWorldId = "conversationReadWorldId";
        /// <summary>
        /// Cached name for the 'openConversationId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @openConversationId = "openConversationId";
        /// <summary>
        /// Cached name for the 'openConversationAgentId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @openConversationAgentId = "openConversationAgentId";
        /// <summary>
        /// Cached name for the 'conversationHistoryExpanded' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationHistoryExpanded = "conversationHistoryExpanded";
        /// <summary>
        /// Cached name for the 'agentListCards' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentListCards = "agentListCards";
        /// <summary>
        /// Cached name for the 'renderedAgentListWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedAgentListWorldId = "renderedAgentListWorldId";
        /// <summary>
        /// Cached name for the 'renderedAgentListTheme' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedAgentListTheme = "renderedAgentListTheme";
        /// <summary>
        /// Cached name for the 'selectedAgentModelGap' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedAgentModelGap = "selectedAgentModelGap";
        /// <summary>
        /// Cached name for the 'agentProfilePanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentProfilePanel = "agentProfilePanel";
        /// <summary>
        /// Cached name for the 'agentPortraitFrame' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentPortraitFrame = "agentPortraitFrame";
        /// <summary>
        /// Cached name for the 'agentPortraitTexture' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentPortraitTexture = "agentPortraitTexture";
        /// <summary>
        /// Cached name for the 'renameToggleButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renameToggleButton = "renameToggleButton";
        /// <summary>
        /// Cached name for the 'renameRow' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renameRow = "renameRow";
        /// <summary>
        /// Cached name for the 'profileActivityLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profileActivityLabel = "profileActivityLabel";
        /// <summary>
        /// Cached name for the 'profileOrderLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profileOrderLabel = "profileOrderLabel";
        /// <summary>
        /// Cached name for the 'profileFindButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profileFindButton = "profileFindButton";
        /// <summary>
        /// Cached name for the 'profileCloseButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profileCloseButton = "profileCloseButton";
        /// <summary>
        /// Cached name for the 'profileMeters' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profileMeters = "profileMeters";
        /// <summary>
        /// Cached name for the 'profileFullnessMeter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profileFullnessMeter = "profileFullnessMeter";
        /// <summary>
        /// Cached name for the 'profileWarmthMeter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profileWarmthMeter = "profileWarmthMeter";
        /// <summary>
        /// Cached name for the 'profileDietMeter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profileDietMeter = "profileDietMeter";
        /// <summary>
        /// Cached name for the 'profileIllnessMeter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profileIllnessMeter = "profileIllnessMeter";
        /// <summary>
        /// Cached name for the 'thoughtsHeading' field.
        /// </summary>
        public new static readonly global::Godot.StringName @thoughtsHeading = "thoughtsHeading";
        /// <summary>
        /// Cached name for the 'speakSection' field.
        /// </summary>
        public new static readonly global::Godot.StringName @speakSection = "speakSection";
        /// <summary>
        /// Cached name for the 'instructionHistory' field.
        /// </summary>
        public new static readonly global::Godot.StringName @instructionHistory = "instructionHistory";
        /// <summary>
        /// Cached name for the 'agentOverviewScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentOverviewScroll = "agentOverviewScroll";
        /// <summary>
        /// Cached name for the 'agentOverviewGap' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentOverviewGap = "agentOverviewGap";
        /// <summary>
        /// Cached name for the 'agentProfileFitQueued' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentProfileFitQueued = "agentProfileFitQueued";
        /// <summary>
        /// Cached name for the 'instructionSuggestButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @instructionSuggestButton = "instructionSuggestButton";
        /// <summary>
        /// Cached name for the 'instructionOrderButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @instructionOrderButton = "instructionOrderButton";
        /// <summary>
        /// Cached name for the 'instructionQueueToggle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @instructionQueueToggle = "instructionQueueToggle";
        /// <summary>
        /// Cached name for the 'instructionCancelButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @instructionCancelButton = "instructionCancelButton";
        /// <summary>
        /// Cached name for the 'thoughtsInset' field.
        /// </summary>
        public new static readonly global::Godot.StringName @thoughtsInset = "thoughtsInset";
        /// <summary>
        /// Cached name for the 'readThoughtsButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @readThoughtsButton = "readThoughtsButton";
        /// <summary>
        /// Cached name for the 'thoughtsPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @thoughtsPanel = "thoughtsPanel";
        /// <summary>
        /// Cached name for the 'thoughtsReaderTitle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @thoughtsReaderTitle = "thoughtsReaderTitle";
        /// <summary>
        /// Cached name for the 'thoughtsReaderText' field.
        /// </summary>
        public new static readonly global::Godot.StringName @thoughtsReaderText = "thoughtsReaderText";
        /// <summary>
        /// Cached name for the 'renderedThoughtsReader' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedThoughtsReader = "renderedThoughtsReader";
        /// <summary>
        /// Cached name for the 'agentProfileRequested' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentProfileRequested = "agentProfileRequested";
        /// <summary>
        /// Cached name for the 'measuredFirstAgentProfile' field.
        /// </summary>
        public new static readonly global::Godot.StringName @measuredFirstAgentProfile = "measuredFirstAgentProfile";
        /// <summary>
        /// Cached name for the 'quickCardNameLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quickCardNameLabel = "quickCardNameLabel";
        /// <summary>
        /// Cached name for the 'quickCardActivityLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quickCardActivityLabel = "quickCardActivityLabel";
        /// <summary>
        /// Cached name for the 'quickCardOrderLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quickCardOrderLabel = "quickCardOrderLabel";
        /// <summary>
        /// Cached name for the 'quickCardMeters' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quickCardMeters = "quickCardMeters";
        /// <summary>
        /// Cached name for the 'quickFullnessMeter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quickFullnessMeter = "quickFullnessMeter";
        /// <summary>
        /// Cached name for the 'quickWarmthMeter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quickWarmthMeter = "quickWarmthMeter";
        /// <summary>
        /// Cached name for the 'quickIllnessMeter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quickIllnessMeter = "quickIllnessMeter";
        /// <summary>
        /// Cached name for the 'quickCardProfileButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quickCardProfileButton = "quickCardProfileButton";
        /// <summary>
        /// Cached name for the 'quickCardSpeakButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quickCardSpeakButton = "quickCardSpeakButton";
        /// <summary>
        /// Cached name for the 'renderedAgentCardTheme' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedAgentCardTheme = "renderedAgentCardTheme";
        /// <summary>
        /// Cached name for the 'apiKeysPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @apiKeysPanel = "apiKeysPanel";
        /// <summary>
        /// Cached name for the 'apiKeyProviderChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @apiKeyProviderChoice = "apiKeyProviderChoice";
        /// <summary>
        /// Cached name for the 'apiKeyLabelInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @apiKeyLabelInput = "apiKeyLabelInput";
        /// <summary>
        /// Cached name for the 'apiKeyInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @apiKeyInput = "apiKeyInput";
        /// <summary>
        /// Cached name for the 'saveApiKeyButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @saveApiKeyButton = "saveApiKeyButton";
        /// <summary>
        /// Cached name for the 'apiKeysStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @apiKeysStatus = "apiKeysStatus";
        /// <summary>
        /// Cached name for the 'savedApiKeys' field.
        /// </summary>
        public new static readonly global::Godot.StringName @savedApiKeys = "savedApiKeys";
        /// <summary>
        /// Cached name for the 'savedApiKeyChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @savedApiKeyChoice = "savedApiKeyChoice";
        /// <summary>
        /// Cached name for the 'deleteApiKeyButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @deleteApiKeyButton = "deleteApiKeyButton";
        /// <summary>
        /// Cached name for the 'apiKeysRead' field.
        /// </summary>
        public new static readonly global::Godot.StringName @apiKeysRead = "apiKeysRead";
        /// <summary>
        /// Cached name for the 'buildingQuickCard' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingQuickCard = "buildingQuickCard";
        /// <summary>
        /// Cached name for the 'buildingDetailsPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingDetailsPanel = "buildingDetailsPanel";
        /// <summary>
        /// Cached name for the 'buildingQuickHeader' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingQuickHeader = "buildingQuickHeader";
        /// <summary>
        /// Cached name for the 'buildingDetailsHeader' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingDetailsHeader = "buildingDetailsHeader";
        /// <summary>
        /// Cached name for the 'buildingQuickStorage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingQuickStorage = "buildingQuickStorage";
        /// <summary>
        /// Cached name for the 'buildingDetailsStorage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingDetailsStorage = "buildingDetailsStorage";
        /// <summary>
        /// Cached name for the 'buildingDetailsButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingDetailsButton = "buildingDetailsButton";
        /// <summary>
        /// Cached name for the 'buildingQuickStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingQuickStatus = "buildingQuickStatus";
        /// <summary>
        /// Cached name for the 'buildingFacts' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingFacts = "buildingFacts";
        /// <summary>
        /// Cached name for the 'buildingDetailsScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingDetailsScroll = "buildingDetailsScroll";
        /// <summary>
        /// Cached name for the 'buildingDetailsContent' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingDetailsContent = "buildingDetailsContent";
        /// <summary>
        /// Cached name for the 'buildingWorkSection' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingWorkSection = "buildingWorkSection";
        /// <summary>
        /// Cached name for the 'buildingWorkRows' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingWorkRows = "buildingWorkRows";
        /// <summary>
        /// Cached name for the 'buildingRecipeSection' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingRecipeSection = "buildingRecipeSection";
        /// <summary>
        /// Cached name for the 'buildingRecipeRows' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingRecipeRows = "buildingRecipeRows";
        /// <summary>
        /// Cached name for the 'renderedBuildingRecipes' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedBuildingRecipes = "renderedBuildingRecipes";
        /// <summary>
        /// Cached name for the 'buildingPeopleSection' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingPeopleSection = "buildingPeopleSection";
        /// <summary>
        /// Cached name for the 'buildingPeopleSummary' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingPeopleSummary = "buildingPeopleSummary";
        /// <summary>
        /// Cached name for the 'buildingPeopleText' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingPeopleText = "buildingPeopleText";
        /// <summary>
        /// Cached name for the 'buildingManagementSection' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingManagementSection = "buildingManagementSection";
        /// <summary>
        /// Cached name for the 'buildingManagementNote' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingManagementNote = "buildingManagementNote";
        /// <summary>
        /// Cached name for the 'buildingManagementChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingManagementChoice = "buildingManagementChoice";
        /// <summary>
        /// Cached name for the 'buildingManagementApply' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingManagementApply = "buildingManagementApply";
        /// <summary>
        /// Cached name for the 'buildingRemoveButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingRemoveButton = "buildingRemoveButton";
        /// <summary>
        /// Cached name for the 'buildingRemoveConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingRemoveConfirmation = "buildingRemoveConfirmation";
        /// <summary>
        /// Cached name for the 'pendingBuildingRemovalWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingBuildingRemovalWorldId = "pendingBuildingRemovalWorldId";
        /// <summary>
        /// Cached name for the 'renderedBuildingManagementWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedBuildingManagementWorldId = "renderedBuildingManagementWorldId";
        /// <summary>
        /// Cached name for the 'renderedBuildingManagementId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedBuildingManagementId = "renderedBuildingManagementId";
        /// <summary>
        /// Cached name for the 'selectedBuildingId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedBuildingId = "selectedBuildingId";
        /// <summary>
        /// Cached name for the 'buildingDetailsRequested' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingDetailsRequested = "buildingDetailsRequested";
        /// <summary>
        /// Cached name for the 'renderedBuildingStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedBuildingStatus = "renderedBuildingStatus";
        /// <summary>
        /// Cached name for the 'renderedBuildingWork' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedBuildingWork = "renderedBuildingWork";
        /// <summary>
        /// Cached name for the 'buildingStorageHistorySection' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingStorageHistorySection = "buildingStorageHistorySection";
        /// <summary>
        /// Cached name for the 'buildingStorageHistoryRows' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingStorageHistoryRows = "buildingStorageHistoryRows";
        /// <summary>
        /// Cached name for the 'renderedBuildingStorageHistory' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedBuildingStorageHistory = "renderedBuildingStorageHistory";
        /// <summary>
        /// Cached name for the 'cameraGliding' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraGliding = "cameraGliding";
        /// <summary>
        /// Cached name for the 'cameraGlideFrom' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraGlideFrom = "cameraGlideFrom";
        /// <summary>
        /// Cached name for the 'cameraGlideTo' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraGlideTo = "cameraGlideTo";
        /// <summary>
        /// Cached name for the 'cameraGlideElapsed' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraGlideElapsed = "cameraGlideElapsed";
        /// <summary>
        /// Cached name for the 'cameraZooming' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraZooming = "cameraZooming";
        /// <summary>
        /// Cached name for the 'cameraZoomFrom' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraZoomFrom = "cameraZoomFrom";
        /// <summary>
        /// Cached name for the 'cameraZoomTo' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraZoomTo = "cameraZoomTo";
        /// <summary>
        /// Cached name for the 'cameraZoomElapsed' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraZoomElapsed = "cameraZoomElapsed";
        /// <summary>
        /// Cached name for the 'cameraZoomAnchor' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraZoomAnchor = "cameraZoomAnchor";
        /// <summary>
        /// Cached name for the 'cameraZoomPoint' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraZoomPoint = "cameraZoomPoint";
        /// <summary>
        /// Cached name for the 'renderedObservationGeneration' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedObservationGeneration = "renderedObservationGeneration";
        /// <summary>
        /// Cached name for the 'settingUpLocalDevice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @settingUpLocalDevice = "settingUpLocalDevice";
        /// <summary>
        /// Cached name for the 'uiLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @uiLayer = "uiLayer";
        /// <summary>
        /// Cached name for the 'menuLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuLayer = "menuLayer";
        /// <summary>
        /// Cached name for the 'statusLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @statusLabel = "statusLabel";
        /// <summary>
        /// Cached name for the 'statusToast' field.
        /// </summary>
        public new static readonly global::Godot.StringName @statusToast = "statusToast";
        /// <summary>
        /// Cached name for the 'settingsButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @settingsButton = "settingsButton";
        /// <summary>
        /// Cached name for the 'modLibraryButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @modLibraryButton = "modLibraryButton";
        /// <summary>
        /// Cached name for the 'gameSettingsCategoryButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @gameSettingsCategoryButton = "gameSettingsCategoryButton";
        /// <summary>
        /// Cached name for the 'worldSettingsCategoryButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldSettingsCategoryButton = "worldSettingsCategoryButton";
        /// <summary>
        /// Cached name for the 'gameSettingsContent' field.
        /// </summary>
        public new static readonly global::Godot.StringName @gameSettingsContent = "gameSettingsContent";
        /// <summary>
        /// Cached name for the 'worldSettingsContent' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldSettingsContent = "worldSettingsContent";
        /// <summary>
        /// Cached name for the 'settingsScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @settingsScroll = "settingsScroll";
        /// <summary>
        /// Cached name for the 'serverUrlInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @serverUrlInput = "serverUrlInput";
        /// <summary>
        /// Cached name for the 'agentModelPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelPanel = "agentModelPanel";
        /// <summary>
        /// Cached name for the 'usageLimitPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @usageLimitPanel = "usageLimitPanel";
        /// <summary>
        /// Cached name for the 'agentModelRoleChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelRoleChoice = "agentModelRoleChoice";
        /// <summary>
        /// Cached name for the 'agentModelTargetChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelTargetChoice = "agentModelTargetChoice";
        /// <summary>
        /// Cached name for the 'agentModelProviderChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelProviderChoice = "agentModelProviderChoice";
        /// <summary>
        /// Cached name for the 'agentModelCredentialChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelCredentialChoice = "agentModelCredentialChoice";
        /// <summary>
        /// Cached name for the 'agentModelPicker' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelPicker = "agentModelPicker";
        /// <summary>
        /// Cached name for the 'agentModelThinkingChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelThinkingChoice = "agentModelThinkingChoice";
        /// <summary>
        /// Cached name for the 'agentModelApiKeyInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelApiKeyInput = "agentModelApiKeyInput";
        /// <summary>
        /// Cached name for the 'agentModelCredentialLabelInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelCredentialLabelInput = "agentModelCredentialLabelInput";
        /// <summary>
        /// Cached name for the 'agentModelConfigurationStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelConfigurationStatus = "agentModelConfigurationStatus";
        /// <summary>
        /// Cached name for the 'agentModelCredentialHint' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelCredentialHint = "agentModelCredentialHint";
        /// <summary>
        /// Cached name for the 'usageMeterStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @usageMeterStatus = "usageMeterStatus";
        /// <summary>
        /// Cached name for the 'usageAttemptLimitInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @usageAttemptLimitInput = "usageAttemptLimitInput";
        /// <summary>
        /// Cached name for the 'applyUsageLimitButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @applyUsageLimitButton = "applyUsageLimitButton";
        /// <summary>
        /// Cached name for the 'grantUsageCallsButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @grantUsageCallsButton = "grantUsageCallsButton";
        /// <summary>
        /// Cached name for the 'refreshUsageButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @refreshUsageButton = "refreshUsageButton";
        /// <summary>
        /// Cached name for the 'saveAgentModelProviderButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @saveAgentModelProviderButton = "saveAgentModelProviderButton";
        /// <summary>
        /// Cached name for the 'forgetAgentModelCredentialButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @forgetAgentModelCredentialButton = "forgetAgentModelCredentialButton";
        /// <summary>
        /// Cached name for the 'deleteAgentModelCredentialSlotButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @deleteAgentModelCredentialSlotButton = "deleteAgentModelCredentialSlotButton";
        /// <summary>
        /// Cached name for the 'openModelSettingsButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @openModelSettingsButton = "openModelSettingsButton";
        /// <summary>
        /// Cached name for the 'refreshAgentModelProviderButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @refreshAgentModelProviderButton = "refreshAgentModelProviderButton";
        /// <summary>
        /// Cached name for the 'topBar' field.
        /// </summary>
        public new static readonly global::Godot.StringName @topBar = "topBar";
        /// <summary>
        /// Cached name for the 'mapButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mapButton = "mapButton";
        /// <summary>
        /// Cached name for the 'worldInfoButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldInfoButton = "worldInfoButton";
        /// <summary>
        /// Cached name for the 'clockLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @clockLabel = "clockLabel";
        /// <summary>
        /// Cached name for the 'agentsButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentsButton = "agentsButton";
        /// <summary>
        /// Cached name for the 'eventLogButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @eventLogButton = "eventLogButton";
        /// <summary>
        /// Cached name for the 'menuButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuButton = "menuButton";
        /// <summary>
        /// Cached name for the 'topBarShade' field.
        /// </summary>
        public new static readonly global::Godot.StringName @topBarShade = "topBarShade";
        /// <summary>
        /// Cached name for the 'terrainLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @terrainLayer = "terrainLayer";
        /// <summary>
        /// Cached name for the 'weatherLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @weatherLayer = "weatherLayer";
        /// <summary>
        /// Cached name for the 'nightLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @nightLayer = "nightLayer";
        /// <summary>
        /// Cached name for the 'buildingCompletionLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @buildingCompletionLayer = "buildingCompletionLayer";
        /// <summary>
        /// Cached name for the 'goldenHourLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @goldenHourLayer = "goldenHourLayer";
        /// <summary>
        /// Cached name for the 'graveLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @graveLayer = "graveLayer";
        /// <summary>
        /// Cached name for the 'nightLightsLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @nightLightsLayer = "nightLightsLayer";
        /// <summary>
        /// Cached name for the 'smokeLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @smokeLayer = "smokeLayer";
        /// <summary>
        /// Cached name for the 'storedStockLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @storedStockLayer = "storedStockLayer";
        /// <summary>
        /// Cached name for the 'terrainWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @terrainWorldId = "terrainWorldId";
        /// <summary>
        /// Cached name for the 'mapCanvas' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mapCanvas = "mapCanvas";
        /// <summary>
        /// Cached name for the 'mapStage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mapStage = "mapStage";
        /// <summary>
        /// Cached name for the 'worldMapPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMapPanel = "worldMapPanel";
        /// <summary>
        /// Cached name for the 'worldMapAtlas' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMapAtlas = "worldMapAtlas";
        /// <summary>
        /// Cached name for the 'objectLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @objectLayer = "objectLayer";
        /// <summary>
        /// Cached name for the 'entityLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @entityLayer = "entityLayer";
        /// <summary>
        /// Cached name for the 'agentsSummaryLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentsSummaryLabel = "agentsSummaryLabel";
        /// <summary>
        /// Cached name for the 'agentQuickCard' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentQuickCard = "agentQuickCard";
        /// <summary>
        /// Cached name for the 'selectedAgentOverview' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedAgentOverview = "selectedAgentOverview";
        /// <summary>
        /// Cached name for the 'selectedAgentModelScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedAgentModelScroll = "selectedAgentModelScroll";
        /// <summary>
        /// Cached name for the 'selectedAgentModelContent' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedAgentModelContent = "selectedAgentModelContent";
        /// <summary>
        /// Cached name for the 'modelSettingsButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @modelSettingsButton = "modelSettingsButton";
        /// <summary>
        /// Cached name for the 'selectedActorNameLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedActorNameLabel = "selectedActorNameLabel";
        /// <summary>
        /// Cached name for the 'renameAgentInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renameAgentInput = "renameAgentInput";
        /// <summary>
        /// Cached name for the 'renameAgentButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renameAgentButton = "renameAgentButton";
        /// <summary>
        /// Cached name for the 'selectedActorSummaryLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedActorSummaryLabel = "selectedActorSummaryLabel";
        /// <summary>
        /// Cached name for the 'selectedActorConditionLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedActorConditionLabel = "selectedActorConditionLabel";
        /// <summary>
        /// Cached name for the 'clearSelectionButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @clearSelectionButton = "clearSelectionButton";
        /// <summary>
        /// Cached name for the 'findAgentButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @findAgentButton = "findAgentButton";
        /// <summary>
        /// Cached name for the 'familyTreeButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @familyTreeButton = "familyTreeButton";
        /// <summary>
        /// Cached name for the 'familyTreePanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @familyTreePanel = "familyTreePanel";
        /// <summary>
        /// Cached name for the 'familyTreeView' field.
        /// </summary>
        public new static readonly global::Godot.StringName @familyTreeView = "familyTreeView";
        /// <summary>
        /// Cached name for the 'familyTreeScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @familyTreeScroll = "familyTreeScroll";
        /// <summary>
        /// Cached name for the 'familyTreeStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @familyTreeStatus = "familyTreeStatus";
        /// <summary>
        /// Cached name for the 'agentList' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentList = "agentList";
        /// <summary>
        /// Cached name for the 'agentDetails' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentDetails = "agentDetails";
        /// <summary>
        /// Cached name for the 'privateThoughtHistory' field.
        /// </summary>
        public new static readonly global::Godot.StringName @privateThoughtHistory = "privateThoughtHistory";
        /// <summary>
        /// Cached name for the 'memoriesButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @memoriesButton = "memoriesButton";
        /// <summary>
        /// Cached name for the 'memoriesPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @memoriesPanel = "memoriesPanel";
        /// <summary>
        /// Cached name for the 'eventLog' field.
        /// </summary>
        public new static readonly global::Godot.StringName @eventLog = "eventLog";
        /// <summary>
        /// Cached name for the 'agentsPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentsPanel = "agentsPanel";
        /// <summary>
        /// Cached name for the 'eventLogPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @eventLogPanel = "eventLogPanel";
        /// <summary>
        /// Cached name for the 'worldInfoPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldInfoPanel = "worldInfoPanel";
        /// <summary>
        /// Cached name for the 'selectedTilePanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedTilePanel = "selectedTilePanel";
        /// <summary>
        /// Cached name for the 'selectedTileText' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedTileText = "selectedTileText";
        /// <summary>
        /// Cached name for the 'pauseMenuPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pauseMenuPanel = "pauseMenuPanel";
        /// <summary>
        /// Cached name for the 'menuActions' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuActions = "menuActions";
        /// <summary>
        /// Cached name for the 'settingsPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @settingsPanel = "settingsPanel";
        /// <summary>
        /// Cached name for the 'menuShade' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuShade = "menuShade";
        /// <summary>
        /// Cached name for the 'appBackdrop' field.
        /// </summary>
        public new static readonly global::Godot.StringName @appBackdrop = "appBackdrop";
        /// <summary>
        /// Cached name for the 'worldBackdrop' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldBackdrop = "worldBackdrop";
        /// <summary>
        /// Cached name for the 'themeChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @themeChoice = "themeChoice";
        /// <summary>
        /// Cached name for the 'cloudHazeToggle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cloudHazeToggle = "cloudHazeToggle";
        /// <summary>
        /// Cached name for the 'lightningToggle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @lightningToggle = "lightningToggle";
        /// <summary>
        /// Cached name for the 'menuHeadingLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuHeadingLabel = "menuHeadingLabel";
        /// <summary>
        /// Cached name for the 'menuCloseButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuCloseButton = "menuCloseButton";
        /// <summary>
        /// Cached name for the 'menuResumeButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuResumeButton = "menuResumeButton";
        /// <summary>
        /// Cached name for the 'quitGameButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quitGameButton = "quitGameButton";
        /// <summary>
        /// Cached name for the 'quitGameConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quitGameConfirmation = "quitGameConfirmation";
        /// <summary>
        /// Cached name for the 'fullscreenToggle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @fullscreenToggle = "fullscreenToggle";
        /// <summary>
        /// Cached name for the 'windowSizeChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @windowSizeChoice = "windowSizeChoice";
        /// <summary>
        /// Cached name for the 'clockFormatChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @clockFormatChoice = "clockFormatChoice";
        /// <summary>
        /// Cached name for the 'dateFormatChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @dateFormatChoice = "dateFormatChoice";
        /// <summary>
        /// Cached name for the 'agingOverrideChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agingOverrideChoice = "agingOverrideChoice";
        /// <summary>
        /// Cached name for the 'routineHelperChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @routineHelperChoice = "routineHelperChoice";
        /// <summary>
        /// Cached name for the 'routineHelperModelPicker' field.
        /// </summary>
        public new static readonly global::Godot.StringName @routineHelperModelPicker = "routineHelperModelPicker";
        /// <summary>
        /// Cached name for the 'routineHelperKeyChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @routineHelperKeyChoice = "routineHelperKeyChoice";
        /// <summary>
        /// Cached name for the 'applyRoutineHelperButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @applyRoutineHelperButton = "applyRoutineHelperButton";
        /// <summary>
        /// Cached name for the 'observedRoutineHelperContext' field.
        /// </summary>
        public new static readonly global::Godot.StringName @observedRoutineHelperContext = "observedRoutineHelperContext";
        /// <summary>
        /// Cached name for the 'applyAgingOverrideButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @applyAgingOverrideButton = "applyAgingOverrideButton";
        /// <summary>
        /// Cached name for the 'lastAgingOverrideWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @lastAgingOverrideWorldId = "lastAgingOverrideWorldId";
        /// <summary>
        /// Cached name for the 'pauseButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pauseButton = "pauseButton";
        /// <summary>
        /// Cached name for the 'instructionText' field.
        /// </summary>
        public new static readonly global::Godot.StringName @instructionText = "instructionText";
        /// <summary>
        /// Cached name for the 'submitInstructionButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @submitInstructionButton = "submitInstructionButton";
        /// <summary>
        /// Cached name for the 'pendingSubmissionLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingSubmissionLabel = "pendingSubmissionLabel";
        /// <summary>
        /// Cached name for the 'retryPendingSubmissionButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @retryPendingSubmissionButton = "retryPendingSubmissionButton";
        /// <summary>
        /// Cached name for the 'forgetPendingSubmissionButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @forgetPendingSubmissionButton = "forgetPendingSubmissionButton";
        /// <summary>
        /// Cached name for the 'worldEditKind' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditKind = "worldEditKind";
        /// <summary>
        /// Cached name for the 'worldEditId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditId = "worldEditId";
        /// <summary>
        /// Cached name for the 'worldEditValue' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditValue = "worldEditValue";
        /// <summary>
        /// Cached name for the 'worldEditSecondaryValue' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditSecondaryValue = "worldEditSecondaryValue";
        /// <summary>
        /// Cached name for the 'worldEditX' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditX = "worldEditX";
        /// <summary>
        /// Cached name for the 'worldEditY' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditY = "worldEditY";
        /// <summary>
        /// Cached name for the 'worldEditRenewable' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditRenewable = "worldEditRenewable";
        /// <summary>
        /// Cached name for the 'submitWorldEditButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @submitWorldEditButton = "submitWorldEditButton";
        /// <summary>
        /// Cached name for the 'worldEditHintLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditHintLabel = "worldEditHintLabel";
        /// <summary>
        /// Cached name for the 'pairingApprovalId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pairingApprovalId = "pairingApprovalId";
        /// <summary>
        /// Cached name for the 'pairingApprovalCode' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pairingApprovalCode = "pairingApprovalCode";
        /// <summary>
        /// Cached name for the 'approvePairingButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @approvePairingButton = "approvePairingButton";
        /// <summary>
        /// Cached name for the 'refreshDevicesButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @refreshDevicesButton = "refreshDevicesButton";
        /// <summary>
        /// Cached name for the 'pairedDeviceList' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pairedDeviceList = "pairedDeviceList";
        /// <summary>
        /// Cached name for the 'revokeDeviceId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @revokeDeviceId = "revokeDeviceId";
        /// <summary>
        /// Cached name for the 'revokeDeviceButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @revokeDeviceButton = "revokeDeviceButton";
        /// <summary>
        /// Cached name for the 'usagePauseWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @usagePauseWorldId = "usagePauseWorldId";
        /// <summary>
        /// Cached name for the 'wasObservedPaused' field.
        /// </summary>
        public new static readonly global::Godot.StringName @wasObservedPaused = "wasObservedPaused";
        /// <summary>
        /// Cached name for the 'selectedAgentId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selectedAgentId = "selectedAgentId";
        /// <summary>
        /// Cached name for the 'renamingAgentId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renamingAgentId = "renamingAgentId";
        /// <summary>
        /// Cached name for the 'isRefreshing' field.
        /// </summary>
        public new static readonly global::Godot.StringName @isRefreshing = "isRefreshing";
        /// <summary>
        /// Cached name for the 'successfulRefreshCount' field.
        /// </summary>
        public new static readonly global::Godot.StringName @successfulRefreshCount = "successfulRefreshCount";
        /// <summary>
        /// Cached name for the 'isOwnerAction' field.
        /// </summary>
        public new static readonly global::Godot.StringName @isOwnerAction = "isOwnerAction";
        /// <summary>
        /// Cached name for the 'registeredEndpointInvalid' field.
        /// </summary>
        public new static readonly global::Godot.StringName @registeredEndpointInvalid = "registeredEndpointInvalid";
        /// <summary>
        /// Cached name for the 'menuPausedWorld' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuPausedWorld = "menuPausedWorld";
        /// <summary>
        /// Cached name for the 'menuPauseConfirmed' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuPauseConfirmed = "menuPauseConfirmed";
        /// <summary>
        /// Cached name for the 'pendingMenuResumes' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingMenuResumes = "pendingMenuResumes";
        /// <summary>
        /// Cached name for the 'pendingMenuResumeGeneration' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingMenuResumeGeneration = "pendingMenuResumeGeneration";
        /// <summary>
        /// Cached name for the 'currentTileSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @currentTileSize = "currentTileSize";
        /// <summary>
        /// Cached name for the 'cameraZoom' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraZoom = "cameraZoom";
        /// <summary>
        /// Cached name for the 'minimumCameraZoom' field.
        /// </summary>
        public new static readonly global::Godot.StringName @minimumCameraZoom = "minimumCameraZoom";
        /// <summary>
        /// Cached name for the 'maximumCameraZoom' field.
        /// </summary>
        public new static readonly global::Godot.StringName @maximumCameraZoom = "maximumCameraZoom";
        /// <summary>
        /// Cached name for the 'cameraCenterTiles' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraCenterTiles = "cameraCenterTiles";
        /// <summary>
        /// Cached name for the 'cameraWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cameraWorldId = "cameraWorldId";
        /// <summary>
        /// Cached name for the 'draggingMap' field.
        /// </summary>
        public new static readonly global::Godot.StringName @draggingMap = "draggingMap";
        /// <summary>
        /// Cached name for the 'renderedEventLog' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedEventLog = "renderedEventLog";
        /// <summary>
        /// Cached name for the 'statusToastKind' field.
        /// </summary>
        public new static readonly global::Godot.StringName @statusToastKind = "statusToastKind";
        /// <summary>
        /// Cached name for the 'statusToastShownAtMsec' field.
        /// </summary>
        public new static readonly global::Godot.StringName @statusToastShownAtMsec = "statusToastShownAtMsec";
        /// <summary>
        /// Cached name for the 'developerEditAgent' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerEditAgent = "developerEditAgent";
        /// <summary>
        /// Cached name for the 'developerEditHint' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerEditHint = "developerEditHint";
        /// <summary>
        /// Cached name for the 'developerEditKind' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerEditKind = "developerEditKind";
        /// <summary>
        /// Cached name for the 'developerEditValue' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerEditValue = "developerEditValue";
        /// <summary>
        /// Cached name for the 'developerEditOther' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerEditOther = "developerEditOther";
        /// <summary>
        /// Cached name for the 'developerEditAmount' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerEditAmount = "developerEditAmount";
        /// <summary>
        /// Cached name for the 'developerEditApply' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerEditApply = "developerEditApply";
        /// <summary>
        /// Cached name for the 'developerEditPeopleKey' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerEditPeopleKey = "developerEditPeopleKey";
        /// <summary>
        /// Cached name for the 'developerPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerPanel = "developerPanel";
        /// <summary>
        /// Cached name for the 'developerScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerScroll = "developerScroll";
        /// <summary>
        /// Cached name for the 'developerBody' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerBody = "developerBody";
        /// <summary>
        /// Cached name for the 'developerTileLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerTileLabel = "developerTileLabel";
        /// <summary>
        /// Cached name for the 'developerFrameLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerFrameLabel = "developerFrameLabel";
        /// <summary>
        /// Cached name for the 'developerTickLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerTickLabel = "developerTickLabel";
        /// <summary>
        /// Cached name for the 'developerRefusedActionLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerRefusedActionLabel = "developerRefusedActionLabel";
        /// <summary>
        /// Cached name for the 'developerAgentCountLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerAgentCountLabel = "developerAgentCountLabel";
        /// <summary>
        /// Cached name for the 'developerAgentList' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerAgentList = "developerAgentList";
        /// <summary>
        /// Cached name for the 'developerPathToggle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerPathToggle = "developerPathToggle";
        /// <summary>
        /// Cached name for the 'developerRouteLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerRouteLabel = "developerRouteLabel";
        /// <summary>
        /// Cached name for the 'plannedPathLayer' field.
        /// </summary>
        public new static readonly global::Godot.StringName @plannedPathLayer = "plannedPathLayer";
        /// <summary>
        /// Cached name for the 'developerFrameMilliseconds' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerFrameMilliseconds = "developerFrameMilliseconds";
        /// <summary>
        /// Cached name for the 'developerReadoutAge' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerReadoutAge = "developerReadoutAge";
        /// <summary>
        /// Cached name for the 'developerAgentListKey' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerAgentListKey = "developerAgentListKey";
        /// <summary>
        /// Cached name for the 'eventRows' field.
        /// </summary>
        public new static readonly global::Godot.StringName @eventRows = "eventRows";
        /// <summary>
        /// Cached name for the 'eventScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @eventScroll = "eventScroll";
        /// <summary>
        /// Cached name for the 'familyLegend' field.
        /// </summary>
        public new static readonly global::Godot.StringName @familyLegend = "familyLegend";
        /// <summary>
        /// Cached name for the 'filtersButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @filtersButton = "filtersButton";
        /// <summary>
        /// Cached name for the 'filtersPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @filtersPanel = "filtersPanel";
        /// <summary>
        /// Cached name for the 'townBorderFilter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @townBorderFilter = "townBorderFilter";
        /// <summary>
        /// Cached name for the 'householdPropertyFilter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @householdPropertyFilter = "householdPropertyFilter";
        /// <summary>
        /// Cached name for the 'townLandTitleFilter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @townLandTitleFilter = "townLandTitleFilter";
        /// <summary>
        /// Cached name for the 'householdLandUseFilter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @householdLandUseFilter = "householdLandUseFilter";
        /// <summary>
        /// Cached name for the 'disputedLandFilter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @disputedLandFilter = "disputedLandFilter";
        /// <summary>
        /// Cached name for the 'founderSetupButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderSetupButton = "founderSetupButton";
        /// <summary>
        /// Cached name for the 'townSiteButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @townSiteButton = "townSiteButton";
        /// <summary>
        /// Cached name for the 'moveFounderButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @moveFounderButton = "moveFounderButton";
        /// <summary>
        /// Cached name for the 'undoFounderButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @undoFounderButton = "undoFounderButton";
        /// <summary>
        /// Cached name for the 'addAgentButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @addAgentButton = "addAgentButton";
        /// <summary>
        /// Cached name for the 'startWorldButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startWorldButton = "startWorldButton";
        /// <summary>
        /// Cached name for the 'founderSetupPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderSetupPanel = "founderSetupPanel";
        /// <summary>
        /// Cached name for the 'founderSetupHint' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderSetupHint = "founderSetupHint";
        /// <summary>
        /// Cached name for the 'founderPlacementIcon' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderPlacementIcon = "founderPlacementIcon";
        /// <summary>
        /// Cached name for the 'founderProviderChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderProviderChoice = "founderProviderChoice";
        /// <summary>
        /// Cached name for the 'founderCredentialChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderCredentialChoice = "founderCredentialChoice";
        /// <summary>
        /// Cached name for the 'founderModelPicker' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderModelPicker = "founderModelPicker";
        /// <summary>
        /// Cached name for the 'founderThinkingChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderThinkingChoice = "founderThinkingChoice";
        /// <summary>
        /// Cached name for the 'founderKeyLabelInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderKeyLabelInput = "founderKeyLabelInput";
        /// <summary>
        /// Cached name for the 'founderApiKeyInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderApiKeyInput = "founderApiKeyInput";
        /// <summary>
        /// Cached name for the 'placingAddedAgent' field.
        /// </summary>
        public new static readonly global::Godot.StringName @placingAddedAgent = "placingAddedAgent";
        /// <summary>
        /// Cached name for the 'choosingFirstTownSite' field.
        /// </summary>
        public new static readonly global::Godot.StringName @choosingFirstTownSite = "choosingFirstTownSite";
        /// <summary>
        /// Cached name for the 'movingFounderId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @movingFounderId = "movingFounderId";
        /// <summary>
        /// Cached name for the 'generationSettingsRows' field.
        /// </summary>
        public new static readonly global::Godot.StringName @generationSettingsRows = "generationSettingsRows";
        /// <summary>
        /// Cached name for the 'generationSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @generationSize = "generationSize";
        /// <summary>
        /// Cached name for the 'generationClimate' field.
        /// </summary>
        public new static readonly global::Godot.StringName @generationClimate = "generationClimate";
        /// <summary>
        /// Cached name for the 'generationWrapping' field.
        /// </summary>
        public new static readonly global::Godot.StringName @generationWrapping = "generationWrapping";
        /// <summary>
        /// Cached name for the 'generationSeed' field.
        /// </summary>
        public new static readonly global::Godot.StringName @generationSeed = "generationSeed";
        /// <summary>
        /// Cached name for the 'generationSettingsHint' field.
        /// </summary>
        public new static readonly global::Godot.StringName @generationSettingsHint = "generationSettingsHint";
        /// <summary>
        /// Cached name for the 'hudBar' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hudBar = "hudBar";
        /// <summary>
        /// Cached name for the 'hudRows' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hudRows = "hudRows";
        /// <summary>
        /// Cached name for the 'hudLeft' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hudLeft = "hudLeft";
        /// <summary>
        /// Cached name for the 'hudTime' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hudTime = "hudTime";
        /// <summary>
        /// Cached name for the 'hudRight' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hudRight = "hudRight";
        /// <summary>
        /// Cached name for the 'founderHudRow' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderHudRow = "founderHudRow";
        /// <summary>
        /// Cached name for the 'hudFounders' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hudFounders = "hudFounders";
        /// <summary>
        /// Cached name for the 'climateBox' field.
        /// </summary>
        public new static readonly global::Godot.StringName @climateBox = "climateBox";
        /// <summary>
        /// Cached name for the 'seasonIcon' field.
        /// </summary>
        public new static readonly global::Godot.StringName @seasonIcon = "seasonIcon";
        /// <summary>
        /// Cached name for the 'seasonLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @seasonLabel = "seasonLabel";
        /// <summary>
        /// Cached name for the 'weatherIcon' field.
        /// </summary>
        public new static readonly global::Godot.StringName @weatherIcon = "weatherIcon";
        /// <summary>
        /// Cached name for the 'weatherLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @weatherLabel = "weatherLabel";
        /// <summary>
        /// Cached name for the 'eventLogBadge' field.
        /// </summary>
        public new static readonly global::Godot.StringName @eventLogBadge = "eventLogBadge";
        /// <summary>
        /// Cached name for the 'agentsWarning' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentsWarning = "agentsWarning";
        /// <summary>
        /// Cached name for the 'worldInfoTownsTab' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldInfoTownsTab = "worldInfoTownsTab";
        /// <summary>
        /// Cached name for the 'worldInfoWorldTab' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldInfoWorldTab = "worldInfoWorldTab";
        /// <summary>
        /// Cached name for the 'townsScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @townsScroll = "townsScroll";
        /// <summary>
        /// Cached name for the 'townsPage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @townsPage = "townsPage";
        /// <summary>
        /// Cached name for the 'townList' field.
        /// </summary>
        public new static readonly global::Godot.StringName @townList = "townList";
        /// <summary>
        /// Cached name for the 'renderedTownList' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedTownList = "renderedTownList";
        /// <summary>
        /// Cached name for the 'eventLogWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @eventLogWorldId = "eventLogWorldId";
        /// <summary>
        /// Cached name for the 'lastSeenEventId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @lastSeenEventId = "lastSeenEventId";
        /// <summary>
        /// Cached name for the 'newEventsAfter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @newEventsAfter = "newEventsAfter";
        /// <summary>
        /// Cached name for the 'unreadEvents' field.
        /// </summary>
        public new static readonly global::Godot.StringName @unreadEvents = "unreadEvents";
        /// <summary>
        /// Cached name for the 'keyboardNavigation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @keyboardNavigation = "keyboardNavigation";
        /// <summary>
        /// Cached name for the 'keyboardNavigationKey' field.
        /// </summary>
        public new static readonly global::Godot.StringName @keyboardNavigationKey = "keyboardNavigationKey";
        /// <summary>
        /// Cached name for the 'refreshingKeyboardMapSelection' field.
        /// </summary>
        public new static readonly global::Godot.StringName @refreshingKeyboardMapSelection = "refreshingKeyboardMapSelection";
        /// <summary>
        /// Cached name for the 'quitToLauncherButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quitToLauncherButton = "quitToLauncherButton";
        /// <summary>
        /// Cached name for the 'quitToLauncherConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quitToLauncherConfirmation = "quitToLauncherConfirmation";
        /// <summary>
        /// Cached name for the 'launcherStartFailure' field.
        /// </summary>
        public new static readonly global::Godot.StringName @launcherStartFailure = "launcherStartFailure";
        /// <summary>
        /// Cached name for the 'openInVersionConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @openInVersionConfirmation = "openInVersionConfirmation";
        /// <summary>
        /// Cached name for the 'pendingOpenVersion' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingOpenVersion = "pendingOpenVersion";
        /// <summary>
        /// Cached name for the 'pendingOpenWorld' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingOpenWorld = "pendingOpenWorld";
        /// <summary>
        /// Cached name for the 'failedLauncherVersion' field.
        /// </summary>
        public new static readonly global::Godot.StringName @failedLauncherVersion = "failedLauncherVersion";
        /// <summary>
        /// Cached name for the 'failedLauncherWorld' field.
        /// </summary>
        public new static readonly global::Godot.StringName @failedLauncherWorld = "failedLauncherWorld";
        /// <summary>
        /// Cached name for the 'requestedWorldToSelect' field.
        /// </summary>
        public new static readonly global::Godot.StringName @requestedWorldToSelect = "requestedWorldToSelect";
        /// <summary>
        /// Cached name for the 'launcherPath' field.
        /// </summary>
        public new static readonly global::Godot.StringName @launcherPath = "launcherPath";
        /// <summary>
        /// Cached name for the 'launcherPathRead' field.
        /// </summary>
        public new static readonly global::Godot.StringName @launcherPathRead = "launcherPathRead";
        /// <summary>
        /// Cached name for the 'localServerStarting' field.
        /// </summary>
        public new static readonly global::Godot.StringName @localServerStarting = "localServerStarting";
        /// <summary>
        /// Cached name for the 'localServerFailure' field.
        /// </summary>
        public new static readonly global::Godot.StringName @localServerFailure = "localServerFailure";
        /// <summary>
        /// Cached name for the 'localServerStopFailure' field.
        /// </summary>
        public new static readonly global::Godot.StringName @localServerStopFailure = "localServerStopFailure";
        /// <summary>
        /// Cached name for the 'isQuittingGame' field.
        /// </summary>
        public new static readonly global::Godot.StringName @isQuittingGame = "isQuittingGame";
        /// <summary>
        /// Cached name for the 'retryLauncherVersion' field.
        /// </summary>
        public new static readonly global::Godot.StringName @retryLauncherVersion = "retryLauncherVersion";
        /// <summary>
        /// Cached name for the 'retryLauncherWorld' field.
        /// </summary>
        public new static readonly global::Godot.StringName @retryLauncherWorld = "retryLauncherWorld";
        /// <summary>
        /// Cached name for the 'retryChooseCurrentWorld' field.
        /// </summary>
        public new static readonly global::Godot.StringName @retryChooseCurrentWorld = "retryChooseCurrentWorld";
        /// <summary>
        /// Cached name for the 'mainMenuNavigationRevision' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuNavigationRevision = "mainMenuNavigationRevision";
        /// <summary>
        /// Cached name for the 'mainMenuOverlay' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuOverlay = "mainMenuOverlay";
        /// <summary>
        /// Cached name for the 'mainMenuBackground' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuBackground = "mainMenuBackground";
        /// <summary>
        /// Cached name for the 'mainMenuBackdrop' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuBackdrop = "mainMenuBackdrop";
        /// <summary>
        /// Cached name for the 'mainMenuStack' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuStack = "mainMenuStack";
        /// <summary>
        /// Cached name for the 'mainMenuLogo' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuLogo = "mainMenuLogo";
        /// <summary>
        /// Cached name for the 'mainMenuCenter' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuCenter = "mainMenuCenter";
        /// <summary>
        /// Cached name for the 'mainMenuCard' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuCard = "mainMenuCard";
        /// <summary>
        /// Cached name for the 'mainMenuStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuStatus = "mainMenuStatus";
        /// <summary>
        /// Cached name for the 'mainMenuContinueButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuContinueButton = "mainMenuContinueButton";
        /// <summary>
        /// Cached name for the 'mainMenuNewButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuNewButton = "mainMenuNewButton";
        /// <summary>
        /// Cached name for the 'mainMenuLoadButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuLoadButton = "mainMenuLoadButton";
        /// <summary>
        /// Cached name for the 'menuQuitToMainButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuQuitToMainButton = "menuQuitToMainButton";
        /// <summary>
        /// Cached name for the 'menuSaveWorldButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuSaveWorldButton = "menuSaveWorldButton";
        /// <summary>
        /// Cached name for the 'worldMenuOverlay' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMenuOverlay = "worldMenuOverlay";
        /// <summary>
        /// Cached name for the 'worldMenuCard' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMenuCard = "worldMenuCard";
        /// <summary>
        /// Cached name for the 'worldMenuScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMenuScroll = "worldMenuScroll";
        /// <summary>
        /// Cached name for the 'worldMenuBody' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMenuBody = "worldMenuBody";
        /// <summary>
        /// Cached name for the 'worldMenuColumns' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMenuColumns = "worldMenuColumns";
        /// <summary>
        /// Cached name for the 'worldPreviewFrame' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldPreviewFrame = "worldPreviewFrame";
        /// <summary>
        /// Cached name for the 'worldMenuHeading' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMenuHeading = "worldMenuHeading";
        /// <summary>
        /// Cached name for the 'worldMenuStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMenuStatus = "worldMenuStatus";
        /// <summary>
        /// Cached name for the 'worldNameInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldNameInput = "worldNameInput";
        /// <summary>
        /// Cached name for the 'worldSeedInput' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldSeedInput = "worldSeedInput";
        /// <summary>
        /// Cached name for the 'worldSizeChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldSizeChoice = "worldSizeChoice";
        /// <summary>
        /// Cached name for the 'worldWaterSlider' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldWaterSlider = "worldWaterSlider";
        /// <summary>
        /// Cached name for the 'worldWaterValue' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldWaterValue = "worldWaterValue";
        /// <summary>
        /// Cached name for the 'worldForestChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldForestChoice = "worldForestChoice";
        /// <summary>
        /// Cached name for the 'worldMountainChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMountainChoice = "worldMountainChoice";
        /// <summary>
        /// Cached name for the 'worldRiverChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldRiverChoice = "worldRiverChoice";
        /// <summary>
        /// Cached name for the 'worldAdvancedOptions' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldAdvancedOptions = "worldAdvancedOptions";
        /// <summary>
        /// Cached name for the 'worldAdvancedToggle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldAdvancedToggle = "worldAdvancedToggle";
        /// <summary>
        /// Cached name for the 'worldResourceChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldResourceChoice = "worldResourceChoice";
        /// <summary>
        /// Cached name for the 'worldClimateModeChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldClimateModeChoice = "worldClimateModeChoice";
        /// <summary>
        /// Cached name for the 'worldClimateFamilyChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldClimateFamilyChoice = "worldClimateFamilyChoice";
        /// <summary>
        /// Cached name for the 'worldWrapChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldWrapChoice = "worldWrapChoice";
        /// <summary>
        /// Cached name for the 'worldLatitudeChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldLatitudeChoice = "worldLatitudeChoice";
        /// <summary>
        /// Cached name for the 'worldPreview' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldPreview = "worldPreview";
        /// <summary>
        /// Cached name for the 'worldPreviewStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldPreviewStatus = "worldPreviewStatus";
        /// <summary>
        /// Cached name for the 'worldAcceptUnmetTargets' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldAcceptUnmetTargets = "worldAcceptUnmetTargets";
        /// <summary>
        /// Cached name for the 'worldPreviewButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldPreviewButton = "worldPreviewButton";
        /// <summary>
        /// Cached name for the 'worldSelectionList' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldSelectionList = "worldSelectionList";
        /// <summary>
        /// Cached name for the 'worldCreateButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldCreateButton = "worldCreateButton";
        /// <summary>
        /// Cached name for the 'worldSelectButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldSelectButton = "worldSelectButton";
        /// <summary>
        /// Cached name for the 'menuLoadSaveButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuLoadSaveButton = "menuLoadSaveButton";
        /// <summary>
        /// Cached name for the 'worldSaveHistoryHost' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldSaveHistoryHost = "worldSaveHistoryHost";
        /// <summary>
        /// Cached name for the 'worldLoadColumns' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldLoadColumns = "worldLoadColumns";
        /// <summary>
        /// Cached name for the 'worldMenuActions' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMenuActions = "worldMenuActions";
        /// <summary>
        /// Cached name for the 'worldDeleteButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldDeleteButton = "worldDeleteButton";
        /// <summary>
        /// Cached name for the 'listedActiveWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @listedActiveWorldId = "listedActiveWorldId";
        /// <summary>
        /// Cached name for the 'worldMenuBusy' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldMenuBusy = "worldMenuBusy";
        /// <summary>
        /// Cached name for the 'worldPreviewRevision' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldPreviewRevision = "worldPreviewRevision";
        /// <summary>
        /// Cached name for the 'quitToMenuConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @quitToMenuConfirmation = "quitToMenuConfirmation";
        /// <summary>
        /// Cached name for the 'isInWorld' field.
        /// </summary>
        public new static readonly global::Godot.StringName @isInWorld = "isInWorld";
        /// <summary>
        /// Cached name for the 'returnToMainMenu' field.
        /// </summary>
        public new static readonly global::Godot.StringName @returnToMainMenu = "returnToMainMenu";
        /// <summary>
        /// Cached name for the 'resumeWorldOnContinue' field.
        /// </summary>
        public new static readonly global::Godot.StringName @resumeWorldOnContinue = "resumeWorldOnContinue";
        /// <summary>
        /// Cached name for the 'mainMenuSettingsButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mainMenuSettingsButton = "mainMenuSettingsButton";
        /// <summary>
        /// Cached name for the 'worldBackButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldBackButton = "worldBackButton";
        /// <summary>
        /// Cached name for the 'menuQuitSeparator' field.
        /// </summary>
        public new static readonly global::Godot.StringName @menuQuitSeparator = "menuQuitSeparator";
        /// <summary>
        /// Cached name for the 'isQuittingToMenu' field.
        /// </summary>
        public new static readonly global::Godot.StringName @isQuittingToMenu = "isQuittingToMenu";
        /// <summary>
        /// Cached name for the 'hoverReadout' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hoverReadout = "hoverReadout";
        /// <summary>
        /// Cached name for the 'hoverReadoutLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hoverReadoutLabel = "hoverReadoutLabel";
        /// <summary>
        /// Cached name for the 'hoverReadoutSwatch' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hoverReadoutSwatch = "hoverReadoutSwatch";
        /// <summary>
        /// Cached name for the 'hoverReadoutTownSiteMode' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hoverReadoutTownSiteMode = "hoverReadoutTownSiteMode";
        /// <summary>
        /// Cached name for the 'memoryTabs' field.
        /// </summary>
        public new static readonly global::Godot.StringName @memoryTabs = "memoryTabs";
        /// <summary>
        /// Cached name for the 'memoryCards' field.
        /// </summary>
        public new static readonly global::Godot.StringName @memoryCards = "memoryCards";
        /// <summary>
        /// Cached name for the 'memoryScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @memoryScroll = "memoryScroll";
        /// <summary>
        /// Cached name for the 'memoryGap' field.
        /// </summary>
        public new static readonly global::Godot.StringName @memoryGap = "memoryGap";
        /// <summary>
        /// Cached name for the 'renderedMemoryCards' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedMemoryCards = "renderedMemoryCards";
        /// <summary>
        /// Cached name for the 'usageScopeHint' field.
        /// </summary>
        public new static readonly global::Godot.StringName @usageScopeHint = "usageScopeHint";
        /// <summary>
        /// Cached name for the 'usageReads' field.
        /// </summary>
        public new static readonly global::Godot.StringName @usageReads = "usageReads";
        /// <summary>
        /// Cached name for the 'usageLimitEdited' field.
        /// </summary>
        public new static readonly global::Godot.StringName @usageLimitEdited = "usageLimitEdited";
        /// <summary>
        /// Cached name for the 'routineHelperSetupCheckButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @routineHelperSetupCheckButton = "routineHelperSetupCheckButton";
        /// <summary>
        /// Cached name for the 'routineHelperSetupCheckStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @routineHelperSetupCheckStatus = "routineHelperSetupCheckStatus";
        /// <summary>
        /// Cached name for the 'routineHelperSetupCheckRevision' field.
        /// </summary>
        public new static readonly global::Godot.StringName @routineHelperSetupCheckRevision = "routineHelperSetupCheckRevision";
        /// <summary>
        /// Cached name for the 'founderKeyEdits' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderKeyEdits = "founderKeyEdits";
        /// <summary>
        /// Cached name for the 'agentModelKeyEdits' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelKeyEdits = "agentModelKeyEdits";
        /// <summary>
        /// Cached name for the 'agentModelContext' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelContext = "agentModelContext";
        /// <summary>
        /// Cached name for the 'agentModelLookup' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelLookup = "agentModelLookup";
        /// <summary>
        /// Cached name for the 'modLibraryPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @modLibraryPanel = "modLibraryPanel";
        /// <summary>
        /// Cached name for the 'modLibraryCards' field.
        /// </summary>
        public new static readonly global::Godot.StringName @modLibraryCards = "modLibraryCards";
        /// <summary>
        /// Cached name for the 'allOrdersButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @allOrdersButton = "allOrdersButton";
        /// <summary>
        /// Cached name for the 'ordersPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @ordersPanel = "ordersPanel";
        /// <summary>
        /// Cached name for the 'ordersReaderTitle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @ordersReaderTitle = "ordersReaderTitle";
        /// <summary>
        /// Cached name for the 'ordersReaderText' field.
        /// </summary>
        public new static readonly global::Godot.StringName @ordersReaderText = "ordersReaderText";
        /// <summary>
        /// Cached name for the 'renderedOrdersReader' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedOrdersReader = "renderedOrdersReader";
        /// <summary>
        /// Cached name for the 'pendingSubmissionPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingSubmissionPanel = "pendingSubmissionPanel";
        /// <summary>
        /// Cached name for the 'reviewPendingSubmissionButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @reviewPendingSubmissionButton = "reviewPendingSubmissionButton";
        /// <summary>
        /// Cached name for the 'pendingRecoveryInProgress' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingRecoveryInProgress = "pendingRecoveryInProgress";
        /// <summary>
        /// Cached name for the 'unloadedPendingSubmission' field.
        /// </summary>
        public new static readonly global::Godot.StringName @unloadedPendingSubmission = "unloadedPendingSubmission";
        /// <summary>
        /// Cached name for the 'statusIcon' field.
        /// </summary>
        public new static readonly global::Godot.StringName @statusIcon = "statusIcon";
        /// <summary>
        /// Cached name for the 'profilePeople' field.
        /// </summary>
        public new static readonly global::Godot.StringName @profilePeople = "profilePeople";
        /// <summary>
        /// Cached name for the 'renderedProfilePeople' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedProfilePeople = "renderedProfilePeople";
        /// <summary>
        /// Cached name for the 'founderModelSetupCheckButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderModelSetupCheckButton = "founderModelSetupCheckButton";
        /// <summary>
        /// Cached name for the 'founderModelSetupCheckStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderModelSetupCheckStatus = "founderModelSetupCheckStatus";
        /// <summary>
        /// Cached name for the 'agentModelSetupCheckButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelSetupCheckButton = "agentModelSetupCheckButton";
        /// <summary>
        /// Cached name for the 'agentModelSetupCheckStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelSetupCheckStatus = "agentModelSetupCheckStatus";
        /// <summary>
        /// Cached name for the 'agentModelSetupCheckContext' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelSetupCheckContext = "agentModelSetupCheckContext";
        /// <summary>
        /// Cached name for the 'founderModelSetupCheckRevision' field.
        /// </summary>
        public new static readonly global::Godot.StringName @founderModelSetupCheckRevision = "founderModelSetupCheckRevision";
        /// <summary>
        /// Cached name for the 'agentModelSetupCheckRevision' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentModelSetupCheckRevision = "agentModelSetupCheckRevision";
        /// <summary>
        /// Cached name for the 'recoveryCleanupButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @recoveryCleanupButton = "recoveryCleanupButton";
        /// <summary>
        /// Cached name for the 'recoveryKeepCount' field.
        /// </summary>
        public new static readonly global::Godot.StringName @recoveryKeepCount = "recoveryKeepCount";
        /// <summary>
        /// Cached name for the 'recoveryCleanupConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @recoveryCleanupConfirmation = "recoveryCleanupConfirmation";
        /// <summary>
        /// Cached name for the 'recoveryCleanupSummary' field.
        /// </summary>
        public new static readonly global::Godot.StringName @recoveryCleanupSummary = "recoveryCleanupSummary";
        /// <summary>
        /// Cached name for the 'agentListWantedHeight' field.
        /// </summary>
        public new static readonly global::Godot.StringName @agentListWantedHeight = "agentListWantedHeight";
        /// <summary>
        /// Cached name for the 'eventLogWantedHeight' field.
        /// </summary>
        public new static readonly global::Godot.StringName @eventLogWantedHeight = "eventLogWantedHeight";
        /// <summary>
        /// Cached name for the 'hudListsRefitQueued' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hudListsRefitQueued = "hudListsRefitQueued";
        /// <summary>
        /// Cached name for the 'saveDiskWarningPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @saveDiskWarningPanel = "saveDiskWarningPanel";
        /// <summary>
        /// Cached name for the 'saveDiskWarningLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @saveDiskWarningLabel = "saveDiskWarningLabel";
        /// <summary>
        /// Cached name for the 'manualSaveDiskWarning' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveDiskWarning = "manualSaveDiskWarning";
        /// <summary>
        /// Cached name for the 'lastDiskSpaceReadMsec' field.
        /// </summary>
        public new static readonly global::Godot.StringName @lastDiskSpaceReadMsec = "lastDiskSpaceReadMsec";
        /// <summary>
        /// Cached name for the 'diskSpaceReadPending' field.
        /// </summary>
        public new static readonly global::Godot.StringName @diskSpaceReadPending = "diskSpaceReadPending";
        /// <summary>
        /// Cached name for the 'manualSaveOverlay' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveOverlay = "manualSaveOverlay";
        /// <summary>
        /// Cached name for the 'manualSaveCard' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveCard = "manualSaveCard";
        /// <summary>
        /// Cached name for the 'manualSaveHeading' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveHeading = "manualSaveHeading";
        /// <summary>
        /// Cached name for the 'manualSaveStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveStatus = "manualSaveStatus";
        /// <summary>
        /// Cached name for the 'manualSaveName' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveName = "manualSaveName";
        /// <summary>
        /// Cached name for the 'manualSaveCreateButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveCreateButton = "manualSaveCreateButton";
        /// <summary>
        /// Cached name for the 'manualSaveBackButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveBackButton = "manualSaveBackButton";
        /// <summary>
        /// Cached name for the 'manualSaveList' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveList = "manualSaveList";
        /// <summary>
        /// Cached name for the 'manualSaveHistory' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveHistory = "manualSaveHistory";
        /// <summary>
        /// Cached name for the 'manualSaveActions' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveActions = "manualSaveActions";
        /// <summary>
        /// Cached name for the 'manualSaveBody' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveBody = "manualSaveBody";
        /// <summary>
        /// Cached name for the 'worldHistoryLoading' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldHistoryLoading = "worldHistoryLoading";
        /// <summary>
        /// Cached name for the 'worldHistoryLoaded' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldHistoryLoaded = "worldHistoryLoaded";
        /// <summary>
        /// Cached name for the 'manualSaveNewBox' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveNewBox = "manualSaveNewBox";
        /// <summary>
        /// Cached name for the 'manualSaveLoadButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveLoadButton = "manualSaveLoadButton";
        /// <summary>
        /// Cached name for the 'manualSaveOverwriteButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveOverwriteButton = "manualSaveOverwriteButton";
        /// <summary>
        /// Cached name for the 'manualSaveLoadConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveLoadConfirmation = "manualSaveLoadConfirmation";
        /// <summary>
        /// Cached name for the 'manualSaveOverwriteConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveOverwriteConfirmation = "manualSaveOverwriteConfirmation";
        /// <summary>
        /// Cached name for the 'worldModelLoadConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldModelLoadConfirmation = "worldModelLoadConfirmation";
        /// <summary>
        /// Cached name for the 'manualSaveDeleteButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveDeleteButton = "manualSaveDeleteButton";
        /// <summary>
        /// Cached name for the 'deletionConfirmation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @deletionConfirmation = "deletionConfirmation";
        /// <summary>
        /// Cached name for the 'listedSaveWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @listedSaveWorldId = "listedSaveWorldId";
        /// <summary>
        /// Cached name for the 'pendingOverwriteSaveId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingOverwriteSaveId = "pendingOverwriteSaveId";
        /// <summary>
        /// Cached name for the 'manualSaveLoadMode' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveLoadMode = "manualSaveLoadMode";
        /// <summary>
        /// Cached name for the 'manualSaveTimeline' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveTimeline = "manualSaveTimeline";
        /// <summary>
        /// Cached name for the 'manualSaveViewRow' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveViewRow = "manualSaveViewRow";
        /// <summary>
        /// Cached name for the 'manualSaveKey' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveKey = "manualSaveKey";
        /// <summary>
        /// Cached name for the 'manualSaveViewLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveViewLabel = "manualSaveViewLabel";
        /// <summary>
        /// Cached name for the 'manualSaveViewChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveViewChoice = "manualSaveViewChoice";
        /// <summary>
        /// Cached name for the 'manualSaveSectionLabel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveSectionLabel = "manualSaveSectionLabel";
        /// <summary>
        /// Cached name for the 'manualSaveDetails' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveDetails = "manualSaveDetails";
        /// <summary>
        /// Cached name for the 'manualSaveShowsList' field.
        /// </summary>
        public new static readonly global::Godot.StringName @manualSaveShowsList = "manualSaveShowsList";
        /// <summary>
        /// Cached name for the 'autosaveEnabledToggle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @autosaveEnabledToggle = "autosaveEnabledToggle";
        /// <summary>
        /// Cached name for the 'autosaveIntervalChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @autosaveIntervalChoice = "autosaveIntervalChoice";
        /// <summary>
        /// Cached name for the 'autosaveRotationChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @autosaveRotationChoice = "autosaveRotationChoice";
        /// <summary>
        /// Cached name for the 'autosaveApplyButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @autosaveApplyButton = "autosaveApplyButton";
        /// <summary>
        /// Cached name for the 'autosaveSettingsStatus' field.
        /// </summary>
        public new static readonly global::Godot.StringName @autosaveSettingsStatus = "autosaveSettingsStatus";
        /// <summary>
        /// Cached name for the 'autosaveSettingsLoaded' field.
        /// </summary>
        public new static readonly global::Godot.StringName @autosaveSettingsLoaded = "autosaveSettingsLoaded";
        /// <summary>
        /// Cached name for the 'autosaveSettingsWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @autosaveSettingsWorldId = "autosaveSettingsWorldId";
        /// <summary>
        /// Cached name for the 'autosaveSettingsGeneration' field.
        /// </summary>
        public new static readonly global::Godot.StringName @autosaveSettingsGeneration = "autosaveSettingsGeneration";
        /// <summary>
        /// Cached name for the 'controlsPanel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @controlsPanel = "controlsPanel";
        /// <summary>
        /// Cached name for the 'controlsColumns' field.
        /// </summary>
        public new static readonly global::Godot.StringName @controlsColumns = "controlsColumns";
        /// <summary>
        /// Cached name for the 'renderedControlsTheme' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedControlsTheme = "renderedControlsTheme";
        /// <summary>
        /// Cached name for the 'startupRecoveryCard' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startupRecoveryCard = "startupRecoveryCard";
        /// <summary>
        /// Cached name for the 'startupRecoveryExplanation' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startupRecoveryExplanation = "startupRecoveryExplanation";
        /// <summary>
        /// Cached name for the 'startupRecoverySave' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startupRecoverySave = "startupRecoverySave";
        /// <summary>
        /// Cached name for the 'startupRecoveryButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startupRecoveryButton = "startupRecoveryButton";
        /// <summary>
        /// Cached name for the 'startupRecoveryDiskWarning' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startupRecoveryDiskWarning = "startupRecoveryDiskWarning";
        /// <summary>
        /// Cached name for the 'startupRecoveryRetry' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startupRecoveryRetry = "startupRecoveryRetry";
        /// <summary>
        /// Cached name for the 'startupRecoveryReadRevision' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startupRecoveryReadRevision = "startupRecoveryReadRevision";
        /// <summary>
        /// Cached name for the 'startupRecoveryBusy' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startupRecoveryBusy = "startupRecoveryBusy";
        /// <summary>
        /// Cached name for the 'tileSwatch' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileSwatch = "tileSwatch";
        /// <summary>
        /// Cached name for the 'tileTitle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileTitle = "tileTitle";
        /// <summary>
        /// Cached name for the 'tileSubtitle' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileSubtitle = "tileSubtitle";
        /// <summary>
        /// Cached name for the 'tileFacts' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileFacts = "tileFacts";
        /// <summary>
        /// Cached name for the 'tileThingsHeading' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileThingsHeading = "tileThingsHeading";
        /// <summary>
        /// Cached name for the 'tileThings' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileThings = "tileThings";
        /// <summary>
        /// Cached name for the 'tileDetailsScroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileDetailsScroll = "tileDetailsScroll";
        /// <summary>
        /// Cached name for the 'tileDetailsContent' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileDetailsContent = "tileDetailsContent";
        /// <summary>
        /// Cached name for the 'worldEditTool' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditTool = "worldEditTool";
        /// <summary>
        /// Cached name for the 'worldEditPick' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditPick = "worldEditPick";
        /// <summary>
        /// Cached name for the 'worldEditAdvanced' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditAdvanced = "worldEditAdvanced";
        /// <summary>
        /// Cached name for the 'worldEditPaint' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditPaint = "worldEditPaint";
        /// <summary>
        /// Cached name for the 'worldEditClear' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditClear = "worldEditClear";
        /// <summary>
        /// Cached name for the 'worldEditAdvancedBody' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditAdvancedBody = "worldEditAdvancedBody";
        /// <summary>
        /// Cached name for the 'worldEditPreview' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditPreview = "worldEditPreview";
        /// <summary>
        /// Cached name for the 'worldEditWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldEditWorldId = "worldEditWorldId";
        /// <summary>
        /// Cached name for the 'worldStatsPage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldStatsPage = "worldStatsPage";
        /// <summary>
        /// Cached name for the 'townExtras' field.
        /// </summary>
        public new static readonly global::Godot.StringName @townExtras = "townExtras";
        /// <summary>
        /// Cached name for the 'townsGap' field.
        /// </summary>
        public new static readonly global::Godot.StringName @townsGap = "townsGap";
        /// <summary>
        /// Cached name for the 'renderedWorldStats' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedWorldStats = "renderedWorldStats";
        /// <summary>
        /// Cached name for the 'renderedWorldToday' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedWorldToday = "renderedWorldToday";
        /// <summary>
        /// Cached name for the 'worldTodayCard' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldTodayCard = "worldTodayCard";
        /// <summary>
        /// Cached name for the 'worldCounts' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldCounts = "worldCounts";
        /// <summary>
        /// Cached name for the 'renderedTownExtras' field.
        /// </summary>
        public new static readonly global::Godot.StringName @renderedTownExtras = "renderedTownExtras";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@conversationReadWorldId) {
            this.@conversationReadWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@openConversationId) {
            this.@openConversationId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@openConversationAgentId) {
            this.@openConversationAgentId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@conversationHistoryExpanded) {
            this.@conversationHistoryExpanded = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@renderedAgentListWorldId) {
            this.@renderedAgentListWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renderedAgentListTheme) {
            this.@renderedAgentListTheme = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@agentProfileFitQueued) {
            this.@agentProfileFitQueued = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@renderedThoughtsReader) {
            this.@renderedThoughtsReader = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@agentProfileRequested) {
            this.@agentProfileRequested = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@measuredFirstAgentProfile) {
            this.@measuredFirstAgentProfile = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@renderedAgentCardTheme) {
            this.@renderedAgentCardTheme = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Theme>(value);
            return true;
        }
        if (name == PropertyName.@apiKeysRead) {
            this.@apiKeysRead = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@renderedBuildingRecipes) {
            this.@renderedBuildingRecipes = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@pendingBuildingRemovalWorldId) {
            this.@pendingBuildingRemovalWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renderedBuildingManagementWorldId) {
            this.@renderedBuildingManagementWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renderedBuildingManagementId) {
            this.@renderedBuildingManagementId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@selectedBuildingId) {
            this.@selectedBuildingId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@buildingDetailsRequested) {
            this.@buildingDetailsRequested = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@renderedBuildingStatus) {
            this.@renderedBuildingStatus = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renderedBuildingWork) {
            this.@renderedBuildingWork = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renderedBuildingStorageHistory) {
            this.@renderedBuildingStorageHistory = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@cameraGliding) {
            this.@cameraGliding = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@cameraGlideFrom) {
            this.@cameraGlideFrom = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(value);
            return true;
        }
        if (name == PropertyName.@cameraGlideTo) {
            this.@cameraGlideTo = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(value);
            return true;
        }
        if (name == PropertyName.@cameraGlideElapsed) {
            this.@cameraGlideElapsed = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@cameraZooming) {
            this.@cameraZooming = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@cameraZoomFrom) {
            this.@cameraZoomFrom = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@cameraZoomTo) {
            this.@cameraZoomTo = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@cameraZoomElapsed) {
            this.@cameraZoomElapsed = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@cameraZoomAnchor) {
            this.@cameraZoomAnchor = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(value);
            return true;
        }
        if (name == PropertyName.@cameraZoomPoint) {
            this.@cameraZoomPoint = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(value);
            return true;
        }
        if (name == PropertyName.@renderedObservationGeneration) {
            this.@renderedObservationGeneration = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@settingUpLocalDevice) {
            this.@settingUpLocalDevice = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@terrainWorldId) {
            this.@terrainWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@observedRoutineHelperContext) {
            this.@observedRoutineHelperContext = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@lastAgingOverrideWorldId) {
            this.@lastAgingOverrideWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@usagePauseWorldId) {
            this.@usagePauseWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@wasObservedPaused) {
            this.@wasObservedPaused = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@selectedAgentId) {
            this.@selectedAgentId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renamingAgentId) {
            this.@renamingAgentId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@isRefreshing) {
            this.@isRefreshing = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@successfulRefreshCount) {
            this.@successfulRefreshCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@isOwnerAction) {
            this.@isOwnerAction = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@registeredEndpointInvalid) {
            this.@registeredEndpointInvalid = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@menuPausedWorld) {
            this.@menuPausedWorld = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@menuPauseConfirmed) {
            this.@menuPauseConfirmed = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@pendingMenuResumes) {
            this.@pendingMenuResumes = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@pendingMenuResumeGeneration) {
            this.@pendingMenuResumeGeneration = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@currentTileSize) {
            this.@currentTileSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@cameraZoom) {
            this.@cameraZoom = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@minimumCameraZoom) {
            this.@minimumCameraZoom = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@maximumCameraZoom) {
            this.@maximumCameraZoom = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@cameraCenterTiles) {
            this.@cameraCenterTiles = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(value);
            return true;
        }
        if (name == PropertyName.@cameraWorldId) {
            this.@cameraWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@draggingMap) {
            this.@draggingMap = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@renderedEventLog) {
            this.@renderedEventLog = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@statusToastKind) {
            this.@statusToastKind = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.StatusToastKind>(value);
            return true;
        }
        if (name == PropertyName.@statusToastShownAtMsec) {
            this.@statusToastShownAtMsec = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@developerEditPeopleKey) {
            this.@developerEditPeopleKey = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@developerFrameMilliseconds) {
            this.@developerFrameMilliseconds = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@developerReadoutAge) {
            this.@developerReadoutAge = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@developerAgentListKey) {
            this.@developerAgentListKey = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@placingAddedAgent) {
            this.@placingAddedAgent = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@choosingFirstTownSite) {
            this.@choosingFirstTownSite = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@movingFounderId) {
            this.@movingFounderId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renderedTownList) {
            this.@renderedTownList = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@eventLogWorldId) {
            this.@eventLogWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@lastSeenEventId) {
            this.@lastSeenEventId = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@newEventsAfter) {
            this.@newEventsAfter = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@unreadEvents) {
            this.@unreadEvents = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@keyboardNavigation) {
            this.@keyboardNavigation = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@keyboardNavigationKey) {
            this.@keyboardNavigationKey = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Key>(value);
            return true;
        }
        if (name == PropertyName.@refreshingKeyboardMapSelection) {
            this.@refreshingKeyboardMapSelection = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@pendingOpenVersion) {
            this.@pendingOpenVersion = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@pendingOpenWorld) {
            this.@pendingOpenWorld = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@failedLauncherVersion) {
            this.@failedLauncherVersion = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@failedLauncherWorld) {
            this.@failedLauncherWorld = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@requestedWorldToSelect) {
            this.@requestedWorldToSelect = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@launcherPath) {
            this.@launcherPath = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@launcherPathRead) {
            this.@launcherPathRead = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@localServerStarting) {
            this.@localServerStarting = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@isQuittingGame) {
            this.@isQuittingGame = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@retryLauncherVersion) {
            this.@retryLauncherVersion = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@retryLauncherWorld) {
            this.@retryLauncherWorld = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@retryChooseCurrentWorld) {
            this.@retryChooseCurrentWorld = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@mainMenuNavigationRevision) {
            this.@mainMenuNavigationRevision = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@listedActiveWorldId) {
            this.@listedActiveWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@worldMenuBusy) {
            this.@worldMenuBusy = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@worldPreviewRevision) {
            this.@worldPreviewRevision = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@isInWorld) {
            this.@isInWorld = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@returnToMainMenu) {
            this.@returnToMainMenu = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@resumeWorldOnContinue) {
            this.@resumeWorldOnContinue = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@isQuittingToMenu) {
            this.@isQuittingToMenu = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@hoverReadoutTownSiteMode) {
            this.@hoverReadoutTownSiteMode = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@renderedMemoryCards) {
            this.@renderedMemoryCards = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@usageReads) {
            this.@usageReads = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@usageLimitEdited) {
            this.@usageLimitEdited = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@routineHelperSetupCheckRevision) {
            this.@routineHelperSetupCheckRevision = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@founderKeyEdits) {
            this.@founderKeyEdits = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@agentModelKeyEdits) {
            this.@agentModelKeyEdits = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@agentModelContext) {
            this.@agentModelContext = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@agentModelLookup) {
            this.@agentModelLookup = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renderedOrdersReader) {
            this.@renderedOrdersReader = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@pendingRecoveryInProgress) {
            this.@pendingRecoveryInProgress = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@unloadedPendingSubmission) {
            this.@unloadedPendingSubmission = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@renderedProfilePeople) {
            this.@renderedProfilePeople = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@agentModelSetupCheckContext) {
            this.@agentModelSetupCheckContext = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@founderModelSetupCheckRevision) {
            this.@founderModelSetupCheckRevision = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@agentModelSetupCheckRevision) {
            this.@agentModelSetupCheckRevision = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@agentListWantedHeight) {
            this.@agentListWantedHeight = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@eventLogWantedHeight) {
            this.@eventLogWantedHeight = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@hudListsRefitQueued) {
            this.@hudListsRefitQueued = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@lastDiskSpaceReadMsec) {
            this.@lastDiskSpaceReadMsec = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@diskSpaceReadPending) {
            this.@diskSpaceReadPending = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@manualSaveBody) {
            this.@manualSaveBody = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.VBoxContainer>(value);
            return true;
        }
        if (name == PropertyName.@worldHistoryLoading) {
            this.@worldHistoryLoading = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@worldHistoryLoaded) {
            this.@worldHistoryLoaded = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@listedSaveWorldId) {
            this.@listedSaveWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@pendingOverwriteSaveId) {
            this.@pendingOverwriteSaveId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@manualSaveLoadMode) {
            this.@manualSaveLoadMode = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@manualSaveShowsList) {
            this.@manualSaveShowsList = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@autosaveSettingsLoaded) {
            this.@autosaveSettingsLoaded = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@autosaveSettingsWorldId) {
            this.@autosaveSettingsWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@autosaveSettingsGeneration) {
            this.@autosaveSettingsGeneration = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@renderedControlsTheme) {
            this.@renderedControlsTheme = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@startupRecoveryReadRevision) {
            this.@startupRecoveryReadRevision = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@startupRecoveryBusy) {
            this.@startupRecoveryBusy = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@worldEditWorldId) {
            this.@worldEditWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renderedWorldStats) {
            this.@renderedWorldStats = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@renderedWorldToday) {
            this.@renderedWorldToday = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@worldTodayCard) {
            this.@worldTodayCard = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.PanelContainer>(value);
            return true;
        }
        if (name == PropertyName.@worldCounts) {
            this.@worldCounts = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.VBoxContainer>(value);
            return true;
        }
        if (name == PropertyName.@renderedTownExtras) {
            this.@renderedTownExtras = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@CameraMoving) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@CameraMoving);
            return true;
        }
        if (name == PropertyName.@DeveloperEditOperation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@DeveloperEditOperation);
            return true;
        }
        if (name == PropertyName.@DatesShowSeason) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@DatesShowSeason);
            return true;
        }
        if (name == PropertyName.@ShowsPlacementOverlays) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@ShowsPlacementOverlays);
            return true;
        }
        if (name == PropertyName.@HudTop) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@HudTop);
            return true;
        }
        if (name == PropertyName.@WorldInfoShowsTowns) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@WorldInfoShowsTowns);
            return true;
        }
        if (name == PropertyName.@DeveloperMode) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@DeveloperMode);
            return true;
        }
        if (name == PropertyName.@LauncherPath) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@LauncherPath);
            return true;
        }
        if (name == PropertyName.@PauseMenuPageOpen) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@PauseMenuPageOpen);
            return true;
        }
        if (name == PropertyName.@UiSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2>(this.@UiSize);
            return true;
        }
        if (name == PropertyName.@WorldHistoryEmbedded) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@WorldHistoryEmbedded);
            return true;
        }
        if (name == PropertyName.@ManualSaveTimelineShown) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@ManualSaveTimelineShown);
            return true;
        }
        if (name == PropertyName.@ListedSaveWorldIsActive) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@ListedSaveWorldIsActive);
            return true;
        }
        if (name == PropertyName.@CanPickWorldEditTile) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@CanPickWorldEditTile);
            return true;
        }
        if (name == PropertyName.@conversationPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@conversationPanel);
            return true;
        }
        if (name == PropertyName.@conversationReaderTitle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@conversationReaderTitle);
            return true;
        }
        if (name == PropertyName.@conversationReaderStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@conversationReaderStatus);
            return true;
        }
        if (name == PropertyName.@conversationReaderSummary) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@conversationReaderSummary);
            return true;
        }
        if (name == PropertyName.@conversationHistoryButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@conversationHistoryButton);
            return true;
        }
        if (name == PropertyName.@conversationHistoryText) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.RichTextLabel>(this.@conversationHistoryText);
            return true;
        }
        if (name == PropertyName.@conversationReadWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@conversationReadWorldId);
            return true;
        }
        if (name == PropertyName.@openConversationId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@openConversationId);
            return true;
        }
        if (name == PropertyName.@openConversationAgentId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@openConversationAgentId);
            return true;
        }
        if (name == PropertyName.@conversationHistoryExpanded) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@conversationHistoryExpanded);
            return true;
        }
        if (name == PropertyName.@agentListCards) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SlotList>(this.@agentListCards);
            return true;
        }
        if (name == PropertyName.@renderedAgentListWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedAgentListWorldId);
            return true;
        }
        if (name == PropertyName.@renderedAgentListTheme) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedAgentListTheme);
            return true;
        }
        if (name == PropertyName.@selectedAgentModelGap) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.MarginContainer>(this.@selectedAgentModelGap);
            return true;
        }
        if (name == PropertyName.@agentProfilePanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@agentProfilePanel);
            return true;
        }
        if (name == PropertyName.@agentPortraitFrame) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@agentPortraitFrame);
            return true;
        }
        if (name == PropertyName.@agentPortraitTexture) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.AtlasTexture>(this.@agentPortraitTexture);
            return true;
        }
        if (name == PropertyName.@renameToggleButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@renameToggleButton);
            return true;
        }
        if (name == PropertyName.@renameRow) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@renameRow);
            return true;
        }
        if (name == PropertyName.@profileActivityLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@profileActivityLabel);
            return true;
        }
        if (name == PropertyName.@profileOrderLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@profileOrderLabel);
            return true;
        }
        if (name == PropertyName.@profileFindButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@profileFindButton);
            return true;
        }
        if (name == PropertyName.@profileCloseButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@profileCloseButton);
            return true;
        }
        if (name == PropertyName.@profileMeters) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.GridContainer>(this.@profileMeters);
            return true;
        }
        if (name == PropertyName.@profileFullnessMeter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelMeter>(this.@profileFullnessMeter);
            return true;
        }
        if (name == PropertyName.@profileWarmthMeter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelMeter>(this.@profileWarmthMeter);
            return true;
        }
        if (name == PropertyName.@profileDietMeter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelMeter>(this.@profileDietMeter);
            return true;
        }
        if (name == PropertyName.@profileIllnessMeter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelMeter>(this.@profileIllnessMeter);
            return true;
        }
        if (name == PropertyName.@thoughtsHeading) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@thoughtsHeading);
            return true;
        }
        if (name == PropertyName.@speakSection) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@speakSection);
            return true;
        }
        if (name == PropertyName.@instructionHistory) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.RichTextLabel>(this.@instructionHistory);
            return true;
        }
        if (name == PropertyName.@agentOverviewScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@agentOverviewScroll);
            return true;
        }
        if (name == PropertyName.@agentOverviewGap) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.MarginContainer>(this.@agentOverviewGap);
            return true;
        }
        if (name == PropertyName.@agentProfileFitQueued) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@agentProfileFitQueued);
            return true;
        }
        if (name == PropertyName.@instructionSuggestButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@instructionSuggestButton);
            return true;
        }
        if (name == PropertyName.@instructionOrderButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@instructionOrderButton);
            return true;
        }
        if (name == PropertyName.@instructionQueueToggle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@instructionQueueToggle);
            return true;
        }
        if (name == PropertyName.@instructionCancelButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@instructionCancelButton);
            return true;
        }
        if (name == PropertyName.@thoughtsInset) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@thoughtsInset);
            return true;
        }
        if (name == PropertyName.@readThoughtsButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@readThoughtsButton);
            return true;
        }
        if (name == PropertyName.@thoughtsPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@thoughtsPanel);
            return true;
        }
        if (name == PropertyName.@thoughtsReaderTitle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@thoughtsReaderTitle);
            return true;
        }
        if (name == PropertyName.@thoughtsReaderText) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.RichTextLabel>(this.@thoughtsReaderText);
            return true;
        }
        if (name == PropertyName.@renderedThoughtsReader) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedThoughtsReader);
            return true;
        }
        if (name == PropertyName.@agentProfileRequested) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@agentProfileRequested);
            return true;
        }
        if (name == PropertyName.@measuredFirstAgentProfile) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@measuredFirstAgentProfile);
            return true;
        }
        if (name == PropertyName.@quickCardNameLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@quickCardNameLabel);
            return true;
        }
        if (name == PropertyName.@quickCardActivityLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@quickCardActivityLabel);
            return true;
        }
        if (name == PropertyName.@quickCardOrderLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@quickCardOrderLabel);
            return true;
        }
        if (name == PropertyName.@quickCardMeters) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@quickCardMeters);
            return true;
        }
        if (name == PropertyName.@quickFullnessMeter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelMeter>(this.@quickFullnessMeter);
            return true;
        }
        if (name == PropertyName.@quickWarmthMeter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelMeter>(this.@quickWarmthMeter);
            return true;
        }
        if (name == PropertyName.@quickIllnessMeter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelMeter>(this.@quickIllnessMeter);
            return true;
        }
        if (name == PropertyName.@quickCardProfileButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@quickCardProfileButton);
            return true;
        }
        if (name == PropertyName.@quickCardSpeakButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@quickCardSpeakButton);
            return true;
        }
        if (name == PropertyName.@renderedAgentCardTheme) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Theme>(this.@renderedAgentCardTheme);
            return true;
        }
        if (name == PropertyName.@apiKeysPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@apiKeysPanel);
            return true;
        }
        if (name == PropertyName.@apiKeyProviderChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@apiKeyProviderChoice);
            return true;
        }
        if (name == PropertyName.@apiKeyLabelInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@apiKeyLabelInput);
            return true;
        }
        if (name == PropertyName.@apiKeyInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@apiKeyInput);
            return true;
        }
        if (name == PropertyName.@saveApiKeyButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@saveApiKeyButton);
            return true;
        }
        if (name == PropertyName.@apiKeysStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@apiKeysStatus);
            return true;
        }
        if (name == PropertyName.@savedApiKeys) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@savedApiKeys);
            return true;
        }
        if (name == PropertyName.@savedApiKeyChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@savedApiKeyChoice);
            return true;
        }
        if (name == PropertyName.@deleteApiKeyButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@deleteApiKeyButton);
            return true;
        }
        if (name == PropertyName.@apiKeysRead) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@apiKeysRead);
            return true;
        }
        if (name == PropertyName.@buildingQuickCard) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@buildingQuickCard);
            return true;
        }
        if (name == PropertyName.@buildingDetailsPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@buildingDetailsPanel);
            return true;
        }
        if (name == PropertyName.@buildingQuickHeader) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.BuildingHeader>(this.@buildingQuickHeader);
            return true;
        }
        if (name == PropertyName.@buildingDetailsHeader) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.BuildingHeader>(this.@buildingDetailsHeader);
            return true;
        }
        if (name == PropertyName.@buildingQuickStorage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.ItemStorage>(this.@buildingQuickStorage);
            return true;
        }
        if (name == PropertyName.@buildingDetailsStorage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.ItemStorage>(this.@buildingDetailsStorage);
            return true;
        }
        if (name == PropertyName.@buildingDetailsButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@buildingDetailsButton);
            return true;
        }
        if (name == PropertyName.@buildingQuickStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingQuickStatus);
            return true;
        }
        if (name == PropertyName.@buildingFacts) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.GridContainer>(this.@buildingFacts);
            return true;
        }
        if (name == PropertyName.@buildingDetailsScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@buildingDetailsScroll);
            return true;
        }
        if (name == PropertyName.@buildingDetailsContent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingDetailsContent);
            return true;
        }
        if (name == PropertyName.@buildingWorkSection) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingWorkSection);
            return true;
        }
        if (name == PropertyName.@buildingWorkRows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingWorkRows);
            return true;
        }
        if (name == PropertyName.@buildingRecipeSection) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingRecipeSection);
            return true;
        }
        if (name == PropertyName.@buildingRecipeRows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingRecipeRows);
            return true;
        }
        if (name == PropertyName.@renderedBuildingRecipes) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedBuildingRecipes);
            return true;
        }
        if (name == PropertyName.@buildingPeopleSection) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingPeopleSection);
            return true;
        }
        if (name == PropertyName.@buildingPeopleSummary) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@buildingPeopleSummary);
            return true;
        }
        if (name == PropertyName.@buildingPeopleText) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@buildingPeopleText);
            return true;
        }
        if (name == PropertyName.@buildingManagementSection) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingManagementSection);
            return true;
        }
        if (name == PropertyName.@buildingManagementNote) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@buildingManagementNote);
            return true;
        }
        if (name == PropertyName.@buildingManagementChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@buildingManagementChoice);
            return true;
        }
        if (name == PropertyName.@buildingManagementApply) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@buildingManagementApply);
            return true;
        }
        if (name == PropertyName.@buildingRemoveButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@buildingRemoveButton);
            return true;
        }
        if (name == PropertyName.@buildingRemoveConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@buildingRemoveConfirmation);
            return true;
        }
        if (name == PropertyName.@pendingBuildingRemovalWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@pendingBuildingRemovalWorldId);
            return true;
        }
        if (name == PropertyName.@renderedBuildingManagementWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedBuildingManagementWorldId);
            return true;
        }
        if (name == PropertyName.@renderedBuildingManagementId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedBuildingManagementId);
            return true;
        }
        if (name == PropertyName.@selectedBuildingId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@selectedBuildingId);
            return true;
        }
        if (name == PropertyName.@buildingDetailsRequested) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@buildingDetailsRequested);
            return true;
        }
        if (name == PropertyName.@renderedBuildingStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedBuildingStatus);
            return true;
        }
        if (name == PropertyName.@renderedBuildingWork) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedBuildingWork);
            return true;
        }
        if (name == PropertyName.@buildingStorageHistorySection) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingStorageHistorySection);
            return true;
        }
        if (name == PropertyName.@buildingStorageHistoryRows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@buildingStorageHistoryRows);
            return true;
        }
        if (name == PropertyName.@renderedBuildingStorageHistory) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedBuildingStorageHistory);
            return true;
        }
        if (name == PropertyName.@cameraGliding) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@cameraGliding);
            return true;
        }
        if (name == PropertyName.@cameraGlideFrom) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2>(this.@cameraGlideFrom);
            return true;
        }
        if (name == PropertyName.@cameraGlideTo) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2>(this.@cameraGlideTo);
            return true;
        }
        if (name == PropertyName.@cameraGlideElapsed) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@cameraGlideElapsed);
            return true;
        }
        if (name == PropertyName.@cameraZooming) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@cameraZooming);
            return true;
        }
        if (name == PropertyName.@cameraZoomFrom) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@cameraZoomFrom);
            return true;
        }
        if (name == PropertyName.@cameraZoomTo) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@cameraZoomTo);
            return true;
        }
        if (name == PropertyName.@cameraZoomElapsed) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@cameraZoomElapsed);
            return true;
        }
        if (name == PropertyName.@cameraZoomAnchor) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2>(this.@cameraZoomAnchor);
            return true;
        }
        if (name == PropertyName.@cameraZoomPoint) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2>(this.@cameraZoomPoint);
            return true;
        }
        if (name == PropertyName.@renderedObservationGeneration) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@renderedObservationGeneration);
            return true;
        }
        if (name == PropertyName.@settingUpLocalDevice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@settingUpLocalDevice);
            return true;
        }
        if (name == PropertyName.@uiLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.ScaledLayer>(this.@uiLayer);
            return true;
        }
        if (name == PropertyName.@menuLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.ScaledLayer>(this.@menuLayer);
            return true;
        }
        if (name == PropertyName.@statusLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@statusLabel);
            return true;
        }
        if (name == PropertyName.@statusToast) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@statusToast);
            return true;
        }
        if (name == PropertyName.@settingsButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@settingsButton);
            return true;
        }
        if (name == PropertyName.@modLibraryButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@modLibraryButton);
            return true;
        }
        if (name == PropertyName.@gameSettingsCategoryButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@gameSettingsCategoryButton);
            return true;
        }
        if (name == PropertyName.@worldSettingsCategoryButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldSettingsCategoryButton);
            return true;
        }
        if (name == PropertyName.@gameSettingsContent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@gameSettingsContent);
            return true;
        }
        if (name == PropertyName.@worldSettingsContent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@worldSettingsContent);
            return true;
        }
        if (name == PropertyName.@settingsScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@settingsScroll);
            return true;
        }
        if (name == PropertyName.@serverUrlInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@serverUrlInput);
            return true;
        }
        if (name == PropertyName.@agentModelPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@agentModelPanel);
            return true;
        }
        if (name == PropertyName.@usageLimitPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@usageLimitPanel);
            return true;
        }
        if (name == PropertyName.@agentModelRoleChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@agentModelRoleChoice);
            return true;
        }
        if (name == PropertyName.@agentModelTargetChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@agentModelTargetChoice);
            return true;
        }
        if (name == PropertyName.@agentModelProviderChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@agentModelProviderChoice);
            return true;
        }
        if (name == PropertyName.@agentModelCredentialChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@agentModelCredentialChoice);
            return true;
        }
        if (name == PropertyName.@agentModelPicker) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.ModelPicker>(this.@agentModelPicker);
            return true;
        }
        if (name == PropertyName.@agentModelThinkingChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@agentModelThinkingChoice);
            return true;
        }
        if (name == PropertyName.@agentModelApiKeyInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@agentModelApiKeyInput);
            return true;
        }
        if (name == PropertyName.@agentModelCredentialLabelInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@agentModelCredentialLabelInput);
            return true;
        }
        if (name == PropertyName.@agentModelConfigurationStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@agentModelConfigurationStatus);
            return true;
        }
        if (name == PropertyName.@agentModelCredentialHint) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@agentModelCredentialHint);
            return true;
        }
        if (name == PropertyName.@usageMeterStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@usageMeterStatus);
            return true;
        }
        if (name == PropertyName.@usageAttemptLimitInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@usageAttemptLimitInput);
            return true;
        }
        if (name == PropertyName.@applyUsageLimitButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@applyUsageLimitButton);
            return true;
        }
        if (name == PropertyName.@grantUsageCallsButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@grantUsageCallsButton);
            return true;
        }
        if (name == PropertyName.@refreshUsageButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@refreshUsageButton);
            return true;
        }
        if (name == PropertyName.@saveAgentModelProviderButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@saveAgentModelProviderButton);
            return true;
        }
        if (name == PropertyName.@forgetAgentModelCredentialButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@forgetAgentModelCredentialButton);
            return true;
        }
        if (name == PropertyName.@deleteAgentModelCredentialSlotButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@deleteAgentModelCredentialSlotButton);
            return true;
        }
        if (name == PropertyName.@openModelSettingsButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@openModelSettingsButton);
            return true;
        }
        if (name == PropertyName.@refreshAgentModelProviderButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@refreshAgentModelProviderButton);
            return true;
        }
        if (name == PropertyName.@topBar) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@topBar);
            return true;
        }
        if (name == PropertyName.@mapButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@mapButton);
            return true;
        }
        if (name == PropertyName.@worldInfoButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldInfoButton);
            return true;
        }
        if (name == PropertyName.@clockLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@clockLabel);
            return true;
        }
        if (name == PropertyName.@agentsButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@agentsButton);
            return true;
        }
        if (name == PropertyName.@eventLogButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@eventLogButton);
            return true;
        }
        if (name == PropertyName.@menuButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@menuButton);
            return true;
        }
        if (name == PropertyName.@topBarShade) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ColorRect>(this.@topBarShade);
            return true;
        }
        if (name == PropertyName.@terrainLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@terrainLayer);
            return true;
        }
        if (name == PropertyName.@weatherLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.WeatherLayer>(this.@weatherLayer);
            return true;
        }
        if (name == PropertyName.@nightLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.NightLayer>(this.@nightLayer);
            return true;
        }
        if (name == PropertyName.@buildingCompletionLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.BuildingCompletionLayer>(this.@buildingCompletionLayer);
            return true;
        }
        if (name == PropertyName.@goldenHourLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.GoldenHourLayer>(this.@goldenHourLayer);
            return true;
        }
        if (name == PropertyName.@graveLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.GraveLayer>(this.@graveLayer);
            return true;
        }
        if (name == PropertyName.@nightLightsLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.NightLightsLayer>(this.@nightLightsLayer);
            return true;
        }
        if (name == PropertyName.@smokeLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SmokeLayer>(this.@smokeLayer);
            return true;
        }
        if (name == PropertyName.@storedStockLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.StoredStockLayer>(this.@storedStockLayer);
            return true;
        }
        if (name == PropertyName.@terrainWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@terrainWorldId);
            return true;
        }
        if (name == PropertyName.@mapCanvas) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@mapCanvas);
            return true;
        }
        if (name == PropertyName.@mapStage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@mapStage);
            return true;
        }
        if (name == PropertyName.@worldMapPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@worldMapPanel);
            return true;
        }
        if (name == PropertyName.@worldMapAtlas) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.WorldMapAtlas>(this.@worldMapAtlas);
            return true;
        }
        if (name == PropertyName.@objectLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@objectLayer);
            return true;
        }
        if (name == PropertyName.@entityLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@entityLayer);
            return true;
        }
        if (name == PropertyName.@agentsSummaryLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@agentsSummaryLabel);
            return true;
        }
        if (name == PropertyName.@agentQuickCard) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@agentQuickCard);
            return true;
        }
        if (name == PropertyName.@selectedAgentOverview) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@selectedAgentOverview);
            return true;
        }
        if (name == PropertyName.@selectedAgentModelScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@selectedAgentModelScroll);
            return true;
        }
        if (name == PropertyName.@selectedAgentModelContent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@selectedAgentModelContent);
            return true;
        }
        if (name == PropertyName.@modelSettingsButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@modelSettingsButton);
            return true;
        }
        if (name == PropertyName.@selectedActorNameLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@selectedActorNameLabel);
            return true;
        }
        if (name == PropertyName.@renameAgentInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@renameAgentInput);
            return true;
        }
        if (name == PropertyName.@renameAgentButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@renameAgentButton);
            return true;
        }
        if (name == PropertyName.@selectedActorSummaryLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@selectedActorSummaryLabel);
            return true;
        }
        if (name == PropertyName.@selectedActorConditionLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@selectedActorConditionLabel);
            return true;
        }
        if (name == PropertyName.@clearSelectionButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@clearSelectionButton);
            return true;
        }
        if (name == PropertyName.@findAgentButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@findAgentButton);
            return true;
        }
        if (name == PropertyName.@familyTreeButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@familyTreeButton);
            return true;
        }
        if (name == PropertyName.@familyTreePanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@familyTreePanel);
            return true;
        }
        if (name == PropertyName.@familyTreeView) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FamilyTreeView>(this.@familyTreeView);
            return true;
        }
        if (name == PropertyName.@familyTreeScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@familyTreeScroll);
            return true;
        }
        if (name == PropertyName.@familyTreeStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@familyTreeStatus);
            return true;
        }
        if (name == PropertyName.@agentList) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ItemList>(this.@agentList);
            return true;
        }
        if (name == PropertyName.@agentDetails) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.RichTextLabel>(this.@agentDetails);
            return true;
        }
        if (name == PropertyName.@privateThoughtHistory) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@privateThoughtHistory);
            return true;
        }
        if (name == PropertyName.@memoriesButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@memoriesButton);
            return true;
        }
        if (name == PropertyName.@memoriesPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@memoriesPanel);
            return true;
        }
        if (name == PropertyName.@eventLog) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.RichTextLabel>(this.@eventLog);
            return true;
        }
        if (name == PropertyName.@agentsPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@agentsPanel);
            return true;
        }
        if (name == PropertyName.@eventLogPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@eventLogPanel);
            return true;
        }
        if (name == PropertyName.@worldInfoPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@worldInfoPanel);
            return true;
        }
        if (name == PropertyName.@selectedTilePanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@selectedTilePanel);
            return true;
        }
        if (name == PropertyName.@selectedTileText) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.RichTextLabel>(this.@selectedTileText);
            return true;
        }
        if (name == PropertyName.@pauseMenuPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@pauseMenuPanel);
            return true;
        }
        if (name == PropertyName.@menuActions) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@menuActions);
            return true;
        }
        if (name == PropertyName.@settingsPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@settingsPanel);
            return true;
        }
        if (name == PropertyName.@menuShade) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ColorRect>(this.@menuShade);
            return true;
        }
        if (name == PropertyName.@appBackdrop) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ColorRect>(this.@appBackdrop);
            return true;
        }
        if (name == PropertyName.@worldBackdrop) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ColorRect>(this.@worldBackdrop);
            return true;
        }
        if (name == PropertyName.@themeChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@themeChoice);
            return true;
        }
        if (name == PropertyName.@cloudHazeToggle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@cloudHazeToggle);
            return true;
        }
        if (name == PropertyName.@lightningToggle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@lightningToggle);
            return true;
        }
        if (name == PropertyName.@menuHeadingLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@menuHeadingLabel);
            return true;
        }
        if (name == PropertyName.@menuCloseButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@menuCloseButton);
            return true;
        }
        if (name == PropertyName.@menuResumeButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@menuResumeButton);
            return true;
        }
        if (name == PropertyName.@quitGameButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@quitGameButton);
            return true;
        }
        if (name == PropertyName.@quitGameConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@quitGameConfirmation);
            return true;
        }
        if (name == PropertyName.@fullscreenToggle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@fullscreenToggle);
            return true;
        }
        if (name == PropertyName.@windowSizeChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@windowSizeChoice);
            return true;
        }
        if (name == PropertyName.@clockFormatChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@clockFormatChoice);
            return true;
        }
        if (name == PropertyName.@dateFormatChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@dateFormatChoice);
            return true;
        }
        if (name == PropertyName.@agingOverrideChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@agingOverrideChoice);
            return true;
        }
        if (name == PropertyName.@routineHelperChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@routineHelperChoice);
            return true;
        }
        if (name == PropertyName.@routineHelperModelPicker) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.ModelPicker>(this.@routineHelperModelPicker);
            return true;
        }
        if (name == PropertyName.@routineHelperKeyChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@routineHelperKeyChoice);
            return true;
        }
        if (name == PropertyName.@applyRoutineHelperButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@applyRoutineHelperButton);
            return true;
        }
        if (name == PropertyName.@observedRoutineHelperContext) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@observedRoutineHelperContext);
            return true;
        }
        if (name == PropertyName.@applyAgingOverrideButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@applyAgingOverrideButton);
            return true;
        }
        if (name == PropertyName.@lastAgingOverrideWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@lastAgingOverrideWorldId);
            return true;
        }
        if (name == PropertyName.@pauseButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.BoldTextButton>(this.@pauseButton);
            return true;
        }
        if (name == PropertyName.@instructionText) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@instructionText);
            return true;
        }
        if (name == PropertyName.@submitInstructionButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@submitInstructionButton);
            return true;
        }
        if (name == PropertyName.@pendingSubmissionLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@pendingSubmissionLabel);
            return true;
        }
        if (name == PropertyName.@retryPendingSubmissionButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@retryPendingSubmissionButton);
            return true;
        }
        if (name == PropertyName.@forgetPendingSubmissionButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@forgetPendingSubmissionButton);
            return true;
        }
        if (name == PropertyName.@worldEditKind) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@worldEditKind);
            return true;
        }
        if (name == PropertyName.@worldEditId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@worldEditId);
            return true;
        }
        if (name == PropertyName.@worldEditValue) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@worldEditValue);
            return true;
        }
        if (name == PropertyName.@worldEditSecondaryValue) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@worldEditSecondaryValue);
            return true;
        }
        if (name == PropertyName.@worldEditX) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.SpinBox>(this.@worldEditX);
            return true;
        }
        if (name == PropertyName.@worldEditY) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.SpinBox>(this.@worldEditY);
            return true;
        }
        if (name == PropertyName.@worldEditRenewable) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckBox>(this.@worldEditRenewable);
            return true;
        }
        if (name == PropertyName.@submitWorldEditButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@submitWorldEditButton);
            return true;
        }
        if (name == PropertyName.@worldEditHintLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@worldEditHintLabel);
            return true;
        }
        if (name == PropertyName.@pairingApprovalId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@pairingApprovalId);
            return true;
        }
        if (name == PropertyName.@pairingApprovalCode) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@pairingApprovalCode);
            return true;
        }
        if (name == PropertyName.@approvePairingButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@approvePairingButton);
            return true;
        }
        if (name == PropertyName.@refreshDevicesButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@refreshDevicesButton);
            return true;
        }
        if (name == PropertyName.@pairedDeviceList) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ItemList>(this.@pairedDeviceList);
            return true;
        }
        if (name == PropertyName.@revokeDeviceId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@revokeDeviceId);
            return true;
        }
        if (name == PropertyName.@revokeDeviceButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@revokeDeviceButton);
            return true;
        }
        if (name == PropertyName.@usagePauseWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@usagePauseWorldId);
            return true;
        }
        if (name == PropertyName.@wasObservedPaused) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@wasObservedPaused);
            return true;
        }
        if (name == PropertyName.@selectedAgentId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@selectedAgentId);
            return true;
        }
        if (name == PropertyName.@renamingAgentId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renamingAgentId);
            return true;
        }
        if (name == PropertyName.@isRefreshing) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@isRefreshing);
            return true;
        }
        if (name == PropertyName.@successfulRefreshCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@successfulRefreshCount);
            return true;
        }
        if (name == PropertyName.@isOwnerAction) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@isOwnerAction);
            return true;
        }
        if (name == PropertyName.@registeredEndpointInvalid) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@registeredEndpointInvalid);
            return true;
        }
        if (name == PropertyName.@menuPausedWorld) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@menuPausedWorld);
            return true;
        }
        if (name == PropertyName.@menuPauseConfirmed) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@menuPauseConfirmed);
            return true;
        }
        if (name == PropertyName.@pendingMenuResumes) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@pendingMenuResumes);
            return true;
        }
        if (name == PropertyName.@pendingMenuResumeGeneration) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@pendingMenuResumeGeneration);
            return true;
        }
        if (name == PropertyName.@currentTileSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@currentTileSize);
            return true;
        }
        if (name == PropertyName.@cameraZoom) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@cameraZoom);
            return true;
        }
        if (name == PropertyName.@minimumCameraZoom) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@minimumCameraZoom);
            return true;
        }
        if (name == PropertyName.@maximumCameraZoom) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@maximumCameraZoom);
            return true;
        }
        if (name == PropertyName.@cameraCenterTiles) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2>(this.@cameraCenterTiles);
            return true;
        }
        if (name == PropertyName.@cameraWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@cameraWorldId);
            return true;
        }
        if (name == PropertyName.@draggingMap) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@draggingMap);
            return true;
        }
        if (name == PropertyName.@renderedEventLog) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedEventLog);
            return true;
        }
        if (name == PropertyName.@statusToastKind) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.Main.StatusToastKind>(this.@statusToastKind);
            return true;
        }
        if (name == PropertyName.@statusToastShownAtMsec) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@statusToastShownAtMsec);
            return true;
        }
        if (name == PropertyName.@developerEditAgent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@developerEditAgent);
            return true;
        }
        if (name == PropertyName.@developerEditHint) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@developerEditHint);
            return true;
        }
        if (name == PropertyName.@developerEditKind) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@developerEditKind);
            return true;
        }
        if (name == PropertyName.@developerEditValue) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@developerEditValue);
            return true;
        }
        if (name == PropertyName.@developerEditOther) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@developerEditOther);
            return true;
        }
        if (name == PropertyName.@developerEditAmount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.SpinBox>(this.@developerEditAmount);
            return true;
        }
        if (name == PropertyName.@developerEditApply) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@developerEditApply);
            return true;
        }
        if (name == PropertyName.@developerEditPeopleKey) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@developerEditPeopleKey);
            return true;
        }
        if (name == PropertyName.@developerPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@developerPanel);
            return true;
        }
        if (name == PropertyName.@developerScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@developerScroll);
            return true;
        }
        if (name == PropertyName.@developerBody) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@developerBody);
            return true;
        }
        if (name == PropertyName.@developerTileLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@developerTileLabel);
            return true;
        }
        if (name == PropertyName.@developerFrameLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@developerFrameLabel);
            return true;
        }
        if (name == PropertyName.@developerTickLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@developerTickLabel);
            return true;
        }
        if (name == PropertyName.@developerRefusedActionLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@developerRefusedActionLabel);
            return true;
        }
        if (name == PropertyName.@developerAgentCountLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@developerAgentCountLabel);
            return true;
        }
        if (name == PropertyName.@developerAgentList) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ItemList>(this.@developerAgentList);
            return true;
        }
        if (name == PropertyName.@developerPathToggle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckBox>(this.@developerPathToggle);
            return true;
        }
        if (name == PropertyName.@developerRouteLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@developerRouteLabel);
            return true;
        }
        if (name == PropertyName.@plannedPathLayer) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PlannedPathLayer>(this.@plannedPathLayer);
            return true;
        }
        if (name == PropertyName.@developerFrameMilliseconds) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@developerFrameMilliseconds);
            return true;
        }
        if (name == PropertyName.@developerReadoutAge) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@developerReadoutAge);
            return true;
        }
        if (name == PropertyName.@developerAgentListKey) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@developerAgentListKey);
            return true;
        }
        if (name == PropertyName.@eventRows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@eventRows);
            return true;
        }
        if (name == PropertyName.@eventScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@eventScroll);
            return true;
        }
        if (name == PropertyName.@familyLegend) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HFlowContainer>(this.@familyLegend);
            return true;
        }
        if (name == PropertyName.@filtersButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@filtersButton);
            return true;
        }
        if (name == PropertyName.@filtersPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@filtersPanel);
            return true;
        }
        if (name == PropertyName.@townBorderFilter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@townBorderFilter);
            return true;
        }
        if (name == PropertyName.@householdPropertyFilter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@householdPropertyFilter);
            return true;
        }
        if (name == PropertyName.@townLandTitleFilter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@townLandTitleFilter);
            return true;
        }
        if (name == PropertyName.@householdLandUseFilter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@householdLandUseFilter);
            return true;
        }
        if (name == PropertyName.@disputedLandFilter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@disputedLandFilter);
            return true;
        }
        if (name == PropertyName.@founderSetupButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@founderSetupButton);
            return true;
        }
        if (name == PropertyName.@townSiteButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@townSiteButton);
            return true;
        }
        if (name == PropertyName.@moveFounderButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@moveFounderButton);
            return true;
        }
        if (name == PropertyName.@undoFounderButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@undoFounderButton);
            return true;
        }
        if (name == PropertyName.@addAgentButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@addAgentButton);
            return true;
        }
        if (name == PropertyName.@startWorldButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@startWorldButton);
            return true;
        }
        if (name == PropertyName.@founderSetupPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@founderSetupPanel);
            return true;
        }
        if (name == PropertyName.@founderSetupHint) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@founderSetupHint);
            return true;
        }
        if (name == PropertyName.@founderPlacementIcon) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(this.@founderPlacementIcon);
            return true;
        }
        if (name == PropertyName.@founderProviderChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@founderProviderChoice);
            return true;
        }
        if (name == PropertyName.@founderCredentialChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@founderCredentialChoice);
            return true;
        }
        if (name == PropertyName.@founderModelPicker) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.ModelPicker>(this.@founderModelPicker);
            return true;
        }
        if (name == PropertyName.@founderThinkingChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@founderThinkingChoice);
            return true;
        }
        if (name == PropertyName.@founderKeyLabelInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@founderKeyLabelInput);
            return true;
        }
        if (name == PropertyName.@founderApiKeyInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@founderApiKeyInput);
            return true;
        }
        if (name == PropertyName.@placingAddedAgent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@placingAddedAgent);
            return true;
        }
        if (name == PropertyName.@choosingFirstTownSite) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@choosingFirstTownSite);
            return true;
        }
        if (name == PropertyName.@movingFounderId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@movingFounderId);
            return true;
        }
        if (name == PropertyName.@generationSettingsRows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@generationSettingsRows);
            return true;
        }
        if (name == PropertyName.@generationSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@generationSize);
            return true;
        }
        if (name == PropertyName.@generationClimate) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@generationClimate);
            return true;
        }
        if (name == PropertyName.@generationWrapping) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@generationWrapping);
            return true;
        }
        if (name == PropertyName.@generationSeed) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@generationSeed);
            return true;
        }
        if (name == PropertyName.@generationSettingsHint) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@generationSettingsHint);
            return true;
        }
        if (name == PropertyName.@hudBar) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.MarginContainer>(this.@hudBar);
            return true;
        }
        if (name == PropertyName.@hudRows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@hudRows);
            return true;
        }
        if (name == PropertyName.@hudLeft) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@hudLeft);
            return true;
        }
        if (name == PropertyName.@hudTime) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@hudTime);
            return true;
        }
        if (name == PropertyName.@hudRight) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@hudRight);
            return true;
        }
        if (name == PropertyName.@founderHudRow) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@founderHudRow);
            return true;
        }
        if (name == PropertyName.@hudFounders) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@hudFounders);
            return true;
        }
        if (name == PropertyName.@climateBox) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@climateBox);
            return true;
        }
        if (name == PropertyName.@seasonIcon) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(this.@seasonIcon);
            return true;
        }
        if (name == PropertyName.@seasonLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@seasonLabel);
            return true;
        }
        if (name == PropertyName.@weatherIcon) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(this.@weatherIcon);
            return true;
        }
        if (name == PropertyName.@weatherLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@weatherLabel);
            return true;
        }
        if (name == PropertyName.@eventLogBadge) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelBadge>(this.@eventLogBadge);
            return true;
        }
        if (name == PropertyName.@agentsWarning) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.PixelBadge>(this.@agentsWarning);
            return true;
        }
        if (name == PropertyName.@worldInfoTownsTab) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldInfoTownsTab);
            return true;
        }
        if (name == PropertyName.@worldInfoWorldTab) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldInfoWorldTab);
            return true;
        }
        if (name == PropertyName.@townsScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@townsScroll);
            return true;
        }
        if (name == PropertyName.@townsPage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@townsPage);
            return true;
        }
        if (name == PropertyName.@townList) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@townList);
            return true;
        }
        if (name == PropertyName.@renderedTownList) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedTownList);
            return true;
        }
        if (name == PropertyName.@eventLogWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@eventLogWorldId);
            return true;
        }
        if (name == PropertyName.@lastSeenEventId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@lastSeenEventId);
            return true;
        }
        if (name == PropertyName.@newEventsAfter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@newEventsAfter);
            return true;
        }
        if (name == PropertyName.@unreadEvents) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@unreadEvents);
            return true;
        }
        if (name == PropertyName.@keyboardNavigation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@keyboardNavigation);
            return true;
        }
        if (name == PropertyName.@keyboardNavigationKey) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Key>(this.@keyboardNavigationKey);
            return true;
        }
        if (name == PropertyName.@refreshingKeyboardMapSelection) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@refreshingKeyboardMapSelection);
            return true;
        }
        if (name == PropertyName.@quitToLauncherButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@quitToLauncherButton);
            return true;
        }
        if (name == PropertyName.@quitToLauncherConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@quitToLauncherConfirmation);
            return true;
        }
        if (name == PropertyName.@launcherStartFailure) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@launcherStartFailure);
            return true;
        }
        if (name == PropertyName.@openInVersionConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@openInVersionConfirmation);
            return true;
        }
        if (name == PropertyName.@pendingOpenVersion) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@pendingOpenVersion);
            return true;
        }
        if (name == PropertyName.@pendingOpenWorld) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@pendingOpenWorld);
            return true;
        }
        if (name == PropertyName.@failedLauncherVersion) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@failedLauncherVersion);
            return true;
        }
        if (name == PropertyName.@failedLauncherWorld) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@failedLauncherWorld);
            return true;
        }
        if (name == PropertyName.@requestedWorldToSelect) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@requestedWorldToSelect);
            return true;
        }
        if (name == PropertyName.@launcherPath) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@launcherPath);
            return true;
        }
        if (name == PropertyName.@launcherPathRead) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@launcherPathRead);
            return true;
        }
        if (name == PropertyName.@localServerStarting) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@localServerStarting);
            return true;
        }
        if (name == PropertyName.@localServerFailure) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@localServerFailure);
            return true;
        }
        if (name == PropertyName.@localServerStopFailure) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@localServerStopFailure);
            return true;
        }
        if (name == PropertyName.@isQuittingGame) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@isQuittingGame);
            return true;
        }
        if (name == PropertyName.@retryLauncherVersion) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@retryLauncherVersion);
            return true;
        }
        if (name == PropertyName.@retryLauncherWorld) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@retryLauncherWorld);
            return true;
        }
        if (name == PropertyName.@retryChooseCurrentWorld) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@retryChooseCurrentWorld);
            return true;
        }
        if (name == PropertyName.@mainMenuNavigationRevision) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@mainMenuNavigationRevision);
            return true;
        }
        if (name == PropertyName.@mainMenuOverlay) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@mainMenuOverlay);
            return true;
        }
        if (name == PropertyName.@mainMenuBackground) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ColorRect>(this.@mainMenuBackground);
            return true;
        }
        if (name == PropertyName.@mainMenuBackdrop) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.MenuBackdrop>(this.@mainMenuBackdrop);
            return true;
        }
        if (name == PropertyName.@mainMenuStack) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@mainMenuStack);
            return true;
        }
        if (name == PropertyName.@mainMenuLogo) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(this.@mainMenuLogo);
            return true;
        }
        if (name == PropertyName.@mainMenuCenter) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CenterContainer>(this.@mainMenuCenter);
            return true;
        }
        if (name == PropertyName.@mainMenuCard) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@mainMenuCard);
            return true;
        }
        if (name == PropertyName.@mainMenuStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@mainMenuStatus);
            return true;
        }
        if (name == PropertyName.@mainMenuContinueButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@mainMenuContinueButton);
            return true;
        }
        if (name == PropertyName.@mainMenuNewButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@mainMenuNewButton);
            return true;
        }
        if (name == PropertyName.@mainMenuLoadButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@mainMenuLoadButton);
            return true;
        }
        if (name == PropertyName.@menuQuitToMainButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@menuQuitToMainButton);
            return true;
        }
        if (name == PropertyName.@menuSaveWorldButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@menuSaveWorldButton);
            return true;
        }
        if (name == PropertyName.@worldMenuOverlay) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@worldMenuOverlay);
            return true;
        }
        if (name == PropertyName.@worldMenuCard) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@worldMenuCard);
            return true;
        }
        if (name == PropertyName.@worldMenuScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@worldMenuScroll);
            return true;
        }
        if (name == PropertyName.@worldMenuBody) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@worldMenuBody);
            return true;
        }
        if (name == PropertyName.@worldMenuColumns) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HFlowContainer>(this.@worldMenuColumns);
            return true;
        }
        if (name == PropertyName.@worldPreviewFrame) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@worldPreviewFrame);
            return true;
        }
        if (name == PropertyName.@worldMenuHeading) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@worldMenuHeading);
            return true;
        }
        if (name == PropertyName.@worldMenuStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@worldMenuStatus);
            return true;
        }
        if (name == PropertyName.@worldNameInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@worldNameInput);
            return true;
        }
        if (name == PropertyName.@worldSeedInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@worldSeedInput);
            return true;
        }
        if (name == PropertyName.@worldSizeChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(this.@worldSizeChoice);
            return true;
        }
        if (name == PropertyName.@worldWaterSlider) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HSlider>(this.@worldWaterSlider);
            return true;
        }
        if (name == PropertyName.@worldWaterValue) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@worldWaterValue);
            return true;
        }
        if (name == PropertyName.@worldForestChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(this.@worldForestChoice);
            return true;
        }
        if (name == PropertyName.@worldMountainChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(this.@worldMountainChoice);
            return true;
        }
        if (name == PropertyName.@worldRiverChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(this.@worldRiverChoice);
            return true;
        }
        if (name == PropertyName.@worldAdvancedOptions) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@worldAdvancedOptions);
            return true;
        }
        if (name == PropertyName.@worldAdvancedToggle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldAdvancedToggle);
            return true;
        }
        if (name == PropertyName.@worldResourceChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(this.@worldResourceChoice);
            return true;
        }
        if (name == PropertyName.@worldClimateModeChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(this.@worldClimateModeChoice);
            return true;
        }
        if (name == PropertyName.@worldClimateFamilyChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@worldClimateFamilyChoice);
            return true;
        }
        if (name == PropertyName.@worldWrapChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckBox>(this.@worldWrapChoice);
            return true;
        }
        if (name == PropertyName.@worldLatitudeChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckBox>(this.@worldLatitudeChoice);
            return true;
        }
        if (name == PropertyName.@worldPreview) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.WorldMapAtlas>(this.@worldPreview);
            return true;
        }
        if (name == PropertyName.@worldPreviewStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@worldPreviewStatus);
            return true;
        }
        if (name == PropertyName.@worldAcceptUnmetTargets) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckBox>(this.@worldAcceptUnmetTargets);
            return true;
        }
        if (name == PropertyName.@worldPreviewButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldPreviewButton);
            return true;
        }
        if (name == PropertyName.@worldSelectionList) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SlotList>(this.@worldSelectionList);
            return true;
        }
        if (name == PropertyName.@worldCreateButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldCreateButton);
            return true;
        }
        if (name == PropertyName.@worldSelectButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldSelectButton);
            return true;
        }
        if (name == PropertyName.@menuLoadSaveButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@menuLoadSaveButton);
            return true;
        }
        if (name == PropertyName.@worldSaveHistoryHost) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@worldSaveHistoryHost);
            return true;
        }
        if (name == PropertyName.@worldLoadColumns) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HFlowContainer>(this.@worldLoadColumns);
            return true;
        }
        if (name == PropertyName.@worldMenuActions) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@worldMenuActions);
            return true;
        }
        if (name == PropertyName.@worldDeleteButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldDeleteButton);
            return true;
        }
        if (name == PropertyName.@listedActiveWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@listedActiveWorldId);
            return true;
        }
        if (name == PropertyName.@worldMenuBusy) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@worldMenuBusy);
            return true;
        }
        if (name == PropertyName.@worldPreviewRevision) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@worldPreviewRevision);
            return true;
        }
        if (name == PropertyName.@quitToMenuConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@quitToMenuConfirmation);
            return true;
        }
        if (name == PropertyName.@isInWorld) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@isInWorld);
            return true;
        }
        if (name == PropertyName.@returnToMainMenu) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@returnToMainMenu);
            return true;
        }
        if (name == PropertyName.@resumeWorldOnContinue) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@resumeWorldOnContinue);
            return true;
        }
        if (name == PropertyName.@mainMenuSettingsButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@mainMenuSettingsButton);
            return true;
        }
        if (name == PropertyName.@worldBackButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldBackButton);
            return true;
        }
        if (name == PropertyName.@menuQuitSeparator) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HSeparator>(this.@menuQuitSeparator);
            return true;
        }
        if (name == PropertyName.@isQuittingToMenu) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@isQuittingToMenu);
            return true;
        }
        if (name == PropertyName.@hoverReadout) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@hoverReadout);
            return true;
        }
        if (name == PropertyName.@hoverReadoutLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@hoverReadoutLabel);
            return true;
        }
        if (name == PropertyName.@hoverReadoutSwatch) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(this.@hoverReadoutSwatch);
            return true;
        }
        if (name == PropertyName.@hoverReadoutTownSiteMode) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@hoverReadoutTownSiteMode);
            return true;
        }
        if (name == PropertyName.@memoryTabs) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(this.@memoryTabs);
            return true;
        }
        if (name == PropertyName.@memoryCards) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@memoryCards);
            return true;
        }
        if (name == PropertyName.@memoryScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@memoryScroll);
            return true;
        }
        if (name == PropertyName.@memoryGap) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.MarginContainer>(this.@memoryGap);
            return true;
        }
        if (name == PropertyName.@renderedMemoryCards) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedMemoryCards);
            return true;
        }
        if (name == PropertyName.@usageScopeHint) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@usageScopeHint);
            return true;
        }
        if (name == PropertyName.@usageReads) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@usageReads);
            return true;
        }
        if (name == PropertyName.@usageLimitEdited) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@usageLimitEdited);
            return true;
        }
        if (name == PropertyName.@routineHelperSetupCheckButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@routineHelperSetupCheckButton);
            return true;
        }
        if (name == PropertyName.@routineHelperSetupCheckStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@routineHelperSetupCheckStatus);
            return true;
        }
        if (name == PropertyName.@routineHelperSetupCheckRevision) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@routineHelperSetupCheckRevision);
            return true;
        }
        if (name == PropertyName.@founderKeyEdits) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@founderKeyEdits);
            return true;
        }
        if (name == PropertyName.@agentModelKeyEdits) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@agentModelKeyEdits);
            return true;
        }
        if (name == PropertyName.@agentModelContext) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@agentModelContext);
            return true;
        }
        if (name == PropertyName.@agentModelLookup) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@agentModelLookup);
            return true;
        }
        if (name == PropertyName.@modLibraryPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@modLibraryPanel);
            return true;
        }
        if (name == PropertyName.@modLibraryCards) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@modLibraryCards);
            return true;
        }
        if (name == PropertyName.@allOrdersButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@allOrdersButton);
            return true;
        }
        if (name == PropertyName.@ordersPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@ordersPanel);
            return true;
        }
        if (name == PropertyName.@ordersReaderTitle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@ordersReaderTitle);
            return true;
        }
        if (name == PropertyName.@ordersReaderText) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.RichTextLabel>(this.@ordersReaderText);
            return true;
        }
        if (name == PropertyName.@renderedOrdersReader) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedOrdersReader);
            return true;
        }
        if (name == PropertyName.@pendingSubmissionPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@pendingSubmissionPanel);
            return true;
        }
        if (name == PropertyName.@reviewPendingSubmissionButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@reviewPendingSubmissionButton);
            return true;
        }
        if (name == PropertyName.@pendingRecoveryInProgress) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@pendingRecoveryInProgress);
            return true;
        }
        if (name == PropertyName.@unloadedPendingSubmission) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@unloadedPendingSubmission);
            return true;
        }
        if (name == PropertyName.@statusIcon) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(this.@statusIcon);
            return true;
        }
        if (name == PropertyName.@profilePeople) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@profilePeople);
            return true;
        }
        if (name == PropertyName.@renderedProfilePeople) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedProfilePeople);
            return true;
        }
        if (name == PropertyName.@founderModelSetupCheckButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@founderModelSetupCheckButton);
            return true;
        }
        if (name == PropertyName.@founderModelSetupCheckStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@founderModelSetupCheckStatus);
            return true;
        }
        if (name == PropertyName.@agentModelSetupCheckButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@agentModelSetupCheckButton);
            return true;
        }
        if (name == PropertyName.@agentModelSetupCheckStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@agentModelSetupCheckStatus);
            return true;
        }
        if (name == PropertyName.@agentModelSetupCheckContext) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@agentModelSetupCheckContext);
            return true;
        }
        if (name == PropertyName.@founderModelSetupCheckRevision) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@founderModelSetupCheckRevision);
            return true;
        }
        if (name == PropertyName.@agentModelSetupCheckRevision) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@agentModelSetupCheckRevision);
            return true;
        }
        if (name == PropertyName.@recoveryCleanupButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@recoveryCleanupButton);
            return true;
        }
        if (name == PropertyName.@recoveryKeepCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.SpinBox>(this.@recoveryKeepCount);
            return true;
        }
        if (name == PropertyName.@recoveryCleanupConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@recoveryCleanupConfirmation);
            return true;
        }
        if (name == PropertyName.@recoveryCleanupSummary) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@recoveryCleanupSummary);
            return true;
        }
        if (name == PropertyName.@agentListWantedHeight) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@agentListWantedHeight);
            return true;
        }
        if (name == PropertyName.@eventLogWantedHeight) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@eventLogWantedHeight);
            return true;
        }
        if (name == PropertyName.@hudListsRefitQueued) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@hudListsRefitQueued);
            return true;
        }
        if (name == PropertyName.@saveDiskWarningPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@saveDiskWarningPanel);
            return true;
        }
        if (name == PropertyName.@saveDiskWarningLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@saveDiskWarningLabel);
            return true;
        }
        if (name == PropertyName.@manualSaveDiskWarning) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@manualSaveDiskWarning);
            return true;
        }
        if (name == PropertyName.@lastDiskSpaceReadMsec) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@lastDiskSpaceReadMsec);
            return true;
        }
        if (name == PropertyName.@diskSpaceReadPending) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@diskSpaceReadPending);
            return true;
        }
        if (name == PropertyName.@manualSaveOverlay) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@manualSaveOverlay);
            return true;
        }
        if (name == PropertyName.@manualSaveCard) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@manualSaveCard);
            return true;
        }
        if (name == PropertyName.@manualSaveHeading) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@manualSaveHeading);
            return true;
        }
        if (name == PropertyName.@manualSaveStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@manualSaveStatus);
            return true;
        }
        if (name == PropertyName.@manualSaveName) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@manualSaveName);
            return true;
        }
        if (name == PropertyName.@manualSaveCreateButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@manualSaveCreateButton);
            return true;
        }
        if (name == PropertyName.@manualSaveBackButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@manualSaveBackButton);
            return true;
        }
        if (name == PropertyName.@manualSaveList) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SlotList>(this.@manualSaveList);
            return true;
        }
        if (name == PropertyName.@manualSaveHistory) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@manualSaveHistory);
            return true;
        }
        if (name == PropertyName.@manualSaveActions) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@manualSaveActions);
            return true;
        }
        if (name == PropertyName.@manualSaveBody) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@manualSaveBody);
            return true;
        }
        if (name == PropertyName.@worldHistoryLoading) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@worldHistoryLoading);
            return true;
        }
        if (name == PropertyName.@worldHistoryLoaded) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@worldHistoryLoaded);
            return true;
        }
        if (name == PropertyName.@manualSaveNewBox) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@manualSaveNewBox);
            return true;
        }
        if (name == PropertyName.@manualSaveLoadButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@manualSaveLoadButton);
            return true;
        }
        if (name == PropertyName.@manualSaveOverwriteButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@manualSaveOverwriteButton);
            return true;
        }
        if (name == PropertyName.@manualSaveLoadConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@manualSaveLoadConfirmation);
            return true;
        }
        if (name == PropertyName.@manualSaveOverwriteConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@manualSaveOverwriteConfirmation);
            return true;
        }
        if (name == PropertyName.@worldModelLoadConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@worldModelLoadConfirmation);
            return true;
        }
        if (name == PropertyName.@manualSaveDeleteButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@manualSaveDeleteButton);
            return true;
        }
        if (name == PropertyName.@deletionConfirmation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ConfirmationDialog>(this.@deletionConfirmation);
            return true;
        }
        if (name == PropertyName.@listedSaveWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@listedSaveWorldId);
            return true;
        }
        if (name == PropertyName.@pendingOverwriteSaveId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@pendingOverwriteSaveId);
            return true;
        }
        if (name == PropertyName.@manualSaveLoadMode) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@manualSaveLoadMode);
            return true;
        }
        if (name == PropertyName.@manualSaveTimeline) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SaveTimeline>(this.@manualSaveTimeline);
            return true;
        }
        if (name == PropertyName.@manualSaveViewRow) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@manualSaveViewRow);
            return true;
        }
        if (name == PropertyName.@manualSaveKey) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@manualSaveKey);
            return true;
        }
        if (name == PropertyName.@manualSaveViewLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@manualSaveViewLabel);
            return true;
        }
        if (name == PropertyName.@manualSaveViewChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(this.@manualSaveViewChoice);
            return true;
        }
        if (name == PropertyName.@manualSaveSectionLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@manualSaveSectionLabel);
            return true;
        }
        if (name == PropertyName.@manualSaveDetails) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@manualSaveDetails);
            return true;
        }
        if (name == PropertyName.@manualSaveShowsList) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@manualSaveShowsList);
            return true;
        }
        if (name == PropertyName.@autosaveEnabledToggle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckBox>(this.@autosaveEnabledToggle);
            return true;
        }
        if (name == PropertyName.@autosaveIntervalChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@autosaveIntervalChoice);
            return true;
        }
        if (name == PropertyName.@autosaveRotationChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@autosaveRotationChoice);
            return true;
        }
        if (name == PropertyName.@autosaveApplyButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@autosaveApplyButton);
            return true;
        }
        if (name == PropertyName.@autosaveSettingsStatus) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@autosaveSettingsStatus);
            return true;
        }
        if (name == PropertyName.@autosaveSettingsLoaded) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@autosaveSettingsLoaded);
            return true;
        }
        if (name == PropertyName.@autosaveSettingsWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@autosaveSettingsWorldId);
            return true;
        }
        if (name == PropertyName.@autosaveSettingsGeneration) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@autosaveSettingsGeneration);
            return true;
        }
        if (name == PropertyName.@controlsPanel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@controlsPanel);
            return true;
        }
        if (name == PropertyName.@controlsColumns) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@controlsColumns);
            return true;
        }
        if (name == PropertyName.@renderedControlsTheme) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedControlsTheme);
            return true;
        }
        if (name == PropertyName.@startupRecoveryCard) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@startupRecoveryCard);
            return true;
        }
        if (name == PropertyName.@startupRecoveryExplanation) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@startupRecoveryExplanation);
            return true;
        }
        if (name == PropertyName.@startupRecoverySave) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@startupRecoverySave);
            return true;
        }
        if (name == PropertyName.@startupRecoveryButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@startupRecoveryButton);
            return true;
        }
        if (name == PropertyName.@startupRecoveryDiskWarning) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@startupRecoveryDiskWarning);
            return true;
        }
        if (name == PropertyName.@startupRecoveryRetry) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@startupRecoveryRetry);
            return true;
        }
        if (name == PropertyName.@startupRecoveryReadRevision) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@startupRecoveryReadRevision);
            return true;
        }
        if (name == PropertyName.@startupRecoveryBusy) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@startupRecoveryBusy);
            return true;
        }
        if (name == PropertyName.@tileSwatch) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(this.@tileSwatch);
            return true;
        }
        if (name == PropertyName.@tileTitle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@tileTitle);
            return true;
        }
        if (name == PropertyName.@tileSubtitle) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@tileSubtitle);
            return true;
        }
        if (name == PropertyName.@tileFacts) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.GridContainer>(this.@tileFacts);
            return true;
        }
        if (name == PropertyName.@tileThingsHeading) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@tileThingsHeading);
            return true;
        }
        if (name == PropertyName.@tileThings) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@tileThings);
            return true;
        }
        if (name == PropertyName.@tileDetailsScroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@tileDetailsScroll);
            return true;
        }
        if (name == PropertyName.@tileDetailsContent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@tileDetailsContent);
            return true;
        }
        if (name == PropertyName.@worldEditTool) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@worldEditTool);
            return true;
        }
        if (name == PropertyName.@worldEditPick) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@worldEditPick);
            return true;
        }
        if (name == PropertyName.@worldEditAdvanced) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckBox>(this.@worldEditAdvanced);
            return true;
        }
        if (name == PropertyName.@worldEditPaint) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckBox>(this.@worldEditPaint);
            return true;
        }
        if (name == PropertyName.@worldEditClear) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@worldEditClear);
            return true;
        }
        if (name == PropertyName.@worldEditAdvancedBody) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@worldEditAdvancedBody);
            return true;
        }
        if (name == PropertyName.@worldEditPreview) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.WorldEditPreviewLayer>(this.@worldEditPreview);
            return true;
        }
        if (name == PropertyName.@worldEditWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@worldEditWorldId);
            return true;
        }
        if (name == PropertyName.@worldStatsPage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@worldStatsPage);
            return true;
        }
        if (name == PropertyName.@townExtras) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@townExtras);
            return true;
        }
        if (name == PropertyName.@townsGap) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.MarginContainer>(this.@townsGap);
            return true;
        }
        if (name == PropertyName.@renderedWorldStats) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedWorldStats);
            return true;
        }
        if (name == PropertyName.@renderedWorldToday) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedWorldToday);
            return true;
        }
        if (name == PropertyName.@worldTodayCard) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(this.@worldTodayCard);
            return true;
        }
        if (name == PropertyName.@worldCounts) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@worldCounts);
            return true;
        }
        if (name == PropertyName.@renderedTownExtras) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@renderedTownExtras);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@conversationPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@conversationReaderTitle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@conversationReaderStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@conversationReaderSummary, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@conversationHistoryButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@conversationHistoryText, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@conversationReadWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@openConversationId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@openConversationAgentId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@conversationHistoryExpanded, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentListCards, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedAgentListWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedAgentListTheme, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@selectedAgentModelGap, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentProfilePanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentPortraitFrame, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentPortraitTexture, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@renameToggleButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@renameRow, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profileActivityLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profileOrderLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profileFindButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profileCloseButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profileMeters, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profileFullnessMeter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profileWarmthMeter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profileDietMeter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profileIllnessMeter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@thoughtsHeading, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@speakSection, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@instructionHistory, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentOverviewScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentOverviewGap, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@agentProfileFitQueued, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@instructionSuggestButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@instructionOrderButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@instructionQueueToggle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@instructionCancelButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@thoughtsInset, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@readThoughtsButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@thoughtsPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@thoughtsReaderTitle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@thoughtsReaderText, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedThoughtsReader, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@agentProfileRequested, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@measuredFirstAgentProfile, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quickCardNameLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quickCardActivityLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quickCardOrderLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quickCardMeters, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quickFullnessMeter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quickWarmthMeter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quickIllnessMeter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quickCardProfileButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quickCardSpeakButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@renderedAgentCardTheme, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@apiKeysPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@apiKeyProviderChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@apiKeyLabelInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@apiKeyInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@saveApiKeyButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@apiKeysStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@savedApiKeys, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@savedApiKeyChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@deleteApiKeyButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@apiKeysRead, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingQuickCard, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingDetailsPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingQuickHeader, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingDetailsHeader, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingQuickStorage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingDetailsStorage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingDetailsButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingQuickStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingFacts, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingDetailsScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingDetailsContent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingWorkSection, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingWorkRows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingRecipeSection, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingRecipeRows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedBuildingRecipes, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingPeopleSection, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingPeopleSummary, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingPeopleText, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingManagementSection, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingManagementNote, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingManagementChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingManagementApply, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingRemoveButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingRemoveConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@pendingBuildingRemovalWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedBuildingManagementWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedBuildingManagementId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@selectedBuildingId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@buildingDetailsRequested, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedBuildingStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedBuildingWork, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingStorageHistorySection, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingStorageHistoryRows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedBuildingStorageHistory, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@cameraGliding, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)5, name: PropertyName.@cameraGlideFrom, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)5, name: PropertyName.@cameraGlideTo, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@cameraGlideElapsed, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@cameraZooming, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@cameraZoomFrom, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@cameraZoomTo, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@cameraZoomElapsed, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)5, name: PropertyName.@cameraZoomAnchor, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)5, name: PropertyName.@cameraZoomPoint, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@CameraMoving, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@renderedObservationGeneration, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@settingUpLocalDevice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@uiLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@statusLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@statusToast, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@settingsButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@modLibraryButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@gameSettingsCategoryButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldSettingsCategoryButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@gameSettingsContent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldSettingsContent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@settingsScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@serverUrlInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@usageLimitPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelRoleChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelTargetChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelProviderChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelCredentialChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelPicker, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelThinkingChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelApiKeyInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelCredentialLabelInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelConfigurationStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelCredentialHint, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@usageMeterStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@usageAttemptLimitInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@applyUsageLimitButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@grantUsageCallsButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@refreshUsageButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@saveAgentModelProviderButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@forgetAgentModelCredentialButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@deleteAgentModelCredentialSlotButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@openModelSettingsButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@refreshAgentModelProviderButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@topBar, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mapButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldInfoButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@clockLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentsButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@eventLogButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@topBarShade, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@terrainLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@weatherLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@nightLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@buildingCompletionLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@goldenHourLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@graveLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@nightLightsLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@smokeLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@storedStockLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@terrainWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mapCanvas, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mapStage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMapPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMapAtlas, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@objectLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@entityLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentsSummaryLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentQuickCard, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@selectedAgentOverview, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@selectedAgentModelScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@selectedAgentModelContent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@modelSettingsButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@selectedActorNameLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@renameAgentInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@renameAgentButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@selectedActorSummaryLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@selectedActorConditionLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@clearSelectionButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@findAgentButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@familyTreeButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@familyTreePanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@familyTreeView, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@familyTreeScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@familyTreeStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentList, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentDetails, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@privateThoughtHistory, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@memoriesButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@memoriesPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@eventLog, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentsPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@eventLogPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldInfoPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@selectedTilePanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@selectedTileText, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@pauseMenuPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuActions, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@settingsPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuShade, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@appBackdrop, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldBackdrop, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@themeChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@cloudHazeToggle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@lightningToggle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuHeadingLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuCloseButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuResumeButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quitGameButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quitGameConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@fullscreenToggle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@windowSizeChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@clockFormatChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@dateFormatChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agingOverrideChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@routineHelperChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@routineHelperModelPicker, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@routineHelperKeyChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@applyRoutineHelperButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@observedRoutineHelperContext, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@applyAgingOverrideButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@lastAgingOverrideWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@pauseButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@instructionText, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@submitInstructionButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@pendingSubmissionLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@retryPendingSubmissionButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@forgetPendingSubmissionButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditKind, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditValue, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditSecondaryValue, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditX, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditY, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditRenewable, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@submitWorldEditButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditHintLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@pairingApprovalId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@pairingApprovalCode, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@approvePairingButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@refreshDevicesButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@pairedDeviceList, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@revokeDeviceId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@revokeDeviceButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@usagePauseWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@wasObservedPaused, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@selectedAgentId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renamingAgentId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@isRefreshing, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@successfulRefreshCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@isOwnerAction, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@registeredEndpointInvalid, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@menuPausedWorld, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@menuPauseConfirmed, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@pendingMenuResumes, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@pendingMenuResumeGeneration, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@currentTileSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@cameraZoom, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@minimumCameraZoom, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@maximumCameraZoom, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)5, name: PropertyName.@cameraCenterTiles, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@cameraWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@draggingMap, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedEventLog, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@statusToastKind, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@statusToastShownAtMsec, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerEditAgent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerEditHint, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerEditKind, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerEditValue, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerEditOther, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerEditAmount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerEditApply, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@developerEditPeopleKey, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@DeveloperEditOperation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerBody, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerTileLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerFrameLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerTickLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerRefusedActionLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerAgentCountLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerAgentList, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerPathToggle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerRouteLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@plannedPathLayer, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@developerFrameMilliseconds, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@developerReadoutAge, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@developerAgentListKey, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@DatesShowSeason, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@eventRows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@eventScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@familyLegend, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@filtersButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@filtersPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@townBorderFilter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@householdPropertyFilter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@townLandTitleFilter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@householdLandUseFilter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@disputedLandFilter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@ShowsPlacementOverlays, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderSetupButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@townSiteButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@moveFounderButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@undoFounderButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@addAgentButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@startWorldButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderSetupPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderSetupHint, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderPlacementIcon, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderProviderChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderCredentialChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderModelPicker, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderThinkingChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderKeyLabelInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderApiKeyInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@placingAddedAgent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@choosingFirstTownSite, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@movingFounderId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@generationSettingsRows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@generationSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@generationClimate, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@generationWrapping, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@generationSeed, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@generationSettingsHint, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hudBar, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hudRows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hudLeft, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hudTime, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hudRight, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderHudRow, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hudFounders, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@climateBox, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@seasonIcon, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@seasonLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@weatherIcon, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@weatherLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@eventLogBadge, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentsWarning, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldInfoTownsTab, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldInfoWorldTab, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@townsScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@townsPage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@townList, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedTownList, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@eventLogWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@lastSeenEventId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@newEventsAfter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@unreadEvents, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@HudTop, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@WorldInfoShowsTowns, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@keyboardNavigation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@keyboardNavigationKey, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@refreshingKeyboardMapSelection, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quitToLauncherButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quitToLauncherConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@launcherStartFailure, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@openInVersionConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@pendingOpenVersion, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@pendingOpenWorld, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@failedLauncherVersion, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@failedLauncherWorld, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@requestedWorldToSelect, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@launcherPath, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@launcherPathRead, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@DeveloperMode, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@LauncherPath, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@localServerStarting, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@localServerFailure, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@localServerStopFailure, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@isQuittingGame, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@retryLauncherVersion, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@retryLauncherWorld, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@retryChooseCurrentWorld, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@mainMenuNavigationRevision, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuOverlay, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuBackground, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuBackdrop, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuStack, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuLogo, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuCenter, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuCard, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuContinueButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuNewButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuLoadButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuQuitToMainButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuSaveWorldButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMenuOverlay, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMenuCard, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMenuScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMenuBody, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMenuColumns, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldPreviewFrame, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMenuHeading, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMenuStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldNameInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldSeedInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldSizeChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldWaterSlider, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldWaterValue, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldForestChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMountainChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldRiverChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldAdvancedOptions, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldAdvancedToggle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldResourceChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldClimateModeChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldClimateFamilyChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldWrapChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldLatitudeChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldPreview, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldPreviewStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldAcceptUnmetTargets, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldPreviewButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldSelectionList, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldCreateButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldSelectButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuLoadSaveButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldSaveHistoryHost, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldLoadColumns, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldMenuActions, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldDeleteButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@listedActiveWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@worldMenuBusy, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@worldPreviewRevision, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@quitToMenuConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@isInWorld, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@returnToMainMenu, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@resumeWorldOnContinue, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@mainMenuSettingsButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldBackButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@menuQuitSeparator, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@isQuittingToMenu, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hoverReadout, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hoverReadoutLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hoverReadoutSwatch, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@hoverReadoutTownSiteMode, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@memoryTabs, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@memoryCards, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@memoryScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@memoryGap, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedMemoryCards, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@usageScopeHint, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@usageReads, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@usageLimitEdited, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@routineHelperSetupCheckButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@routineHelperSetupCheckStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@routineHelperSetupCheckRevision, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@founderKeyEdits, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@agentModelKeyEdits, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@agentModelContext, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@agentModelLookup, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@modLibraryPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@modLibraryCards, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@allOrdersButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@ordersPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@ordersReaderTitle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@ordersReaderText, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedOrdersReader, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@PauseMenuPageOpen, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@pendingSubmissionPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@reviewPendingSubmissionButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@pendingRecoveryInProgress, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@unloadedPendingSubmission, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@statusIcon, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@profilePeople, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedProfilePeople, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderModelSetupCheckButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@founderModelSetupCheckStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelSetupCheckButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@agentModelSetupCheckStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@agentModelSetupCheckContext, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@founderModelSetupCheckRevision, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@agentModelSetupCheckRevision, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@recoveryCleanupButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@recoveryKeepCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@recoveryCleanupConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@recoveryCleanupSummary, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@agentListWantedHeight, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@eventLogWantedHeight, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@hudListsRefitQueued, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)5, name: PropertyName.@UiSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@saveDiskWarningPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@saveDiskWarningLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveDiskWarning, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@lastDiskSpaceReadMsec, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@diskSpaceReadPending, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveOverlay, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveCard, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveHeading, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveName, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveCreateButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveBackButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveList, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveHistory, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveActions, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveBody, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@WorldHistoryEmbedded, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@worldHistoryLoading, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@worldHistoryLoaded, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveNewBox, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveLoadButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveOverwriteButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveLoadConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveOverwriteConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldModelLoadConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveDeleteButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@deletionConfirmation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@listedSaveWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@pendingOverwriteSaveId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@manualSaveLoadMode, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveTimeline, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveViewRow, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveKey, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveViewLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveViewChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveSectionLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@manualSaveDetails, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@manualSaveShowsList, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@autosaveEnabledToggle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@autosaveIntervalChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@autosaveRotationChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@autosaveApplyButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@autosaveSettingsStatus, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@autosaveSettingsLoaded, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@autosaveSettingsWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@autosaveSettingsGeneration, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@ManualSaveTimelineShown, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@ListedSaveWorldIsActive, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@controlsPanel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@controlsColumns, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedControlsTheme, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@startupRecoveryCard, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@startupRecoveryExplanation, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@startupRecoverySave, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@startupRecoveryButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@startupRecoveryDiskWarning, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@startupRecoveryRetry, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@startupRecoveryReadRevision, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@startupRecoveryBusy, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tileSwatch, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tileTitle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tileSubtitle, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tileFacts, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tileThingsHeading, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tileThings, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tileDetailsScroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@tileDetailsContent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditTool, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditPick, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditAdvanced, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditPaint, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditClear, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditAdvancedBody, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldEditPreview, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@worldEditWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@CanPickWorldEditTile, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldStatsPage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@townExtras, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@townsGap, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedWorldStats, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedWorldToday, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldTodayCard, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@worldCounts, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@renderedTownExtras, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
