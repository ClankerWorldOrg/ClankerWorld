﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class WorldMapAtlas
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'VisibleTiles' property.
        /// </summary>
        public new static readonly global::Godot.StringName @VisibleTiles = "VisibleTiles";
        /// <summary>
        /// Cached name for the 'WrapsEastWest' property.
        /// </summary>
        public new static readonly global::Godot.StringName @WrapsEastWest = "WrapsEastWest";
        /// <summary>
        /// Cached name for the 'ShowCameraBounds' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowCameraBounds = "ShowCameraBounds";
        /// <summary>
        /// Cached name for the 'Backdrop' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Backdrop = "Backdrop";
        /// <summary>
        /// Cached name for the 'AtlasEdge' property.
        /// </summary>
        public new static readonly global::Godot.StringName @AtlasEdge = "AtlasEdge";
        /// <summary>
        /// Cached name for the 'TownMarkerCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @TownMarkerCount = "TownMarkerCount";
        /// <summary>
        /// Cached name for the 'AgentMarkerCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @AgentMarkerCount = "AgentMarkerCount";
        /// <summary>
        /// Cached name for the 'atlasTexture' field.
        /// </summary>
        public new static readonly global::Godot.StringName @atlasTexture = "atlasTexture";
        /// <summary>
        /// Cached name for the 'mapWidth' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mapWidth = "mapWidth";
        /// <summary>
        /// Cached name for the 'mapHeight' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mapHeight = "mapHeight";
        /// <summary>
        /// Cached name for the 'visibleTiles' field.
        /// </summary>
        public new static readonly global::Godot.StringName @visibleTiles = "visibleTiles";
        /// <summary>
        /// Cached name for the 'dragging' field.
        /// </summary>
        public new static readonly global::Godot.StringName @dragging = "dragging";
        /// <summary>
        /// Cached name for the 'dragOffset' field.
        /// </summary>
        public new static readonly global::Godot.StringName @dragOffset = "dragOffset";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@WrapsEastWest) {
            this.@WrapsEastWest = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@ShowCameraBounds) {
            this.@ShowCameraBounds = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@Backdrop) {
            this.@Backdrop = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(value);
            return true;
        }
        if (name == PropertyName.@AtlasEdge) {
            this.@AtlasEdge = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(value);
            return true;
        }
        if (name == PropertyName.@atlasTexture) {
            this.@atlasTexture = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Texture2D>(value);
            return true;
        }
        if (name == PropertyName.@mapWidth) {
            this.@mapWidth = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@mapHeight) {
            this.@mapHeight = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@visibleTiles) {
            this.@visibleTiles = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(value);
            return true;
        }
        if (name == PropertyName.@dragging) {
            this.@dragging = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@dragOffset) {
            this.@dragOffset = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@VisibleTiles) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@VisibleTiles);
            return true;
        }
        if (name == PropertyName.@WrapsEastWest) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@WrapsEastWest);
            return true;
        }
        if (name == PropertyName.@ShowCameraBounds) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@ShowCameraBounds);
            return true;
        }
        if (name == PropertyName.@Backdrop) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(this.@Backdrop);
            return true;
        }
        if (name == PropertyName.@AtlasEdge) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(this.@AtlasEdge);
            return true;
        }
        if (name == PropertyName.@TownMarkerCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@TownMarkerCount);
            return true;
        }
        if (name == PropertyName.@AgentMarkerCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@AgentMarkerCount);
            return true;
        }
        if (name == PropertyName.@atlasTexture) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Texture2D>(this.@atlasTexture);
            return true;
        }
        if (name == PropertyName.@mapWidth) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@mapWidth);
            return true;
        }
        if (name == PropertyName.@mapHeight) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@mapHeight);
            return true;
        }
        if (name == PropertyName.@visibleTiles) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@visibleTiles);
            return true;
        }
        if (name == PropertyName.@dragging) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@dragging);
            return true;
        }
        if (name == PropertyName.@dragOffset) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2>(this.@dragOffset);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@atlasTexture, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@mapWidth, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@mapHeight, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@visibleTiles, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@dragging, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)5, name: PropertyName.@dragOffset, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@VisibleTiles, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@WrapsEastWest, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@ShowCameraBounds, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)20, name: PropertyName.@Backdrop, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)20, name: PropertyName.@AtlasEdge, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@TownMarkerCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@AgentMarkerCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
