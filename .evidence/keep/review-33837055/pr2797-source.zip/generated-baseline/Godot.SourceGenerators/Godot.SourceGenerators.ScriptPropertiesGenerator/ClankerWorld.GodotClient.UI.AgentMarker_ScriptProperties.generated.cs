﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class AgentMarker
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'WaitingMarkerVisible' property.
        /// </summary>
        public new static readonly global::Godot.StringName @WaitingMarkerVisible = "WaitingMarkerVisible";
        /// <summary>
        /// Cached name for the 'WaitingFrame' property.
        /// </summary>
        public new static readonly global::Godot.StringName @WaitingFrame = "WaitingFrame";
        /// <summary>
        /// Cached name for the 'Caption' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Caption = "Caption";
        /// <summary>
        /// Cached name for the 'Selected' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Selected = "Selected";
        /// <summary>
        /// Cached name for the 'ConversationBadgeVisible' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ConversationBadgeVisible = "ConversationBadgeVisible";
        /// <summary>
        /// Cached name for the 'ConversationUnread' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ConversationUnread = "ConversationUnread";
        /// <summary>
        /// Cached name for the 'ConversationBadgeBounds' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ConversationBadgeBounds = "ConversationBadgeBounds";
        /// <summary>
        /// Cached name for the 'Variant' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Variant = "Variant";
        /// <summary>
        /// Cached name for the 'Stage' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Stage = "Stage";
        /// <summary>
        /// Cached name for the 'Facing' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Facing = "Facing";
        /// <summary>
        /// Cached name for the 'Activity' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Activity = "Activity";
        /// <summary>
        /// Cached name for the 'Swimming' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Swimming = "Swimming";
        /// <summary>
        /// Cached name for the 'Frame' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Frame = "Frame";
        /// <summary>
        /// Cached name for the 'NameShown' property.
        /// </summary>
        public new static readonly global::Godot.StringName @NameShown = "NameShown";
        /// <summary>
        /// Cached name for the 'NameplateText' property.
        /// </summary>
        public new static readonly global::Godot.StringName @NameplateText = "NameplateText";
        /// <summary>
        /// Cached name for the 'caption' field.
        /// </summary>
        public new static readonly global::Godot.StringName @caption = "caption";
        /// <summary>
        /// Cached name for the 'selected' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selected = "selected";
        /// <summary>
        /// Cached name for the 'hovered' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hovered = "hovered";
        /// <summary>
        /// Cached name for the 'conversationBadgeVisible' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationBadgeVisible = "conversationBadgeVisible";
        /// <summary>
        /// Cached name for the 'conversationUnread' field.
        /// </summary>
        public new static readonly global::Godot.StringName @conversationUnread = "conversationUnread";
        /// <summary>
        /// Cached name for the 'variant' field.
        /// </summary>
        public new static readonly global::Godot.StringName @variant = "variant";
        /// <summary>
        /// Cached name for the 'stage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @stage = "stage";
        /// <summary>
        /// Cached name for the 'facing' field.
        /// </summary>
        public new static readonly global::Godot.StringName @facing = "facing";
        /// <summary>
        /// Cached name for the 'activity' field.
        /// </summary>
        public new static readonly global::Godot.StringName @activity = "activity";
        /// <summary>
        /// Cached name for the 'swimming' field.
        /// </summary>
        public new static readonly global::Godot.StringName @swimming = "swimming";
        /// <summary>
        /// Cached name for the 'swimmingSeconds' field.
        /// </summary>
        public new static readonly global::Godot.StringName @swimmingSeconds = "swimmingSeconds";
        /// <summary>
        /// Cached name for the 'step' field.
        /// </summary>
        public new static readonly global::Godot.StringName @step = "step";
        /// <summary>
        /// Cached name for the 'motionWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @motionWorldId = "motionWorldId";
        /// <summary>
        /// Cached name for the 'modelWaiting' field.
        /// </summary>
        public new static readonly global::Godot.StringName @modelWaiting = "modelWaiting";
        /// <summary>
        /// Cached name for the 'modelWaitSeconds' field.
        /// </summary>
        public new static readonly global::Godot.StringName @modelWaitSeconds = "modelWaitSeconds";
        /// <summary>
        /// Cached name for the 'modelWaitWorldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @modelWaitWorldId = "modelWaitWorldId";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@Caption) {
            this.@Caption = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@Selected) {
            this.@Selected = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@ConversationBadgeVisible) {
            this.@ConversationBadgeVisible = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@ConversationUnread) {
            this.@ConversationUnread = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@Variant) {
            this.@Variant = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@Stage) {
            this.@Stage = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@Activity) {
            this.@Activity = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.AgentFrame>(value);
            return true;
        }
        if (name == PropertyName.@Swimming) {
            this.@Swimming = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@caption) {
            this.@caption = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@selected) {
            this.@selected = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@hovered) {
            this.@hovered = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@conversationBadgeVisible) {
            this.@conversationBadgeVisible = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@conversationUnread) {
            this.@conversationUnread = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@variant) {
            this.@variant = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@stage) {
            this.@stage = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@facing) {
            this.@facing = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@activity) {
            this.@activity = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.AgentFrame>(value);
            return true;
        }
        if (name == PropertyName.@swimming) {
            this.@swimming = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@swimmingSeconds) {
            this.@swimmingSeconds = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@step) {
            this.@step = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.AgentFrame>(value);
            return true;
        }
        if (name == PropertyName.@motionWorldId) {
            this.@motionWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@modelWaiting) {
            this.@modelWaiting = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@modelWaitSeconds) {
            this.@modelWaitSeconds = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@modelWaitWorldId) {
            this.@modelWaitWorldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@WaitingMarkerVisible) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@WaitingMarkerVisible);
            return true;
        }
        if (name == PropertyName.@WaitingFrame) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@WaitingFrame);
            return true;
        }
        if (name == PropertyName.@Caption) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Caption);
            return true;
        }
        if (name == PropertyName.@Selected) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@Selected);
            return true;
        }
        if (name == PropertyName.@ConversationBadgeVisible) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@ConversationBadgeVisible);
            return true;
        }
        if (name == PropertyName.@ConversationUnread) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@ConversationUnread);
            return true;
        }
        if (name == PropertyName.@ConversationBadgeBounds) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@ConversationBadgeBounds);
            return true;
        }
        if (name == PropertyName.@Variant) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Variant);
            return true;
        }
        if (name == PropertyName.@Stage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Stage);
            return true;
        }
        if (name == PropertyName.@Facing) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Facing);
            return true;
        }
        if (name == PropertyName.@Activity) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.AgentFrame>(this.@Activity);
            return true;
        }
        if (name == PropertyName.@Swimming) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@Swimming);
            return true;
        }
        if (name == PropertyName.@Frame) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.AgentFrame>(this.@Frame);
            return true;
        }
        if (name == PropertyName.@NameShown) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@NameShown);
            return true;
        }
        if (name == PropertyName.@NameplateText) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@NameplateText);
            return true;
        }
        if (name == PropertyName.@caption) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@caption);
            return true;
        }
        if (name == PropertyName.@selected) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@selected);
            return true;
        }
        if (name == PropertyName.@hovered) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@hovered);
            return true;
        }
        if (name == PropertyName.@conversationBadgeVisible) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@conversationBadgeVisible);
            return true;
        }
        if (name == PropertyName.@conversationUnread) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@conversationUnread);
            return true;
        }
        if (name == PropertyName.@variant) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@variant);
            return true;
        }
        if (name == PropertyName.@stage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@stage);
            return true;
        }
        if (name == PropertyName.@facing) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@facing);
            return true;
        }
        if (name == PropertyName.@activity) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.AgentFrame>(this.@activity);
            return true;
        }
        if (name == PropertyName.@swimming) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@swimming);
            return true;
        }
        if (name == PropertyName.@swimmingSeconds) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@swimmingSeconds);
            return true;
        }
        if (name == PropertyName.@step) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.AgentFrame>(this.@step);
            return true;
        }
        if (name == PropertyName.@motionWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@motionWorldId);
            return true;
        }
        if (name == PropertyName.@modelWaiting) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@modelWaiting);
            return true;
        }
        if (name == PropertyName.@modelWaitSeconds) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@modelWaitSeconds);
            return true;
        }
        if (name == PropertyName.@modelWaitWorldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@modelWaitWorldId);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@caption, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@selected, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@hovered, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@conversationBadgeVisible, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@conversationUnread, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@variant, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@stage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@facing, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@activity, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@swimming, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@swimmingSeconds, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@step, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@motionWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@modelWaiting, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@modelWaitSeconds, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@modelWaitWorldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@WaitingMarkerVisible, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@WaitingFrame, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Caption, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@Selected, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@ConversationBadgeVisible, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@ConversationUnread, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@ConversationBadgeBounds, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Variant, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Stage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Facing, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Activity, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@Swimming, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Frame, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@NameShown, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@NameplateText, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
