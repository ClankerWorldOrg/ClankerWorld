﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class NightLightsLayer
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'source' field.
        /// </summary>
        public new static readonly global::Godot.StringName @source = "source";
        /// <summary>
        /// Cached name for the 'night' field.
        /// </summary>
        public new static readonly global::Godot.StringName @night = "night";
        /// <summary>
        /// Cached name for the 'wrapsEastWest' field.
        /// </summary>
        public new static readonly global::Godot.StringName @wrapsEastWest = "wrapsEastWest";
        /// <summary>
        /// Cached name for the 'drawnCamera' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnCamera = "drawnCamera";
        /// <summary>
        /// Cached name for the 'drawnTileSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnTileSize = "drawnTileSize";
        /// <summary>
        /// Cached name for the 'drawnDarkness' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnDarkness = "drawnDarkness";
        /// <summary>
        /// Cached name for the 'clock' field.
        /// </summary>
        public new static readonly global::Godot.StringName @clock = "clock";
        /// <summary>
        /// Cached name for the 'drawnTime' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnTime = "drawnTime";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@source) {
            this.@source = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(value);
            return true;
        }
        if (name == PropertyName.@night) {
            this.@night = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.NightLayer>(value);
            return true;
        }
        if (name == PropertyName.@wrapsEastWest) {
            this.@wrapsEastWest = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@drawnCamera) {
            this.@drawnCamera = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(value);
            return true;
        }
        if (name == PropertyName.@drawnTileSize) {
            this.@drawnTileSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@drawnDarkness) {
            this.@drawnDarkness = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@clock) {
            this.@clock = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@drawnTime) {
            this.@drawnTime = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@source) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@source);
            return true;
        }
        if (name == PropertyName.@night) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.NightLayer>(this.@night);
            return true;
        }
        if (name == PropertyName.@wrapsEastWest) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@wrapsEastWest);
            return true;
        }
        if (name == PropertyName.@drawnCamera) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@drawnCamera);
            return true;
        }
        if (name == PropertyName.@drawnTileSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@drawnTileSize);
            return true;
        }
        if (name == PropertyName.@drawnDarkness) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@drawnDarkness);
            return true;
        }
        if (name == PropertyName.@clock) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@clock);
            return true;
        }
        if (name == PropertyName.@drawnTime) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@drawnTime);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@source, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@night, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@wrapsEastWest, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@drawnCamera, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@drawnTileSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@drawnDarkness, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@clock, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@drawnTime, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
