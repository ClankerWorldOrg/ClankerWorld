﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SaveTimelineKeyIcon
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'Kind' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Kind = "Kind";
        /// <summary>
        /// Cached name for the 'kind' field.
        /// </summary>
        public new static readonly global::Godot.StringName @kind = "kind";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@Kind) {
            this.@Kind = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.SaveTimelineKeyKind>(value);
            return true;
        }
        if (name == PropertyName.@kind) {
            this.@kind = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.SaveTimelineKeyKind>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Kind) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SaveTimelineKeyKind>(this.@Kind);
            return true;
        }
        if (name == PropertyName.@kind) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SaveTimelineKeyKind>(this.@kind);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@kind, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Kind, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
