﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class BoldTextButton
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Button.PropertyName {
        /// <summary>
        /// Cached name for the 'Caption' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Caption = "Caption";
        /// <summary>
        /// Cached name for the 'Glyph' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Glyph = "Glyph";
        /// <summary>
        /// Cached name for the 'Captions' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Captions = "Captions";
        /// <summary>
        /// Cached name for the 'caption' field.
        /// </summary>
        public new static readonly global::Godot.StringName @caption = "caption";
        /// <summary>
        /// Cached name for the 'glyph' field.
        /// </summary>
        public new static readonly global::Godot.StringName @glyph = "glyph";
        /// <summary>
        /// Cached name for the 'captions' field.
        /// </summary>
        public new static readonly global::Godot.StringName @captions = "captions";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@Caption) {
            this.@Caption = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@Glyph) {
            this.@Glyph = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Texture2D>(value);
            return true;
        }
        if (name == PropertyName.@Captions) {
            this.@Captions = global::Godot.NativeInterop.VariantUtils.ConvertTo<string[]>(value);
            return true;
        }
        if (name == PropertyName.@caption) {
            this.@caption = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@glyph) {
            this.@glyph = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Texture2D>(value);
            return true;
        }
        if (name == PropertyName.@captions) {
            this.@captions = global::Godot.NativeInterop.VariantUtils.ConvertTo<string[]>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Caption) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Caption);
            return true;
        }
        if (name == PropertyName.@Glyph) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Texture2D>(this.@Glyph);
            return true;
        }
        if (name == PropertyName.@Captions) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string[]>(this.@Captions);
            return true;
        }
        if (name == PropertyName.@caption) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@caption);
            return true;
        }
        if (name == PropertyName.@glyph) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Texture2D>(this.@glyph);
            return true;
        }
        if (name == PropertyName.@captions) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string[]>(this.@captions);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@caption, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@glyph, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)34, name: PropertyName.@captions, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Caption, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@Glyph, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)34, name: PropertyName.@Captions, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
