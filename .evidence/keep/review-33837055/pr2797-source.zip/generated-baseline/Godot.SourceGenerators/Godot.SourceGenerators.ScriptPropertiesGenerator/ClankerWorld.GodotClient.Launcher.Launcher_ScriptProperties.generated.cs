﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.Launcher {

partial class Launcher
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'backdrop' field.
        /// </summary>
        public new static readonly global::Godot.StringName @backdrop = "backdrop";
        /// <summary>
        /// Cached name for the 'status' field.
        /// </summary>
        public new static readonly global::Godot.StringName @status = "status";
        /// <summary>
        /// Cached name for the 'playTarget' field.
        /// </summary>
        public new static readonly global::Godot.StringName @playTarget = "playTarget";
        /// <summary>
        /// Cached name for the 'launcherUpdate' field.
        /// </summary>
        public new static readonly global::Godot.StringName @launcherUpdate = "launcherUpdate";
        /// <summary>
        /// Cached name for the 'versionChoice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @versionChoice = "versionChoice";
        /// <summary>
        /// Cached name for the 'playButton' field.
        /// </summary>
        public new static readonly global::Godot.StringName @playButton = "playButton";
        /// <summary>
        /// Cached name for the 'progressBar' field.
        /// </summary>
        public new static readonly global::Godot.StringName @progressBar = "progressBar";
        /// <summary>
        /// Cached name for the 'installedRows' field.
        /// </summary>
        public new static readonly global::Godot.StringName @installedRows = "installedRows";
        /// <summary>
        /// Cached name for the 'availableRows' field.
        /// </summary>
        public new static readonly global::Godot.StringName @availableRows = "availableRows";
        /// <summary>
        /// Cached name for the 'developerMode' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerMode = "developerMode";
        /// <summary>
        /// Cached name for the 'developerHint' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerHint = "developerHint";
        /// <summary>
        /// Cached name for the 'developerOptions' field.
        /// </summary>
        public new static readonly global::Godot.StringName @developerOptions = "developerOptions";
        /// <summary>
        /// Cached name for the 'testData' field.
        /// </summary>
        public new static readonly global::Godot.StringName @testData = "testData";
        /// <summary>
        /// Cached name for the 'detailedLogs' field.
        /// </summary>
        public new static readonly global::Godot.StringName @detailedLogs = "detailedLogs";
        /// <summary>
        /// Cached name for the 'localBuild' field.
        /// </summary>
        public new static readonly global::Godot.StringName @localBuild = "localBuild";
        /// <summary>
        /// Cached name for the 'playTab' field.
        /// </summary>
        public new static readonly global::Godot.StringName @playTab = "playTab";
        /// <summary>
        /// Cached name for the 'versionsTab' field.
        /// </summary>
        public new static readonly global::Godot.StringName @versionsTab = "versionsTab";
        /// <summary>
        /// Cached name for the 'settingsTab' field.
        /// </summary>
        public new static readonly global::Godot.StringName @settingsTab = "settingsTab";
        /// <summary>
        /// Cached name for the 'playPage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @playPage = "playPage";
        /// <summary>
        /// Cached name for the 'versionsPage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @versionsPage = "versionsPage";
        /// <summary>
        /// Cached name for the 'settingsPage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @settingsPage = "settingsPage";
        /// <summary>
        /// Cached name for the 'navigationTabs' field.
        /// </summary>
        public new static readonly global::Godot.StringName @navigationTabs = "navigationTabs";
        /// <summary>
        /// Cached name for the 'releasesReached' field.
        /// </summary>
        public new static readonly global::Godot.StringName @releasesReached = "releasesReached";
        /// <summary>
        /// Cached name for the 'requestedVersion' field.
        /// </summary>
        public new static readonly global::Godot.StringName @requestedVersion = "requestedVersion";
        /// <summary>
        /// Cached name for the 'requestedWorld' field.
        /// </summary>
        public new static readonly global::Godot.StringName @requestedWorld = "requestedWorld";
        /// <summary>
        /// Cached name for the 'busy' field.
        /// </summary>
        public new static readonly global::Godot.StringName @busy = "busy";
        /// <summary>
        /// Cached name for the 'hostingPage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hostingPage = "hostingPage";
        /// <summary>
        /// Cached name for the 'hostingAddress' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hostingAddress = "hostingAddress";
        /// <summary>
        /// Cached name for the 'hostingState' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hostingState = "hostingState";
        /// <summary>
        /// Cached name for the 'hostingData' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hostingData = "hostingData";
        /// <summary>
        /// Cached name for the 'pendingDevices' field.
        /// </summary>
        public new static readonly global::Godot.StringName @pendingDevices = "pendingDevices";
        /// <summary>
        /// Cached name for the 'startHosting' field.
        /// </summary>
        public new static readonly global::Godot.StringName @startHosting = "startHosting";
        /// <summary>
        /// Cached name for the 'playHosted' field.
        /// </summary>
        public new static readonly global::Godot.StringName @playHosted = "playHosted";
        /// <summary>
        /// Cached name for the 'stopHosting' field.
        /// </summary>
        public new static readonly global::Godot.StringName @stopHosting = "stopHosting";
        /// <summary>
        /// Cached name for the 'hostingBack' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hostingBack = "hostingBack";
        /// <summary>
        /// Cached name for the 'resumeHosting' field.
        /// </summary>
        public new static readonly global::Godot.StringName @resumeHosting = "resumeHosting";
        /// <summary>
        /// Cached name for the 'stopWithGame' field.
        /// </summary>
        public new static readonly global::Godot.StringName @stopWithGame = "stopWithGame";
        /// <summary>
        /// Cached name for the 'hostingRunning' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hostingRunning = "hostingRunning";
        /// <summary>
        /// Cached name for the 'refreshingHost' field.
        /// </summary>
        public new static readonly global::Godot.StringName @refreshingHost = "refreshingHost";
        /// <summary>
        /// Cached name for the 'joinPage' field.
        /// </summary>
        public new static readonly global::Godot.StringName @joinPage = "joinPage";
        /// <summary>
        /// Cached name for the 'hostAddress' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hostAddress = "hostAddress";
        /// <summary>
        /// Cached name for the 'comparison' field.
        /// </summary>
        public new static readonly global::Godot.StringName @comparison = "comparison";
        /// <summary>
        /// Cached name for the 'joinHost' field.
        /// </summary>
        public new static readonly global::Godot.StringName @joinHost = "joinHost";
        /// <summary>
        /// Cached name for the 'checkApproval' field.
        /// </summary>
        public new static readonly global::Godot.StringName @checkApproval = "checkApproval";
        /// <summary>
        /// Cached name for the 'forgetHost' field.
        /// </summary>
        public new static readonly global::Godot.StringName @forgetHost = "forgetHost";
        /// <summary>
        /// Cached name for the 'joining' field.
        /// </summary>
        public new static readonly global::Godot.StringName @joining = "joining";
        /// <summary>
        /// Cached name for the 'joinRegistrationPath' field.
        /// </summary>
        public new static readonly global::Godot.StringName @joinRegistrationPath = "joinRegistrationPath";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@releasesReached) {
            this.@releasesReached = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@requestedVersion) {
            this.@requestedVersion = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@requestedWorld) {
            this.@requestedWorld = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@busy) {
            this.@busy = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@hostingRunning) {
            this.@hostingRunning = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@refreshingHost) {
            this.@refreshingHost = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@joining) {
            this.@joining = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@joinRegistrationPath) {
            this.@joinRegistrationPath = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@backdrop) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.MenuBackdrop>(this.@backdrop);
            return true;
        }
        if (name == PropertyName.@status) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@status);
            return true;
        }
        if (name == PropertyName.@playTarget) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@playTarget);
            return true;
        }
        if (name == PropertyName.@launcherUpdate) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@launcherUpdate);
            return true;
        }
        if (name == PropertyName.@versionChoice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@versionChoice);
            return true;
        }
        if (name == PropertyName.@playButton) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@playButton);
            return true;
        }
        if (name == PropertyName.@progressBar) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ProgressBar>(this.@progressBar);
            return true;
        }
        if (name == PropertyName.@installedRows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@installedRows);
            return true;
        }
        if (name == PropertyName.@availableRows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@availableRows);
            return true;
        }
        if (name == PropertyName.@developerMode) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@developerMode);
            return true;
        }
        if (name == PropertyName.@developerHint) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@developerHint);
            return true;
        }
        if (name == PropertyName.@developerOptions) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@developerOptions);
            return true;
        }
        if (name == PropertyName.@testData) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@testData);
            return true;
        }
        if (name == PropertyName.@detailedLogs) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@detailedLogs);
            return true;
        }
        if (name == PropertyName.@localBuild) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@localBuild);
            return true;
        }
        if (name == PropertyName.@playTab) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@playTab);
            return true;
        }
        if (name == PropertyName.@versionsTab) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@versionsTab);
            return true;
        }
        if (name == PropertyName.@settingsTab) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@settingsTab);
            return true;
        }
        if (name == PropertyName.@playPage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@playPage);
            return true;
        }
        if (name == PropertyName.@versionsPage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@versionsPage);
            return true;
        }
        if (name == PropertyName.@settingsPage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(this.@settingsPage);
            return true;
        }
        if (name == PropertyName.@navigationTabs) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@navigationTabs);
            return true;
        }
        if (name == PropertyName.@releasesReached) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@releasesReached);
            return true;
        }
        if (name == PropertyName.@requestedVersion) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@requestedVersion);
            return true;
        }
        if (name == PropertyName.@requestedWorld) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@requestedWorld);
            return true;
        }
        if (name == PropertyName.@busy) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@busy);
            return true;
        }
        if (name == PropertyName.@hostingPage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@hostingPage);
            return true;
        }
        if (name == PropertyName.@hostingAddress) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@hostingAddress);
            return true;
        }
        if (name == PropertyName.@hostingState) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@hostingState);
            return true;
        }
        if (name == PropertyName.@hostingData) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@hostingData);
            return true;
        }
        if (name == PropertyName.@pendingDevices) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@pendingDevices);
            return true;
        }
        if (name == PropertyName.@startHosting) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@startHosting);
            return true;
        }
        if (name == PropertyName.@playHosted) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@playHosted);
            return true;
        }
        if (name == PropertyName.@stopHosting) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@stopHosting);
            return true;
        }
        if (name == PropertyName.@hostingBack) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@hostingBack);
            return true;
        }
        if (name == PropertyName.@resumeHosting) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@resumeHosting);
            return true;
        }
        if (name == PropertyName.@stopWithGame) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CheckButton>(this.@stopWithGame);
            return true;
        }
        if (name == PropertyName.@hostingRunning) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@hostingRunning);
            return true;
        }
        if (name == PropertyName.@refreshingHost) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@refreshingHost);
            return true;
        }
        if (name == PropertyName.@joinPage) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@joinPage);
            return true;
        }
        if (name == PropertyName.@hostAddress) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@hostAddress);
            return true;
        }
        if (name == PropertyName.@comparison) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@comparison);
            return true;
        }
        if (name == PropertyName.@joinHost) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@joinHost);
            return true;
        }
        if (name == PropertyName.@checkApproval) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@checkApproval);
            return true;
        }
        if (name == PropertyName.@forgetHost) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@forgetHost);
            return true;
        }
        if (name == PropertyName.@joining) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@joining);
            return true;
        }
        if (name == PropertyName.@joinRegistrationPath) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@joinRegistrationPath);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@backdrop, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@status, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@playTarget, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@launcherUpdate, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@versionChoice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@playButton, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@progressBar, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@installedRows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@availableRows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerMode, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerHint, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@developerOptions, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@testData, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@detailedLogs, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@localBuild, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@playTab, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@versionsTab, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@settingsTab, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@playPage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@versionsPage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@settingsPage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@navigationTabs, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@releasesReached, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@requestedVersion, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@requestedWorld, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@busy, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hostingPage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hostingAddress, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hostingState, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hostingData, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@pendingDevices, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@startHosting, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@playHosted, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@stopHosting, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hostingBack, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@resumeHosting, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@stopWithGame, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@hostingRunning, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@refreshingHost, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@joinPage, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@hostAddress, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@comparison, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@joinHost, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@checkApproval, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@forgetHost, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@joining, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@joinRegistrationPath, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
