﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class BuildingCompletionLayer
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'ActiveCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ActiveCount = "ActiveCount";
        /// <summary>
        /// Cached name for the 'DrawnMomentCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawnMomentCount = "DrawnMomentCount";
        /// <summary>
        /// Cached name for the 'DrawnSpanCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawnSpanCount = "DrawnSpanCount";
        /// <summary>
        /// Cached name for the 'FirstAge' property.
        /// </summary>
        public new static readonly global::Godot.StringName @FirstAge = "FirstAge";
        /// <summary>
        /// Cached name for the 'terrain' field.
        /// </summary>
        public new static readonly global::Godot.StringName @terrain = "terrain";
        /// <summary>
        /// Cached name for the 'paused' field.
        /// </summary>
        public new static readonly global::Godot.StringName @paused = "paused";
        /// <summary>
        /// Cached name for the 'lastVisible' field.
        /// </summary>
        public new static readonly global::Godot.StringName @lastVisible = "lastVisible";
        /// <summary>
        /// Cached name for the 'lastSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @lastSize = "lastSize";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@DrawnMomentCount) {
            this.@DrawnMomentCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@DrawnSpanCount) {
            this.@DrawnSpanCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@terrain) {
            this.@terrain = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(value);
            return true;
        }
        if (name == PropertyName.@paused) {
            this.@paused = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@lastVisible) {
            this.@lastVisible = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(value);
            return true;
        }
        if (name == PropertyName.@lastSize) {
            this.@lastSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@ActiveCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@ActiveCount);
            return true;
        }
        if (name == PropertyName.@DrawnMomentCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@DrawnMomentCount);
            return true;
        }
        if (name == PropertyName.@DrawnSpanCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@DrawnSpanCount);
            return true;
        }
        if (name == PropertyName.@FirstAge) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@FirstAge);
            return true;
        }
        if (name == PropertyName.@terrain) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@terrain);
            return true;
        }
        if (name == PropertyName.@paused) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@paused);
            return true;
        }
        if (name == PropertyName.@lastVisible) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@lastVisible);
            return true;
        }
        if (name == PropertyName.@lastSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@lastSize);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@terrain, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@paused, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@lastVisible, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@lastSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@ActiveCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@DrawnMomentCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@DrawnSpanCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@FirstAge, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
