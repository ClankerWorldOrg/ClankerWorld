﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class MenuBackdrop
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'Night' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Night = "Night";
        /// <summary>
        /// Cached name for the 'AnimationTime' property.
        /// </summary>
        public new static readonly global::Godot.StringName @AnimationTime = "AnimationTime";
        /// <summary>
        /// Cached name for the 'night' field.
        /// </summary>
        public new static readonly global::Godot.StringName @night = "night";
        /// <summary>
        /// Cached name for the 'elapsed' field.
        /// </summary>
        public new static readonly global::Godot.StringName @elapsed = "elapsed";
        /// <summary>
        /// Cached name for the 'drawnFrame' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnFrame = "drawnFrame";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@Night) {
            this.@Night = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@night) {
            this.@night = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@elapsed) {
            this.@elapsed = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@drawnFrame) {
            this.@drawnFrame = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Night) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@Night);
            return true;
        }
        if (name == PropertyName.@AnimationTime) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@AnimationTime);
            return true;
        }
        if (name == PropertyName.@night) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@night);
            return true;
        }
        if (name == PropertyName.@elapsed) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@elapsed);
            return true;
        }
        if (name == PropertyName.@drawnFrame) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@drawnFrame);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@night, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@elapsed, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@drawnFrame, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@Night, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@AnimationTime, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
