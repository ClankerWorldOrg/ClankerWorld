﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class PixelMeter
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'Kind' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Kind = "Kind";
        /// <summary>
        /// Cached name for the 'Caption' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Caption = "Caption";
        /// <summary>
        /// Cached name for the 'CaptionWidth' property.
        /// </summary>
        public new static readonly global::Godot.StringName @CaptionWidth = "CaptionWidth";
        /// <summary>
        /// Cached name for the 'Percent' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Percent = "Percent";
        /// <summary>
        /// Cached name for the 'percent' field.
        /// </summary>
        public new static readonly global::Godot.StringName @percent = "percent";
        /// <summary>
        /// Cached name for the 'captionWidth' field.
        /// </summary>
        public new static readonly global::Godot.StringName @captionWidth = "captionWidth";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@Percent) {
            this.@Percent = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@percent) {
            this.@percent = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@captionWidth) {
            this.@captionWidth = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Kind) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.MeterKind>(this.@Kind);
            return true;
        }
        if (name == PropertyName.@Caption) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Caption);
            return true;
        }
        if (name == PropertyName.@CaptionWidth) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@CaptionWidth);
            return true;
        }
        if (name == PropertyName.@Percent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Percent);
            return true;
        }
        if (name == PropertyName.@percent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@percent);
            return true;
        }
        if (name == PropertyName.@captionWidth) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@captionWidth);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@percent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@captionWidth, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Kind, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Caption, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@CaptionWidth, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Percent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
