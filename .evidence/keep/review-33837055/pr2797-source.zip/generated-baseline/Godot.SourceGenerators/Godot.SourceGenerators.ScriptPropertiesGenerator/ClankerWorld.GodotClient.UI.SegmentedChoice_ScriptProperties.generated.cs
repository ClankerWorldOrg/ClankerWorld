﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SegmentedChoice
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.PanelContainer.PropertyName {
        /// <summary>
        /// Cached name for the 'ItemCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ItemCount = "ItemCount";
        /// <summary>
        /// Cached name for the 'KeyboardReachable' property.
        /// </summary>
        public new static readonly global::Godot.StringName @KeyboardReachable = "KeyboardReachable";
        /// <summary>
        /// Cached name for the 'Selected' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Selected = "Selected";
        /// <summary>
        /// Cached name for the 'row' field.
        /// </summary>
        public new static readonly global::Godot.StringName @row = "row";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@ItemCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@ItemCount);
            return true;
        }
        if (name == PropertyName.@KeyboardReachable) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@KeyboardReachable);
            return true;
        }
        if (name == PropertyName.@Selected) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Selected);
            return true;
        }
        if (name == PropertyName.@row) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@row);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@row, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@ItemCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@KeyboardReachable, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Selected, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
