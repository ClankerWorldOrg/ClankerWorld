﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class BuildingHeader
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.HBoxContainer.PropertyName {
        /// <summary>
        /// Cached name for the 'Roof' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Roof = "Roof";
        /// <summary>
        /// Cached name for the 'NameLabel' property.
        /// </summary>
        public new static readonly global::Godot.StringName @NameLabel = "NameLabel";
        /// <summary>
        /// Cached name for the 'OwnerLabel' property.
        /// </summary>
        public new static readonly global::Godot.StringName @OwnerLabel = "OwnerLabel";
        /// <summary>
        /// Cached name for the 'Find' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Find = "Find";
        /// <summary>
        /// Cached name for the 'Close' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Close = "Close";
        /// <summary>
        /// Cached name for the 'RoofSize' property.
        /// </summary>
        public new static readonly global::Godot.StringName @RoofSize = "RoofSize";
        /// <summary>
        /// Cached name for the 'roofKey' field.
        /// </summary>
        public new static readonly global::Godot.StringName @roofKey = "roofKey";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@roofKey) {
            this.@roofKey = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Roof) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(this.@Roof);
            return true;
        }
        if (name == PropertyName.@NameLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@NameLabel);
            return true;
        }
        if (name == PropertyName.@OwnerLabel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(this.@OwnerLabel);
            return true;
        }
        if (name == PropertyName.@Find) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@Find);
            return true;
        }
        if (name == PropertyName.@Close) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@Close);
            return true;
        }
        if (name == PropertyName.@RoofSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@RoofSize);
            return true;
        }
        if (name == PropertyName.@roofKey) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@roofKey);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@roofKey, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@Roof, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@NameLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@OwnerLabel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@Find, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@Close, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@RoofSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
