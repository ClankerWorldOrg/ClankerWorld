﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class ItemSlot
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'Kind' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Kind = "Kind";
        /// <summary>
        /// Cached name for the 'Quantity' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Quantity = "Quantity";
        /// <summary>
        /// Cached name for the 'DisplayName' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DisplayName = "DisplayName";
        /// <summary>
        /// Cached name for the 'IconSize' property.
        /// </summary>
        public new static readonly global::Godot.StringName @IconSize = "IconSize";
        /// <summary>
        /// Cached name for the 'Named' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Named = "Named";
        /// <summary>
        /// Cached name for the 'Box' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Box = "Box";
        /// <summary>
        /// Cached name for the 'CellWidth' property.
        /// </summary>
        public new static readonly global::Godot.StringName @CellWidth = "CellWidth";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@Kind) {
            this.@Kind = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@Quantity) {
            this.@Quantity = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@DisplayName) {
            this.@DisplayName = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Kind) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Kind);
            return true;
        }
        if (name == PropertyName.@Quantity) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Quantity);
            return true;
        }
        if (name == PropertyName.@DisplayName) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@DisplayName);
            return true;
        }
        if (name == PropertyName.@IconSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@IconSize);
            return true;
        }
        if (name == PropertyName.@Named) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@Named);
            return true;
        }
        if (name == PropertyName.@Box) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Box);
            return true;
        }
        if (name == PropertyName.@CellWidth) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@CellWidth);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Kind, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Quantity, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@DisplayName, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@IconSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@Named, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Box, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@CellWidth, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
