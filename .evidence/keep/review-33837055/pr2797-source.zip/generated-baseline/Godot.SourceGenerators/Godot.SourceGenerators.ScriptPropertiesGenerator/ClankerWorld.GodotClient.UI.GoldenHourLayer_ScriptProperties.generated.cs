﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class GoldenHourLayer
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'ShownStrength' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ShownStrength = "ShownStrength";
        /// <summary>
        /// Cached name for the 'IsDawn' property.
        /// </summary>
        public new static readonly global::Godot.StringName @IsDawn = "IsDawn";
        /// <summary>
        /// Cached name for the 'CurrentMultiplier' property.
        /// </summary>
        public new static readonly global::Godot.StringName @CurrentMultiplier = "CurrentMultiplier";
        /// <summary>
        /// Cached name for the 'DrawnArea' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawnArea = "DrawnArea";
        /// <summary>
        /// Cached name for the 'source' field.
        /// </summary>
        public new static readonly global::Godot.StringName @source = "source";
        /// <summary>
        /// Cached name for the 'worldId' field.
        /// </summary>
        public new static readonly global::Godot.StringName @worldId = "worldId";
        /// <summary>
        /// Cached name for the 'target' field.
        /// </summary>
        public new static readonly global::Godot.StringName @target = "target";
        /// <summary>
        /// Cached name for the 'shown' field.
        /// </summary>
        public new static readonly global::Godot.StringName @shown = "shown";
        /// <summary>
        /// Cached name for the 'dawn' field.
        /// </summary>
        public new static readonly global::Godot.StringName @dawn = "dawn";
        /// <summary>
        /// Cached name for the 'paused' field.
        /// </summary>
        public new static readonly global::Godot.StringName @paused = "paused";
        /// <summary>
        /// Cached name for the 'drawnCamera' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnCamera = "drawnCamera";
        /// <summary>
        /// Cached name for the 'drawnTileSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnTileSize = "drawnTileSize";
        /// <summary>
        /// Cached name for the 'drawnMultiplier' field.
        /// </summary>
        public new static readonly global::Godot.StringName @drawnMultiplier = "drawnMultiplier";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@DrawnArea) {
            this.@DrawnArea = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(value);
            return true;
        }
        if (name == PropertyName.@source) {
            this.@source = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(value);
            return true;
        }
        if (name == PropertyName.@worldId) {
            this.@worldId = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@target) {
            this.@target = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@shown) {
            this.@shown = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@dawn) {
            this.@dawn = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@paused) {
            this.@paused = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@drawnCamera) {
            this.@drawnCamera = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(value);
            return true;
        }
        if (name == PropertyName.@drawnTileSize) {
            this.@drawnTileSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@drawnMultiplier) {
            this.@drawnMultiplier = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@ShownStrength) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@ShownStrength);
            return true;
        }
        if (name == PropertyName.@IsDawn) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@IsDawn);
            return true;
        }
        if (name == PropertyName.@CurrentMultiplier) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(this.@CurrentMultiplier);
            return true;
        }
        if (name == PropertyName.@DrawnArea) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@DrawnArea);
            return true;
        }
        if (name == PropertyName.@source) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(this.@source);
            return true;
        }
        if (name == PropertyName.@worldId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@worldId);
            return true;
        }
        if (name == PropertyName.@target) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@target);
            return true;
        }
        if (name == PropertyName.@shown) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@shown);
            return true;
        }
        if (name == PropertyName.@dawn) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@dawn);
            return true;
        }
        if (name == PropertyName.@paused) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@paused);
            return true;
        }
        if (name == PropertyName.@drawnCamera) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@drawnCamera);
            return true;
        }
        if (name == PropertyName.@drawnTileSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@drawnTileSize);
            return true;
        }
        if (name == PropertyName.@drawnMultiplier) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(this.@drawnMultiplier);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@source, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@worldId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@target, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@shown, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@dawn, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@paused, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@drawnCamera, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@drawnTileSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)20, name: PropertyName.@drawnMultiplier, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@ShownStrength, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@IsDawn, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)20, name: PropertyName.@CurrentMultiplier, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@DrawnArea, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
