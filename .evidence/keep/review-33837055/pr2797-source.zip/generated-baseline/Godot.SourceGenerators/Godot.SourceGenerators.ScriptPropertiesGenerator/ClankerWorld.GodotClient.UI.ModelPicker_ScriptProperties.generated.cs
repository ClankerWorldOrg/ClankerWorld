﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class ModelPicker
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.VBoxContainer.PropertyName {
        /// <summary>
        /// Cached name for the 'Model' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Model = "Model";
        /// <summary>
        /// Cached name for the 'IsTyping' property.
        /// </summary>
        public new static readonly global::Godot.StringName @IsTyping = "IsTyping";
        /// <summary>
        /// Cached name for the 'Editable' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Editable = "Editable";
        /// <summary>
        /// Cached name for the 'Choice' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Choice = "Choice";
        /// <summary>
        /// Cached name for the 'TypedInput' property.
        /// </summary>
        public new static readonly global::Godot.StringName @TypedInput = "TypedInput";
        /// <summary>
        /// Cached name for the 'Problem' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Problem = "Problem";
        /// <summary>
        /// Cached name for the 'CanRetry' property.
        /// </summary>
        public new static readonly global::Godot.StringName @CanRetry = "CanRetry";
        /// <summary>
        /// Cached name for the 'choice' field.
        /// </summary>
        public new static readonly global::Godot.StringName @choice = "choice";
        /// <summary>
        /// Cached name for the 'typed' field.
        /// </summary>
        public new static readonly global::Godot.StringName @typed = "typed";
        /// <summary>
        /// Cached name for the 'problemRow' field.
        /// </summary>
        public new static readonly global::Godot.StringName @problemRow = "problemRow";
        /// <summary>
        /// Cached name for the 'problem' field.
        /// </summary>
        public new static readonly global::Godot.StringName @problem = "problem";
        /// <summary>
        /// Cached name for the 'retry' field.
        /// </summary>
        public new static readonly global::Godot.StringName @retry = "retry";
        /// <summary>
        /// Cached name for the 'defaultModel' field.
        /// </summary>
        public new static readonly global::Godot.StringName @defaultModel = "defaultModel";
        /// <summary>
        /// Cached name for the 'current' field.
        /// </summary>
        public new static readonly global::Godot.StringName @current = "current";
        /// <summary>
        /// Cached name for the 'error' field.
        /// </summary>
        public new static readonly global::Godot.StringName @error = "error";
        /// <summary>
        /// Cached name for the 'loading' field.
        /// </summary>
        public new static readonly global::Godot.StringName @loading = "loading";
        /// <summary>
        /// Cached name for the 'listed' field.
        /// </summary>
        public new static readonly global::Godot.StringName @listed = "listed";
        /// <summary>
        /// Cached name for the 'typing' field.
        /// </summary>
        public new static readonly global::Godot.StringName @typing = "typing";
        /// <summary>
        /// Cached name for the 'mustChoose' field.
        /// </summary>
        public new static readonly global::Godot.StringName @mustChoose = "mustChoose";
        /// <summary>
        /// Cached name for the 'newAgent' field.
        /// </summary>
        public new static readonly global::Godot.StringName @newAgent = "newAgent";
        /// <summary>
        /// Cached name for the 'request' field.
        /// </summary>
        public new static readonly global::Godot.StringName @request = "request";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@Editable) {
            this.@Editable = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@defaultModel) {
            this.@defaultModel = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@current) {
            this.@current = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@error) {
            this.@error = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@loading) {
            this.@loading = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@listed) {
            this.@listed = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@typing) {
            this.@typing = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@mustChoose) {
            this.@mustChoose = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@newAgent) {
            this.@newAgent = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@request) {
            this.@request = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Model) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Model);
            return true;
        }
        if (name == PropertyName.@IsTyping) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@IsTyping);
            return true;
        }
        if (name == PropertyName.@Editable) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@Editable);
            return true;
        }
        if (name == PropertyName.@Choice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@Choice);
            return true;
        }
        if (name == PropertyName.@TypedInput) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@TypedInput);
            return true;
        }
        if (name == PropertyName.@Problem) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Problem);
            return true;
        }
        if (name == PropertyName.@CanRetry) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@CanRetry);
            return true;
        }
        if (name == PropertyName.@choice) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.OptionButton>(this.@choice);
            return true;
        }
        if (name == PropertyName.@typed) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.LineEdit>(this.@typed);
            return true;
        }
        if (name == PropertyName.@problemRow) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(this.@problemRow);
            return true;
        }
        if (name == PropertyName.@problem) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@problem);
            return true;
        }
        if (name == PropertyName.@retry) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(this.@retry);
            return true;
        }
        if (name == PropertyName.@defaultModel) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@defaultModel);
            return true;
        }
        if (name == PropertyName.@current) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@current);
            return true;
        }
        if (name == PropertyName.@error) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@error);
            return true;
        }
        if (name == PropertyName.@loading) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@loading);
            return true;
        }
        if (name == PropertyName.@listed) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@listed);
            return true;
        }
        if (name == PropertyName.@typing) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@typing);
            return true;
        }
        if (name == PropertyName.@mustChoose) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@mustChoose);
            return true;
        }
        if (name == PropertyName.@newAgent) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@newAgent);
            return true;
        }
        if (name == PropertyName.@request) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@request);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@choice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@typed, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@problemRow, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@problem, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@retry, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@defaultModel, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@current, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@error, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@loading, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@listed, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@typing, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@mustChoose, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@newAgent, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@request, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Model, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@IsTyping, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@Editable, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@Choice, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@TypedInput, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Problem, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@CanRetry, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
