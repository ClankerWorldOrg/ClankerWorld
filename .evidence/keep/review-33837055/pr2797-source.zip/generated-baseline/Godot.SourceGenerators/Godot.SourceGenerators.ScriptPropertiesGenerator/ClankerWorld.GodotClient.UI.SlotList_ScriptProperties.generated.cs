﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SlotList
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.ScrollContainer.PropertyName {
        /// <summary>
        /// Cached name for the 'ItemCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ItemCount = "ItemCount";
        /// <summary>
        /// Cached name for the 'Compact' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Compact = "Compact";
        /// <summary>
        /// Cached name for the 'Placeholder' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Placeholder = "Placeholder";
        /// <summary>
        /// Cached name for the 'cards' field.
        /// </summary>
        public new static readonly global::Godot.StringName @cards = "cards";
        /// <summary>
        /// Cached name for the 'placeholder' field.
        /// </summary>
        public new static readonly global::Godot.StringName @placeholder = "placeholder";
        /// <summary>
        /// Cached name for the 'selected' field.
        /// </summary>
        public new static readonly global::Godot.StringName @selected = "selected";
        /// <summary>
        /// Cached name for the 'hovered' field.
        /// </summary>
        public new static readonly global::Godot.StringName @hovered = "hovered";
        /// <summary>
        /// Cached name for the 'compact' field.
        /// </summary>
        public new static readonly global::Godot.StringName @compact = "compact";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@Compact) {
            this.@Compact = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@Placeholder) {
            this.@Placeholder = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@selected) {
            this.@selected = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@hovered) {
            this.@hovered = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@compact) {
            this.@compact = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@ItemCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@ItemCount);
            return true;
        }
        if (name == PropertyName.@Compact) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@Compact);
            return true;
        }
        if (name == PropertyName.@Placeholder) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@Placeholder);
            return true;
        }
        if (name == PropertyName.@cards) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.VBoxContainer>(this.@cards);
            return true;
        }
        if (name == PropertyName.@placeholder) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(this.@placeholder);
            return true;
        }
        if (name == PropertyName.@selected) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@selected);
            return true;
        }
        if (name == PropertyName.@hovered) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@hovered);
            return true;
        }
        if (name == PropertyName.@compact) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@compact);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@cards, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@placeholder, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@selected, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@hovered, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@ItemCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@Compact, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@compact, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@Placeholder, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
