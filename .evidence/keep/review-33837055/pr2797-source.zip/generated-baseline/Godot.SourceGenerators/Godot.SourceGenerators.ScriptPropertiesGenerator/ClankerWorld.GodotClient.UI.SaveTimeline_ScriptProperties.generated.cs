﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SaveTimeline
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.PanelContainer.PropertyName {
        /// <summary>
        /// Cached name for the 'Rows' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Rows = "Rows";
        /// <summary>
        /// Cached name for the 'SelectedId' property.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedId = "SelectedId";
        /// <summary>
        /// Cached name for the 'PixelsPerDay' property.
        /// </summary>
        public new static readonly global::Godot.StringName @PixelsPerDay = "PixelsPerDay";
        /// <summary>
        /// Cached name for the 'ContentHeight' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ContentHeight = "ContentHeight";
        /// <summary>
        /// Cached name for the 'names' field.
        /// </summary>
        public new static readonly global::Godot.StringName @names = "names";
        /// <summary>
        /// Cached name for the 'scroll' field.
        /// </summary>
        public new static readonly global::Godot.StringName @scroll = "scroll";
        /// <summary>
        /// Cached name for the 'rows' field.
        /// </summary>
        public new static readonly global::Godot.StringName @rows = "rows";
        /// <summary>
        /// Cached name for the 'maximumHeight' field.
        /// </summary>
        public new static readonly global::Godot.StringName @maximumHeight = "maximumHeight";
        /// <summary>
        /// Cached name for the 'scrollsSideways' field.
        /// </summary>
        public new static readonly global::Godot.StringName @scrollsSideways = "scrollsSideways";
        /// <summary>
        /// Cached name for the 'revealing' field.
        /// </summary>
        public new static readonly global::Godot.StringName @revealing = "revealing";
        /// <summary>
        /// Cached name for the 'revealQueued' field.
        /// </summary>
        public new static readonly global::Godot.StringName @revealQueued = "revealQueued";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@maximumHeight) {
            this.@maximumHeight = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@scrollsSideways) {
            this.@scrollsSideways = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@revealing) {
            this.@revealing = global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(value);
            return true;
        }
        if (name == PropertyName.@revealQueued) {
            this.@revealQueued = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@Rows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SaveTimelineRows>(this.@Rows);
            return true;
        }
        if (name == PropertyName.@SelectedId) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@SelectedId);
            return true;
        }
        if (name == PropertyName.@PixelsPerDay) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@PixelsPerDay);
            return true;
        }
        if (name == PropertyName.@ContentHeight) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@ContentHeight);
            return true;
        }
        if (name == PropertyName.@names) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SaveTimelineNames>(this.@names);
            return true;
        }
        if (name == PropertyName.@scroll) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ScrollContainer>(this.@scroll);
            return true;
        }
        if (name == PropertyName.@rows) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.SaveTimelineRows>(this.@rows);
            return true;
        }
        if (name == PropertyName.@maximumHeight) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@maximumHeight);
            return true;
        }
        if (name == PropertyName.@scrollsSideways) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@scrollsSideways);
            return true;
        }
        if (name == PropertyName.@revealing) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(this.@revealing);
            return true;
        }
        if (name == PropertyName.@revealQueued) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@revealQueued);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@names, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@scroll, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@rows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@maximumHeight, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@scrollsSideways, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@revealing, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@revealQueued, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@Rows, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)4, name: PropertyName.@SelectedId, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@PixelsPerDay, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@ContentHeight, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
