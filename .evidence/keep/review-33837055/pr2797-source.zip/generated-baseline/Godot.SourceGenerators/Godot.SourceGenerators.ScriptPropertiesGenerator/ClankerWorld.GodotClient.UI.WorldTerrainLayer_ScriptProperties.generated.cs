﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class WorldTerrainLayer
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the properties and fields contained in this class, for fast lookup.
    /// </summary>
    public new class PropertyName : global::Godot.Control.PropertyName {
        /// <summary>
        /// Cached name for the 'AutumnLeavesEnabled' property.
        /// </summary>
        public new static readonly global::Godot.StringName @AutumnLeavesEnabled = "AutumnLeavesEnabled";
        /// <summary>
        /// Cached name for the 'AutumnLeafDrawCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @AutumnLeafDrawCount = "AutumnLeafDrawCount";
        /// <summary>
        /// Cached name for the 'Season' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Season = "Season";
        /// <summary>
        /// Cached name for the 'VisibleTileCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @VisibleTileCount = "VisibleTileCount";
        /// <summary>
        /// Cached name for the 'OverviewNaturalObjectDrawCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @OverviewNaturalObjectDrawCount = "OverviewNaturalObjectDrawCount";
        /// <summary>
        /// Cached name for the 'MeasureDrawCost' property.
        /// </summary>
        public new static readonly global::Godot.StringName @MeasureDrawCost = "MeasureDrawCost";
        /// <summary>
        /// Cached name for the 'LastDrawMilliseconds' property.
        /// </summary>
        public new static readonly global::Godot.StringName @LastDrawMilliseconds = "LastDrawMilliseconds";
        /// <summary>
        /// Cached name for the 'DrawSampleCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawSampleCount = "DrawSampleCount";
        /// <summary>
        /// Cached name for the 'TownBorderTileCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @TownBorderTileCount = "TownBorderTileCount";
        /// <summary>
        /// Cached name for the 'HouseholdPropertyTileCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @HouseholdPropertyTileCount = "HouseholdPropertyTileCount";
        /// <summary>
        /// Cached name for the 'TownLandTitleTileCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @TownLandTitleTileCount = "TownLandTitleTileCount";
        /// <summary>
        /// Cached name for the 'HouseholdLandUseTileCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @HouseholdLandUseTileCount = "HouseholdLandUseTileCount";
        /// <summary>
        /// Cached name for the 'DisputedLandTileCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DisputedLandTileCount = "DisputedLandTileCount";
        /// <summary>
        /// Cached name for the 'VisibleTiles' property.
        /// </summary>
        public new static readonly global::Godot.StringName @VisibleTiles = "VisibleTiles";
        /// <summary>
        /// Cached name for the 'TileSize' property.
        /// </summary>
        public new static readonly global::Godot.StringName @TileSize = "TileSize";
        /// <summary>
        /// Cached name for the 'Stride' property.
        /// </summary>
        public new static readonly global::Godot.StringName @Stride = "Stride";
        /// <summary>
        /// Cached name for the 'WrapsEastWest' property.
        /// </summary>
        public new static readonly global::Godot.StringName @WrapsEastWest = "WrapsEastWest";
        /// <summary>
        /// Cached name for the 'WeatherRegionSize' property.
        /// </summary>
        public new static readonly global::Godot.StringName @WeatherRegionSize = "WeatherRegionSize";
        /// <summary>
        /// Cached name for the 'WeatherVersion' property.
        /// </summary>
        public new static readonly global::Godot.StringName @WeatherVersion = "WeatherVersion";
        /// <summary>
        /// Cached name for the 'HasActiveWeather' property.
        /// </summary>
        public new static readonly global::Godot.StringName @HasActiveWeather = "HasActiveWeather";
        /// <summary>
        /// Cached name for the 'DrawsGroundTextures' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawsGroundTextures = "DrawsGroundTextures";
        /// <summary>
        /// Cached name for the 'BuildingSpriteCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildingSpriteCount = "BuildingSpriteCount";
        /// <summary>
        /// Cached name for the 'ConstructionSiteCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ConstructionSiteCount = "ConstructionSiteCount";
        /// <summary>
        /// Cached name for the 'ResourceKindSpriteCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ResourceKindSpriteCount = "ResourceKindSpriteCount";
        /// <summary>
        /// Cached name for the 'CactusSpriteCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @CactusSpriteCount = "CactusSpriteCount";
        /// <summary>
        /// Cached name for the 'SnowFootprintCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @SnowFootprintCount = "SnowFootprintCount";
        /// <summary>
        /// Cached name for the 'DrawnSnowTileCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawnSnowTileCount = "DrawnSnowTileCount";
        /// <summary>
        /// Cached name for the 'DrawnSnowFootprintCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawnSnowFootprintCount = "DrawnSnowFootprintCount";
        /// <summary>
        /// Cached name for the 'SnowOverviewDrawCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @SnowOverviewDrawCount = "SnowOverviewDrawCount";
        /// <summary>
        /// Cached name for the 'ReliefTextureCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @ReliefTextureCount = "ReliefTextureCount";
        /// <summary>
        /// Cached name for the 'PendingReliefChunkCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @PendingReliefChunkCount = "PendingReliefChunkCount";
        /// <summary>
        /// Cached name for the 'HillOverlayTileCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @HillOverlayTileCount = "HillOverlayTileCount";
        /// <summary>
        /// Cached name for the 'FadingReliefChunkCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @FadingReliefChunkCount = "FadingReliefChunkCount";
        /// <summary>
        /// Cached name for the 'PrefetchedReliefChunkCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @PrefetchedReliefChunkCount = "PrefetchedReliefChunkCount";
        /// <summary>
        /// Cached name for the 'DrawsRelief' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawsRelief = "DrawsRelief";
        /// <summary>
        /// Cached name for the 'DrawnSnowRoofCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawnSnowRoofCount = "DrawnSnowRoofCount";
        /// <summary>
        /// Cached name for the 'DrawnSnowRoofRegionCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawnSnowRoofRegionCount = "DrawnSnowRoofRegionCount";
        /// <summary>
        /// Cached name for the 'LastSnowRoofRegion' property.
        /// </summary>
        public new static readonly global::Godot.StringName @LastSnowRoofRegion = "LastSnowRoofRegion";
        /// <summary>
        /// Cached name for the 'RoofSnowTextureCount' property.
        /// </summary>
        public new static readonly global::Godot.StringName @RoofSnowTextureCount = "RoofSnowTextureCount";
        /// <summary>
        /// Cached name for the 'paletteTexture' field.
        /// </summary>
        public new static readonly global::Godot.StringName @paletteTexture = "paletteTexture";
        /// <summary>
        /// Cached name for the 'townSiteGuidanceTexture' field.
        /// </summary>
        public new static readonly global::Godot.StringName @townSiteGuidanceTexture = "townSiteGuidanceTexture";
        /// <summary>
        /// Cached name for the 'visibleTiles' field.
        /// </summary>
        public new static readonly global::Godot.StringName @visibleTiles = "visibleTiles";
        /// <summary>
        /// Cached name for the 'tileSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileSize = "tileSize";
        /// <summary>
        /// Cached name for the 'tileGap' field.
        /// </summary>
        public new static readonly global::Godot.StringName @tileGap = "tileGap";
        /// <summary>
        /// Cached name for the 'wrapsEastWest' field.
        /// </summary>
        public new static readonly global::Godot.StringName @wrapsEastWest = "wrapsEastWest";
        /// <summary>
        /// Cached name for the 'trees' field.
        /// </summary>
        public new static readonly global::Godot.StringName @trees = "trees";
        /// <summary>
        /// Cached name for the 'naturalObjects' field.
        /// </summary>
        public new static readonly global::Godot.StringName @naturalObjects = "naturalObjects";
        /// <summary>
        /// Cached name for the 'naturalStages' field.
        /// </summary>
        public new static readonly global::Godot.StringName @naturalStages = "naturalStages";
        /// <summary>
        /// Cached name for the 'weatherRegionSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @weatherRegionSize = "weatherRegionSize";
        /// <summary>
        /// Cached name for the 'groundSnowRegionSize' field.
        /// </summary>
        public new static readonly global::Godot.StringName @groundSnowRegionSize = "groundSnowRegionSize";
        /// <summary>
        /// Cached name for the 'snowTicksPerHour' field.
        /// </summary>
        public new static readonly global::Godot.StringName @snowTicksPerHour = "snowTicksPerHour";
        /// <summary>
        /// Cached name for the 'reliefTextureBytes' field.
        /// </summary>
        public new static readonly global::Godot.StringName @reliefTextureBytes = "reliefTextureBytes";
        /// <summary>
        /// Cached name for the 'reliefDrawSerial' field.
        /// </summary>
        public new static readonly global::Godot.StringName @reliefDrawSerial = "reliefDrawSerial";
        /// <summary>
        /// Cached name for the 'lastReliefCovers' field.
        /// </summary>
        public new static readonly global::Godot.StringName @lastReliefCovers = "lastReliefCovers";
        /// <summary>
        /// Cached name for the 'reliefDrawAtMs' field.
        /// </summary>
        public new static readonly global::Godot.StringName @reliefDrawAtMs = "reliefDrawAtMs";
        /// <summary>
        /// Cached name for the 'naturalAppearanceTrees' field.
        /// </summary>
        public new static readonly global::Godot.StringName @naturalAppearanceTrees = "naturalAppearanceTrees";
        /// <summary>
        /// Cached name for the 'resourceKindAppearanceTrees' field.
        /// </summary>
        public new static readonly global::Godot.StringName @resourceKindAppearanceTrees = "resourceKindAppearanceTrees";
        /// <summary>
        /// Cached name for the 'resourceKindAppearanceNaturalObjects' field.
        /// </summary>
        public new static readonly global::Godot.StringName @resourceKindAppearanceNaturalObjects = "resourceKindAppearanceNaturalObjects";
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool SetGodotClassPropertyValue(in godot_string_name name, in godot_variant value)
    {
        if (name == PropertyName.@AutumnLeavesEnabled) {
            this.@AutumnLeavesEnabled = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@AutumnLeafDrawCount) {
            this.@AutumnLeafDrawCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@Season) {
            this.@Season = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.LandscapeSeason>(value);
            return true;
        }
        if (name == PropertyName.@VisibleTileCount) {
            this.@VisibleTileCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@OverviewNaturalObjectDrawCount) {
            this.@OverviewNaturalObjectDrawCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@MeasureDrawCost) {
            this.@MeasureDrawCost = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@LastDrawMilliseconds) {
            this.@LastDrawMilliseconds = global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(value);
            return true;
        }
        if (name == PropertyName.@DrawSampleCount) {
            this.@DrawSampleCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@WeatherVersion) {
            this.@WeatherVersion = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@HasActiveWeather) {
            this.@HasActiveWeather = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@CactusSpriteCount) {
            this.@CactusSpriteCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@DrawnSnowTileCount) {
            this.@DrawnSnowTileCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@DrawnSnowFootprintCount) {
            this.@DrawnSnowFootprintCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@SnowOverviewDrawCount) {
            this.@SnowOverviewDrawCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@HillOverlayTileCount) {
            this.@HillOverlayTileCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@FadingReliefChunkCount) {
            this.@FadingReliefChunkCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@PrefetchedReliefChunkCount) {
            this.@PrefetchedReliefChunkCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@DrawnSnowRoofCount) {
            this.@DrawnSnowRoofCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@DrawnSnowRoofRegionCount) {
            this.@DrawnSnowRoofRegionCount = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@LastSnowRoofRegion) {
            this.@LastSnowRoofRegion = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(value);
            return true;
        }
        if (name == PropertyName.@paletteTexture) {
            this.@paletteTexture = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Texture2D>(value);
            return true;
        }
        if (name == PropertyName.@townSiteGuidanceTexture) {
            this.@townSiteGuidanceTexture = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.ImageTexture>(value);
            return true;
        }
        if (name == PropertyName.@visibleTiles) {
            this.@visibleTiles = global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(value);
            return true;
        }
        if (name == PropertyName.@tileSize) {
            this.@tileSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@tileGap) {
            this.@tileGap = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@wrapsEastWest) {
            this.@wrapsEastWest = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@trees) {
            this.@trees = global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(value);
            return true;
        }
        if (name == PropertyName.@naturalObjects) {
            this.@naturalObjects = global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(value);
            return true;
        }
        if (name == PropertyName.@naturalStages) {
            this.@naturalStages = global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(value);
            return true;
        }
        if (name == PropertyName.@weatherRegionSize) {
            this.@weatherRegionSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@groundSnowRegionSize) {
            this.@groundSnowRegionSize = global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(value);
            return true;
        }
        if (name == PropertyName.@snowTicksPerHour) {
            this.@snowTicksPerHour = global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(value);
            return true;
        }
        if (name == PropertyName.@reliefTextureBytes) {
            this.@reliefTextureBytes = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@reliefDrawSerial) {
            this.@reliefDrawSerial = global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(value);
            return true;
        }
        if (name == PropertyName.@lastReliefCovers) {
            this.@lastReliefCovers = global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(value);
            return true;
        }
        if (name == PropertyName.@reliefDrawAtMs) {
            this.@reliefDrawAtMs = global::Godot.NativeInterop.VariantUtils.ConvertTo<ulong>(value);
            return true;
        }
        if (name == PropertyName.@naturalAppearanceTrees) {
            this.@naturalAppearanceTrees = global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(value);
            return true;
        }
        if (name == PropertyName.@resourceKindAppearanceTrees) {
            this.@resourceKindAppearanceTrees = global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(value);
            return true;
        }
        if (name == PropertyName.@resourceKindAppearanceNaturalObjects) {
            this.@resourceKindAppearanceNaturalObjects = global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(value);
            return true;
        }
        return base.SetGodotClassPropertyValue(name, value);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool GetGodotClassPropertyValue(in godot_string_name name, out godot_variant value)
    {
        if (name == PropertyName.@AutumnLeavesEnabled) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@AutumnLeavesEnabled);
            return true;
        }
        if (name == PropertyName.@AutumnLeafDrawCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@AutumnLeafDrawCount);
            return true;
        }
        if (name == PropertyName.@Season) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.LandscapeSeason>(this.@Season);
            return true;
        }
        if (name == PropertyName.@VisibleTileCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@VisibleTileCount);
            return true;
        }
        if (name == PropertyName.@OverviewNaturalObjectDrawCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@OverviewNaturalObjectDrawCount);
            return true;
        }
        if (name == PropertyName.@MeasureDrawCost) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@MeasureDrawCost);
            return true;
        }
        if (name == PropertyName.@LastDrawMilliseconds) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<double>(this.@LastDrawMilliseconds);
            return true;
        }
        if (name == PropertyName.@DrawSampleCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@DrawSampleCount);
            return true;
        }
        if (name == PropertyName.@TownBorderTileCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@TownBorderTileCount);
            return true;
        }
        if (name == PropertyName.@HouseholdPropertyTileCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@HouseholdPropertyTileCount);
            return true;
        }
        if (name == PropertyName.@TownLandTitleTileCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@TownLandTitleTileCount);
            return true;
        }
        if (name == PropertyName.@HouseholdLandUseTileCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@HouseholdLandUseTileCount);
            return true;
        }
        if (name == PropertyName.@DisputedLandTileCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@DisputedLandTileCount);
            return true;
        }
        if (name == PropertyName.@VisibleTiles) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@VisibleTiles);
            return true;
        }
        if (name == PropertyName.@TileSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@TileSize);
            return true;
        }
        if (name == PropertyName.@Stride) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@Stride);
            return true;
        }
        if (name == PropertyName.@WrapsEastWest) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@WrapsEastWest);
            return true;
        }
        if (name == PropertyName.@WeatherRegionSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@WeatherRegionSize);
            return true;
        }
        if (name == PropertyName.@WeatherVersion) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@WeatherVersion);
            return true;
        }
        if (name == PropertyName.@HasActiveWeather) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@HasActiveWeather);
            return true;
        }
        if (name == PropertyName.@DrawsGroundTextures) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@DrawsGroundTextures);
            return true;
        }
        if (name == PropertyName.@BuildingSpriteCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@BuildingSpriteCount);
            return true;
        }
        if (name == PropertyName.@ConstructionSiteCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@ConstructionSiteCount);
            return true;
        }
        if (name == PropertyName.@ResourceKindSpriteCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@ResourceKindSpriteCount);
            return true;
        }
        if (name == PropertyName.@CactusSpriteCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@CactusSpriteCount);
            return true;
        }
        if (name == PropertyName.@SnowFootprintCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@SnowFootprintCount);
            return true;
        }
        if (name == PropertyName.@DrawnSnowTileCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@DrawnSnowTileCount);
            return true;
        }
        if (name == PropertyName.@DrawnSnowFootprintCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@DrawnSnowFootprintCount);
            return true;
        }
        if (name == PropertyName.@SnowOverviewDrawCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@SnowOverviewDrawCount);
            return true;
        }
        if (name == PropertyName.@ReliefTextureCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@ReliefTextureCount);
            return true;
        }
        if (name == PropertyName.@PendingReliefChunkCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@PendingReliefChunkCount);
            return true;
        }
        if (name == PropertyName.@HillOverlayTileCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@HillOverlayTileCount);
            return true;
        }
        if (name == PropertyName.@FadingReliefChunkCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@FadingReliefChunkCount);
            return true;
        }
        if (name == PropertyName.@PrefetchedReliefChunkCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@PrefetchedReliefChunkCount);
            return true;
        }
        if (name == PropertyName.@DrawsRelief) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@DrawsRelief);
            return true;
        }
        if (name == PropertyName.@DrawnSnowRoofCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@DrawnSnowRoofCount);
            return true;
        }
        if (name == PropertyName.@DrawnSnowRoofRegionCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@DrawnSnowRoofRegionCount);
            return true;
        }
        if (name == PropertyName.@LastSnowRoofRegion) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@LastSnowRoofRegion);
            return true;
        }
        if (name == PropertyName.@RoofSnowTextureCount) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@RoofSnowTextureCount);
            return true;
        }
        if (name == PropertyName.@paletteTexture) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Texture2D>(this.@paletteTexture);
            return true;
        }
        if (name == PropertyName.@townSiteGuidanceTexture) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ImageTexture>(this.@townSiteGuidanceTexture);
            return true;
        }
        if (name == PropertyName.@visibleTiles) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(this.@visibleTiles);
            return true;
        }
        if (name == PropertyName.@tileSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@tileSize);
            return true;
        }
        if (name == PropertyName.@tileGap) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@tileGap);
            return true;
        }
        if (name == PropertyName.@wrapsEastWest) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@wrapsEastWest);
            return true;
        }
        if (name == PropertyName.@trees) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<byte[]>(this.@trees);
            return true;
        }
        if (name == PropertyName.@naturalObjects) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<byte[]>(this.@naturalObjects);
            return true;
        }
        if (name == PropertyName.@naturalStages) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<byte[]>(this.@naturalStages);
            return true;
        }
        if (name == PropertyName.@weatherRegionSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@weatherRegionSize);
            return true;
        }
        if (name == PropertyName.@groundSnowRegionSize) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(this.@groundSnowRegionSize);
            return true;
        }
        if (name == PropertyName.@snowTicksPerHour) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(this.@snowTicksPerHour);
            return true;
        }
        if (name == PropertyName.@reliefTextureBytes) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@reliefTextureBytes);
            return true;
        }
        if (name == PropertyName.@reliefDrawSerial) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<long>(this.@reliefDrawSerial);
            return true;
        }
        if (name == PropertyName.@lastReliefCovers) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(this.@lastReliefCovers);
            return true;
        }
        if (name == PropertyName.@reliefDrawAtMs) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<ulong>(this.@reliefDrawAtMs);
            return true;
        }
        if (name == PropertyName.@naturalAppearanceTrees) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<byte[]>(this.@naturalAppearanceTrees);
            return true;
        }
        if (name == PropertyName.@resourceKindAppearanceTrees) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<byte[]>(this.@resourceKindAppearanceTrees);
            return true;
        }
        if (name == PropertyName.@resourceKindAppearanceNaturalObjects) {
            value = global::Godot.NativeInterop.VariantUtils.CreateFrom<byte[]>(this.@resourceKindAppearanceNaturalObjects);
            return true;
        }
        return base.GetGodotClassPropertyValue(name, out value);
    }
    /// <summary>
    /// Get the property information for all the properties declared in this class.
    /// This method is used by Godot to register the available properties in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo> GetGodotPropertyList()
    {
        var properties = new global::System.Collections.Generic.List<global::Godot.Bridge.PropertyInfo>();
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@AutumnLeavesEnabled, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@AutumnLeafDrawCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@paletteTexture, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Season, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)24, name: PropertyName.@townSiteGuidanceTexture, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@visibleTiles, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@tileSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@tileGap, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@wrapsEastWest, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)29, name: PropertyName.@trees, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)29, name: PropertyName.@naturalObjects, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)29, name: PropertyName.@naturalStages, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@weatherRegionSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@VisibleTileCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@OverviewNaturalObjectDrawCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@MeasureDrawCost, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@LastDrawMilliseconds, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@DrawSampleCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@TownBorderTileCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@HouseholdPropertyTileCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@TownLandTitleTileCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@HouseholdLandUseTileCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@DisputedLandTileCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@VisibleTiles, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@TileSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@Stride, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@WrapsEastWest, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@WeatherRegionSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@WeatherVersion, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@HasActiveWeather, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@DrawsGroundTextures, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@BuildingSpriteCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@ConstructionSiteCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@ResourceKindSpriteCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@CactusSpriteCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@groundSnowRegionSize, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)3, name: PropertyName.@snowTicksPerHour, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@SnowFootprintCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@DrawnSnowTileCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@DrawnSnowFootprintCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@SnowOverviewDrawCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@reliefTextureBytes, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@reliefDrawSerial, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@lastReliefCovers, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@reliefDrawAtMs, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@ReliefTextureCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@PendingReliefChunkCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@HillOverlayTileCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@FadingReliefChunkCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@PrefetchedReliefChunkCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)1, name: PropertyName.@DrawsRelief, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)29, name: PropertyName.@naturalAppearanceTrees, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)29, name: PropertyName.@resourceKindAppearanceTrees, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)29, name: PropertyName.@resourceKindAppearanceNaturalObjects, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@DrawnSnowRoofCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@DrawnSnowRoofRegionCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)7, name: PropertyName.@LastSnowRoofRegion, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        properties.Add(new(type: (global::Godot.Variant.Type)2, name: PropertyName.@RoofSnowTextureCount, hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)4096, exported: false));
        return properties;
    }
#pragma warning restore CS0109
}

}
