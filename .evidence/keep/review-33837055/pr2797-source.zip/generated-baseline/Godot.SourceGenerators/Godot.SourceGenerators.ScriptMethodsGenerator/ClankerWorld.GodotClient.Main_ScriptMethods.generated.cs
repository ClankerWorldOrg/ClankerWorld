﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient {

partial class Main
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the methods contained in this class, for fast lookup.
    /// </summary>
    public new class MethodName : global::Godot.Control.MethodName {
        /// <summary>
        /// Cached name for the 'VerifyAgentCardStyleRetention' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyAgentCardStyleRetention = "VerifyAgentCardStyleRetention";
        /// <summary>
        /// Cached name for the 'VerifyMarriageOrderText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyMarriageOrderText = "VerifyMarriageOrderText";
        /// <summary>
        /// Cached name for the 'VerifyAnimalPresentation' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyAnimalPresentation = "VerifyAnimalPresentation";
        /// <summary>
        /// Cached name for the 'VerifyBoatPresentation' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyBoatPresentation = "VerifyBoatPresentation";
        /// <summary>
        /// Cached name for the 'VerifyConstructionPixelContracts' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyConstructionPixelContracts = "VerifyConstructionPixelContracts";
        /// <summary>
        /// Cached name for the 'RequireConstructionHalf' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RequireConstructionHalf = "RequireConstructionHalf";
        /// <summary>
        /// Cached name for the 'ConstructionColor' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConstructionColor = "ConstructionColor";
        /// <summary>
        /// Cached name for the 'VerifyPlainEllipses' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyPlainEllipses = "VerifyPlainEllipses";
        /// <summary>
        /// Cached name for the 'VerifyAgentTextEllipses' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyAgentTextEllipses = "VerifyAgentTextEllipses";
        /// <summary>
        /// Cached name for the 'VerifyEventLogRefusalRollover' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyEventLogRefusalRollover = "VerifyEventLogRefusalRollover";
        /// <summary>
        /// Cached name for the 'HandcartPixelDigest' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HandcartPixelDigest = "HandcartPixelDigest";
        /// <summary>
        /// Cached name for the 'ApprovedHandcartDigest' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ApprovedHandcartDigest = "ApprovedHandcartDigest";
        /// <summary>
        /// Cached name for the 'VerifyHandcartApprovedPixels' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyHandcartApprovedPixels = "VerifyHandcartApprovedPixels";
        /// <summary>
        /// Cached name for the 'VerifyHandcartMotionAndZoom' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyHandcartMotionAndZoom = "VerifyHandcartMotionAndZoom";
        /// <summary>
        /// Cached name for the 'VerifyHandcartInspection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyHandcartInspection = "VerifyHandcartInspection";
        /// <summary>
        /// Cached name for the 'AgentListCardText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AgentListCardText = "AgentListCardText";
        /// <summary>
        /// Cached name for the 'VerifyEventRows' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyEventRows = "VerifyEventRows";
        /// <summary>
        /// Cached name for the 'ShowsFind' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowsFind = "ShowsFind";
        /// <summary>
        /// Cached name for the 'NewcomerOfferButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @NewcomerOfferButton = "NewcomerOfferButton";
        /// <summary>
        /// Cached name for the 'VerifyControlsKeycaps' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyControlsKeycaps = "VerifyControlsKeycaps";
        /// <summary>
        /// Cached name for the 'VerifyDeveloperRunOptions' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyDeveloperRunOptions = "VerifyDeveloperRunOptions";
        /// <summary>
        /// Cached name for the 'VerifySaveBranchList' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifySaveBranchList = "VerifySaveBranchList";
        /// <summary>
        /// Cached name for the 'VerifyMapPanels' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyMapPanels = "VerifyMapPanels";
        /// <summary>
        /// Cached name for the 'VerifyModelSettingsLayout' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyModelSettingsLayout = "VerifyModelSettingsLayout";
        /// <summary>
        /// Cached name for the 'VerifyAbandonedBuildingLooks' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyAbandonedBuildingLooks = "VerifyAbandonedBuildingLooks";
        /// <summary>
        /// Cached name for the 'VerifyAbandonedLanternsAndBridges' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyAbandonedLanternsAndBridges = "VerifyAbandonedLanternsAndBridges";
        /// <summary>
        /// Cached name for the 'VerifyAbandonedArtSampling' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyAbandonedArtSampling = "VerifyAbandonedArtSampling";
        /// <summary>
        /// Cached name for the 'VerifyPeopleInside' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyPeopleInside = "VerifyPeopleInside";
        /// <summary>
        /// Cached name for the 'VerifyOrnamentPresentation' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyOrnamentPresentation = "VerifyOrnamentPresentation";
        /// <summary>
        /// Cached name for the 'CaptionForChecks' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CaptionForChecks = "CaptionForChecks";
        /// <summary>
        /// Cached name for the 'VerifyPanelParts' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyPanelParts = "VerifyPanelParts";
        /// <summary>
        /// Cached name for the 'VerifyProblemReport' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyProblemReport = "VerifyProblemReport";
        /// <summary>
        /// Cached name for the 'ReliefRegionMatches' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ReliefRegionMatches = "ReliefRegionMatches";
        /// <summary>
        /// Cached name for the 'CheckThemeTextContrast' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CheckThemeTextContrast = "CheckThemeTextContrast";
        /// <summary>
        /// Cached name for the 'ThemeTextSurface' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ThemeTextSurface = "ThemeTextSurface";
        /// <summary>
        /// Cached name for the 'TextureCenter' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TextureCenter = "TextureCenter";
        /// <summary>
        /// Cached name for the 'Composite' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Composite = "Composite";
        /// <summary>
        /// Cached name for the 'VerifyToolMakingPresentation' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyToolMakingPresentation = "VerifyToolMakingPresentation";
        /// <summary>
        /// Cached name for the 'ShowsGlyph' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowsGlyph = "ShowsGlyph";
        /// <summary>
        /// Cached name for the 'VerifyConsistentButtons' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyConsistentButtons = "VerifyConsistentButtons";
        /// <summary>
        /// Cached name for the 'VerifyModelPicker' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyModelPicker = "VerifyModelPicker";
        /// <summary>
        /// Cached name for the 'VerifyChildModelStatus' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyChildModelStatus = "VerifyChildModelStatus";
        /// <summary>
        /// Cached name for the 'VerifyPixelText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyPixelText = "VerifyPixelText";
        /// <summary>
        /// Cached name for the 'VerifyWorldThumbnailFallback' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyWorldThumbnailFallback = "VerifyWorldThumbnailFallback";
        /// <summary>
        /// Cached name for the 'VerifyMainMenuLogo' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyMainMenuLogo = "VerifyMainMenuLogo";
        /// <summary>
        /// Cached name for the 'VerifyAppIconFile' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyAppIconFile = "VerifyAppIconFile";
        /// <summary>
        /// Cached name for the 'FinishUiSmoke' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FinishUiSmoke = "FinishUiSmoke";
        /// <summary>
        /// Cached name for the 'VerifyEventLogAgentNames' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyEventLogAgentNames = "VerifyEventLogAgentNames";
        /// <summary>
        /// Cached name for the 'ShowWorldActionSmokeMenu' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowWorldActionSmokeMenu = "ShowWorldActionSmokeMenu";
        /// <summary>
        /// Cached name for the 'ChooseWorldActionSmokeRow' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ChooseWorldActionSmokeRow = "ChooseWorldActionSmokeRow";
        /// <summary>
        /// Cached name for the 'RequireWorldPreviewCleared' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RequireWorldPreviewCleared = "RequireWorldPreviewCleared";
        /// <summary>
        /// Cached name for the 'VerifyYardAnimalInspection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyYardAnimalInspection = "VerifyYardAnimalInspection";
        /// <summary>
        /// Cached name for the 'BuildConversationReader' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildConversationReader = "BuildConversationReader";
        /// <summary>
        /// Cached name for the 'OpenAgentConversation' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenAgentConversation = "OpenAgentConversation";
        /// <summary>
        /// Cached name for the 'ToggleConversationHistory' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleConversationHistory = "ToggleConversationHistory";
        /// <summary>
        /// Cached name for the 'ConversationPreview' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConversationPreview = "ConversationPreview";
        /// <summary>
        /// Cached name for the 'ConversationInterruptionText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConversationInterruptionText = "ConversationInterruptionText";
        /// <summary>
        /// Cached name for the 'ConversationOutcomeText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConversationOutcomeText = "ConversationOutcomeText";
        /// <summary>
        /// Cached name for the 'ConversationTurnKey' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConversationTurnKey = "ConversationTurnKey";
        /// <summary>
        /// Cached name for the 'BuildAgentListCards' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildAgentListCards = "BuildAgentListCards";
        /// <summary>
        /// Cached name for the 'SelectAgentListCard' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectAgentListCard = "SelectAgentListCard";
        /// <summary>
        /// Cached name for the 'Capitalize' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Capitalize = "Capitalize";
        /// <summary>
        /// Cached name for the 'RefreshAgentListSelection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshAgentListSelection = "RefreshAgentListSelection";
        /// <summary>
        /// Cached name for the 'CenterOnAgent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CenterOnAgent = "CenterOnAgent";
        /// <summary>
        /// Cached name for the 'SelectedRoleId' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedRoleId = "SelectedRoleId";
        /// <summary>
        /// Cached name for the 'SelectedAgentModelTarget' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedAgentModelTarget = "SelectedAgentModelTarget";
        /// <summary>
        /// Cached name for the 'SelectedTargetWasBornHere' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedTargetWasBornHere = "SelectedTargetWasBornHere";
        /// <summary>
        /// Cached name for the 'PopulateAgentModelTargets' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PopulateAgentModelTargets = "PopulateAgentModelTargets";
        /// <summary>
        /// Cached name for the 'ActiveProviderForSelectedRole' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ActiveProviderForSelectedRole = "ActiveProviderForSelectedRole";
        /// <summary>
        /// Cached name for the 'PopulateProviderChoices' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PopulateProviderChoices = "PopulateProviderChoices";
        /// <summary>
        /// Cached name for the 'SelectProviderChoice' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectProviderChoice = "SelectProviderChoice";
        /// <summary>
        /// Cached name for the 'AddProviderChoice' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddProviderChoice = "AddProviderChoice";
        /// <summary>
        /// Cached name for the 'SelectedProviderId' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedProviderId = "SelectedProviderId";
        /// <summary>
        /// Cached name for the 'SelectedCredentialChoice' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedCredentialChoice = "SelectedCredentialChoice";
        /// <summary>
        /// Cached name for the 'PopulateCredentialChoices' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PopulateCredentialChoices = "PopulateCredentialChoices";
        /// <summary>
        /// Cached name for the 'IsModelProvider' method.
        /// </summary>
        public new static readonly global::Godot.StringName @IsModelProvider = "IsModelProvider";
        /// <summary>
        /// Cached name for the 'PopulateThinkingChoices' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PopulateThinkingChoices = "PopulateThinkingChoices";
        /// <summary>
        /// Cached name for the 'SelectedThinking' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedThinking = "SelectedThinking";
        /// <summary>
        /// Cached name for the 'SelectThinking' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectThinking = "SelectThinking";
        /// <summary>
        /// Cached name for the 'RenderProviderConfiguration' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderProviderConfiguration = "RenderProviderConfiguration";
        /// <summary>
        /// Cached name for the 'SelectedChildModelStatus' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedChildModelStatus = "SelectedChildModelStatus";
        /// <summary>
        /// Cached name for the 'RoleDisplayName' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RoleDisplayName = "RoleDisplayName";
        /// <summary>
        /// Cached name for the 'ProviderDisplayName' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ProviderDisplayName = "ProviderDisplayName";
        /// <summary>
        /// Cached name for the 'DefaultProviderModel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DefaultProviderModel = "DefaultProviderModel";
        /// <summary>
        /// Cached name for the 'FieldCaption' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FieldCaption = "FieldCaption";
        /// <summary>
        /// Cached name for the 'BuildAgentModelPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildAgentModelPanel = "BuildAgentModelPanel";
        /// <summary>
        /// Cached name for the 'OpenAgentModelEditor' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenAgentModelEditor = "OpenAgentModelEditor";
        /// <summary>
        /// Cached name for the 'BuildAgentModelScroll' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildAgentModelScroll = "BuildAgentModelScroll";
        /// <summary>
        /// Cached name for the 'FitAgentModelScroll' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitAgentModelScroll = "FitAgentModelScroll";
        /// <summary>
        /// Cached name for the 'CloseAgentModelEditor' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CloseAgentModelEditor = "CloseAgentModelEditor";
        /// <summary>
        /// Cached name for the 'BuildAgentProfile' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildAgentProfile = "BuildAgentProfile";
        /// <summary>
        /// Cached name for the 'AddProfileText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddProfileText = "AddProfileText";
        /// <summary>
        /// Cached name for the 'StyleCompactToggle' method.
        /// </summary>
        public new static readonly global::Godot.StringName @StyleCompactToggle = "StyleCompactToggle";
        /// <summary>
        /// Cached name for the 'ReaderHeading' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ReaderHeading = "ReaderHeading";
        /// <summary>
        /// Cached name for the 'BuildThoughtsReader' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildThoughtsReader = "BuildThoughtsReader";
        /// <summary>
        /// Cached name for the 'OpenThoughtsReader' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenThoughtsReader = "OpenThoughtsReader";
        /// <summary>
        /// Cached name for the 'PlaceReaderPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PlaceReaderPanel = "PlaceReaderPanel";
        /// <summary>
        /// Cached name for the 'OpenAgentProfile' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenAgentProfile = "OpenAgentProfile";
        /// <summary>
        /// Cached name for the 'AgentProfileBack' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AgentProfileBack = "AgentProfileBack";
        /// <summary>
        /// Cached name for the 'ToggleRenameRow' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleRenameRow = "ToggleRenameRow";
        /// <summary>
        /// Cached name for the 'UpdateAgentProfileCloseButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdateAgentProfileCloseButton = "UpdateAgentProfileCloseButton";
        /// <summary>
        /// Cached name for the 'PositionAgentProfile' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PositionAgentProfile = "PositionAgentProfile";
        /// <summary>
        /// Cached name for the 'QueueAgentProfileFit' method.
        /// </summary>
        public new static readonly global::Godot.StringName @QueueAgentProfileFit = "QueueAgentProfileFit";
        /// <summary>
        /// Cached name for the 'FitQueuedAgentProfile' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitQueuedAgentProfile = "FitQueuedAgentProfile";
        /// <summary>
        /// Cached name for the 'FitAgentOverviewScroll' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitAgentOverviewScroll = "FitAgentOverviewScroll";
        /// <summary>
        /// Cached name for the 'BuildAgentCards' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildAgentCards = "BuildAgentCards";
        /// <summary>
        /// Cached name for the 'BuildQuickCard' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildQuickCard = "BuildQuickCard";
        /// <summary>
        /// Cached name for the 'RefreshAgentCardIcons' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshAgentCardIcons = "RefreshAgentCardIcons";
        /// <summary>
        /// Cached name for the 'CenterOnSelectedAgent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CenterOnSelectedAgent = "CenterOnSelectedAgent";
        /// <summary>
        /// Cached name for the 'Sentence' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Sentence = "Sentence";
        /// <summary>
        /// Cached name for the 'ThoughtTime' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ThoughtTime = "ThoughtTime";
        /// <summary>
        /// Cached name for the 'BuildApiKeysPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildApiKeysPanel = "BuildApiKeysPanel";
        /// <summary>
        /// Cached name for the 'RenderSavedApiKeys' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderSavedApiKeys = "RenderSavedApiKeys";
        /// <summary>
        /// Cached name for the 'CredentialProviderDisplayName' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CredentialProviderDisplayName = "CredentialProviderDisplayName";
        /// <summary>
        /// Cached name for the 'BuildBuildingCards' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildBuildingCards = "BuildBuildingCards";
        /// <summary>
        /// Cached name for the 'SectionRow' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SectionRow = "SectionRow";
        /// <summary>
        /// Cached name for the 'SelectBuilding' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectBuilding = "SelectBuilding";
        /// <summary>
        /// Cached name for the 'ClearBuildingSelection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearBuildingSelection = "ClearBuildingSelection";
        /// <summary>
        /// Cached name for the 'OpenBuildingDetails' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenBuildingDetails = "OpenBuildingDetails";
        /// <summary>
        /// Cached name for the 'BuildingDetailsBack' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildingDetailsBack = "BuildingDetailsBack";
        /// <summary>
        /// Cached name for the 'CenterOnSelectedBuilding' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CenterOnSelectedBuilding = "CenterOnSelectedBuilding";
        /// <summary>
        /// Cached name for the 'ApplyBuildingReassignment' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ApplyBuildingReassignment = "ApplyBuildingReassignment";
        /// <summary>
        /// Cached name for the 'ConfirmBuildingRemoval' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfirmBuildingRemoval = "ConfirmBuildingRemoval";
        /// <summary>
        /// Cached name for the 'CancelBuildingRemoval' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CancelBuildingRemoval = "CancelBuildingRemoval";
        /// <summary>
        /// Cached name for the 'RemoveSelectedBuilding' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RemoveSelectedBuilding = "RemoveSelectedBuilding";
        /// <summary>
        /// Cached name for the 'RecipeName' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RecipeName = "RecipeName";
        /// <summary>
        /// Cached name for the 'RecipeIcon' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RecipeIcon = "RecipeIcon";
        /// <summary>
        /// Cached name for the 'TimeLeft' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TimeLeft = "TimeLeft";
        /// <summary>
        /// Cached name for the 'PeopleInside' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PeopleInside = "PeopleInside";
        /// <summary>
        /// Cached name for the 'Plural' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Plural = "Plural";
        /// <summary>
        /// Cached name for the 'ClearChildren' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearChildren = "ClearChildren";
        /// <summary>
        /// Cached name for the 'PositionBuildingDetails' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PositionBuildingDetails = "PositionBuildingDetails";
        /// <summary>
        /// Cached name for the 'BuildBuildingStorageHistory' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildBuildingStorageHistory = "BuildBuildingStorageHistory";
        /// <summary>
        /// Cached name for the 'BeginCameraMotion' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BeginCameraMotion = "BeginCameraMotion";
        /// <summary>
        /// Cached name for the 'CancelCameraMotion' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CancelCameraMotion = "CancelCameraMotion";
        /// <summary>
        /// Cached name for the 'SetCameraAtImmediately' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetCameraAtImmediately = "SetCameraAtImmediately";
        /// <summary>
        /// Cached name for the 'AdvanceCameraMotion' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AdvanceCameraMotion = "AdvanceCameraMotion";
        /// <summary>
        /// Cached name for the 'IsCurrentWorldRequest' method.
        /// </summary>
        public new static readonly global::Godot.StringName @IsCurrentWorldRequest = "IsCurrentWorldRequest";
        /// <summary>
        /// Cached name for the 'ConfiguredServerUrl' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfiguredServerUrl = "ConfiguredServerUrl";
        /// <summary>
        /// Cached name for the '_Ready' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Ready = "_Ready";
        /// <summary>
        /// Cached name for the '_ExitTree' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_ExitTree = "_ExitTree";
        /// <summary>
        /// Cached name for the 'BuildDeveloperEdits' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildDeveloperEdits = "BuildDeveloperEdits";
        /// <summary>
        /// Cached name for the 'ConfigureDeveloperEdit' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfigureDeveloperEdit = "ConfigureDeveloperEdit";
        /// <summary>
        /// Cached name for the 'BuildDeveloperTools' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildDeveloperTools = "BuildDeveloperTools";
        /// <summary>
        /// Cached name for the 'BuildDeveloperAgingOverride' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildDeveloperAgingOverride = "BuildDeveloperAgingOverride";
        /// <summary>
        /// Cached name for the 'ToggleDeveloperTools' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleDeveloperTools = "ToggleDeveloperTools";
        /// <summary>
        /// Cached name for the 'CloseDeveloperTools' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CloseDeveloperTools = "CloseDeveloperTools";
        /// <summary>
        /// Cached name for the 'PositionDeveloperTools' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PositionDeveloperTools = "PositionDeveloperTools";
        /// <summary>
        /// Cached name for the 'JumpToDeveloperAgent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @JumpToDeveloperAgent = "JumpToDeveloperAgent";
        /// <summary>
        /// Cached name for the 'RenderDeveloperTile' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderDeveloperTile = "RenderDeveloperTile";
        /// <summary>
        /// Cached name for the 'UpdateDeveloperFrameTime' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdateDeveloperFrameTime = "UpdateDeveloperFrameTime";
        /// <summary>
        /// Cached name for the 'RenderDeveloperRoute' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderDeveloperRoute = "RenderDeveloperRoute";
        /// <summary>
        /// Cached name for the 'RenderPlannedPath' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderPlannedPath = "RenderPlannedPath";
        /// <summary>
        /// Cached name for the 'StyleConfirmation' method.
        /// </summary>
        public new static readonly global::Godot.StringName @StyleConfirmation = "StyleConfirmation";
        /// <summary>
        /// Cached name for the 'SetFullscreen' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetFullscreen = "SetFullscreen";
        /// <summary>
        /// Cached name for the 'ApplySavedDisplaySettings' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ApplySavedDisplaySettings = "ApplySavedDisplaySettings";
        /// <summary>
        /// Cached name for the 'ApplyUiScale' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ApplyUiScale = "ApplyUiScale";
        /// <summary>
        /// Cached name for the 'SetUiFactor' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetUiFactor = "SetUiFactor";
        /// <summary>
        /// Cached name for the 'ScaleWindows' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ScaleWindows = "ScaleWindows";
        /// <summary>
        /// Cached name for the 'ScaleMapText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ScaleMapText = "ScaleMapText";
        /// <summary>
        /// Cached name for the 'PopupDialog' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PopupDialog = "PopupDialog";
        /// <summary>
        /// Cached name for the 'DialogSize' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DialogSize = "DialogSize";
        /// <summary>
        /// Cached name for the 'FitDialog' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitDialog = "FitDialog";
        /// <summary>
        /// Cached name for the 'CurrentMonitorSize' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CurrentMonitorSize = "CurrentMonitorSize";
        /// <summary>
        /// Cached name for the 'AutomaticRenderSize' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AutomaticRenderSize = "AutomaticRenderSize";
        /// <summary>
        /// Cached name for the 'RefreshRenderSize' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshRenderSize = "RefreshRenderSize";
        /// <summary>
        /// Cached name for the 'DisplaySizeIndex' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DisplaySizeIndex = "DisplaySizeIndex";
        /// <summary>
        /// Cached name for the 'SettingsBox' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SettingsBox = "SettingsBox";
        /// <summary>
        /// Cached name for the 'DisplaySettingRow' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DisplaySettingRow = "DisplaySettingRow";
        /// <summary>
        /// Cached name for the 'SetWindowSize' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetWindowSize = "SetWindowSize";
        /// <summary>
        /// Cached name for the 'SetCloudHaze' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetCloudHaze = "SetCloudHaze";
        /// <summary>
        /// Cached name for the 'SetLightningFlashes' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetLightningFlashes = "SetLightningFlashes";
        /// <summary>
        /// Cached name for the 'SetUiTheme' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetUiTheme = "SetUiTheme";
        /// <summary>
        /// Cached name for the '_Notification' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Notification = "_Notification";
        /// <summary>
        /// Cached name for the 'ApplyThemeColors' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ApplyThemeColors = "ApplyThemeColors";
        /// <summary>
        /// Cached name for the 'SetClockFormat' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetClockFormat = "SetClockFormat";
        /// <summary>
        /// Cached name for the 'DateStyleIndex' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DateStyleIndex = "DateStyleIndex";
        /// <summary>
        /// Cached name for the 'SetDateStyle' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetDateStyle = "SetDateStyle";
        /// <summary>
        /// Cached name for the 'DisplayWorldClock' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DisplayWorldClock = "DisplayWorldClock";
        /// <summary>
        /// Cached name for the 'RenderEventLog' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderEventLog = "RenderEventLog";
        /// <summary>
        /// Cached name for the 'JumpToEvent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @JumpToEvent = "JumpToEvent";
        /// <summary>
        /// Cached name for the 'BuildEventRows' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildEventRows = "BuildEventRows";
        /// <summary>
        /// Cached name for the 'AddNewcomerOffer' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddNewcomerOffer = "AddNewcomerOffer";
        /// <summary>
        /// Cached name for the 'FillFamilyLegend' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FillFamilyLegend = "FillFamilyLegend";
        /// <summary>
        /// Cached name for the 'BuildFiltersButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildFiltersButton = "BuildFiltersButton";
        /// <summary>
        /// Cached name for the 'BuildMapFiltersPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildMapFiltersPanel = "BuildMapFiltersPanel";
        /// <summary>
        /// Cached name for the 'ToggleMapFilters' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleMapFilters = "ToggleMapFilters";
        /// <summary>
        /// Cached name for the 'ApplyMapFiltersFromCurrentSnapshot' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ApplyMapFiltersFromCurrentSnapshot = "ApplyMapFiltersFromCurrentSnapshot";
        /// <summary>
        /// Cached name for the 'ToggleMoveFounder' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleMoveFounder = "ToggleMoveFounder";
        /// <summary>
        /// Cached name for the 'ToggleFirstTownSite' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleFirstTownSite = "ToggleFirstTownSite";
        /// <summary>
        /// Cached name for the 'CancelFirstTownSiteSelection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CancelFirstTownSiteSelection = "CancelFirstTownSiteSelection";
        /// <summary>
        /// Cached name for the 'BuildFounderSetupPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildFounderSetupPanel = "BuildFounderSetupPanel";
        /// <summary>
        /// Cached name for the 'SelectedFounderProvider' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedFounderProvider = "SelectedFounderProvider";
        /// <summary>
        /// Cached name for the 'SelectedFounderCredential' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedFounderCredential = "SelectedFounderCredential";
        /// <summary>
        /// Cached name for the 'PopulateFounderCredentials' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PopulateFounderCredentials = "PopulateFounderCredentials";
        /// <summary>
        /// Cached name for the 'RenderFounderCredentialInputs' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderFounderCredentialInputs = "RenderFounderCredentialInputs";
        /// <summary>
        /// Cached name for the 'ResetAddAgentPlacementHint' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ResetAddAgentPlacementHint = "ResetAddAgentPlacementHint";
        /// <summary>
        /// Cached name for the 'PlacementRefusalText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PlacementRefusalText = "PlacementRefusalText";
        /// <summary>
        /// Cached name for the 'BuildGenerationSettings' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildGenerationSettings = "BuildGenerationSettings";
        /// <summary>
        /// Cached name for the 'BuildTopBar' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildTopBar = "BuildTopBar";
        /// <summary>
        /// Cached name for the 'HudGroup' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HudGroup = "HudGroup";
        /// <summary>
        /// Cached name for the 'AttachCorner' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AttachCorner = "AttachCorner";
        /// <summary>
        /// Cached name for the 'CompactHud' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CompactHud = "CompactHud";
        /// <summary>
        /// Cached name for the 'PlaceUnderButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PlaceUnderButton = "PlaceUnderButton";
        /// <summary>
        /// Cached name for the 'PlaceHudPanels' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PlaceHudPanels = "PlaceHudPanels";
        /// <summary>
        /// Cached name for the 'HudPanels' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HudPanels = "HudPanels";
        /// <summary>
        /// Cached name for the 'RefreshHudIcons' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshHudIcons = "RefreshHudIcons";
        /// <summary>
        /// Cached name for the 'UpdateUnreadEvents' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdateUnreadEvents = "UpdateUnreadEvents";
        /// <summary>
        /// Cached name for the 'MarkEventsSeen' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MarkEventsSeen = "MarkEventsSeen";
        /// <summary>
        /// Cached name for the 'BuildWorldInfoPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildWorldInfoPanel = "BuildWorldInfoPanel";
        /// <summary>
        /// Cached name for the 'ShowWorldInfoPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowWorldInfoPage = "ShowWorldInfoPage";
        /// <summary>
        /// Cached name for the 'ToggleTowns' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleTowns = "ToggleTowns";
        /// <summary>
        /// Cached name for the 'CivicElectionName' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CivicElectionName = "CivicElectionName";
        /// <summary>
        /// Cached name for the 'TownListText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TownListText = "TownListText";
        /// <summary>
        /// Cached name for the 'CenterOnTown' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CenterOnTown = "CenterOnTown";
        /// <summary>
        /// Cached name for the 'BuildKeyboardNavigation' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildKeyboardNavigation = "BuildKeyboardNavigation";
        /// <summary>
        /// Cached name for the 'ConfigureKeyboardScrollBar' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfigureKeyboardScrollBar = "ConfigureKeyboardScrollBar";
        /// <summary>
        /// Cached name for the 'CurrentKeyboardPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CurrentKeyboardPanel = "CurrentKeyboardPanel";
        /// <summary>
        /// Cached name for the 'IsKeyboardFocusable' method.
        /// </summary>
        public new static readonly global::Godot.StringName @IsKeyboardFocusable = "IsKeyboardFocusable";
        /// <summary>
        /// Cached name for the 'KeyboardControls' method.
        /// </summary>
        public new static readonly global::Godot.StringName @KeyboardControls = "KeyboardControls";
        /// <summary>
        /// Cached name for the 'FocusKeyboardPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FocusKeyboardPanel = "FocusKeyboardPanel";
        /// <summary>
        /// Cached name for the 'HandleKeyboardNavigationInput' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HandleKeyboardNavigationInput = "HandleKeyboardNavigationInput";
        /// <summary>
        /// Cached name for the 'BeginKeyboardMapSelection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BeginKeyboardMapSelection = "BeginKeyboardMapSelection";
        /// <summary>
        /// Cached name for the 'KeyboardMapCanvasPoint' method.
        /// </summary>
        public new static readonly global::Godot.StringName @KeyboardMapCanvasPoint = "KeyboardMapCanvasPoint";
        /// <summary>
        /// Cached name for the 'RefreshKeyboardMapSelection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshKeyboardMapSelection = "RefreshKeyboardMapSelection";
        /// <summary>
        /// Cached name for the 'CenterKeyboardCameraAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CenterKeyboardCameraAt = "CenterKeyboardCameraAt";
        /// <summary>
        /// Cached name for the 'GameUserPath' method.
        /// </summary>
        public new static readonly global::Godot.StringName @GameUserPath = "GameUserPath";
        /// <summary>
        /// Cached name for the 'BuildQuitToLauncher' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildQuitToLauncher = "BuildQuitToLauncher";
        /// <summary>
        /// Cached name for the 'TryOpenLauncher' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TryOpenLauncher = "TryOpenLauncher";
        /// <summary>
        /// Cached name for the 'ShowLauncherStartFailure' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowLauncherStartFailure = "ShowLauncherStartFailure";
        /// <summary>
        /// Cached name for the 'BuildLayout' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildLayout = "BuildLayout";
        /// <summary>
        /// Cached name for the 'ShowSettingsSection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowSettingsSection = "ShowSettingsSection";
        /// <summary>
        /// Cached name for the 'BuildWorldColumn' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildWorldColumn = "BuildWorldColumn";
        /// <summary>
        /// Cached name for the 'BuildInspectorColumn' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildInspectorColumn = "BuildInspectorColumn";
        /// <summary>
        /// Cached name for the 'BuildOwnerColumn' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildOwnerColumn = "BuildOwnerColumn";
        /// <summary>
        /// Cached name for the 'BuildStatusToast' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildStatusToast = "BuildStatusToast";
        /// <summary>
        /// Cached name for the 'EmptyToNull' method.
        /// </summary>
        public new static readonly global::Godot.StringName @EmptyToNull = "EmptyToNull";
        /// <summary>
        /// Cached name for the 'SetPanelText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetPanelText = "SetPanelText";
        /// <summary>
        /// Cached name for the 'ConfigureTextPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfigureTextPanel = "ConfigureTextPanel";
        /// <summary>
        /// Cached name for the 'FitQueuedTextPanels' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitQueuedTextPanels = "FitQueuedTextPanels";
        /// <summary>
        /// Cached name for the 'FitTextPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitTextPanel = "FitTextPanel";
        /// <summary>
        /// Cached name for the 'FitFloatingPanelsToContents' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitFloatingPanelsToContents = "FitFloatingPanelsToContents";
        /// <summary>
        /// Cached name for the 'FloatingPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FloatingPanel = "FloatingPanel";
        /// <summary>
        /// Cached name for the 'NewPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @NewPanel = "NewPanel";
        /// <summary>
        /// Cached name for the 'AddPanelContents' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddPanelContents = "AddPanelContents";
        /// <summary>
        /// Cached name for the 'MetricRow' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MetricRow = "MetricRow";
        /// <summary>
        /// Cached name for the 'CloseButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CloseButton = "CloseButton";
        /// <summary>
        /// Cached name for the 'StyleIconButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @StyleIconButton = "StyleIconButton";
        /// <summary>
        /// Cached name for the 'StyleMenuChoice' method.
        /// </summary>
        public new static readonly global::Godot.StringName @StyleMenuChoice = "StyleMenuChoice";
        /// <summary>
        /// Cached name for the 'StyleButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @StyleButton = "StyleButton";
        /// <summary>
        /// Cached name for the 'StyleSettingsCategoryButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @StyleSettingsCategoryButton = "StyleSettingsCategoryButton";
        /// <summary>
        /// Cached name for the 'SelectSettingsCategory' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectSettingsCategory = "SelectSettingsCategory";
        /// <summary>
        /// Cached name for the 'CompleteLocalServerStartup' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CompleteLocalServerStartup = "CompleteLocalServerStartup";
        /// <summary>
        /// Cached name for the 'QuitGame' method.
        /// </summary>
        public new static readonly global::Godot.StringName @QuitGame = "QuitGame";
        /// <summary>
        /// Cached name for the 'QuitToLauncher' method.
        /// </summary>
        public new static readonly global::Godot.StringName @QuitToLauncher = "QuitToLauncher";
        /// <summary>
        /// Cached name for the 'ShowLocalServerStopFailure' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowLocalServerStopFailure = "ShowLocalServerStopFailure";
        /// <summary>
        /// Cached name for the 'BuildMainMenu' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildMainMenu = "BuildMainMenu";
        /// <summary>
        /// Cached name for the 'ShowMainMenu' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowMainMenu = "ShowMainMenu";
        /// <summary>
        /// Cached name for the 'RefreshMainMenuAvailability' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshMainMenuAvailability = "RefreshMainMenuAvailability";
        /// <summary>
        /// Cached name for the 'SetMainMenuStatus' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetMainMenuStatus = "SetMainMenuStatus";
        /// <summary>
        /// Cached name for the 'FitMainMenuLogo' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitMainMenuLogo = "FitMainMenuLogo";
        /// <summary>
        /// Cached name for the 'OpenMainMenuSettings' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenMainMenuSettings = "OpenMainMenuSettings";
        /// <summary>
        /// Cached name for the 'QuitToMainMenu' method.
        /// </summary>
        public new static readonly global::Godot.StringName @QuitToMainMenu = "QuitToMainMenu";
        /// <summary>
        /// Cached name for the 'SetWorldMenuActionsVisible' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetWorldMenuActionsVisible = "SetWorldMenuActionsVisible";
        /// <summary>
        /// Cached name for the 'BuildWorldMenu' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildWorldMenu = "BuildWorldMenu";
        /// <summary>
        /// Cached name for the 'WorldOptionRow' method.
        /// </summary>
        public new static readonly global::Godot.StringName @WorldOptionRow = "WorldOptionRow";
        /// <summary>
        /// Cached name for the 'LayoutWorldMenu' method.
        /// </summary>
        public new static readonly global::Godot.StringName @LayoutWorldMenu = "LayoutWorldMenu";
        /// <summary>
        /// Cached name for the 'OpenWorldMenu' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenWorldMenu = "OpenWorldMenu";
        /// <summary>
        /// Cached name for the 'RenderWorldList' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderWorldList = "RenderWorldList";
        /// <summary>
        /// Cached name for the 'SlotIcon' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SlotIcon = "SlotIcon";
        /// <summary>
        /// Cached name for the 'RefreshWorldMenuAvailability' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshWorldMenuAvailability = "RefreshWorldMenuAvailability";
        /// <summary>
        /// Cached name for the 'GenerationAmountText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @GenerationAmountText = "GenerationAmountText";
        /// <summary>
        /// Cached name for the 'ResetWorldGenerationOptions' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ResetWorldGenerationOptions = "ResetWorldGenerationOptions";
        /// <summary>
        /// Cached name for the 'InvalidateWorldPreview' method.
        /// </summary>
        public new static readonly global::Godot.StringName @InvalidateWorldPreview = "InvalidateWorldPreview";
        /// <summary>
        /// Cached name for the 'Percent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Percent = "Percent";
        /// <summary>
        /// Cached name for the 'ForestAmount' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ForestAmount = "ForestAmount";
        /// <summary>
        /// Cached name for the 'MountainAmount' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MountainAmount = "MountainAmount";
        /// <summary>
        /// Cached name for the 'RefreshMenuIcons' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshMenuIcons = "RefreshMenuIcons";
        /// <summary>
        /// Cached name for the 'BuildMapHud' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildMapHud = "BuildMapHud";
        /// <summary>
        /// Cached name for the 'PositionMapHud' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PositionMapHud = "PositionMapHud";
        /// <summary>
        /// Cached name for the 'CameraAxis' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CameraAxis = "CameraAxis";
        /// <summary>
        /// Cached name for the 'PositiveMod' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PositiveMod = "PositiveMod";
        /// <summary>
        /// Cached name for the 'WrappedMarkerX' method.
        /// </summary>
        public new static readonly global::Godot.StringName @WrappedMarkerX = "WrappedMarkerX";
        /// <summary>
        /// Cached name for the 'RepositionWrappedMapMarkers' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RepositionWrappedMapMarkers = "RepositionWrappedMapMarkers";
        /// <summary>
        /// Cached name for the 'RefreshOverviewViewport' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshOverviewViewport = "RefreshOverviewViewport";
        /// <summary>
        /// Cached name for the 'CenterCameraAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CenterCameraAt = "CenterCameraAt";
        /// <summary>
        /// Cached name for the 'PanCamera' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PanCamera = "PanCamera";
        /// <summary>
        /// Cached name for the 'HandleMapInput' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HandleMapInput = "HandleMapInput";
        /// <summary>
        /// Cached name for the 'RefreshTileHoverAtMouse' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshTileHoverAtMouse = "RefreshTileHoverAtMouse";
        /// <summary>
        /// Cached name for the 'ClearTileSelection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearTileSelection = "ClearTileSelection";
        /// <summary>
        /// Cached name for the 'PositionSelectedTilePanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PositionSelectedTilePanel = "PositionSelectedTilePanel";
        /// <summary>
        /// Cached name for the 'UpdateTileHover' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdateTileHover = "UpdateTileHover";
        /// <summary>
        /// Cached name for the 'OverviewLegend' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OverviewLegend = "OverviewLegend";
        /// <summary>
        /// Cached name for the 'FilterSwatch' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FilterSwatch = "FilterSwatch";
        /// <summary>
        /// Cached name for the 'FilterRow' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FilterRow = "FilterRow";
        /// <summary>
        /// Cached name for the 'AdvanceMapMarkers' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AdvanceMapMarkers = "AdvanceMapMarkers";
        /// <summary>
        /// Cached name for the 'BuildMemoryCards' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildMemoryCards = "BuildMemoryCards";
        /// <summary>
        /// Cached name for the 'MemoryAccent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MemoryAccent = "MemoryAccent";
        /// <summary>
        /// Cached name for the 'Sureness' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Sureness = "Sureness";
        /// <summary>
        /// Cached name for the 'MemoryEntry' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MemoryEntry = "MemoryEntry";
        /// <summary>
        /// Cached name for the 'MetaLine' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MetaLine = "MetaLine";
        /// <summary>
        /// Cached name for the 'MetaText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MetaText = "MetaText";
        /// <summary>
        /// Cached name for the 'Tag' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Tag = "Tag";
        /// <summary>
        /// Cached name for the 'ShowMemoryCards' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowMemoryCards = "ShowMemoryCards";
        /// <summary>
        /// Cached name for the 'FitMemoryCards' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitMemoryCards = "FitMemoryCards";
        /// <summary>
        /// Cached name for the 'MemoryCardsText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MemoryCardsText = "MemoryCardsText";
        /// <summary>
        /// Cached name for the 'RenderUsageStatus' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderUsageStatus = "RenderUsageStatus";
        /// <summary>
        /// Cached name for the 'BuildUsageLimitPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildUsageLimitPanel = "BuildUsageLimitPanel";
        /// <summary>
        /// Cached name for the 'HasModelList' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HasModelList = "HasModelList";
        /// <summary>
        /// Cached name for the 'RequestFounderModels' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RequestFounderModels = "RequestFounderModels";
        /// <summary>
        /// Cached name for the 'SyncAgentModelPicker' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SyncAgentModelPicker = "SyncAgentModelPicker";
        /// <summary>
        /// Cached name for the 'OnFounderKeyEdited' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OnFounderKeyEdited = "OnFounderKeyEdited";
        /// <summary>
        /// Cached name for the 'OnAgentModelKeyEdited' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OnAgentModelKeyEdited = "OnAgentModelKeyEdited";
        /// <summary>
        /// Cached name for the 'SelectedRoutineHelper' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedRoutineHelper = "SelectedRoutineHelper";
        /// <summary>
        /// Cached name for the 'BuildRoutineHelperSettings' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildRoutineHelperSettings = "BuildRoutineHelperSettings";
        /// <summary>
        /// Cached name for the 'RequestRoutineHelperModels' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RequestRoutineHelperModels = "RequestRoutineHelperModels";
        /// <summary>
        /// Cached name for the 'ClearRoutineHelperSetupCheck' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearRoutineHelperSetupCheck = "ClearRoutineHelperSetupCheck";
        /// <summary>
        /// Cached name for the 'SelectedRoutineHelperKey' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedRoutineHelperKey = "SelectedRoutineHelperKey";
        /// <summary>
        /// Cached name for the 'RefreshRoutineHelperKeys' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshRoutineHelperKeys = "RefreshRoutineHelperKeys";
        /// <summary>
        /// Cached name for the 'BuildModLibrary' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildModLibrary = "BuildModLibrary";
        /// <summary>
        /// Cached name for the 'ShowModLibrary' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowModLibrary = "ShowModLibrary";
        /// <summary>
        /// Cached name for the 'ModLibraryText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ModLibraryText = "ModLibraryText";
        /// <summary>
        /// Cached name for the 'ConfigureOrderLabel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfigureOrderLabel = "ConfigureOrderLabel";
        /// <summary>
        /// Cached name for the 'BuildOrdersReader' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildOrdersReader = "BuildOrdersReader";
        /// <summary>
        /// Cached name for the 'OpenOrdersReader' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenOrdersReader = "OpenOrdersReader";
        /// <summary>
        /// Cached name for the 'OrderItemName' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OrderItemName = "OrderItemName";
        /// <summary>
        /// Cached name for the 'ProgressUnitLabel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ProgressUnitLabel = "ProgressUnitLabel";
        /// <summary>
        /// Cached name for the 'OrderBuildingName' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OrderBuildingName = "OrderBuildingName";
        /// <summary>
        /// Cached name for the 'InstructionSubmissionResultText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @InstructionSubmissionResultText = "InstructionSubmissionResultText";
        /// <summary>
        /// Cached name for the 'RefreshControlAvailability' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshControlAvailability = "RefreshControlAvailability";
        /// <summary>
        /// Cached name for the 'RenderPairedDevices' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderPairedDevices = "RenderPairedDevices";
        /// <summary>
        /// Cached name for the 'BuildDeveloperDevices' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildDeveloperDevices = "BuildDeveloperDevices";
        /// <summary>
        /// Cached name for the 'ToggleAgents' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleAgents = "ToggleAgents";
        /// <summary>
        /// Cached name for the 'ToggleEvents' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleEvents = "ToggleEvents";
        /// <summary>
        /// Cached name for the 'ToggleWorldInfo' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleWorldInfo = "ToggleWorldInfo";
        /// <summary>
        /// Cached name for the 'OpenFamilyTree' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenFamilyTree = "OpenFamilyTree";
        /// <summary>
        /// Cached name for the 'UpdateFamilyTreeStatus' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdateFamilyTreeStatus = "UpdateFamilyTreeStatus";
        /// <summary>
        /// Cached name for the 'SelectFromFamilyTree' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectFromFamilyTree = "SelectFromFamilyTree";
        /// <summary>
        /// Cached name for the 'OpenMemories' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenMemories = "OpenMemories";
        /// <summary>
        /// Cached name for the 'ShowPauseMenuPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowPauseMenuPage = "ShowPauseMenuPage";
        /// <summary>
        /// Cached name for the 'ShowPauseMenuButtons' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowPauseMenuButtons = "ShowPauseMenuButtons";
        /// <summary>
        /// Cached name for the 'ClosePauseMenu' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClosePauseMenu = "ClosePauseMenu";
        /// <summary>
        /// Cached name for the '_UnhandledKeyInput' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_UnhandledKeyInput = "_UnhandledKeyInput";
        /// <summary>
        /// Cached name for the '_Process' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Process = "_Process";
        /// <summary>
        /// Cached name for the 'PanCameraForFrame' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PanCameraForFrame = "PanCameraForFrame";
        /// <summary>
        /// Cached name for the 'HandleEscape' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HandleEscape = "HandleEscape";
        /// <summary>
        /// Cached name for the 'Keycap' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Keycap = "Keycap";
        /// <summary>
        /// Cached name for the 'BuildPendingSubmissionRecovery' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildPendingSubmissionRecovery = "BuildPendingSubmissionRecovery";
        /// <summary>
        /// Cached name for the 'ReviewPendingSubmission' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ReviewPendingSubmission = "ReviewPendingSubmission";
        /// <summary>
        /// Cached name for the 'LoadPendingSubmission' method.
        /// </summary>
        public new static readonly global::Godot.StringName @LoadPendingSubmission = "LoadPendingSubmission";
        /// <summary>
        /// Cached name for the 'ForgetPendingSubmission' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ForgetPendingSubmission = "ForgetPendingSubmission";
        /// <summary>
        /// Cached name for the 'RenderPendingSubmission' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderPendingSubmission = "RenderPendingSubmission";
        /// <summary>
        /// Cached name for the 'SetOwnerRequestBusy' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetOwnerRequestBusy = "SetOwnerRequestBusy";
        /// <summary>
        /// Cached name for the 'BindOwnerRequestPanels' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BindOwnerRequestPanels = "BindOwnerRequestPanels";
        /// <summary>
        /// Cached name for the 'SetStatus' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetStatus = "SetStatus";
        /// <summary>
        /// Cached name for the 'ExpireStatusToast' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ExpireStatusToast = "ExpireStatusToast";
        /// <summary>
        /// Cached name for the 'ShowHeldState' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowHeldState = "ShowHeldState";
        /// <summary>
        /// Cached name for the 'ResourceGlyph' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ResourceGlyph = "ResourceGlyph";
        /// <summary>
        /// Cached name for the 'ObjectMarker' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ObjectMarker = "ObjectMarker";
        /// <summary>
        /// Cached name for the 'ObjectGlyph' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ObjectGlyph = "ObjectGlyph";
        /// <summary>
        /// Cached name for the 'ShortMarker' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShortMarker = "ShortMarker";
        /// <summary>
        /// Cached name for the 'Pretty' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Pretty = "Pretty";
        /// <summary>
        /// Cached name for the 'NeedPercent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @NeedPercent = "NeedPercent";
        /// <summary>
        /// Cached name for the 'NewReportProblemButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @NewReportProblemButton = "NewReportProblemButton";
        /// <summary>
        /// Cached name for the 'ReportProblem' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ReportProblem = "ReportProblem";
        /// <summary>
        /// Cached name for the 'WriteProblemReport' method.
        /// </summary>
        public new static readonly global::Godot.StringName @WriteProblemReport = "WriteProblemReport";
        /// <summary>
        /// Cached name for the 'ProblemReportDirectory' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ProblemReportDirectory = "ProblemReportDirectory";
        /// <summary>
        /// Cached name for the 'PreviousGameLog' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PreviousGameLog = "PreviousGameLog";
        /// <summary>
        /// Cached name for the 'SizeText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SizeText = "SizeText";
        /// <summary>
        /// Cached name for the 'BuildProfilePeople' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildProfilePeople = "BuildProfilePeople";
        /// <summary>
        /// Cached name for the 'ProfilePeopleText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ProfilePeopleText = "ProfilePeopleText";
        /// <summary>
        /// Cached name for the 'ResetAgentModelSetupCheckForCurrentChoice' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ResetAgentModelSetupCheckForCurrentChoice = "ResetAgentModelSetupCheckForCurrentChoice";
        /// <summary>
        /// Cached name for the 'ClearFounderModelSetupCheck' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearFounderModelSetupCheck = "ClearFounderModelSetupCheck";
        /// <summary>
        /// Cached name for the 'ClearAgentModelSetupCheck' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearAgentModelSetupCheck = "ClearAgentModelSetupCheck";
        /// <summary>
        /// Cached name for the 'VerifyModelSetupCheckControls' method.
        /// </summary>
        public new static readonly global::Godot.StringName @VerifyModelSetupCheckControls = "VerifyModelSetupCheckControls";
        /// <summary>
        /// Cached name for the 'BuildRecoveryCleanup' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildRecoveryCleanup = "BuildRecoveryCleanup";
        /// <summary>
        /// Cached name for the 'ApplyResponsiveLayout' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ApplyResponsiveLayout = "ApplyResponsiveLayout";
        /// <summary>
        /// Cached name for the 'PositionFamilyTreePanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PositionFamilyTreePanel = "PositionFamilyTreePanel";
        /// <summary>
        /// Cached name for the 'PlaceQuickCard' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PlaceQuickCard = "PlaceQuickCard";
        /// <summary>
        /// Cached name for the 'FitMenuScrolls' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitMenuScrolls = "FitMenuScrolls";
        /// <summary>
        /// Cached name for the 'CardTop' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CardTop = "CardTop";
        /// <summary>
        /// Cached name for the 'FitHudLists' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitHudLists = "FitHudLists";
        /// <summary>
        /// Cached name for the 'QueueHudListsFit' method.
        /// </summary>
        public new static readonly global::Godot.StringName @QueueHudListsFit = "QueueHudListsFit";
        /// <summary>
        /// Cached name for the 'ListRoom' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ListRoom = "ListRoom";
        /// <summary>
        /// Cached name for the 'BuildSaveDiskWarning' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildSaveDiskWarning = "BuildSaveDiskWarning";
        /// <summary>
        /// Cached name for the 'BuildAutosaveSettings' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildAutosaveSettings = "BuildAutosaveSettings";
        /// <summary>
        /// Cached name for the 'IsCurrentAutosaveSettingsContext' method.
        /// </summary>
        public new static readonly global::Godot.StringName @IsCurrentAutosaveSettingsContext = "IsCurrentAutosaveSettingsContext";
        /// <summary>
        /// Cached name for the 'CancelAutosaveSettingsRead' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CancelAutosaveSettingsRead = "CancelAutosaveSettingsRead";
        /// <summary>
        /// Cached name for the 'BuildManualSavesPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildManualSavesPanel = "BuildManualSavesPanel";
        /// <summary>
        /// Cached name for the 'BuildManualSaveTimeline' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildManualSaveTimeline = "BuildManualSaveTimeline";
        /// <summary>
        /// Cached name for the 'ApplyManualSaveView' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ApplyManualSaveView = "ApplyManualSaveView";
        /// <summary>
        /// Cached name for the 'FitManualSaveList' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitManualSaveList = "FitManualSaveList";
        /// <summary>
        /// Cached name for the 'ManualSaveTimelineWidth' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ManualSaveTimelineWidth = "ManualSaveTimelineWidth";
        /// <summary>
        /// Cached name for the 'ManualSaveCardFrame' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ManualSaveCardFrame = "ManualSaveCardFrame";
        /// <summary>
        /// Cached name for the 'FitManualSaveTimeline' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FitManualSaveTimeline = "FitManualSaveTimeline";
        /// <summary>
        /// Cached name for the 'ChooseTimelineSave' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ChooseTimelineSave = "ChooseTimelineSave";
        /// <summary>
        /// Cached name for the 'RenderManualSaveDetails' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderManualSaveDetails = "RenderManualSaveDetails";
        /// <summary>
        /// Cached name for the 'TimelineReadout' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TimelineReadout = "TimelineReadout";
        /// <summary>
        /// Cached name for the 'ClearWorldSaveHistory' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearWorldSaveHistory = "ClearWorldSaveHistory";
        /// <summary>
        /// Cached name for the 'CancelManualSaveListRead' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CancelManualSaveListRead = "CancelManualSaveListRead";
        /// <summary>
        /// Cached name for the 'RefreshManualSaveAvailability' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshManualSaveAvailability = "RefreshManualSaveAvailability";
        /// <summary>
        /// Cached name for the 'CurrentManualSaveWorldId' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CurrentManualSaveWorldId = "CurrentManualSaveWorldId";
        /// <summary>
        /// Cached name for the 'ShowManualSavePanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowManualSavePanel = "ShowManualSavePanel";
        /// <summary>
        /// Cached name for the 'RenderManualSaveTimeline' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderManualSaveTimeline = "RenderManualSaveTimeline";
        /// <summary>
        /// Cached name for the 'RenderManualSaveList' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RenderManualSaveList = "RenderManualSaveList";
        /// <summary>
        /// Cached name for the 'ShortBranchTag' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShortBranchTag = "ShortBranchTag";
        /// <summary>
        /// Cached name for the 'ConfirmManualSaveOverwrite' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfirmManualSaveOverwrite = "ConfirmManualSaveOverwrite";
        /// <summary>
        /// Cached name for the 'DisplaySaveClock' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DisplaySaveClock = "DisplaySaveClock";
        /// <summary>
        /// Cached name for the 'ConfirmManualSaveLoad' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfirmManualSaveLoad = "ConfirmManualSaveLoad";
        /// <summary>
        /// Cached name for the 'ConfirmSaveDeletion' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfirmSaveDeletion = "ConfirmSaveDeletion";
        /// <summary>
        /// Cached name for the 'ConfirmWorldDeletion' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfirmWorldDeletion = "ConfirmWorldDeletion";
        /// <summary>
        /// Cached name for the 'SelectAgentFromList' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectAgentFromList = "SelectAgentFromList";
        /// <summary>
        /// Cached name for the 'SelectAgent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectAgent = "SelectAgent";
        /// <summary>
        /// Cached name for the 'ClearAgentSelection' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearAgentSelection = "ClearAgentSelection";
        /// <summary>
        /// Cached name for the 'BuildControlsPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildControlsPanel = "BuildControlsPanel";
        /// <summary>
        /// Cached name for the 'PositionControlsPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PositionControlsPanel = "PositionControlsPanel";
        /// <summary>
        /// Cached name for the 'ToggleControlsPanel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ToggleControlsPanel = "ToggleControlsPanel";
        /// <summary>
        /// Cached name for the 'WorldKeysAvailable' method.
        /// </summary>
        public new static readonly global::Godot.StringName @WorldKeysAvailable = "WorldKeysAvailable";
        /// <summary>
        /// Cached name for the 'NoMenuOverWorld' method.
        /// </summary>
        public new static readonly global::Godot.StringName @NoMenuOverWorld = "NoMenuOverWorld";
        /// <summary>
        /// Cached name for the '_Input' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Input = "_Input";
        /// <summary>
        /// Cached name for the 'HandleShortcutKey' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HandleShortcutKey = "HandleShortcutKey";
        /// <summary>
        /// Cached name for the 'PressTopBarAction' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PressTopBarAction = "PressTopBarAction";
        /// <summary>
        /// Cached name for the 'CycleSelectedAgent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CycleSelectedAgent = "CycleSelectedAgent";
        /// <summary>
        /// Cached name for the 'CenterOnHome' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CenterOnHome = "CenterOnHome";
        /// <summary>
        /// Cached name for the 'ZoomAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ZoomAt = "ZoomAt";
        /// <summary>
        /// Cached name for the 'BuildControlsGroups' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildControlsGroups = "BuildControlsGroups";
        /// <summary>
        /// Cached name for the 'FillControlsGroups' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FillControlsGroups = "FillControlsGroups";
        /// <summary>
        /// Cached name for the 'BuildStartupRecovery' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildStartupRecovery = "BuildStartupRecovery";
        /// <summary>
        /// Cached name for the 'BuildTileCard' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildTileCard = "BuildTileCard";
        /// <summary>
        /// Cached name for the 'HeightWords' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HeightWords = "HeightWords";
        /// <summary>
        /// Cached name for the 'AddTileFact' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddTileFact = "AddTileFact";
        /// <summary>
        /// Cached name for the 'AddTileThing' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddTileThing = "AddTileThing";
        /// <summary>
        /// Cached name for the 'TileCardText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TileCardText = "TileCardText";
        /// <summary>
        /// Cached name for the 'BuildDeveloperWorldEdit' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildDeveloperWorldEdit = "BuildDeveloperWorldEdit";
        /// <summary>
        /// Cached name for the 'ConfigureWorldEditPicker' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfigureWorldEditPicker = "ConfigureWorldEditPicker";
        /// <summary>
        /// Cached name for the 'ClearWorldEditPreview' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearWorldEditPreview = "ClearWorldEditPreview";
        /// <summary>
        /// Cached name for the 'UpdateWorldEditPreview' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdateWorldEditPreview = "UpdateWorldEditPreview";
        /// <summary>
        /// Cached name for the 'AddWorldEditKinds' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddWorldEditKinds = "AddWorldEditKinds";
        /// <summary>
        /// Cached name for the 'AddWorldEditKind' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddWorldEditKind = "AddWorldEditKind";
        /// <summary>
        /// Cached name for the 'UpdateWorldEditHint' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdateWorldEditHint = "UpdateWorldEditHint";
        /// <summary>
        /// Cached name for the 'ConfigureCoordinate' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConfigureCoordinate = "ConfigureCoordinate";
        /// <summary>
        /// Cached name for the 'SelectedWorldEditKind' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectedWorldEditKind = "SelectedWorldEditKind";
        /// <summary>
        /// Cached name for the 'BuildWorldInfoPages' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildWorldInfoPages = "BuildWorldInfoPages";
        /// <summary>
        /// Cached name for the 'StatTile' method.
        /// </summary>
        public new static readonly global::Godot.StringName @StatTile = "StatTile";
        /// <summary>
        /// Cached name for the 'PageText' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PageText = "PageText";
        /// <summary>
        /// Cached name for the 'ResetDisplayedWorldContext' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ResetDisplayedWorldContext = "ResetDisplayedWorldContext";
        /// <summary>
        /// Cached name for the 'MapObjectLabelFits' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MapObjectLabelFits = "MapObjectLabelFits";
    }
    /// <summary>
    /// Get the method information for all the methods declared in this class.
    /// This method is used by Godot to register the available methods in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotMethodList()
    {
        var methods = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(448);
        methods.Add(new(name: MethodName.@VerifyAgentCardStyleRetention, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyMarriageOrderText, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyAnimalPresentation, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyBoatPresentation, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyConstructionPixelContracts, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RequireConstructionHalf, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "full", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Image")), new(type: (global::Godot.Variant.Type)24, name: "half", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Image")), new(type: (global::Godot.Variant.Type)4, name: "name", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConstructionColor, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)29, name: "pixels", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "width", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "red", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "green", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "blue", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyPlainEllipses, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "when", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyAgentTextEllipses, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyEventLogRefusalRollover, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@HandcartPixelDigest, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "image", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Image")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ApprovedHandcartDigest, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "facing", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "loaded", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "pulled", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyHandcartApprovedPixels, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyHandcartMotionAndZoom, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyHandcartInspection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@AgentListCardText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyEventRows, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowsFind, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@NewcomerOfferButton, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyControlsKeycaps, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyDeveloperRunOptions, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifySaveBranchList, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyMapPanels, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyModelSettingsLayout, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyAbandonedBuildingLooks, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyAbandonedLanternsAndBridges, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyAbandonedArtSampling, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyPeopleInside, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyOrnamentPresentation, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CaptionForChecks, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyPanelParts, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyProblemReport, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ReliefRegionMatches, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)29, name: "whole", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "wholeWidth", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)29, name: "chunk", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "chunkWidth", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "left", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "top", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "rows", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CheckThemeTextContrast, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ThemeTextSurface, returnVal: new(type: (global::Godot.Variant.Type)20, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "style", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("StyleBox")), new(type: (global::Godot.Variant.Type)20, name: "paper", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@TextureCenter, returnVal: new(type: (global::Godot.Variant.Type)20, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "texture", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("StyleBoxTexture")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Composite, returnVal: new(type: (global::Godot.Variant.Type)20, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)20, name: "ink", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "surface", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyToolMakingPresentation, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowsGlyph, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")), new(type: (global::Godot.Variant.Type)2, name: "glyph", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyConsistentButtons, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyModelPicker, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyChildModelStatus, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyPixelText, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "when", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyWorldThumbnailFallback, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyMainMenuLogo, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)6, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyAppIconFile, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FinishUiSmoke, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "exitCode", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyEventLogAgentNames, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowWorldActionSmokeMenu, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ChooseWorldActionSmokeRow, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "row", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RequireWorldPreviewCleared, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyYardAnimalInspection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildConversationReader, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenAgentConversation, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "agentId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleConversationHistory, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConversationPreview, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "maximumLength", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConversationInterruptionText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "interruption", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConversationOutcomeText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "outcome", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConversationTurnKey, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "worldId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "turnId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildAgentListCards, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "body", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectAgentListCard, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "keepAgentListOpen", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Capitalize, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshAgentListSelection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CenterOnAgent, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "agentId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedRoleId, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedAgentModelTarget, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedTargetWasBornHere, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PopulateAgentModelTargets, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ActiveProviderForSelectedRole, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PopulateProviderChoices, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "selectedProvider", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectProviderChoice, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "provider", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddProviderChoice, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "id", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedProviderId, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedCredentialChoice, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PopulateCredentialChoices, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@IsModelProvider, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "provider", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PopulateThinkingChoices, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "choice", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("OptionButton")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedThinking, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "choice", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("OptionButton")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectThinking, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "choice", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("OptionButton")), new(type: (global::Godot.Variant.Type)4, name: "thinking", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderProviderConfiguration, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedChildModelStatus, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RoleDisplayName, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "role", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ProviderDisplayName, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "provider", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DefaultProviderModel, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "provider", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FieldCaption, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)24, name: "field", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildAgentModelPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenAgentModelEditor, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildAgentModelScroll, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitAgentModelScroll, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CloseAgentModelEditor, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildAgentProfile, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddProfileText, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "parent", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Container")), new(type: (global::Godot.Variant.Type)24, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@StyleCompactToggle, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ReaderHeading, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("HBoxContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "panel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")), new(type: (global::Godot.Variant.Type)24, name: "title", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")), new(type: (global::Godot.Variant.Type)4, name: "closeHint", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildThoughtsReader, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenThoughtsReader, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PlaceReaderPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "panel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenAgentProfile, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "speak", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AgentProfileBack, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleRenameRow, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdateAgentProfileCloseButton, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "living", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PositionAgentProfile, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@QueueAgentProfileFit, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitQueuedAgentProfile, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitAgentOverviewScroll, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildAgentCards, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildQuickCard, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshAgentCardIcons, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CenterOnSelectedAgent, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@Sentence, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ThoughtTime, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "tick", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "now", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildApiKeysPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderSavedApiKeys, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CredentialProviderDisplayName, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "provider", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildBuildingCards, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SectionRow, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("HBoxContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "title", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)24, name: "summary", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectBuilding, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "instanceId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearBuildingSelection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenBuildingDetails, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildingDetailsBack, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CenterOnSelectedBuilding, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ApplyBuildingReassignment, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfirmBuildingRemoval, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CancelBuildingRemoval, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RemoveSelectedBuilding, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RecipeName, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "recipeId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RecipeIcon, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "recipeId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@TimeLeft, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "ticks", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PeopleInside, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)34, name: "names", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Plural, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "amount", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "noun", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearChildren, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "parent", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Node")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PositionBuildingDetails, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildBuildingStorageHistory, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BeginCameraMotion, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CancelCameraMotion, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetCameraAtImmediately, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "tileCenter", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AdvanceCameraMotion, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "delta", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@IsCurrentWorldRequest, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "generation", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfiguredServerUrl, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Ready, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@_ExitTree, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildDeveloperEdits, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfigureDeveloperEdit, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildDeveloperTools, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildDeveloperAgingOverride, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleDeveloperTools, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CloseDeveloperTools, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PositionDeveloperTools, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@JumpToDeveloperAgent, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderDeveloperTile, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdateDeveloperFrameTime, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "delta", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderDeveloperRoute, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderPlannedPath, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@StyleConfirmation, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "dialog", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("ConfirmationDialog")), new(type: (global::Godot.Variant.Type)4, name: "title", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "confirm", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetFullscreen, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "enabled", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ApplySavedDisplaySettings, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ApplyUiScale, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetUiFactor, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "factor", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ScaleWindows, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "factor", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ScaleMapText, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "factor", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PopupDialog, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "dialog", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("ConfirmationDialog")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DialogSize, returnVal: new(type: (global::Godot.Variant.Type)6, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)6, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitDialog, returnVal: new(type: (global::Godot.Variant.Type)6, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "dialog", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("AcceptDialog")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CurrentMonitorSize, returnVal: new(type: (global::Godot.Variant.Type)6, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@AutomaticRenderSize, returnVal: new(type: (global::Godot.Variant.Type)6, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshRenderSize, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@DisplaySizeIndex, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)6, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SettingsBox, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "title", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)28, name: "rows", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DisplaySettingRow, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("HBoxContainer")), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)24, name: "choice", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetWindowSize, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetCloudHaze, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "enabled", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetLightningFlashes, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "enabled", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetUiTheme, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Notification, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "what", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ApplyThemeColors, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetClockFormat, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DateStyleIndex, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "style", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetDateStyle, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DisplayWorldClock, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "worldTick", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderEventLog, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@JumpToEvent, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "eventId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildEventRows, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "body", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddNewcomerOffer, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FillFamilyLegend, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildFiltersButton, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildMapFiltersPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "canvas", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleMapFilters, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ApplyMapFiltersFromCurrentSnapshot, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleMoveFounder, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleFirstTownSite, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CancelFirstTownSiteSelection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildFounderSetupPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "canvas", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedFounderProvider, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedFounderCredential, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PopulateFounderCredentials, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderFounderCredentialInputs, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ResetAddAgentPlacementHint, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PlacementRefusalText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "ambiguity", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildGenerationSettings, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildTopBar, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "canvas", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@HudGroup, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "row", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("HBoxContainer")), new(type: (global::Godot.Variant.Type)1, name: "padRight", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AttachCorner, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")), new(type: (global::Godot.Variant.Type)24, name: "marker", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")), new(type: (global::Godot.Variant.Type)5, name: "offset", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CompactHud, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "compact", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PlaceUnderButton, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "panel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")), new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PlaceHudPanels, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@HudPanels, returnVal: new(type: (global::Godot.Variant.Type)28, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshHudIcons, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdateUnreadEvents, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "worldId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@MarkEventsSeen, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildWorldInfoPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowWorldInfoPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "towns", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleTowns, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CivicElectionName, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@TownListText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CenterOnTown, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "townId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildKeyboardNavigation, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfigureKeyboardScrollBar, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "bar", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("ScrollBar")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CurrentKeyboardPanel, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@IsKeyboardFocusable, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "control", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@KeyboardControls, returnVal: new(type: (global::Godot.Variant.Type)28, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "panel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FocusKeyboardPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "panel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@HandleKeyboardNavigationInput, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "input", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("InputEvent")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BeginKeyboardMapSelection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@KeyboardMapCanvasPoint, returnVal: new(type: (global::Godot.Variant.Type)5, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)6, name: "tile", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshKeyboardMapSelection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CenterKeyboardCameraAt, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "tileCenter", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "immediately", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@GameUserPath, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "fileName", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildQuitToLauncher, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "menu", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("VBoxContainer")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@TryOpenLauncher, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "version", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "worldId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowLauncherStartFailure, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildLayout, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowSettingsSection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "worldSpecific", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildWorldColumn, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildInspectorColumn, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildOwnerColumn, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildStatusToast, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@EmptyToNull, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetPanelText, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("RichTextLabel")), new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfigureTextPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("RichTextLabel")), new(type: (global::Godot.Variant.Type)3, name: "maximumHeight", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitQueuedTextPanels, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitTextPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("RichTextLabel")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitFloatingPanelsToContents, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FloatingPanel, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "control", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@NewPanel, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "title", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddPanelContents, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "panel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")), new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@MetricRow, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("HBoxContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "caption", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)24, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CloseButton, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "tooltip", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@StyleIconButton, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")), new(type: (global::Godot.Variant.Type)2, name: "glyph", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@StyleMenuChoice, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")), new(type: (global::Godot.Variant.Type)1, name: "primary", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@StyleButton, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")), new(type: (global::Godot.Variant.Type)1, name: "primary", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@StyleSettingsCategoryButton, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectSettingsCategory, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "selected", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CompleteLocalServerStartup, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@QuitGame, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@QuitToLauncher, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowLocalServerStopFailure, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "launcherVersion", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "launcherWorld", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "chooseCurrentWorld", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildMainMenu, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowMainMenu, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshMainMenuAvailability, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetMainMenuStatus, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitMainMenuLogo, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenMainMenuSettings, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@QuitToMainMenu, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetWorldMenuActionsVisible, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "visible", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildWorldMenu, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@WorldOptionRow, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("HBoxContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "caption", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)24, name: "field", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@LayoutWorldMenu, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenWorldMenu, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "create", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderWorldList, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SlotIcon, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("ImageTexture")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "glyph", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshWorldMenuAvailability, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@GenerationAmountText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "choice", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ResetWorldGenerationOptions, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@InvalidateWorldPreview, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "refresh", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Percent, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ForestAmount, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "percent", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@MountainAmount, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "percent", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshMenuIcons, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildMapHud, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "canvas", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PositionMapHud, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CameraAxis, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "centerTile", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "stagePixels", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "viewportPixels", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "stride", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PositiveMod, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "modulus", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@WrappedMarkerX, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "canonicalX", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "mapWidth", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "stride", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "wrapsEastWest", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RepositionWrappedMapMarkers, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "mapWidth", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "stride", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "wrapsEastWest", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshOverviewViewport, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "mapWidth", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "mapHeight", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "stride", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "wrapsEastWest", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CenterCameraAt, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "tileCenter", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PanCamera, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "deltaTiles", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@HandleMapInput, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "event", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("InputEvent")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshTileHoverAtMouse, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearTileSelection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PositionSelectedTilePanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdateTileHover, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "canvasPosition", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "keyboard", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@OverviewLegend, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("HBoxContainer")), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FilterSwatch, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("ImageTexture")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "look", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FilterRow, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("HBoxContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "toggle", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("CheckButton")), new(type: (global::Godot.Variant.Type)2, name: "look", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "title", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "detail", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AdvanceMapMarkers, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "delta", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildMemoryCards, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "body", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("VBoxContainer")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@MemoryAccent, returnVal: new(type: (global::Godot.Variant.Type)20, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Sureness, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("TextureRect")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "basisPoints", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "tooltip", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@MemoryEntry, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "glyph", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "words", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)24, name: "meta", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")), new(type: (global::Godot.Variant.Type)24, name: "extra", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")), new(type: (global::Godot.Variant.Type)1, name: "faded", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@MetaLine, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("HFlowContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)28, name: "parts", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@MetaText, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Tag, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "note", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowMemoryCards, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitMemoryCards, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@MemoryCardsText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderUsageStatus, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildUsageLimitPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@HasModelList, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "provider", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RequestFounderModels, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SyncAgentModelPicker, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "force", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@OnFounderKeyEdited, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OnAgentModelKeyEdited, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedRoutineHelper, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildRoutineHelperSettings, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RequestRoutineHelperModels, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearRoutineHelperSetupCheck, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedRoutineHelperKey, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshRoutineHelperKeys, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "selectedSlotId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildModLibrary, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "menuBody", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("VBoxContainer")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowModLibrary, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ModLibraryText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfigureOrderLabel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildOrdersReader, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenOrdersReader, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OrderItemName, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ProgressUnitLabel, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "unit", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@OrderBuildingName, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@InstructionSubmissionResultText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "queue", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshControlAvailability, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderPairedDevices, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildDeveloperDevices, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleAgents, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleEvents, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleWorldInfo, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenFamilyTree, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdateFamilyTreeStatus, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectFromFamilyTree, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "id", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenMemories, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowPauseMenuPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "title", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowPauseMenuButtons, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClosePauseMenu, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@_UnhandledKeyInput, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "event", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("InputEvent")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Process, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "delta", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PanCameraForFrame, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "direction", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "delta", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@HandleEscape, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@Keycap, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "key", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildPendingSubmissionRecovery, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ReviewPendingSubmission, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@LoadPendingSubmission, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ForgetPendingSubmission, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderPendingSubmission, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetOwnerRequestBusy, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "busy", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BindOwnerRequestPanels, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetStatus, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "good", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ExpireStatusToast, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "refreshSucceeded", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowHeldState, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "reason", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ResourceGlyph, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "naturalObjectKind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ResourceGlyph, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ObjectMarker, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ObjectGlyph, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShortMarker, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Pretty, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@NeedPercent, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "basisPoints", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@NewReportProblemButton, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ReportProblem, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@WriteProblemReport, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "directory", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ProblemReportDirectory, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PreviousGameLog, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "gameLog", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SizeText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)6, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildProfilePeople, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "body", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("VBoxContainer")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ProfilePeopleText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ResetAgentModelSetupCheckForCurrentChoice, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearFounderModelSetupCheck, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearAgentModelSetupCheck, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@VerifyModelSetupCheckControls, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildRecoveryCleanup, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "body", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("VBoxContainer")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ApplyResponsiveLayout, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@PositionFamilyTreePanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "viewport", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "hudTop", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PlaceQuickCard, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "card", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")), new(type: (global::Godot.Variant.Type)7, name: "target", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitMenuScrolls, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "viewportHeight", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CardTop, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "cardHeight", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitHudLists, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@QueueHudListsFit, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ListRoom, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "panel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")), new(type: (global::Godot.Variant.Type)24, name: "list", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildSaveDiskWarning, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildAutosaveSettings, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@IsCurrentAutosaveSettingsContext, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CancelAutosaveSettingsRead, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildManualSavesPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildManualSaveTimeline, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "body", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("VBoxContainer")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ApplyManualSaveView, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitManualSaveList, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ManualSaveTimelineWidth, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ManualSaveCardFrame, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FitManualSaveTimeline, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ChooseTimelineSave, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "id", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderManualSaveDetails, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@TimelineReadout, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearWorldSaveHistory, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CancelManualSaveListRead, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshManualSaveAvailability, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@CurrentManualSaveWorldId, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowManualSavePanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "loadMode", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderManualSaveTimeline, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RenderManualSaveList, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShortBranchTag, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfirmManualSaveOverwrite, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@DisplaySaveClock, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "tick", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfirmManualSaveLoad, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfirmSaveDeletion, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfirmWorldDeletion, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectAgentFromList, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "keepAgentListOpen", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectAgent, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "agentId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearAgentSelection, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildControlsPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PositionControlsPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ToggleControlsPanel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@WorldKeysAvailable, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@NoMenuOverWorld, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Input, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "event", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("InputEvent")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@HandleShortcutKey, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "key", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("InputEventKey")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PressTopBarAction, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CycleSelectedAgent, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "step", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CenterOnHome, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ZoomAt, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "canvasPoint", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "zoomIn", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildControlsGroups, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FillControlsGroups, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildStartupRecovery, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildTileCard, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "content", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@HeightWords, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "level", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddTileFact, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "key", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddTileThing, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "icon", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Texture2D")), new(type: (global::Godot.Variant.Type)4, name: "name", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "detail", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@TileCardText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildDeveloperWorldEdit, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfigureWorldEditPicker, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "previousKind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearWorldEditPreview, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdateWorldEditPreview, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddWorldEditKinds, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddWorldEditKind, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "description", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdateWorldEditHint, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConfigureCoordinate, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "box", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("SpinBox")), new(type: (global::Godot.Variant.Type)4, name: "placeholder", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectedWorldEditKind, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildWorldInfoPages, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "body", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("VBoxContainer")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@StatTile, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("PanelContainer")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "icon", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Texture2D")), new(type: (global::Godot.Variant.Type)4, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PageText, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "page", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ResetDisplayedWorldContext, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@MapObjectLabelFits, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "visual", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")), new(type: (global::Godot.Variant.Type)4, name: "label", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        return methods;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool InvokeGodotClassMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@VerifyAgentCardStyleRetention && args.Count == 0) {
            @VerifyAgentCardStyleRetention();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyMarriageOrderText && args.Count == 0) {
            @VerifyMarriageOrderText();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyAnimalPresentation && args.Count == 0) {
            @VerifyAnimalPresentation();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyBoatPresentation && args.Count == 0) {
            @VerifyBoatPresentation();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyConstructionPixelContracts && args.Count == 0) {
            @VerifyConstructionPixelContracts();
            ret = default;
            return true;
        }
        if (method == MethodName.@RequireConstructionHalf && args.Count == 3) {
            @RequireConstructionHalf(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Image>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Image>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ConstructionColor && args.Count == 7) {
            var callRet = @ConstructionColor(global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[3]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[4]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[5]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[6]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyPlainEllipses && args.Count == 1) {
            @VerifyPlainEllipses(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyAgentTextEllipses && args.Count == 0) {
            @VerifyAgentTextEllipses();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyEventLogRefusalRollover && args.Count == 0) {
            @VerifyEventLogRefusalRollover();
            ret = default;
            return true;
        }
        if (method == MethodName.@HandcartPixelDigest && args.Count == 1) {
            var callRet = @HandcartPixelDigest(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Image>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ApprovedHandcartDigest && args.Count == 3) {
            var callRet = @ApprovedHandcartDigest(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyHandcartApprovedPixels && args.Count == 0) {
            @VerifyHandcartApprovedPixels();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyHandcartMotionAndZoom && args.Count == 0) {
            @VerifyHandcartMotionAndZoom();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyHandcartInspection && args.Count == 0) {
            @VerifyHandcartInspection();
            ret = default;
            return true;
        }
        if (method == MethodName.@AgentListCardText && args.Count == 1) {
            var callRet = @AgentListCardText(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyEventRows && args.Count == 0) {
            @VerifyEventRows();
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowsFind && args.Count == 1) {
            var callRet = @ShowsFind(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@NewcomerOfferButton && args.Count == 0) {
            var callRet = @NewcomerOfferButton();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyControlsKeycaps && args.Count == 0) {
            @VerifyControlsKeycaps();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyDeveloperRunOptions && args.Count == 0) {
            @VerifyDeveloperRunOptions();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifySaveBranchList && args.Count == 0) {
            @VerifySaveBranchList();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyMapPanels && args.Count == 0) {
            @VerifyMapPanels();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyModelSettingsLayout && args.Count == 0) {
            @VerifyModelSettingsLayout();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyAbandonedBuildingLooks && args.Count == 0) {
            @VerifyAbandonedBuildingLooks();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyAbandonedLanternsAndBridges && args.Count == 0) {
            @VerifyAbandonedLanternsAndBridges();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyAbandonedArtSampling && args.Count == 0) {
            @VerifyAbandonedArtSampling();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyPeopleInside && args.Count == 0) {
            @VerifyPeopleInside();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyOrnamentPresentation && args.Count == 0) {
            @VerifyOrnamentPresentation();
            ret = default;
            return true;
        }
        if (method == MethodName.@CaptionForChecks && args.Count == 1) {
            var callRet = @CaptionForChecks(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyPanelParts && args.Count == 0) {
            @VerifyPanelParts();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyProblemReport && args.Count == 0) {
            @VerifyProblemReport();
            ret = default;
            return true;
        }
        if (method == MethodName.@ReliefRegionMatches && args.Count == 7) {
            var callRet = @ReliefRegionMatches(global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[3]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[4]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[5]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[6]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@CheckThemeTextContrast && args.Count == 0) {
            @CheckThemeTextContrast();
            ret = default;
            return true;
        }
        if (method == MethodName.@ThemeTextSurface && args.Count == 2) {
            var callRet = @ThemeTextSurface(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.StyleBox>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@TextureCenter && args.Count == 1) {
            var callRet = @TextureCenter(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.StyleBoxTexture>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@Composite && args.Count == 2) {
            var callRet = @Composite(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyToolMakingPresentation && args.Count == 0) {
            @VerifyToolMakingPresentation();
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowsGlyph && args.Count == 2) {
            var callRet = @ShowsGlyph(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.PixelGlyph>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyConsistentButtons && args.Count == 0) {
            @VerifyConsistentButtons();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyModelPicker && args.Count == 0) {
            @VerifyModelPicker();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyChildModelStatus && args.Count == 0) {
            @VerifyChildModelStatus();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyPixelText && args.Count == 1) {
            @VerifyPixelText(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyWorldThumbnailFallback && args.Count == 0) {
            @VerifyWorldThumbnailFallback();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyMainMenuLogo && args.Count == 1) {
            @VerifyMainMenuLogo(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyAppIconFile && args.Count == 0) {
            @VerifyAppIconFile();
            ret = default;
            return true;
        }
        if (method == MethodName.@FinishUiSmoke && args.Count == 1) {
            @FinishUiSmoke(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyEventLogAgentNames && args.Count == 0) {
            @VerifyEventLogAgentNames();
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowWorldActionSmokeMenu && args.Count == 0) {
            @ShowWorldActionSmokeMenu();
            ret = default;
            return true;
        }
        if (method == MethodName.@ChooseWorldActionSmokeRow && args.Count == 1) {
            @ChooseWorldActionSmokeRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RequireWorldPreviewCleared && args.Count == 0) {
            @RequireWorldPreviewCleared();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyYardAnimalInspection && args.Count == 0) {
            @VerifyYardAnimalInspection();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildConversationReader && args.Count == 0) {
            @BuildConversationReader();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenAgentConversation && args.Count == 1) {
            @OpenAgentConversation(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleConversationHistory && args.Count == 0) {
            @ToggleConversationHistory();
            ret = default;
            return true;
        }
        if (method == MethodName.@ConversationPreview && args.Count == 2) {
            var callRet = @ConversationPreview(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConversationInterruptionText && args.Count == 1) {
            var callRet = @ConversationInterruptionText(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConversationOutcomeText && args.Count == 1) {
            var callRet = @ConversationOutcomeText(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConversationTurnKey && args.Count == 2) {
            var callRet = @ConversationTurnKey(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildAgentListCards && args.Count == 1) {
            @BuildAgentListCards(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectAgentListCard && args.Count == 2) {
            @SelectAgentListCard(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Capitalize && args.Count == 1) {
            var callRet = @Capitalize(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@RefreshAgentListSelection && args.Count == 0) {
            @RefreshAgentListSelection();
            ret = default;
            return true;
        }
        if (method == MethodName.@CenterOnAgent && args.Count == 1) {
            @CenterOnAgent(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectedRoleId && args.Count == 0) {
            var callRet = @SelectedRoleId();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SelectedAgentModelTarget && args.Count == 0) {
            var callRet = @SelectedAgentModelTarget();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SelectedTargetWasBornHere && args.Count == 0) {
            var callRet = @SelectedTargetWasBornHere();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@PopulateAgentModelTargets && args.Count == 0) {
            @PopulateAgentModelTargets();
            ret = default;
            return true;
        }
        if (method == MethodName.@ActiveProviderForSelectedRole && args.Count == 0) {
            var callRet = @ActiveProviderForSelectedRole();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@PopulateProviderChoices && args.Count == 1) {
            @PopulateProviderChoices(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectProviderChoice && args.Count == 1) {
            @SelectProviderChoice(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@AddProviderChoice && args.Count == 2) {
            @AddProviderChoice(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectedProviderId && args.Count == 0) {
            var callRet = @SelectedProviderId();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SelectedCredentialChoice && args.Count == 0) {
            var callRet = @SelectedCredentialChoice();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@PopulateCredentialChoices && args.Count == 0) {
            @PopulateCredentialChoices();
            ret = default;
            return true;
        }
        if (method == MethodName.@IsModelProvider && args.Count == 1) {
            var callRet = @IsModelProvider(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@PopulateThinkingChoices && args.Count == 1) {
            @PopulateThinkingChoices(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.OptionButton>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectedThinking && args.Count == 1) {
            var callRet = @SelectedThinking(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.OptionButton>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SelectThinking && args.Count == 2) {
            @SelectThinking(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.OptionButton>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderProviderConfiguration && args.Count == 0) {
            @RenderProviderConfiguration();
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectedChildModelStatus && args.Count == 0) {
            var callRet = @SelectedChildModelStatus();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@RoleDisplayName && args.Count == 1) {
            var callRet = @RoleDisplayName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ProviderDisplayName && args.Count == 1) {
            var callRet = @ProviderDisplayName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@DefaultProviderModel && args.Count == 1) {
            var callRet = @DefaultProviderModel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@FieldCaption && args.Count == 2) {
            var callRet = @FieldCaption(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(callRet);
            return true;
        }
        if (method == MethodName.@BuildAgentModelPanel && args.Count == 0) {
            @BuildAgentModelPanel();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenAgentModelEditor && args.Count == 0) {
            @OpenAgentModelEditor();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildAgentModelScroll && args.Count == 0) {
            @BuildAgentModelScroll();
            ret = default;
            return true;
        }
        if (method == MethodName.@FitAgentModelScroll && args.Count == 0) {
            @FitAgentModelScroll();
            ret = default;
            return true;
        }
        if (method == MethodName.@CloseAgentModelEditor && args.Count == 0) {
            @CloseAgentModelEditor();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildAgentProfile && args.Count == 0) {
            @BuildAgentProfile();
            ret = default;
            return true;
        }
        if (method == MethodName.@AddProfileText && args.Count == 2) {
            @AddProfileText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Container>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StyleCompactToggle && args.Count == 1) {
            @StyleCompactToggle(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ReaderHeading && args.Count == 3) {
            var callRet = @ReaderHeading(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.PanelContainer>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@BuildThoughtsReader && args.Count == 0) {
            @BuildThoughtsReader();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenThoughtsReader && args.Count == 0) {
            @OpenThoughtsReader();
            ret = default;
            return true;
        }
        if (method == MethodName.@PlaceReaderPanel && args.Count == 1) {
            @PlaceReaderPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.PanelContainer>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenAgentProfile && args.Count == 1) {
            @OpenAgentProfile(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@AgentProfileBack && args.Count == 0) {
            @AgentProfileBack();
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleRenameRow && args.Count == 0) {
            @ToggleRenameRow();
            ret = default;
            return true;
        }
        if (method == MethodName.@UpdateAgentProfileCloseButton && args.Count == 1) {
            @UpdateAgentProfileCloseButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PositionAgentProfile && args.Count == 0) {
            @PositionAgentProfile();
            ret = default;
            return true;
        }
        if (method == MethodName.@QueueAgentProfileFit && args.Count == 0) {
            @QueueAgentProfileFit();
            ret = default;
            return true;
        }
        if (method == MethodName.@FitQueuedAgentProfile && args.Count == 0) {
            @FitQueuedAgentProfile();
            ret = default;
            return true;
        }
        if (method == MethodName.@FitAgentOverviewScroll && args.Count == 0) {
            @FitAgentOverviewScroll();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildAgentCards && args.Count == 0) {
            @BuildAgentCards();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildQuickCard && args.Count == 0) {
            @BuildQuickCard();
            ret = default;
            return true;
        }
        if (method == MethodName.@RefreshAgentCardIcons && args.Count == 0) {
            @RefreshAgentCardIcons();
            ret = default;
            return true;
        }
        if (method == MethodName.@CenterOnSelectedAgent && args.Count == 0) {
            @CenterOnSelectedAgent();
            ret = default;
            return true;
        }
        if (method == MethodName.@Sentence && args.Count == 1) {
            var callRet = @Sentence(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ThoughtTime && args.Count == 2) {
            var callRet = @ThoughtTime(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildApiKeysPanel && args.Count == 0) {
            @BuildApiKeysPanel();
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderSavedApiKeys && args.Count == 0) {
            @RenderSavedApiKeys();
            ret = default;
            return true;
        }
        if (method == MethodName.@CredentialProviderDisplayName && args.Count == 1) {
            var callRet = @CredentialProviderDisplayName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildBuildingCards && args.Count == 0) {
            @BuildBuildingCards();
            ret = default;
            return true;
        }
        if (method == MethodName.@SectionRow && args.Count == 2) {
            var callRet = @SectionRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@SelectBuilding && args.Count == 1) {
            @SelectBuilding(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ClearBuildingSelection && args.Count == 0) {
            @ClearBuildingSelection();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenBuildingDetails && args.Count == 0) {
            @OpenBuildingDetails();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildingDetailsBack && args.Count == 0) {
            @BuildingDetailsBack();
            ret = default;
            return true;
        }
        if (method == MethodName.@CenterOnSelectedBuilding && args.Count == 0) {
            @CenterOnSelectedBuilding();
            ret = default;
            return true;
        }
        if (method == MethodName.@ApplyBuildingReassignment && args.Count == 0) {
            @ApplyBuildingReassignment();
            ret = default;
            return true;
        }
        if (method == MethodName.@ConfirmBuildingRemoval && args.Count == 0) {
            @ConfirmBuildingRemoval();
            ret = default;
            return true;
        }
        if (method == MethodName.@CancelBuildingRemoval && args.Count == 0) {
            @CancelBuildingRemoval();
            ret = default;
            return true;
        }
        if (method == MethodName.@RemoveSelectedBuilding && args.Count == 0) {
            @RemoveSelectedBuilding();
            ret = default;
            return true;
        }
        if (method == MethodName.@RecipeName && args.Count == 1) {
            var callRet = @RecipeName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@RecipeIcon && args.Count == 1) {
            var callRet = @RecipeIcon(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@TimeLeft && args.Count == 1) {
            var callRet = @TimeLeft(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@PeopleInside && args.Count == 1) {
            var callRet = @PeopleInside(global::Godot.NativeInterop.VariantUtils.ConvertTo<string[]>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@Plural && args.Count == 2) {
            var callRet = @Plural(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ClearChildren && args.Count == 1) {
            @ClearChildren(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Node>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PositionBuildingDetails && args.Count == 0) {
            @PositionBuildingDetails();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildBuildingStorageHistory && args.Count == 0) {
            @BuildBuildingStorageHistory();
            ret = default;
            return true;
        }
        if (method == MethodName.@BeginCameraMotion && args.Count == 0) {
            @BeginCameraMotion();
            ret = default;
            return true;
        }
        if (method == MethodName.@CancelCameraMotion && args.Count == 0) {
            @CancelCameraMotion();
            ret = default;
            return true;
        }
        if (method == MethodName.@SetCameraAtImmediately && args.Count == 1) {
            @SetCameraAtImmediately(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@AdvanceCameraMotion && args.Count == 1) {
            @AdvanceCameraMotion(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@IsCurrentWorldRequest && args.Count == 1) {
            var callRet = @IsCurrentWorldRequest(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@ConfiguredServerUrl && args.Count == 0) {
            var callRet = @ConfiguredServerUrl();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@_Ready && args.Count == 0) {
            @_Ready();
            ret = default;
            return true;
        }
        if (method == MethodName.@_ExitTree && args.Count == 0) {
            @_ExitTree();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildDeveloperEdits && args.Count == 0) {
            @BuildDeveloperEdits();
            ret = default;
            return true;
        }
        if (method == MethodName.@ConfigureDeveloperEdit && args.Count == 0) {
            @ConfigureDeveloperEdit();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildDeveloperTools && args.Count == 1) {
            @BuildDeveloperTools(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildDeveloperAgingOverride && args.Count == 0) {
            @BuildDeveloperAgingOverride();
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleDeveloperTools && args.Count == 0) {
            @ToggleDeveloperTools();
            ret = default;
            return true;
        }
        if (method == MethodName.@CloseDeveloperTools && args.Count == 0) {
            @CloseDeveloperTools();
            ret = default;
            return true;
        }
        if (method == MethodName.@PositionDeveloperTools && args.Count == 0) {
            @PositionDeveloperTools();
            ret = default;
            return true;
        }
        if (method == MethodName.@JumpToDeveloperAgent && args.Count == 1) {
            @JumpToDeveloperAgent(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderDeveloperTile && args.Count == 0) {
            @RenderDeveloperTile();
            ret = default;
            return true;
        }
        if (method == MethodName.@UpdateDeveloperFrameTime && args.Count == 1) {
            @UpdateDeveloperFrameTime(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderDeveloperRoute && args.Count == 0) {
            @RenderDeveloperRoute();
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderPlannedPath && args.Count == 0) {
            @RenderPlannedPath();
            ret = default;
            return true;
        }
        if (method == MethodName.@StyleConfirmation && args.Count == 3) {
            @StyleConfirmation(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.ConfirmationDialog>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SetFullscreen && args.Count == 1) {
            @SetFullscreen(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ApplySavedDisplaySettings && args.Count == 0) {
            @ApplySavedDisplaySettings();
            ret = default;
            return true;
        }
        if (method == MethodName.@ApplyUiScale && args.Count == 0) {
            @ApplyUiScale();
            ret = default;
            return true;
        }
        if (method == MethodName.@SetUiFactor && args.Count == 1) {
            @SetUiFactor(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ScaleWindows && args.Count == 1) {
            @ScaleWindows(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ScaleMapText && args.Count == 1) {
            @ScaleMapText(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PopupDialog && args.Count == 1) {
            @PopupDialog(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.ConfirmationDialog>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@DialogSize && args.Count == 1) {
            var callRet = @DialogSize(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2I>(callRet);
            return true;
        }
        if (method == MethodName.@FitDialog && args.Count == 1) {
            var callRet = @FitDialog(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.AcceptDialog>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2I>(callRet);
            return true;
        }
        if (method == MethodName.@CurrentMonitorSize && args.Count == 0) {
            var callRet = @CurrentMonitorSize();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2I>(callRet);
            return true;
        }
        if (method == MethodName.@AutomaticRenderSize && args.Count == 0) {
            var callRet = @AutomaticRenderSize();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2I>(callRet);
            return true;
        }
        if (method == MethodName.@RefreshRenderSize && args.Count == 0) {
            @RefreshRenderSize();
            ret = default;
            return true;
        }
        if (method == MethodName.@DisplaySizeIndex && args.Count == 1) {
            var callRet = @DisplaySizeIndex(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@SettingsBox && args.Count == 2) {
            var callRet = @SettingsBox(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertToSystemArrayOfGodotObject<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@DisplaySettingRow && args.Count == 2) {
            var callRet = @DisplaySettingRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@SetWindowSize && args.Count == 1) {
            @SetWindowSize(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SetCloudHaze && args.Count == 1) {
            @SetCloudHaze(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SetLightningFlashes && args.Count == 1) {
            @SetLightningFlashes(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SetUiTheme && args.Count == 1) {
            @SetUiTheme(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@_Notification && args.Count == 1) {
            @_Notification(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ApplyThemeColors && args.Count == 0) {
            @ApplyThemeColors();
            ret = default;
            return true;
        }
        if (method == MethodName.@SetClockFormat && args.Count == 1) {
            @SetClockFormat(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@DateStyleIndex && args.Count == 1) {
            var callRet = @DateStyleIndex(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@SetDateStyle && args.Count == 1) {
            @SetDateStyle(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@DisplayWorldClock && args.Count == 1) {
            var callRet = @DisplayWorldClock(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@RenderEventLog && args.Count == 0) {
            @RenderEventLog();
            ret = default;
            return true;
        }
        if (method == MethodName.@JumpToEvent && args.Count == 1) {
            @JumpToEvent(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildEventRows && args.Count == 1) {
            @BuildEventRows(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@AddNewcomerOffer && args.Count == 0) {
            @AddNewcomerOffer();
            ret = default;
            return true;
        }
        if (method == MethodName.@FillFamilyLegend && args.Count == 0) {
            @FillFamilyLegend();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildFiltersButton && args.Count == 0) {
            @BuildFiltersButton();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildMapFiltersPanel && args.Count == 1) {
            @BuildMapFiltersPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleMapFilters && args.Count == 0) {
            @ToggleMapFilters();
            ret = default;
            return true;
        }
        if (method == MethodName.@ApplyMapFiltersFromCurrentSnapshot && args.Count == 0) {
            @ApplyMapFiltersFromCurrentSnapshot();
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleMoveFounder && args.Count == 0) {
            @ToggleMoveFounder();
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleFirstTownSite && args.Count == 0) {
            @ToggleFirstTownSite();
            ret = default;
            return true;
        }
        if (method == MethodName.@CancelFirstTownSiteSelection && args.Count == 0) {
            @CancelFirstTownSiteSelection();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildFounderSetupPanel && args.Count == 1) {
            @BuildFounderSetupPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectedFounderProvider && args.Count == 0) {
            var callRet = @SelectedFounderProvider();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SelectedFounderCredential && args.Count == 0) {
            var callRet = @SelectedFounderCredential();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@PopulateFounderCredentials && args.Count == 0) {
            @PopulateFounderCredentials();
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderFounderCredentialInputs && args.Count == 0) {
            @RenderFounderCredentialInputs();
            ret = default;
            return true;
        }
        if (method == MethodName.@ResetAddAgentPlacementHint && args.Count == 0) {
            @ResetAddAgentPlacementHint();
            ret = default;
            return true;
        }
        if (method == MethodName.@PlacementRefusalText && args.Count == 1) {
            var callRet = @PlacementRefusalText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.AgentPlacement.AgentPlacementAmbiguity>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildGenerationSettings && args.Count == 0) {
            @BuildGenerationSettings();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildTopBar && args.Count == 1) {
            @BuildTopBar(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@HudGroup && args.Count == 2) {
            var callRet = @HudGroup(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.HBoxContainer>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@AttachCorner && args.Count == 3) {
            @AttachCorner(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@CompactHud && args.Count == 1) {
            @CompactHud(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PlaceUnderButton && args.Count == 2) {
            @PlaceUnderButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PlaceHudPanels && args.Count == 0) {
            @PlaceHudPanels();
            ret = default;
            return true;
        }
        if (method == MethodName.@HudPanels && args.Count == 0) {
            var callRet = @HudPanels();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFromSystemArrayOfGodotObject(callRet);
            return true;
        }
        if (method == MethodName.@RefreshHudIcons && args.Count == 0) {
            @RefreshHudIcons();
            ret = default;
            return true;
        }
        if (method == MethodName.@UpdateUnreadEvents && args.Count == 1) {
            @UpdateUnreadEvents(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@MarkEventsSeen && args.Count == 0) {
            @MarkEventsSeen();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildWorldInfoPanel && args.Count == 1) {
            @BuildWorldInfoPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowWorldInfoPage && args.Count == 1) {
            @ShowWorldInfoPage(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleTowns && args.Count == 0) {
            @ToggleTowns();
            ret = default;
            return true;
        }
        if (method == MethodName.@CivicElectionName && args.Count == 1) {
            var callRet = @CivicElectionName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@TownListText && args.Count == 0) {
            var callRet = @TownListText();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@CenterOnTown && args.Count == 1) {
            @CenterOnTown(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildKeyboardNavigation && args.Count == 0) {
            @BuildKeyboardNavigation();
            ret = default;
            return true;
        }
        if (method == MethodName.@ConfigureKeyboardScrollBar && args.Count == 1) {
            @ConfigureKeyboardScrollBar(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.ScrollBar>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@CurrentKeyboardPanel && args.Count == 0) {
            var callRet = @CurrentKeyboardPanel();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(callRet);
            return true;
        }
        if (method == MethodName.@IsKeyboardFocusable && args.Count == 1) {
            var callRet = @IsKeyboardFocusable(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@KeyboardControls && args.Count == 1) {
            var callRet = @KeyboardControls(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFromSystemArrayOfGodotObject(callRet);
            return true;
        }
        if (method == MethodName.@FocusKeyboardPanel && args.Count == 1) {
            @FocusKeyboardPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@HandleKeyboardNavigationInput && args.Count == 1) {
            var callRet = @HandleKeyboardNavigationInput(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.InputEvent>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@BeginKeyboardMapSelection && args.Count == 0) {
            @BeginKeyboardMapSelection();
            ret = default;
            return true;
        }
        if (method == MethodName.@KeyboardMapCanvasPoint && args.Count == 1) {
            var callRet = @KeyboardMapCanvasPoint(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2>(callRet);
            return true;
        }
        if (method == MethodName.@RefreshKeyboardMapSelection && args.Count == 0) {
            @RefreshKeyboardMapSelection();
            ret = default;
            return true;
        }
        if (method == MethodName.@CenterKeyboardCameraAt && args.Count == 2) {
            @CenterKeyboardCameraAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@GameUserPath && args.Count == 1) {
            var callRet = @GameUserPath(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildQuitToLauncher && args.Count == 1) {
            @BuildQuitToLauncher(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.VBoxContainer>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@TryOpenLauncher && args.Count == 2) {
            var callRet = @TryOpenLauncher(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@ShowLauncherStartFailure && args.Count == 0) {
            @ShowLauncherStartFailure();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildLayout && args.Count == 0) {
            @BuildLayout();
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowSettingsSection && args.Count == 1) {
            @ShowSettingsSection(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildWorldColumn && args.Count == 1) {
            @BuildWorldColumn(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildInspectorColumn && args.Count == 1) {
            @BuildInspectorColumn(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildOwnerColumn && args.Count == 1) {
            @BuildOwnerColumn(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildStatusToast && args.Count == 1) {
            @BuildStatusToast(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@EmptyToNull && args.Count == 1) {
            var callRet = @EmptyToNull(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SetPanelText && args.Count == 2) {
            @SetPanelText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.RichTextLabel>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ConfigureTextPanel && args.Count == 2) {
            @ConfigureTextPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.RichTextLabel>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@FitQueuedTextPanels && args.Count == 0) {
            @FitQueuedTextPanels();
            ret = default;
            return true;
        }
        if (method == MethodName.@FitTextPanel && args.Count == 1) {
            @FitTextPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.RichTextLabel>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@FitFloatingPanelsToContents && args.Count == 0) {
            @FitFloatingPanelsToContents();
            ret = default;
            return true;
        }
        if (method == MethodName.@FloatingPanel && args.Count == 1) {
            var callRet = @FloatingPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@NewPanel && args.Count == 2) {
            var callRet = @NewPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@AddPanelContents && args.Count == 2) {
            @AddPanelContents(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.PanelContainer>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@MetricRow && args.Count == 2) {
            var callRet = @MetricRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@CloseButton && args.Count == 1) {
            var callRet = @CloseButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(callRet);
            return true;
        }
        if (method == MethodName.@StyleIconButton && args.Count == 2) {
            @StyleIconButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.PixelGlyph>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StyleMenuChoice && args.Count == 2) {
            @StyleMenuChoice(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StyleButton && args.Count == 2) {
            @StyleButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StyleSettingsCategoryButton && args.Count == 1) {
            @StyleSettingsCategoryButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectSettingsCategory && args.Count == 1) {
            @SelectSettingsCategory(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@CompleteLocalServerStartup && args.Count == 0) {
            @CompleteLocalServerStartup();
            ret = default;
            return true;
        }
        if (method == MethodName.@QuitGame && args.Count == 0) {
            @QuitGame();
            ret = default;
            return true;
        }
        if (method == MethodName.@QuitToLauncher && args.Count == 0) {
            @QuitToLauncher();
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowLocalServerStopFailure && args.Count == 3) {
            @ShowLocalServerStopFailure(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildMainMenu && args.Count == 0) {
            @BuildMainMenu();
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowMainMenu && args.Count == 0) {
            @ShowMainMenu();
            ret = default;
            return true;
        }
        if (method == MethodName.@RefreshMainMenuAvailability && args.Count == 0) {
            @RefreshMainMenuAvailability();
            ret = default;
            return true;
        }
        if (method == MethodName.@SetMainMenuStatus && args.Count == 1) {
            @SetMainMenuStatus(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@FitMainMenuLogo && args.Count == 0) {
            @FitMainMenuLogo();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenMainMenuSettings && args.Count == 0) {
            @OpenMainMenuSettings();
            ret = default;
            return true;
        }
        if (method == MethodName.@QuitToMainMenu && args.Count == 0) {
            @QuitToMainMenu();
            ret = default;
            return true;
        }
        if (method == MethodName.@SetWorldMenuActionsVisible && args.Count == 1) {
            @SetWorldMenuActionsVisible(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildWorldMenu && args.Count == 0) {
            @BuildWorldMenu();
            ret = default;
            return true;
        }
        if (method == MethodName.@WorldOptionRow && args.Count == 2) {
            var callRet = @WorldOptionRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@LayoutWorldMenu && args.Count == 0) {
            @LayoutWorldMenu();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenWorldMenu && args.Count == 1) {
            @OpenWorldMenu(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderWorldList && args.Count == 0) {
            @RenderWorldList();
            ret = default;
            return true;
        }
        if (method == MethodName.@SlotIcon && args.Count == 1) {
            var callRet = @SlotIcon(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.PixelGlyph>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ImageTexture>(callRet);
            return true;
        }
        if (method == MethodName.@RefreshWorldMenuAvailability && args.Count == 0) {
            @RefreshWorldMenuAvailability();
            ret = default;
            return true;
        }
        if (method == MethodName.@GenerationAmountText && args.Count == 1) {
            var callRet = @GenerationAmountText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ResetWorldGenerationOptions && args.Count == 0) {
            @ResetWorldGenerationOptions();
            ret = default;
            return true;
        }
        if (method == MethodName.@InvalidateWorldPreview && args.Count == 1) {
            @InvalidateWorldPreview(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Percent && args.Count == 1) {
            var callRet = @Percent(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ForestAmount && args.Count == 1) {
            var callRet = @ForestAmount(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@MountainAmount && args.Count == 1) {
            var callRet = @MountainAmount(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@RefreshMenuIcons && args.Count == 0) {
            @RefreshMenuIcons();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildMapHud && args.Count == 1) {
            @BuildMapHud(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PositionMapHud && args.Count == 0) {
            @PositionMapHud();
            ret = default;
            return true;
        }
        if (method == MethodName.@CameraAxis && args.Count == 4) {
            var callRet = @CameraAxis(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@PositiveMod && args.Count == 2) {
            var callRet = @PositiveMod(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@WrappedMarkerX && args.Count == 4) {
            var callRet = @WrappedMarkerX(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@RepositionWrappedMapMarkers && args.Count == 3) {
            @RepositionWrappedMapMarkers(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RefreshOverviewViewport && args.Count == 4) {
            @RefreshOverviewViewport(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[3]));
            ret = default;
            return true;
        }
        if (method == MethodName.@CenterCameraAt && args.Count == 1) {
            @CenterCameraAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PanCamera && args.Count == 1) {
            @PanCamera(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@HandleMapInput && args.Count == 1) {
            @HandleMapInput(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.InputEvent>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RefreshTileHoverAtMouse && args.Count == 0) {
            @RefreshTileHoverAtMouse();
            ret = default;
            return true;
        }
        if (method == MethodName.@ClearTileSelection && args.Count == 0) {
            @ClearTileSelection();
            ret = default;
            return true;
        }
        if (method == MethodName.@PositionSelectedTilePanel && args.Count == 0) {
            @PositionSelectedTilePanel();
            ret = default;
            return true;
        }
        if (method == MethodName.@UpdateTileHover && args.Count == 2) {
            @UpdateTileHover(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@OverviewLegend && args.Count == 0) {
            var callRet = @OverviewLegend();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@FilterSwatch && args.Count == 1) {
            var callRet = @FilterSwatch(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.FilterLook>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ImageTexture>(callRet);
            return true;
        }
        if (method == MethodName.@FilterRow && args.Count == 4) {
            var callRet = @FilterRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.CheckButton>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.FilterLook>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@AdvanceMapMarkers && args.Count == 1) {
            @AdvanceMapMarkers(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildMemoryCards && args.Count == 1) {
            @BuildMemoryCards(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.VBoxContainer>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@MemoryAccent && args.Count == 1) {
            var callRet = @MemoryAccent(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.MemoryKind>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@Sureness && args.Count == 2) {
            var callRet = @Sureness(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(callRet);
            return true;
        }
        if (method == MethodName.@MemoryEntry && args.Count == 6) {
            var callRet = @MemoryEntry(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.MemoryKind>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.PixelGlyph>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[3]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[4]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[5]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@MetaLine && args.Count == 1) {
            var callRet = @MetaLine(global::Godot.NativeInterop.VariantUtils.ConvertToSystemArrayOfGodotObject<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HFlowContainer>(callRet);
            return true;
        }
        if (method == MethodName.@MetaText && args.Count == 1) {
            var callRet = @MetaText(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(callRet);
            return true;
        }
        if (method == MethodName.@Tag && args.Count == 2) {
            var callRet = @Tag(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(callRet);
            return true;
        }
        if (method == MethodName.@ShowMemoryCards && args.Count == 0) {
            @ShowMemoryCards();
            ret = default;
            return true;
        }
        if (method == MethodName.@FitMemoryCards && args.Count == 0) {
            @FitMemoryCards();
            ret = default;
            return true;
        }
        if (method == MethodName.@MemoryCardsText && args.Count == 0) {
            var callRet = @MemoryCardsText();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@RenderUsageStatus && args.Count == 0) {
            @RenderUsageStatus();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildUsageLimitPanel && args.Count == 0) {
            @BuildUsageLimitPanel();
            ret = default;
            return true;
        }
        if (method == MethodName.@HasModelList && args.Count == 1) {
            var callRet = @HasModelList(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@RequestFounderModels && args.Count == 0) {
            @RequestFounderModels();
            ret = default;
            return true;
        }
        if (method == MethodName.@SyncAgentModelPicker && args.Count == 1) {
            @SyncAgentModelPicker(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@OnFounderKeyEdited && args.Count == 0) {
            @OnFounderKeyEdited();
            ret = default;
            return true;
        }
        if (method == MethodName.@OnAgentModelKeyEdited && args.Count == 0) {
            @OnAgentModelKeyEdited();
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectedRoutineHelper && args.Count == 0) {
            var callRet = @SelectedRoutineHelper();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildRoutineHelperSettings && args.Count == 0) {
            @BuildRoutineHelperSettings();
            ret = default;
            return true;
        }
        if (method == MethodName.@RequestRoutineHelperModels && args.Count == 0) {
            @RequestRoutineHelperModels();
            ret = default;
            return true;
        }
        if (method == MethodName.@ClearRoutineHelperSetupCheck && args.Count == 0) {
            @ClearRoutineHelperSetupCheck();
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectedRoutineHelperKey && args.Count == 0) {
            var callRet = @SelectedRoutineHelperKey();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@RefreshRoutineHelperKeys && args.Count == 1) {
            @RefreshRoutineHelperKeys(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildModLibrary && args.Count == 1) {
            @BuildModLibrary(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.VBoxContainer>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowModLibrary && args.Count == 0) {
            @ShowModLibrary();
            ret = default;
            return true;
        }
        if (method == MethodName.@ModLibraryText && args.Count == 0) {
            var callRet = @ModLibraryText();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConfigureOrderLabel && args.Count == 1) {
            @ConfigureOrderLabel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildOrdersReader && args.Count == 0) {
            @BuildOrdersReader();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenOrdersReader && args.Count == 0) {
            @OpenOrdersReader();
            ret = default;
            return true;
        }
        if (method == MethodName.@OrderItemName && args.Count == 1) {
            var callRet = @OrderItemName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ProgressUnitLabel && args.Count == 1) {
            var callRet = @ProgressUnitLabel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@OrderBuildingName && args.Count == 1) {
            var callRet = @OrderBuildingName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@InstructionSubmissionResultText && args.Count == 2) {
            var callRet = @InstructionSubmissionResultText(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@RefreshControlAvailability && args.Count == 0) {
            @RefreshControlAvailability();
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderPairedDevices && args.Count == 0) {
            @RenderPairedDevices();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildDeveloperDevices && args.Count == 0) {
            @BuildDeveloperDevices();
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleAgents && args.Count == 0) {
            @ToggleAgents();
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleEvents && args.Count == 0) {
            @ToggleEvents();
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleWorldInfo && args.Count == 0) {
            @ToggleWorldInfo();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenFamilyTree && args.Count == 0) {
            @OpenFamilyTree();
            ret = default;
            return true;
        }
        if (method == MethodName.@UpdateFamilyTreeStatus && args.Count == 0) {
            @UpdateFamilyTreeStatus();
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectFromFamilyTree && args.Count == 1) {
            @SelectFromFamilyTree(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenMemories && args.Count == 0) {
            @OpenMemories();
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowPauseMenuPage && args.Count == 1) {
            @ShowPauseMenuPage(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowPauseMenuButtons && args.Count == 0) {
            @ShowPauseMenuButtons();
            ret = default;
            return true;
        }
        if (method == MethodName.@ClosePauseMenu && args.Count == 0) {
            @ClosePauseMenu();
            ret = default;
            return true;
        }
        if (method == MethodName.@_UnhandledKeyInput && args.Count == 1) {
            @_UnhandledKeyInput(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.InputEvent>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@_Process && args.Count == 1) {
            @_Process(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PanCameraForFrame && args.Count == 2) {
            @PanCameraForFrame(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@HandleEscape && args.Count == 0) {
            var callRet = @HandleEscape();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@Keycap && args.Count == 1) {
            var callRet = @Keycap(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(callRet);
            return true;
        }
        if (method == MethodName.@BuildPendingSubmissionRecovery && args.Count == 1) {
            @BuildPendingSubmissionRecovery(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ReviewPendingSubmission && args.Count == 0) {
            @ReviewPendingSubmission();
            ret = default;
            return true;
        }
        if (method == MethodName.@LoadPendingSubmission && args.Count == 0) {
            @LoadPendingSubmission();
            ret = default;
            return true;
        }
        if (method == MethodName.@ForgetPendingSubmission && args.Count == 0) {
            @ForgetPendingSubmission();
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderPendingSubmission && args.Count == 0) {
            @RenderPendingSubmission();
            ret = default;
            return true;
        }
        if (method == MethodName.@SetOwnerRequestBusy && args.Count == 1) {
            @SetOwnerRequestBusy(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BindOwnerRequestPanels && args.Count == 0) {
            @BindOwnerRequestPanels();
            ret = default;
            return true;
        }
        if (method == MethodName.@SetStatus && args.Count == 3) {
            @SetStatus(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.StatusToastKind>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ExpireStatusToast && args.Count == 1) {
            @ExpireStatusToast(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowHeldState && args.Count == 1) {
            @ShowHeldState(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ResourceGlyph && args.Count == 2) {
            var callRet = @ResourceGlyph(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ResourceGlyph && args.Count == 1) {
            var callRet = @ResourceGlyph(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ObjectMarker && args.Count == 1) {
            var callRet = @ObjectMarker(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ObjectGlyph && args.Count == 1) {
            var callRet = @ObjectGlyph(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ShortMarker && args.Count == 1) {
            var callRet = @ShortMarker(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@Pretty && args.Count == 1) {
            var callRet = @Pretty(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@NeedPercent && args.Count == 1) {
            var callRet = @NeedPercent(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@NewReportProblemButton && args.Count == 0) {
            var callRet = @NewReportProblemButton();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(callRet);
            return true;
        }
        if (method == MethodName.@ReportProblem && args.Count == 0) {
            @ReportProblem();
            ret = default;
            return true;
        }
        if (method == MethodName.@WriteProblemReport && args.Count == 1) {
            var callRet = @WriteProblemReport(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ProblemReportDirectory && args.Count == 0) {
            var callRet = @ProblemReportDirectory();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@PreviousGameLog && args.Count == 1) {
            var callRet = @PreviousGameLog(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SizeText && args.Count == 1) {
            var callRet = @SizeText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildProfilePeople && args.Count == 1) {
            @BuildProfilePeople(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.VBoxContainer>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ProfilePeopleText && args.Count == 0) {
            var callRet = @ProfilePeopleText();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ResetAgentModelSetupCheckForCurrentChoice && args.Count == 0) {
            @ResetAgentModelSetupCheckForCurrentChoice();
            ret = default;
            return true;
        }
        if (method == MethodName.@ClearFounderModelSetupCheck && args.Count == 0) {
            @ClearFounderModelSetupCheck();
            ret = default;
            return true;
        }
        if (method == MethodName.@ClearAgentModelSetupCheck && args.Count == 0) {
            @ClearAgentModelSetupCheck();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyModelSetupCheckControls && args.Count == 0) {
            @VerifyModelSetupCheckControls();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildRecoveryCleanup && args.Count == 1) {
            @BuildRecoveryCleanup(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.VBoxContainer>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ApplyResponsiveLayout && args.Count == 0) {
            @ApplyResponsiveLayout();
            ret = default;
            return true;
        }
        if (method == MethodName.@PositionFamilyTreePanel && args.Count == 2) {
            @PositionFamilyTreePanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PlaceQuickCard && args.Count == 2) {
            @PlaceQuickCard(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.PanelContainer>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@FitMenuScrolls && args.Count == 1) {
            @FitMenuScrolls(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@CardTop && args.Count == 1) {
            var callRet = @CardTop(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@FitHudLists && args.Count == 0) {
            @FitHudLists();
            ret = default;
            return true;
        }
        if (method == MethodName.@QueueHudListsFit && args.Count == 0) {
            @QueueHudListsFit();
            ret = default;
            return true;
        }
        if (method == MethodName.@ListRoom && args.Count == 2) {
            var callRet = @ListRoom(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@BuildSaveDiskWarning && args.Count == 1) {
            @BuildSaveDiskWarning(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildAutosaveSettings && args.Count == 0) {
            @BuildAutosaveSettings();
            ret = default;
            return true;
        }
        if (method == MethodName.@IsCurrentAutosaveSettingsContext && args.Count == 0) {
            var callRet = @IsCurrentAutosaveSettingsContext();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@CancelAutosaveSettingsRead && args.Count == 0) {
            @CancelAutosaveSettingsRead();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildManualSavesPanel && args.Count == 0) {
            @BuildManualSavesPanel();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildManualSaveTimeline && args.Count == 1) {
            @BuildManualSaveTimeline(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.VBoxContainer>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ApplyManualSaveView && args.Count == 0) {
            @ApplyManualSaveView();
            ret = default;
            return true;
        }
        if (method == MethodName.@FitManualSaveList && args.Count == 0) {
            @FitManualSaveList();
            ret = default;
            return true;
        }
        if (method == MethodName.@ManualSaveTimelineWidth && args.Count == 0) {
            var callRet = @ManualSaveTimelineWidth();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@ManualSaveCardFrame && args.Count == 0) {
            var callRet = @ManualSaveCardFrame();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@FitManualSaveTimeline && args.Count == 0) {
            @FitManualSaveTimeline();
            ret = default;
            return true;
        }
        if (method == MethodName.@ChooseTimelineSave && args.Count == 1) {
            @ChooseTimelineSave(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderManualSaveDetails && args.Count == 0) {
            @RenderManualSaveDetails();
            ret = default;
            return true;
        }
        if (method == MethodName.@TimelineReadout && args.Count == 0) {
            var callRet = @TimelineReadout();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ClearWorldSaveHistory && args.Count == 0) {
            @ClearWorldSaveHistory();
            ret = default;
            return true;
        }
        if (method == MethodName.@CancelManualSaveListRead && args.Count == 0) {
            @CancelManualSaveListRead();
            ret = default;
            return true;
        }
        if (method == MethodName.@RefreshManualSaveAvailability && args.Count == 0) {
            @RefreshManualSaveAvailability();
            ret = default;
            return true;
        }
        if (method == MethodName.@CurrentManualSaveWorldId && args.Count == 0) {
            var callRet = @CurrentManualSaveWorldId();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ShowManualSavePanel && args.Count == 1) {
            @ShowManualSavePanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderManualSaveTimeline && args.Count == 0) {
            @RenderManualSaveTimeline();
            ret = default;
            return true;
        }
        if (method == MethodName.@RenderManualSaveList && args.Count == 0) {
            @RenderManualSaveList();
            ret = default;
            return true;
        }
        if (method == MethodName.@ShortBranchTag && args.Count == 1) {
            var callRet = @ShortBranchTag(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConfirmManualSaveOverwrite && args.Count == 0) {
            @ConfirmManualSaveOverwrite();
            ret = default;
            return true;
        }
        if (method == MethodName.@DisplaySaveClock && args.Count == 1) {
            var callRet = @DisplaySaveClock(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConfirmManualSaveLoad && args.Count == 0) {
            @ConfirmManualSaveLoad();
            ret = default;
            return true;
        }
        if (method == MethodName.@ConfirmSaveDeletion && args.Count == 0) {
            @ConfirmSaveDeletion();
            ret = default;
            return true;
        }
        if (method == MethodName.@ConfirmWorldDeletion && args.Count == 0) {
            @ConfirmWorldDeletion();
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectAgentFromList && args.Count == 2) {
            @SelectAgentFromList(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectAgent && args.Count == 1) {
            @SelectAgent(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ClearAgentSelection && args.Count == 0) {
            @ClearAgentSelection();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildControlsPanel && args.Count == 1) {
            @BuildControlsPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PositionControlsPanel && args.Count == 0) {
            @PositionControlsPanel();
            ret = default;
            return true;
        }
        if (method == MethodName.@ToggleControlsPanel && args.Count == 0) {
            @ToggleControlsPanel();
            ret = default;
            return true;
        }
        if (method == MethodName.@WorldKeysAvailable && args.Count == 0) {
            var callRet = @WorldKeysAvailable();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@NoMenuOverWorld && args.Count == 0) {
            var callRet = @NoMenuOverWorld();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@_Input && args.Count == 1) {
            @_Input(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.InputEvent>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@HandleShortcutKey && args.Count == 1) {
            var callRet = @HandleShortcutKey(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.InputEventKey>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@PressTopBarAction && args.Count == 1) {
            @PressTopBarAction(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@CycleSelectedAgent && args.Count == 1) {
            @CycleSelectedAgent(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@CenterOnHome && args.Count == 0) {
            @CenterOnHome();
            ret = default;
            return true;
        }
        if (method == MethodName.@ZoomAt && args.Count == 2) {
            @ZoomAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildControlsGroups && args.Count == 1) {
            @BuildControlsGroups(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@FillControlsGroups && args.Count == 0) {
            @FillControlsGroups();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildStartupRecovery && args.Count == 0) {
            @BuildStartupRecovery();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildTileCard && args.Count == 1) {
            @BuildTileCard(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@HeightWords && args.Count == 1) {
            var callRet = @HeightWords(global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@AddTileFact && args.Count == 2) {
            @AddTileFact(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@AddTileThing && args.Count == 3) {
            @AddTileThing(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Texture2D>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@TileCardText && args.Count == 0) {
            var callRet = @TileCardText();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildDeveloperWorldEdit && args.Count == 0) {
            @BuildDeveloperWorldEdit();
            ret = default;
            return true;
        }
        if (method == MethodName.@ConfigureWorldEditPicker && args.Count == 1) {
            @ConfigureWorldEditPicker(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ClearWorldEditPreview && args.Count == 0) {
            @ClearWorldEditPreview();
            ret = default;
            return true;
        }
        if (method == MethodName.@UpdateWorldEditPreview && args.Count == 0) {
            @UpdateWorldEditPreview();
            ret = default;
            return true;
        }
        if (method == MethodName.@AddWorldEditKinds && args.Count == 0) {
            @AddWorldEditKinds();
            ret = default;
            return true;
        }
        if (method == MethodName.@AddWorldEditKind && args.Count == 2) {
            @AddWorldEditKind(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@UpdateWorldEditHint && args.Count == 0) {
            @UpdateWorldEditHint();
            ret = default;
            return true;
        }
        if (method == MethodName.@ConfigureCoordinate && args.Count == 2) {
            @ConfigureCoordinate(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.SpinBox>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectedWorldEditKind && args.Count == 0) {
            var callRet = @SelectedWorldEditKind();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildWorldInfoPages && args.Count == 1) {
            @BuildWorldInfoPages(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.VBoxContainer>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StatTile && args.Count == 3) {
            var callRet = @StatTile(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Texture2D>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@PageText && args.Count == 1) {
            var callRet = @PageText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ResetDisplayedWorldContext && args.Count == 0) {
            @ResetDisplayedWorldContext();
            ret = default;
            return true;
        }
        if (method == MethodName.@MapObjectLabelFits && args.Count == 2) {
            var callRet = @MapObjectLabelFits(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        return base.InvokeGodotClassMethod(method, args, out ret);
    }
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static bool InvokeGodotClassStaticMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@VerifyMarriageOrderText && args.Count == 0) {
            @VerifyMarriageOrderText();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyConstructionPixelContracts && args.Count == 0) {
            @VerifyConstructionPixelContracts();
            ret = default;
            return true;
        }
        if (method == MethodName.@RequireConstructionHalf && args.Count == 3) {
            @RequireConstructionHalf(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Image>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Image>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ConstructionColor && args.Count == 7) {
            var callRet = @ConstructionColor(global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[3]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[4]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[5]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[6]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@HandcartPixelDigest && args.Count == 1) {
            var callRet = @HandcartPixelDigest(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Image>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ApprovedHandcartDigest && args.Count == 3) {
            var callRet = @ApprovedHandcartDigest(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyHandcartApprovedPixels && args.Count == 0) {
            @VerifyHandcartApprovedPixels();
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowsFind && args.Count == 1) {
            var callRet = @ShowsFind(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyAbandonedArtSampling && args.Count == 0) {
            @VerifyAbandonedArtSampling();
            ret = default;
            return true;
        }
        if (method == MethodName.@CaptionForChecks && args.Count == 1) {
            var callRet = @CaptionForChecks(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ReliefRegionMatches && args.Count == 7) {
            var callRet = @ReliefRegionMatches(global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte[]>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[3]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[4]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[5]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[6]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@CheckThemeTextContrast && args.Count == 0) {
            @CheckThemeTextContrast();
            ret = default;
            return true;
        }
        if (method == MethodName.@ThemeTextSurface && args.Count == 2) {
            var callRet = @ThemeTextSurface(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.StyleBox>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@TextureCenter && args.Count == 1) {
            var callRet = @TextureCenter(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.StyleBoxTexture>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@Composite && args.Count == 2) {
            var callRet = @Composite(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@ShowsGlyph && args.Count == 2) {
            var callRet = @ShowsGlyph(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.PixelGlyph>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@VerifyWorldThumbnailFallback && args.Count == 0) {
            @VerifyWorldThumbnailFallback();
            ret = default;
            return true;
        }
        if (method == MethodName.@VerifyAppIconFile && args.Count == 0) {
            @VerifyAppIconFile();
            ret = default;
            return true;
        }
        if (method == MethodName.@ConversationPreview && args.Count == 2) {
            var callRet = @ConversationPreview(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConversationInterruptionText && args.Count == 1) {
            var callRet = @ConversationInterruptionText(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConversationOutcomeText && args.Count == 1) {
            var callRet = @ConversationOutcomeText(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConversationTurnKey && args.Count == 2) {
            var callRet = @ConversationTurnKey(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@Capitalize && args.Count == 1) {
            var callRet = @Capitalize(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@IsModelProvider && args.Count == 1) {
            var callRet = @IsModelProvider(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@PopulateThinkingChoices && args.Count == 1) {
            @PopulateThinkingChoices(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.OptionButton>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectedThinking && args.Count == 1) {
            var callRet = @SelectedThinking(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.OptionButton>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SelectThinking && args.Count == 2) {
            @SelectThinking(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.OptionButton>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@RoleDisplayName && args.Count == 1) {
            var callRet = @RoleDisplayName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ProviderDisplayName && args.Count == 1) {
            var callRet = @ProviderDisplayName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@DefaultProviderModel && args.Count == 1) {
            var callRet = @DefaultProviderModel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@FieldCaption && args.Count == 2) {
            var callRet = @FieldCaption(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.FittedLabel>(callRet);
            return true;
        }
        if (method == MethodName.@AddProfileText && args.Count == 2) {
            @AddProfileText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Container>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StyleCompactToggle && args.Count == 1) {
            @StyleCompactToggle(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ReaderHeading && args.Count == 3) {
            var callRet = @ReaderHeading(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.PanelContainer>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@Sentence && args.Count == 1) {
            var callRet = @Sentence(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@CredentialProviderDisplayName && args.Count == 1) {
            var callRet = @CredentialProviderDisplayName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SectionRow && args.Count == 2) {
            var callRet = @SectionRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@RecipeName && args.Count == 1) {
            var callRet = @RecipeName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@RecipeIcon && args.Count == 1) {
            var callRet = @RecipeIcon(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@PeopleInside && args.Count == 1) {
            var callRet = @PeopleInside(global::Godot.NativeInterop.VariantUtils.ConvertTo<string[]>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@Plural && args.Count == 2) {
            var callRet = @Plural(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ClearChildren && args.Count == 1) {
            @ClearChildren(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Node>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ConfiguredServerUrl && args.Count == 0) {
            var callRet = @ConfiguredServerUrl();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@StyleConfirmation && args.Count == 3) {
            @StyleConfirmation(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.ConfirmationDialog>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@FitDialog && args.Count == 1) {
            var callRet = @FitDialog(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.AcceptDialog>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2I>(callRet);
            return true;
        }
        if (method == MethodName.@CurrentMonitorSize && args.Count == 0) {
            var callRet = @CurrentMonitorSize();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2I>(callRet);
            return true;
        }
        if (method == MethodName.@DisplaySizeIndex && args.Count == 1) {
            var callRet = @DisplaySizeIndex(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@SettingsBox && args.Count == 2) {
            var callRet = @SettingsBox(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertToSystemArrayOfGodotObject<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@DateStyleIndex && args.Count == 1) {
            var callRet = @DateStyleIndex(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@PlacementRefusalText && args.Count == 1) {
            var callRet = @PlacementRefusalText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.AgentPlacement.AgentPlacementAmbiguity>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@HudGroup && args.Count == 2) {
            var callRet = @HudGroup(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.HBoxContainer>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@AttachCorner && args.Count == 3) {
            @AttachCorner(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@CivicElectionName && args.Count == 1) {
            var callRet = @CivicElectionName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConfigureKeyboardScrollBar && args.Count == 1) {
            @ConfigureKeyboardScrollBar(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.ScrollBar>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@IsKeyboardFocusable && args.Count == 1) {
            var callRet = @IsKeyboardFocusable(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@KeyboardControls && args.Count == 1) {
            var callRet = @KeyboardControls(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFromSystemArrayOfGodotObject(callRet);
            return true;
        }
        if (method == MethodName.@GameUserPath && args.Count == 1) {
            var callRet = @GameUserPath(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@EmptyToNull && args.Count == 1) {
            var callRet = @EmptyToNull(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@FloatingPanel && args.Count == 1) {
            var callRet = @FloatingPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@NewPanel && args.Count == 2) {
            var callRet = @NewPanel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@AddPanelContents && args.Count == 2) {
            @AddPanelContents(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.PanelContainer>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@MetricRow && args.Count == 2) {
            var callRet = @MetricRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@CloseButton && args.Count == 1) {
            var callRet = @CloseButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Button>(callRet);
            return true;
        }
        if (method == MethodName.@StyleIconButton && args.Count == 2) {
            @StyleIconButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.PixelGlyph>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StyleMenuChoice && args.Count == 2) {
            @StyleMenuChoice(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StyleButton && args.Count == 2) {
            @StyleButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StyleSettingsCategoryButton && args.Count == 1) {
            @StyleSettingsCategoryButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@WorldOptionRow && args.Count == 2) {
            var callRet = @WorldOptionRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@SlotIcon && args.Count == 1) {
            var callRet = @SlotIcon(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.PixelGlyph>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ImageTexture>(callRet);
            return true;
        }
        if (method == MethodName.@GenerationAmountText && args.Count == 1) {
            var callRet = @GenerationAmountText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.SegmentedChoice>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@Percent && args.Count == 1) {
            var callRet = @Percent(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ForestAmount && args.Count == 1) {
            var callRet = @ForestAmount(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@MountainAmount && args.Count == 1) {
            var callRet = @MountainAmount(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@CameraAxis && args.Count == 4) {
            var callRet = @CameraAxis(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@PositiveMod && args.Count == 2) {
            var callRet = @PositiveMod(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@OverviewLegend && args.Count == 0) {
            var callRet = @OverviewLegend();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@FilterSwatch && args.Count == 1) {
            var callRet = @FilterSwatch(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.FilterLook>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ImageTexture>(callRet);
            return true;
        }
        if (method == MethodName.@FilterRow && args.Count == 4) {
            var callRet = @FilterRow(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.CheckButton>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.FilterLook>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HBoxContainer>(callRet);
            return true;
        }
        if (method == MethodName.@MemoryAccent && args.Count == 1) {
            var callRet = @MemoryAccent(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.MemoryKind>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@Sureness && args.Count == 2) {
            var callRet = @Sureness(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.TextureRect>(callRet);
            return true;
        }
        if (method == MethodName.@MemoryEntry && args.Count == 6) {
            var callRet = @MemoryEntry(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.Main.MemoryKind>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.PixelGlyph>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[3]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[4]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[5]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@MetaLine && args.Count == 1) {
            var callRet = @MetaLine(global::Godot.NativeInterop.VariantUtils.ConvertToSystemArrayOfGodotObject<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.HFlowContainer>(callRet);
            return true;
        }
        if (method == MethodName.@MetaText && args.Count == 1) {
            var callRet = @MetaText(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(callRet);
            return true;
        }
        if (method == MethodName.@Tag && args.Count == 2) {
            var callRet = @Tag(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(callRet);
            return true;
        }
        if (method == MethodName.@HasModelList && args.Count == 1) {
            var callRet = @HasModelList(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@ConfigureOrderLabel && args.Count == 1) {
            @ConfigureOrderLabel(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@OrderItemName && args.Count == 1) {
            var callRet = @OrderItemName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ProgressUnitLabel && args.Count == 1) {
            var callRet = @ProgressUnitLabel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@OrderBuildingName && args.Count == 1) {
            var callRet = @OrderBuildingName(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@InstructionSubmissionResultText && args.Count == 2) {
            var callRet = @InstructionSubmissionResultText(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@Keycap && args.Count == 1) {
            var callRet = @Keycap(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Control>(callRet);
            return true;
        }
        if (method == MethodName.@ResourceGlyph && args.Count == 2) {
            var callRet = @ResourceGlyph(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ResourceGlyph && args.Count == 1) {
            var callRet = @ResourceGlyph(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ObjectMarker && args.Count == 1) {
            var callRet = @ObjectMarker(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ObjectGlyph && args.Count == 1) {
            var callRet = @ObjectGlyph(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ShortMarker && args.Count == 1) {
            var callRet = @ShortMarker(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@Pretty && args.Count == 1) {
            var callRet = @Pretty(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@NeedPercent && args.Count == 1) {
            var callRet = @NeedPercent(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@PreviousGameLog && args.Count == 1) {
            var callRet = @PreviousGameLog(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SizeText && args.Count == 1) {
            var callRet = @SizeText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@PressTopBarAction && args.Count == 1) {
            @PressTopBarAction(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@HeightWords && args.Count == 1) {
            var callRet = @HeightWords(global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@ConfigureCoordinate && args.Count == 2) {
            @ConfigureCoordinate(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.SpinBox>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@StatTile && args.Count == 3) {
            var callRet = @StatTile(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Texture2D>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.PanelContainer>(callRet);
            return true;
        }
        if (method == MethodName.@PageText && args.Count == 1) {
            var callRet = @PageText(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@MapObjectLabelFits && args.Count == 2) {
            var callRet = @MapObjectLabelFits(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Label>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        ret = default;
        return false;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassMethod(in godot_string_name method)
    {
        if (method == MethodName.@VerifyAgentCardStyleRetention) {
           return true;
        }
        if (method == MethodName.@VerifyMarriageOrderText) {
           return true;
        }
        if (method == MethodName.@VerifyAnimalPresentation) {
           return true;
        }
        if (method == MethodName.@VerifyBoatPresentation) {
           return true;
        }
        if (method == MethodName.@VerifyConstructionPixelContracts) {
           return true;
        }
        if (method == MethodName.@RequireConstructionHalf) {
           return true;
        }
        if (method == MethodName.@ConstructionColor) {
           return true;
        }
        if (method == MethodName.@VerifyPlainEllipses) {
           return true;
        }
        if (method == MethodName.@VerifyAgentTextEllipses) {
           return true;
        }
        if (method == MethodName.@VerifyEventLogRefusalRollover) {
           return true;
        }
        if (method == MethodName.@HandcartPixelDigest) {
           return true;
        }
        if (method == MethodName.@ApprovedHandcartDigest) {
           return true;
        }
        if (method == MethodName.@VerifyHandcartApprovedPixels) {
           return true;
        }
        if (method == MethodName.@VerifyHandcartMotionAndZoom) {
           return true;
        }
        if (method == MethodName.@VerifyHandcartInspection) {
           return true;
        }
        if (method == MethodName.@AgentListCardText) {
           return true;
        }
        if (method == MethodName.@VerifyEventRows) {
           return true;
        }
        if (method == MethodName.@ShowsFind) {
           return true;
        }
        if (method == MethodName.@NewcomerOfferButton) {
           return true;
        }
        if (method == MethodName.@VerifyControlsKeycaps) {
           return true;
        }
        if (method == MethodName.@VerifyDeveloperRunOptions) {
           return true;
        }
        if (method == MethodName.@VerifySaveBranchList) {
           return true;
        }
        if (method == MethodName.@VerifyMapPanels) {
           return true;
        }
        if (method == MethodName.@VerifyModelSettingsLayout) {
           return true;
        }
        if (method == MethodName.@VerifyAbandonedBuildingLooks) {
           return true;
        }
        if (method == MethodName.@VerifyAbandonedLanternsAndBridges) {
           return true;
        }
        if (method == MethodName.@VerifyAbandonedArtSampling) {
           return true;
        }
        if (method == MethodName.@VerifyPeopleInside) {
           return true;
        }
        if (method == MethodName.@VerifyOrnamentPresentation) {
           return true;
        }
        if (method == MethodName.@CaptionForChecks) {
           return true;
        }
        if (method == MethodName.@VerifyPanelParts) {
           return true;
        }
        if (method == MethodName.@VerifyProblemReport) {
           return true;
        }
        if (method == MethodName.@ReliefRegionMatches) {
           return true;
        }
        if (method == MethodName.@CheckThemeTextContrast) {
           return true;
        }
        if (method == MethodName.@ThemeTextSurface) {
           return true;
        }
        if (method == MethodName.@TextureCenter) {
           return true;
        }
        if (method == MethodName.@Composite) {
           return true;
        }
        if (method == MethodName.@VerifyToolMakingPresentation) {
           return true;
        }
        if (method == MethodName.@ShowsGlyph) {
           return true;
        }
        if (method == MethodName.@VerifyConsistentButtons) {
           return true;
        }
        if (method == MethodName.@VerifyModelPicker) {
           return true;
        }
        if (method == MethodName.@VerifyChildModelStatus) {
           return true;
        }
        if (method == MethodName.@VerifyPixelText) {
           return true;
        }
        if (method == MethodName.@VerifyWorldThumbnailFallback) {
           return true;
        }
        if (method == MethodName.@VerifyMainMenuLogo) {
           return true;
        }
        if (method == MethodName.@VerifyAppIconFile) {
           return true;
        }
        if (method == MethodName.@FinishUiSmoke) {
           return true;
        }
        if (method == MethodName.@VerifyEventLogAgentNames) {
           return true;
        }
        if (method == MethodName.@ShowWorldActionSmokeMenu) {
           return true;
        }
        if (method == MethodName.@ChooseWorldActionSmokeRow) {
           return true;
        }
        if (method == MethodName.@RequireWorldPreviewCleared) {
           return true;
        }
        if (method == MethodName.@VerifyYardAnimalInspection) {
           return true;
        }
        if (method == MethodName.@BuildConversationReader) {
           return true;
        }
        if (method == MethodName.@OpenAgentConversation) {
           return true;
        }
        if (method == MethodName.@ToggleConversationHistory) {
           return true;
        }
        if (method == MethodName.@ConversationPreview) {
           return true;
        }
        if (method == MethodName.@ConversationInterruptionText) {
           return true;
        }
        if (method == MethodName.@ConversationOutcomeText) {
           return true;
        }
        if (method == MethodName.@ConversationTurnKey) {
           return true;
        }
        if (method == MethodName.@BuildAgentListCards) {
           return true;
        }
        if (method == MethodName.@SelectAgentListCard) {
           return true;
        }
        if (method == MethodName.@Capitalize) {
           return true;
        }
        if (method == MethodName.@RefreshAgentListSelection) {
           return true;
        }
        if (method == MethodName.@CenterOnAgent) {
           return true;
        }
        if (method == MethodName.@SelectedRoleId) {
           return true;
        }
        if (method == MethodName.@SelectedAgentModelTarget) {
           return true;
        }
        if (method == MethodName.@SelectedTargetWasBornHere) {
           return true;
        }
        if (method == MethodName.@PopulateAgentModelTargets) {
           return true;
        }
        if (method == MethodName.@ActiveProviderForSelectedRole) {
           return true;
        }
        if (method == MethodName.@PopulateProviderChoices) {
           return true;
        }
        if (method == MethodName.@SelectProviderChoice) {
           return true;
        }
        if (method == MethodName.@AddProviderChoice) {
           return true;
        }
        if (method == MethodName.@SelectedProviderId) {
           return true;
        }
        if (method == MethodName.@SelectedCredentialChoice) {
           return true;
        }
        if (method == MethodName.@PopulateCredentialChoices) {
           return true;
        }
        if (method == MethodName.@IsModelProvider) {
           return true;
        }
        if (method == MethodName.@PopulateThinkingChoices) {
           return true;
        }
        if (method == MethodName.@SelectedThinking) {
           return true;
        }
        if (method == MethodName.@SelectThinking) {
           return true;
        }
        if (method == MethodName.@RenderProviderConfiguration) {
           return true;
        }
        if (method == MethodName.@SelectedChildModelStatus) {
           return true;
        }
        if (method == MethodName.@RoleDisplayName) {
           return true;
        }
        if (method == MethodName.@ProviderDisplayName) {
           return true;
        }
        if (method == MethodName.@DefaultProviderModel) {
           return true;
        }
        if (method == MethodName.@FieldCaption) {
           return true;
        }
        if (method == MethodName.@BuildAgentModelPanel) {
           return true;
        }
        if (method == MethodName.@OpenAgentModelEditor) {
           return true;
        }
        if (method == MethodName.@BuildAgentModelScroll) {
           return true;
        }
        if (method == MethodName.@FitAgentModelScroll) {
           return true;
        }
        if (method == MethodName.@CloseAgentModelEditor) {
           return true;
        }
        if (method == MethodName.@BuildAgentProfile) {
           return true;
        }
        if (method == MethodName.@AddProfileText) {
           return true;
        }
        if (method == MethodName.@StyleCompactToggle) {
           return true;
        }
        if (method == MethodName.@ReaderHeading) {
           return true;
        }
        if (method == MethodName.@BuildThoughtsReader) {
           return true;
        }
        if (method == MethodName.@OpenThoughtsReader) {
           return true;
        }
        if (method == MethodName.@PlaceReaderPanel) {
           return true;
        }
        if (method == MethodName.@OpenAgentProfile) {
           return true;
        }
        if (method == MethodName.@AgentProfileBack) {
           return true;
        }
        if (method == MethodName.@ToggleRenameRow) {
           return true;
        }
        if (method == MethodName.@UpdateAgentProfileCloseButton) {
           return true;
        }
        if (method == MethodName.@PositionAgentProfile) {
           return true;
        }
        if (method == MethodName.@QueueAgentProfileFit) {
           return true;
        }
        if (method == MethodName.@FitQueuedAgentProfile) {
           return true;
        }
        if (method == MethodName.@FitAgentOverviewScroll) {
           return true;
        }
        if (method == MethodName.@BuildAgentCards) {
           return true;
        }
        if (method == MethodName.@BuildQuickCard) {
           return true;
        }
        if (method == MethodName.@RefreshAgentCardIcons) {
           return true;
        }
        if (method == MethodName.@CenterOnSelectedAgent) {
           return true;
        }
        if (method == MethodName.@Sentence) {
           return true;
        }
        if (method == MethodName.@ThoughtTime) {
           return true;
        }
        if (method == MethodName.@BuildApiKeysPanel) {
           return true;
        }
        if (method == MethodName.@RenderSavedApiKeys) {
           return true;
        }
        if (method == MethodName.@CredentialProviderDisplayName) {
           return true;
        }
        if (method == MethodName.@BuildBuildingCards) {
           return true;
        }
        if (method == MethodName.@SectionRow) {
           return true;
        }
        if (method == MethodName.@SelectBuilding) {
           return true;
        }
        if (method == MethodName.@ClearBuildingSelection) {
           return true;
        }
        if (method == MethodName.@OpenBuildingDetails) {
           return true;
        }
        if (method == MethodName.@BuildingDetailsBack) {
           return true;
        }
        if (method == MethodName.@CenterOnSelectedBuilding) {
           return true;
        }
        if (method == MethodName.@ApplyBuildingReassignment) {
           return true;
        }
        if (method == MethodName.@ConfirmBuildingRemoval) {
           return true;
        }
        if (method == MethodName.@CancelBuildingRemoval) {
           return true;
        }
        if (method == MethodName.@RemoveSelectedBuilding) {
           return true;
        }
        if (method == MethodName.@RecipeName) {
           return true;
        }
        if (method == MethodName.@RecipeIcon) {
           return true;
        }
        if (method == MethodName.@TimeLeft) {
           return true;
        }
        if (method == MethodName.@PeopleInside) {
           return true;
        }
        if (method == MethodName.@Plural) {
           return true;
        }
        if (method == MethodName.@ClearChildren) {
           return true;
        }
        if (method == MethodName.@PositionBuildingDetails) {
           return true;
        }
        if (method == MethodName.@BuildBuildingStorageHistory) {
           return true;
        }
        if (method == MethodName.@BeginCameraMotion) {
           return true;
        }
        if (method == MethodName.@CancelCameraMotion) {
           return true;
        }
        if (method == MethodName.@SetCameraAtImmediately) {
           return true;
        }
        if (method == MethodName.@AdvanceCameraMotion) {
           return true;
        }
        if (method == MethodName.@IsCurrentWorldRequest) {
           return true;
        }
        if (method == MethodName.@ConfiguredServerUrl) {
           return true;
        }
        if (method == MethodName.@_Ready) {
           return true;
        }
        if (method == MethodName.@_ExitTree) {
           return true;
        }
        if (method == MethodName.@BuildDeveloperEdits) {
           return true;
        }
        if (method == MethodName.@ConfigureDeveloperEdit) {
           return true;
        }
        if (method == MethodName.@BuildDeveloperTools) {
           return true;
        }
        if (method == MethodName.@BuildDeveloperAgingOverride) {
           return true;
        }
        if (method == MethodName.@ToggleDeveloperTools) {
           return true;
        }
        if (method == MethodName.@CloseDeveloperTools) {
           return true;
        }
        if (method == MethodName.@PositionDeveloperTools) {
           return true;
        }
        if (method == MethodName.@JumpToDeveloperAgent) {
           return true;
        }
        if (method == MethodName.@RenderDeveloperTile) {
           return true;
        }
        if (method == MethodName.@UpdateDeveloperFrameTime) {
           return true;
        }
        if (method == MethodName.@RenderDeveloperRoute) {
           return true;
        }
        if (method == MethodName.@RenderPlannedPath) {
           return true;
        }
        if (method == MethodName.@StyleConfirmation) {
           return true;
        }
        if (method == MethodName.@SetFullscreen) {
           return true;
        }
        if (method == MethodName.@ApplySavedDisplaySettings) {
           return true;
        }
        if (method == MethodName.@ApplyUiScale) {
           return true;
        }
        if (method == MethodName.@SetUiFactor) {
           return true;
        }
        if (method == MethodName.@ScaleWindows) {
           return true;
        }
        if (method == MethodName.@ScaleMapText) {
           return true;
        }
        if (method == MethodName.@PopupDialog) {
           return true;
        }
        if (method == MethodName.@DialogSize) {
           return true;
        }
        if (method == MethodName.@FitDialog) {
           return true;
        }
        if (method == MethodName.@CurrentMonitorSize) {
           return true;
        }
        if (method == MethodName.@AutomaticRenderSize) {
           return true;
        }
        if (method == MethodName.@RefreshRenderSize) {
           return true;
        }
        if (method == MethodName.@DisplaySizeIndex) {
           return true;
        }
        if (method == MethodName.@SettingsBox) {
           return true;
        }
        if (method == MethodName.@DisplaySettingRow) {
           return true;
        }
        if (method == MethodName.@SetWindowSize) {
           return true;
        }
        if (method == MethodName.@SetCloudHaze) {
           return true;
        }
        if (method == MethodName.@SetLightningFlashes) {
           return true;
        }
        if (method == MethodName.@SetUiTheme) {
           return true;
        }
        if (method == MethodName.@_Notification) {
           return true;
        }
        if (method == MethodName.@ApplyThemeColors) {
           return true;
        }
        if (method == MethodName.@SetClockFormat) {
           return true;
        }
        if (method == MethodName.@DateStyleIndex) {
           return true;
        }
        if (method == MethodName.@SetDateStyle) {
           return true;
        }
        if (method == MethodName.@DisplayWorldClock) {
           return true;
        }
        if (method == MethodName.@RenderEventLog) {
           return true;
        }
        if (method == MethodName.@JumpToEvent) {
           return true;
        }
        if (method == MethodName.@BuildEventRows) {
           return true;
        }
        if (method == MethodName.@AddNewcomerOffer) {
           return true;
        }
        if (method == MethodName.@FillFamilyLegend) {
           return true;
        }
        if (method == MethodName.@BuildFiltersButton) {
           return true;
        }
        if (method == MethodName.@BuildMapFiltersPanel) {
           return true;
        }
        if (method == MethodName.@ToggleMapFilters) {
           return true;
        }
        if (method == MethodName.@ApplyMapFiltersFromCurrentSnapshot) {
           return true;
        }
        if (method == MethodName.@ToggleMoveFounder) {
           return true;
        }
        if (method == MethodName.@ToggleFirstTownSite) {
           return true;
        }
        if (method == MethodName.@CancelFirstTownSiteSelection) {
           return true;
        }
        if (method == MethodName.@BuildFounderSetupPanel) {
           return true;
        }
        if (method == MethodName.@SelectedFounderProvider) {
           return true;
        }
        if (method == MethodName.@SelectedFounderCredential) {
           return true;
        }
        if (method == MethodName.@PopulateFounderCredentials) {
           return true;
        }
        if (method == MethodName.@RenderFounderCredentialInputs) {
           return true;
        }
        if (method == MethodName.@ResetAddAgentPlacementHint) {
           return true;
        }
        if (method == MethodName.@PlacementRefusalText) {
           return true;
        }
        if (method == MethodName.@BuildGenerationSettings) {
           return true;
        }
        if (method == MethodName.@BuildTopBar) {
           return true;
        }
        if (method == MethodName.@HudGroup) {
           return true;
        }
        if (method == MethodName.@AttachCorner) {
           return true;
        }
        if (method == MethodName.@CompactHud) {
           return true;
        }
        if (method == MethodName.@PlaceUnderButton) {
           return true;
        }
        if (method == MethodName.@PlaceHudPanels) {
           return true;
        }
        if (method == MethodName.@HudPanels) {
           return true;
        }
        if (method == MethodName.@RefreshHudIcons) {
           return true;
        }
        if (method == MethodName.@UpdateUnreadEvents) {
           return true;
        }
        if (method == MethodName.@MarkEventsSeen) {
           return true;
        }
        if (method == MethodName.@BuildWorldInfoPanel) {
           return true;
        }
        if (method == MethodName.@ShowWorldInfoPage) {
           return true;
        }
        if (method == MethodName.@ToggleTowns) {
           return true;
        }
        if (method == MethodName.@CivicElectionName) {
           return true;
        }
        if (method == MethodName.@TownListText) {
           return true;
        }
        if (method == MethodName.@CenterOnTown) {
           return true;
        }
        if (method == MethodName.@BuildKeyboardNavigation) {
           return true;
        }
        if (method == MethodName.@ConfigureKeyboardScrollBar) {
           return true;
        }
        if (method == MethodName.@CurrentKeyboardPanel) {
           return true;
        }
        if (method == MethodName.@IsKeyboardFocusable) {
           return true;
        }
        if (method == MethodName.@KeyboardControls) {
           return true;
        }
        if (method == MethodName.@FocusKeyboardPanel) {
           return true;
        }
        if (method == MethodName.@HandleKeyboardNavigationInput) {
           return true;
        }
        if (method == MethodName.@BeginKeyboardMapSelection) {
           return true;
        }
        if (method == MethodName.@KeyboardMapCanvasPoint) {
           return true;
        }
        if (method == MethodName.@RefreshKeyboardMapSelection) {
           return true;
        }
        if (method == MethodName.@CenterKeyboardCameraAt) {
           return true;
        }
        if (method == MethodName.@GameUserPath) {
           return true;
        }
        if (method == MethodName.@BuildQuitToLauncher) {
           return true;
        }
        if (method == MethodName.@TryOpenLauncher) {
           return true;
        }
        if (method == MethodName.@ShowLauncherStartFailure) {
           return true;
        }
        if (method == MethodName.@BuildLayout) {
           return true;
        }
        if (method == MethodName.@ShowSettingsSection) {
           return true;
        }
        if (method == MethodName.@BuildWorldColumn) {
           return true;
        }
        if (method == MethodName.@BuildInspectorColumn) {
           return true;
        }
        if (method == MethodName.@BuildOwnerColumn) {
           return true;
        }
        if (method == MethodName.@BuildStatusToast) {
           return true;
        }
        if (method == MethodName.@EmptyToNull) {
           return true;
        }
        if (method == MethodName.@SetPanelText) {
           return true;
        }
        if (method == MethodName.@ConfigureTextPanel) {
           return true;
        }
        if (method == MethodName.@FitQueuedTextPanels) {
           return true;
        }
        if (method == MethodName.@FitTextPanel) {
           return true;
        }
        if (method == MethodName.@FitFloatingPanelsToContents) {
           return true;
        }
        if (method == MethodName.@FloatingPanel) {
           return true;
        }
        if (method == MethodName.@NewPanel) {
           return true;
        }
        if (method == MethodName.@AddPanelContents) {
           return true;
        }
        if (method == MethodName.@MetricRow) {
           return true;
        }
        if (method == MethodName.@CloseButton) {
           return true;
        }
        if (method == MethodName.@StyleIconButton) {
           return true;
        }
        if (method == MethodName.@StyleMenuChoice) {
           return true;
        }
        if (method == MethodName.@StyleButton) {
           return true;
        }
        if (method == MethodName.@StyleSettingsCategoryButton) {
           return true;
        }
        if (method == MethodName.@SelectSettingsCategory) {
           return true;
        }
        if (method == MethodName.@CompleteLocalServerStartup) {
           return true;
        }
        if (method == MethodName.@QuitGame) {
           return true;
        }
        if (method == MethodName.@QuitToLauncher) {
           return true;
        }
        if (method == MethodName.@ShowLocalServerStopFailure) {
           return true;
        }
        if (method == MethodName.@BuildMainMenu) {
           return true;
        }
        if (method == MethodName.@ShowMainMenu) {
           return true;
        }
        if (method == MethodName.@RefreshMainMenuAvailability) {
           return true;
        }
        if (method == MethodName.@SetMainMenuStatus) {
           return true;
        }
        if (method == MethodName.@FitMainMenuLogo) {
           return true;
        }
        if (method == MethodName.@OpenMainMenuSettings) {
           return true;
        }
        if (method == MethodName.@QuitToMainMenu) {
           return true;
        }
        if (method == MethodName.@SetWorldMenuActionsVisible) {
           return true;
        }
        if (method == MethodName.@BuildWorldMenu) {
           return true;
        }
        if (method == MethodName.@WorldOptionRow) {
           return true;
        }
        if (method == MethodName.@LayoutWorldMenu) {
           return true;
        }
        if (method == MethodName.@OpenWorldMenu) {
           return true;
        }
        if (method == MethodName.@RenderWorldList) {
           return true;
        }
        if (method == MethodName.@SlotIcon) {
           return true;
        }
        if (method == MethodName.@RefreshWorldMenuAvailability) {
           return true;
        }
        if (method == MethodName.@GenerationAmountText) {
           return true;
        }
        if (method == MethodName.@ResetWorldGenerationOptions) {
           return true;
        }
        if (method == MethodName.@InvalidateWorldPreview) {
           return true;
        }
        if (method == MethodName.@Percent) {
           return true;
        }
        if (method == MethodName.@ForestAmount) {
           return true;
        }
        if (method == MethodName.@MountainAmount) {
           return true;
        }
        if (method == MethodName.@RefreshMenuIcons) {
           return true;
        }
        if (method == MethodName.@BuildMapHud) {
           return true;
        }
        if (method == MethodName.@PositionMapHud) {
           return true;
        }
        if (method == MethodName.@CameraAxis) {
           return true;
        }
        if (method == MethodName.@PositiveMod) {
           return true;
        }
        if (method == MethodName.@WrappedMarkerX) {
           return true;
        }
        if (method == MethodName.@RepositionWrappedMapMarkers) {
           return true;
        }
        if (method == MethodName.@RefreshOverviewViewport) {
           return true;
        }
        if (method == MethodName.@CenterCameraAt) {
           return true;
        }
        if (method == MethodName.@PanCamera) {
           return true;
        }
        if (method == MethodName.@HandleMapInput) {
           return true;
        }
        if (method == MethodName.@RefreshTileHoverAtMouse) {
           return true;
        }
        if (method == MethodName.@ClearTileSelection) {
           return true;
        }
        if (method == MethodName.@PositionSelectedTilePanel) {
           return true;
        }
        if (method == MethodName.@UpdateTileHover) {
           return true;
        }
        if (method == MethodName.@OverviewLegend) {
           return true;
        }
        if (method == MethodName.@FilterSwatch) {
           return true;
        }
        if (method == MethodName.@FilterRow) {
           return true;
        }
        if (method == MethodName.@AdvanceMapMarkers) {
           return true;
        }
        if (method == MethodName.@BuildMemoryCards) {
           return true;
        }
        if (method == MethodName.@MemoryAccent) {
           return true;
        }
        if (method == MethodName.@Sureness) {
           return true;
        }
        if (method == MethodName.@MemoryEntry) {
           return true;
        }
        if (method == MethodName.@MetaLine) {
           return true;
        }
        if (method == MethodName.@MetaText) {
           return true;
        }
        if (method == MethodName.@Tag) {
           return true;
        }
        if (method == MethodName.@ShowMemoryCards) {
           return true;
        }
        if (method == MethodName.@FitMemoryCards) {
           return true;
        }
        if (method == MethodName.@MemoryCardsText) {
           return true;
        }
        if (method == MethodName.@RenderUsageStatus) {
           return true;
        }
        if (method == MethodName.@BuildUsageLimitPanel) {
           return true;
        }
        if (method == MethodName.@HasModelList) {
           return true;
        }
        if (method == MethodName.@RequestFounderModels) {
           return true;
        }
        if (method == MethodName.@SyncAgentModelPicker) {
           return true;
        }
        if (method == MethodName.@OnFounderKeyEdited) {
           return true;
        }
        if (method == MethodName.@OnAgentModelKeyEdited) {
           return true;
        }
        if (method == MethodName.@SelectedRoutineHelper) {
           return true;
        }
        if (method == MethodName.@BuildRoutineHelperSettings) {
           return true;
        }
        if (method == MethodName.@RequestRoutineHelperModels) {
           return true;
        }
        if (method == MethodName.@ClearRoutineHelperSetupCheck) {
           return true;
        }
        if (method == MethodName.@SelectedRoutineHelperKey) {
           return true;
        }
        if (method == MethodName.@RefreshRoutineHelperKeys) {
           return true;
        }
        if (method == MethodName.@BuildModLibrary) {
           return true;
        }
        if (method == MethodName.@ShowModLibrary) {
           return true;
        }
        if (method == MethodName.@ModLibraryText) {
           return true;
        }
        if (method == MethodName.@ConfigureOrderLabel) {
           return true;
        }
        if (method == MethodName.@BuildOrdersReader) {
           return true;
        }
        if (method == MethodName.@OpenOrdersReader) {
           return true;
        }
        if (method == MethodName.@OrderItemName) {
           return true;
        }
        if (method == MethodName.@ProgressUnitLabel) {
           return true;
        }
        if (method == MethodName.@OrderBuildingName) {
           return true;
        }
        if (method == MethodName.@InstructionSubmissionResultText) {
           return true;
        }
        if (method == MethodName.@RefreshControlAvailability) {
           return true;
        }
        if (method == MethodName.@RenderPairedDevices) {
           return true;
        }
        if (method == MethodName.@BuildDeveloperDevices) {
           return true;
        }
        if (method == MethodName.@ToggleAgents) {
           return true;
        }
        if (method == MethodName.@ToggleEvents) {
           return true;
        }
        if (method == MethodName.@ToggleWorldInfo) {
           return true;
        }
        if (method == MethodName.@OpenFamilyTree) {
           return true;
        }
        if (method == MethodName.@UpdateFamilyTreeStatus) {
           return true;
        }
        if (method == MethodName.@SelectFromFamilyTree) {
           return true;
        }
        if (method == MethodName.@OpenMemories) {
           return true;
        }
        if (method == MethodName.@ShowPauseMenuPage) {
           return true;
        }
        if (method == MethodName.@ShowPauseMenuButtons) {
           return true;
        }
        if (method == MethodName.@ClosePauseMenu) {
           return true;
        }
        if (method == MethodName.@_UnhandledKeyInput) {
           return true;
        }
        if (method == MethodName.@_Process) {
           return true;
        }
        if (method == MethodName.@PanCameraForFrame) {
           return true;
        }
        if (method == MethodName.@HandleEscape) {
           return true;
        }
        if (method == MethodName.@Keycap) {
           return true;
        }
        if (method == MethodName.@BuildPendingSubmissionRecovery) {
           return true;
        }
        if (method == MethodName.@ReviewPendingSubmission) {
           return true;
        }
        if (method == MethodName.@LoadPendingSubmission) {
           return true;
        }
        if (method == MethodName.@ForgetPendingSubmission) {
           return true;
        }
        if (method == MethodName.@RenderPendingSubmission) {
           return true;
        }
        if (method == MethodName.@SetOwnerRequestBusy) {
           return true;
        }
        if (method == MethodName.@BindOwnerRequestPanels) {
           return true;
        }
        if (method == MethodName.@SetStatus) {
           return true;
        }
        if (method == MethodName.@ExpireStatusToast) {
           return true;
        }
        if (method == MethodName.@ShowHeldState) {
           return true;
        }
        if (method == MethodName.@ResourceGlyph) {
           return true;
        }
        if (method == MethodName.@ObjectMarker) {
           return true;
        }
        if (method == MethodName.@ObjectGlyph) {
           return true;
        }
        if (method == MethodName.@ShortMarker) {
           return true;
        }
        if (method == MethodName.@Pretty) {
           return true;
        }
        if (method == MethodName.@NeedPercent) {
           return true;
        }
        if (method == MethodName.@NewReportProblemButton) {
           return true;
        }
        if (method == MethodName.@ReportProblem) {
           return true;
        }
        if (method == MethodName.@WriteProblemReport) {
           return true;
        }
        if (method == MethodName.@ProblemReportDirectory) {
           return true;
        }
        if (method == MethodName.@PreviousGameLog) {
           return true;
        }
        if (method == MethodName.@SizeText) {
           return true;
        }
        if (method == MethodName.@BuildProfilePeople) {
           return true;
        }
        if (method == MethodName.@ProfilePeopleText) {
           return true;
        }
        if (method == MethodName.@ResetAgentModelSetupCheckForCurrentChoice) {
           return true;
        }
        if (method == MethodName.@ClearFounderModelSetupCheck) {
           return true;
        }
        if (method == MethodName.@ClearAgentModelSetupCheck) {
           return true;
        }
        if (method == MethodName.@VerifyModelSetupCheckControls) {
           return true;
        }
        if (method == MethodName.@BuildRecoveryCleanup) {
           return true;
        }
        if (method == MethodName.@ApplyResponsiveLayout) {
           return true;
        }
        if (method == MethodName.@PositionFamilyTreePanel) {
           return true;
        }
        if (method == MethodName.@PlaceQuickCard) {
           return true;
        }
        if (method == MethodName.@FitMenuScrolls) {
           return true;
        }
        if (method == MethodName.@CardTop) {
           return true;
        }
        if (method == MethodName.@FitHudLists) {
           return true;
        }
        if (method == MethodName.@QueueHudListsFit) {
           return true;
        }
        if (method == MethodName.@ListRoom) {
           return true;
        }
        if (method == MethodName.@BuildSaveDiskWarning) {
           return true;
        }
        if (method == MethodName.@BuildAutosaveSettings) {
           return true;
        }
        if (method == MethodName.@IsCurrentAutosaveSettingsContext) {
           return true;
        }
        if (method == MethodName.@CancelAutosaveSettingsRead) {
           return true;
        }
        if (method == MethodName.@BuildManualSavesPanel) {
           return true;
        }
        if (method == MethodName.@BuildManualSaveTimeline) {
           return true;
        }
        if (method == MethodName.@ApplyManualSaveView) {
           return true;
        }
        if (method == MethodName.@FitManualSaveList) {
           return true;
        }
        if (method == MethodName.@ManualSaveTimelineWidth) {
           return true;
        }
        if (method == MethodName.@ManualSaveCardFrame) {
           return true;
        }
        if (method == MethodName.@FitManualSaveTimeline) {
           return true;
        }
        if (method == MethodName.@ChooseTimelineSave) {
           return true;
        }
        if (method == MethodName.@RenderManualSaveDetails) {
           return true;
        }
        if (method == MethodName.@TimelineReadout) {
           return true;
        }
        if (method == MethodName.@ClearWorldSaveHistory) {
           return true;
        }
        if (method == MethodName.@CancelManualSaveListRead) {
           return true;
        }
        if (method == MethodName.@RefreshManualSaveAvailability) {
           return true;
        }
        if (method == MethodName.@CurrentManualSaveWorldId) {
           return true;
        }
        if (method == MethodName.@ShowManualSavePanel) {
           return true;
        }
        if (method == MethodName.@RenderManualSaveTimeline) {
           return true;
        }
        if (method == MethodName.@RenderManualSaveList) {
           return true;
        }
        if (method == MethodName.@ShortBranchTag) {
           return true;
        }
        if (method == MethodName.@ConfirmManualSaveOverwrite) {
           return true;
        }
        if (method == MethodName.@DisplaySaveClock) {
           return true;
        }
        if (method == MethodName.@ConfirmManualSaveLoad) {
           return true;
        }
        if (method == MethodName.@ConfirmSaveDeletion) {
           return true;
        }
        if (method == MethodName.@ConfirmWorldDeletion) {
           return true;
        }
        if (method == MethodName.@SelectAgentFromList) {
           return true;
        }
        if (method == MethodName.@SelectAgent) {
           return true;
        }
        if (method == MethodName.@ClearAgentSelection) {
           return true;
        }
        if (method == MethodName.@BuildControlsPanel) {
           return true;
        }
        if (method == MethodName.@PositionControlsPanel) {
           return true;
        }
        if (method == MethodName.@ToggleControlsPanel) {
           return true;
        }
        if (method == MethodName.@WorldKeysAvailable) {
           return true;
        }
        if (method == MethodName.@NoMenuOverWorld) {
           return true;
        }
        if (method == MethodName.@_Input) {
           return true;
        }
        if (method == MethodName.@HandleShortcutKey) {
           return true;
        }
        if (method == MethodName.@PressTopBarAction) {
           return true;
        }
        if (method == MethodName.@CycleSelectedAgent) {
           return true;
        }
        if (method == MethodName.@CenterOnHome) {
           return true;
        }
        if (method == MethodName.@ZoomAt) {
           return true;
        }
        if (method == MethodName.@BuildControlsGroups) {
           return true;
        }
        if (method == MethodName.@FillControlsGroups) {
           return true;
        }
        if (method == MethodName.@BuildStartupRecovery) {
           return true;
        }
        if (method == MethodName.@BuildTileCard) {
           return true;
        }
        if (method == MethodName.@HeightWords) {
           return true;
        }
        if (method == MethodName.@AddTileFact) {
           return true;
        }
        if (method == MethodName.@AddTileThing) {
           return true;
        }
        if (method == MethodName.@TileCardText) {
           return true;
        }
        if (method == MethodName.@BuildDeveloperWorldEdit) {
           return true;
        }
        if (method == MethodName.@ConfigureWorldEditPicker) {
           return true;
        }
        if (method == MethodName.@ClearWorldEditPreview) {
           return true;
        }
        if (method == MethodName.@UpdateWorldEditPreview) {
           return true;
        }
        if (method == MethodName.@AddWorldEditKinds) {
           return true;
        }
        if (method == MethodName.@AddWorldEditKind) {
           return true;
        }
        if (method == MethodName.@UpdateWorldEditHint) {
           return true;
        }
        if (method == MethodName.@ConfigureCoordinate) {
           return true;
        }
        if (method == MethodName.@SelectedWorldEditKind) {
           return true;
        }
        if (method == MethodName.@BuildWorldInfoPages) {
           return true;
        }
        if (method == MethodName.@StatTile) {
           return true;
        }
        if (method == MethodName.@PageText) {
           return true;
        }
        if (method == MethodName.@ResetDisplayedWorldContext) {
           return true;
        }
        if (method == MethodName.@MapObjectLabelFits) {
           return true;
        }
        return base.HasGodotClassMethod(method);
    }
}

}
