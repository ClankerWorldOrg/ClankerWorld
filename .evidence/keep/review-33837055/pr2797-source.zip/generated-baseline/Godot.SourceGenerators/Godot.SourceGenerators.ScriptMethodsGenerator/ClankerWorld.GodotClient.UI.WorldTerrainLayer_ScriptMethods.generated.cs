﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class WorldTerrainLayer
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the methods contained in this class, for fast lookup.
    /// </summary>
    public new class MethodName : global::Godot.Control.MethodName {
        /// <summary>
        /// Cached name for the 'SetAutumnLeaves' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetAutumnLeaves = "SetAutumnLeaves";
        /// <summary>
        /// Cached name for the 'AutumnLeafGround' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AutumnLeafGround = "AutumnLeafGround";
        /// <summary>
        /// Cached name for the 'SetSeason' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetSeason = "SetSeason";
        /// <summary>
        /// Cached name for the 'GuidanceColor' method.
        /// </summary>
        public new static readonly global::Godot.StringName @GuidanceColor = "GuidanceColor";
        /// <summary>
        /// Cached name for the 'BridgeNeglectAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BridgeNeglectAt = "BridgeNeglectAt";
        /// <summary>
        /// Cached name for the 'ConstructionStageAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ConstructionStageAt = "ConstructionStageAt";
        /// <summary>
        /// Cached name for the 'NeglectAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @NeglectAt = "NeglectAt";
        /// <summary>
        /// Cached name for the 'WeatherAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @WeatherAt = "WeatherAt";
        /// <summary>
        /// Cached name for the 'SetCamera' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetCamera = "SetCamera";
        /// <summary>
        /// Cached name for the 'TreeStageAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TreeStageAt = "TreeStageAt";
        /// <summary>
        /// Cached name for the 'NaturalObjectNameAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @NaturalObjectNameAt = "NaturalObjectNameAt";
        /// <summary>
        /// Cached name for the 'NaturalObjectStageAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @NaturalObjectStageAt = "NaturalObjectStageAt";
        /// <summary>
        /// Cached name for the '_Draw' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Draw = "_Draw";
        /// <summary>
        /// Cached name for the 'DrawMapContents' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawMapContents = "DrawMapContents";
        /// <summary>
        /// Cached name for the 'DrawCoast' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawCoast = "DrawCoast";
        /// <summary>
        /// Cached name for the 'DrawNaturalObject' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawNaturalObject = "DrawNaturalObject";
        /// <summary>
        /// Cached name for the 'DrawLeaf' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawLeaf = "DrawLeaf";
        /// <summary>
        /// Cached name for the 'Mod' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Mod = "Mod";
        /// <summary>
        /// Cached name for the 'HouseholdColorIndex' method.
        /// </summary>
        public new static readonly global::Godot.StringName @HouseholdColorIndex = "HouseholdColorIndex";
        /// <summary>
        /// Cached name for the 'RoadLinksAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RoadLinksAt = "RoadLinksAt";
        /// <summary>
        /// Cached name for the 'IsRoad' method.
        /// </summary>
        public new static readonly global::Godot.StringName @IsRoad = "IsRoad";
        /// <summary>
        /// Cached name for the 'IsDeck' method.
        /// </summary>
        public new static readonly global::Godot.StringName @IsDeck = "IsDeck";
        /// <summary>
        /// Cached name for the 'DrawResourceKindSprite' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawResourceKindSprite = "DrawResourceKindSprite";
        /// <summary>
        /// Cached name for the 'DrawNatureSprite' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawNatureSprite = "DrawNatureSprite";
        /// <summary>
        /// Cached name for the 'DrawsAsYoungOrchard' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawsAsYoungOrchard = "DrawsAsYoungOrchard";
        /// <summary>
        /// Cached name for the 'DrawTree' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawTree = "DrawTree";
        /// <summary>
        /// Cached name for the 'ResetGroundSnow' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ResetGroundSnow = "ResetGroundSnow";
        /// <summary>
        /// Cached name for the 'GroundSnowAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @GroundSnowAt = "GroundSnowAt";
        /// <summary>
        /// Cached name for the 'SnowCoverAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SnowCoverAt = "SnowCoverAt";
        /// <summary>
        /// Cached name for the 'CanSnowAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CanSnowAt = "CanSnowAt";
        /// <summary>
        /// Cached name for the 'AddSnowFootprints' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddSnowFootprints = "AddSnowFootprints";
        /// <summary>
        /// Cached name for the '_Ready' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Ready = "_Ready";
        /// <summary>
        /// Cached name for the '_Process' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Process = "_Process";
        /// <summary>
        /// Cached name for the 'ResetRelief' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ResetRelief = "ResetRelief";
        /// <summary>
        /// Cached name for the 'BeginReliefDraw' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BeginReliefDraw = "BeginReliefDraw";
        /// <summary>
        /// Cached name for the 'ReliefCovers' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ReliefCovers = "ReliefCovers";
        /// <summary>
        /// Cached name for the 'TrimRelief' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TrimRelief = "TrimRelief";
        /// <summary>
        /// Cached name for the 'ResetResourceAppearanceInputs' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ResetResourceAppearanceInputs = "ResetResourceAppearanceInputs";
    }
    /// <summary>
    /// Get the method information for all the methods declared in this class.
    /// This method is used by Godot to register the available methods in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotMethodList()
    {
        var methods = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(38);
        methods.Add(new(name: MethodName.@SetAutumnLeaves, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "season", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AutumnLeafGround, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "pixel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "stride", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetSeason, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "observed", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@GuidanceColor, returnVal: new(type: (global::Godot.Variant.Type)20, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "strength", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BridgeNeglectAt, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)6, name: "tile", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ConstructionStageAt, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)6, name: "tile", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@NeglectAt, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)6, name: "tile", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@WeatherAt, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetCamera, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)7, name: "visible", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "gap", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "wrap", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@TreeStageAt, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@NaturalObjectNameAt, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@NaturalObjectStageAt, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Draw, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawMapContents, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawCoast, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "coasts", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Texture2D")), new(type: (global::Godot.Variant.Type)7, name: "tile", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "style", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "atlasSize", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawNaturalObject, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "position", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "kind", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "stage", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawLeaf, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "center", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "radius", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "color", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Mod, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "modulus", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@HouseholdColorIndex, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "householdId", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@RoadLinksAt, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@IsRoad, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@IsDeck, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "eastWest", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawResourceKindSprite, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "position", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "sprite", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawNatureSprite, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "position", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "sprite", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawsAsYoungOrchard, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "tree", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawTree, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "position", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "tree", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ResetGroundSnow, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@GroundSnowAt, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SnowCoverAt, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CanSnowAt, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddSnowFootprints, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)6, name: "from", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)6, name: "to", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "tick", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Ready, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Process, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "delta", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ResetRelief, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BeginReliefDraw, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ReliefCovers, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "mapX", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "atlasSize", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@TrimRelief, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ResetResourceAppearanceInputs, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        return methods;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool InvokeGodotClassMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@SetAutumnLeaves && args.Count == 1) {
            @SetAutumnLeaves(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@AutumnLeafGround && args.Count == 2) {
            var callRet = @AutumnLeafGround(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@SetSeason && args.Count == 1) {
            @SetSeason(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@GuidanceColor && args.Count == 1) {
            var callRet = @GuidanceColor(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@BridgeNeglectAt && args.Count == 1) {
            var callRet = @BridgeNeglectAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.BuildingNeglect>(callRet);
            return true;
        }
        if (method == MethodName.@ConstructionStageAt && args.Count == 1) {
            var callRet = @ConstructionStageAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@NeglectAt && args.Count == 1) {
            var callRet = @NeglectAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.BuildingNeglect>(callRet);
            return true;
        }
        if (method == MethodName.@WeatherAt && args.Count == 2) {
            var callRet = @WeatherAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@SetCamera && args.Count == 4) {
            @SetCamera(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[3]));
            ret = default;
            return true;
        }
        if (method == MethodName.@TreeStageAt && args.Count == 2) {
            var callRet = @TreeStageAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@NaturalObjectNameAt && args.Count == 2) {
            var callRet = @NaturalObjectNameAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@NaturalObjectStageAt && args.Count == 2) {
            var callRet = @NaturalObjectStageAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@_Draw && args.Count == 0) {
            @_Draw();
            ret = default;
            return true;
        }
        if (method == MethodName.@DrawMapContents && args.Count == 0) {
            @DrawMapContents();
            ret = default;
            return true;
        }
        if (method == MethodName.@DrawCoast && args.Count == 6) {
            @DrawCoast(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Texture2D>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Rect2>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[3]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.TerrainStyle>(args[4]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[5]));
            ret = default;
            return true;
        }
        if (method == MethodName.@DrawNaturalObject && args.Count == 3) {
            @DrawNaturalObject(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@DrawLeaf && args.Count == 3) {
            @DrawLeaf(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Mod && args.Count == 2) {
            var callRet = @Mod(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@HouseholdColorIndex && args.Count == 1) {
            var callRet = @HouseholdColorIndex(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@RoadLinksAt && args.Count == 2) {
            var callRet = @RoadLinksAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::ClankerWorld.GodotClient.UI.RoadLinks>(callRet);
            return true;
        }
        if (method == MethodName.@IsRoad && args.Count == 2) {
            var callRet = @IsRoad(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@IsDeck && args.Count == 3) {
            var callRet = @IsDeck(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@DrawResourceKindSprite && args.Count == 2) {
            @DrawResourceKindSprite(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.NatureSprite>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@DrawNatureSprite && args.Count == 2) {
            @DrawNatureSprite(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.NatureSprite>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@DrawsAsYoungOrchard && args.Count == 1) {
            var callRet = @DrawsAsYoungOrchard(global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@DrawTree && args.Count == 2) {
            @DrawTree(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ResetGroundSnow && args.Count == 0) {
            @ResetGroundSnow();
            ret = default;
            return true;
        }
        if (method == MethodName.@GroundSnowAt && args.Count == 2) {
            var callRet = @GroundSnowAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@SnowCoverAt && args.Count == 2) {
            var callRet = @SnowCoverAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@CanSnowAt && args.Count == 2) {
            var callRet = @CanSnowAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@AddSnowFootprints && args.Count == 3) {
            @AddSnowFootprints(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2I>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@_Ready && args.Count == 0) {
            @_Ready();
            ret = default;
            return true;
        }
        if (method == MethodName.@_Process && args.Count == 1) {
            @_Process(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ResetRelief && args.Count == 0) {
            @ResetRelief();
            ret = default;
            return true;
        }
        if (method == MethodName.@BeginReliefDraw && args.Count == 0) {
            @BeginReliefDraw();
            ret = default;
            return true;
        }
        if (method == MethodName.@ReliefCovers && args.Count == 3) {
            var callRet = @ReliefCovers(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@TrimRelief && args.Count == 0) {
            @TrimRelief();
            ret = default;
            return true;
        }
        if (method == MethodName.@ResetResourceAppearanceInputs && args.Count == 0) {
            @ResetResourceAppearanceInputs();
            ret = default;
            return true;
        }
        return base.InvokeGodotClassMethod(method, args, out ret);
    }
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static bool InvokeGodotClassStaticMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@GuidanceColor && args.Count == 1) {
            var callRet = @GuidanceColor(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@Mod && args.Count == 2) {
            var callRet = @Mod(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@HouseholdColorIndex && args.Count == 1) {
            var callRet = @HouseholdColorIndex(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@DrawsAsYoungOrchard && args.Count == 1) {
            var callRet = @DrawsAsYoungOrchard(global::Godot.NativeInterop.VariantUtils.ConvertTo<byte>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        ret = default;
        return false;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassMethod(in godot_string_name method)
    {
        if (method == MethodName.@SetAutumnLeaves) {
           return true;
        }
        if (method == MethodName.@AutumnLeafGround) {
           return true;
        }
        if (method == MethodName.@SetSeason) {
           return true;
        }
        if (method == MethodName.@GuidanceColor) {
           return true;
        }
        if (method == MethodName.@BridgeNeglectAt) {
           return true;
        }
        if (method == MethodName.@ConstructionStageAt) {
           return true;
        }
        if (method == MethodName.@NeglectAt) {
           return true;
        }
        if (method == MethodName.@WeatherAt) {
           return true;
        }
        if (method == MethodName.@SetCamera) {
           return true;
        }
        if (method == MethodName.@TreeStageAt) {
           return true;
        }
        if (method == MethodName.@NaturalObjectNameAt) {
           return true;
        }
        if (method == MethodName.@NaturalObjectStageAt) {
           return true;
        }
        if (method == MethodName.@_Draw) {
           return true;
        }
        if (method == MethodName.@DrawMapContents) {
           return true;
        }
        if (method == MethodName.@DrawCoast) {
           return true;
        }
        if (method == MethodName.@DrawNaturalObject) {
           return true;
        }
        if (method == MethodName.@DrawLeaf) {
           return true;
        }
        if (method == MethodName.@Mod) {
           return true;
        }
        if (method == MethodName.@HouseholdColorIndex) {
           return true;
        }
        if (method == MethodName.@RoadLinksAt) {
           return true;
        }
        if (method == MethodName.@IsRoad) {
           return true;
        }
        if (method == MethodName.@IsDeck) {
           return true;
        }
        if (method == MethodName.@DrawResourceKindSprite) {
           return true;
        }
        if (method == MethodName.@DrawNatureSprite) {
           return true;
        }
        if (method == MethodName.@DrawsAsYoungOrchard) {
           return true;
        }
        if (method == MethodName.@DrawTree) {
           return true;
        }
        if (method == MethodName.@ResetGroundSnow) {
           return true;
        }
        if (method == MethodName.@GroundSnowAt) {
           return true;
        }
        if (method == MethodName.@SnowCoverAt) {
           return true;
        }
        if (method == MethodName.@CanSnowAt) {
           return true;
        }
        if (method == MethodName.@AddSnowFootprints) {
           return true;
        }
        if (method == MethodName.@_Ready) {
           return true;
        }
        if (method == MethodName.@_Process) {
           return true;
        }
        if (method == MethodName.@ResetRelief) {
           return true;
        }
        if (method == MethodName.@BeginReliefDraw) {
           return true;
        }
        if (method == MethodName.@ReliefCovers) {
           return true;
        }
        if (method == MethodName.@TrimRelief) {
           return true;
        }
        if (method == MethodName.@ResetResourceAppearanceInputs) {
           return true;
        }
        return base.HasGodotClassMethod(method);
    }
}

}
