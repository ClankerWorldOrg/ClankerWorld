﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class WeatherLayer
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the methods contained in this class, for fast lookup.
    /// </summary>
    public new class MethodName : global::Godot.Control.MethodName {
        /// <summary>
        /// Cached name for the 'WeatherAmounts' method.
        /// </summary>
        public new static readonly global::Godot.StringName @WeatherAmounts = "WeatherAmounts";
        /// <summary>
        /// Cached name for the 'UpdateRegions' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdateRegions = "UpdateRegions";
        /// <summary>
        /// Cached name for the 'CoverageAt' method.
        /// </summary>
        public new static readonly global::Godot.StringName @CoverageAt = "CoverageAt";
        /// <summary>
        /// Cached name for the 'Follow' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Follow = "Follow";
        /// <summary>
        /// Cached name for the '_Process' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Process = "_Process";
        /// <summary>
        /// Cached name for the '_Draw' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Draw = "_Draw";
        /// <summary>
        /// Cached name for the 'MapRect' method.
        /// </summary>
        public new static readonly global::Godot.StringName @MapRect = "MapRect";
        /// <summary>
        /// Cached name for the 'FieldCoversCamera' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FieldCoversCamera = "FieldCoversCamera";
        /// <summary>
        /// Cached name for the 'RebuildField' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RebuildField = "RebuildField";
        /// <summary>
        /// Cached name for the 'PaintWashes' method.
        /// </summary>
        public new static readonly global::Godot.StringName @PaintWashes = "PaintWashes";
        /// <summary>
        /// Cached name for the 'DrawPrecipitation' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawPrecipitation = "DrawPrecipitation";
        /// <summary>
        /// Cached name for the 'ParticleTexture' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ParticleTexture = "ParticleTexture";
        /// <summary>
        /// Cached name for the 'LightningFlash' method.
        /// </summary>
        public new static readonly global::Godot.StringName @LightningFlash = "LightningFlash";
        /// <summary>
        /// Cached name for the 'DrawClouds' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawClouds = "DrawClouds";
        /// <summary>
        /// Cached name for the 'TargetCloudiness' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TargetCloudiness = "TargetCloudiness";
        /// <summary>
        /// Cached name for the 'BuildCloudTexture' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildCloudTexture = "BuildCloudTexture";
        /// <summary>
        /// Cached name for the 'Blur' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Blur = "Blur";
        /// <summary>
        /// Cached name for the 'AlignDown' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AlignDown = "AlignDown";
        /// <summary>
        /// Cached name for the 'SmoothStep' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SmoothStep = "SmoothStep";
    }
    /// <summary>
    /// Get the method information for all the methods declared in this class.
    /// This method is used by Godot to register the available methods in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotMethodList()
    {
        var methods = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(19);
        methods.Add(new(name: MethodName.@WeatherAmounts, returnVal: new(type: (global::Godot.Variant.Type)20, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "weather", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdateRegions, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "now", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@CoverageAt, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "x", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "weather", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Follow, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "terrain", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Process, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "delta", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Draw, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@MapRect, returnVal: new(type: (global::Godot.Variant.Type)7, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "stride", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@FieldCoversCamera, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RebuildField, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "now", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@PaintWashes, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawPrecipitation, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "time", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "stride", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ParticleTexture, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("CanvasTexture")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "shape", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@LightningFlash, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "time", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawClouds, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "time", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "stride", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@TargetCloudiness, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildCloudTexture, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("ImageTexture")), flags: (global::Godot.MethodFlags)33, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@Blur, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)32, name: "field", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "radius", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AlignDown, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)2, name: "step", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SmoothStep, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "from", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "to", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        return methods;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool InvokeGodotClassMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@WeatherAmounts && args.Count == 1) {
            var callRet = @WeatherAmounts(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@UpdateRegions && args.Count == 1) {
            @UpdateRegions(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@CoverageAt && args.Count == 3) {
            var callRet = @CoverageAt(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@Follow && args.Count == 1) {
            @Follow(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.WorldTerrainLayer>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@_Process && args.Count == 1) {
            @_Process(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@_Draw && args.Count == 0) {
            @_Draw();
            ret = default;
            return true;
        }
        if (method == MethodName.@MapRect && args.Count == 1) {
            var callRet = @MapRect(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(callRet);
            return true;
        }
        if (method == MethodName.@FieldCoversCamera && args.Count == 0) {
            var callRet = @FieldCoversCamera();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@RebuildField && args.Count == 1) {
            @RebuildField(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@PaintWashes && args.Count == 0) {
            @PaintWashes();
            ret = default;
            return true;
        }
        if (method == MethodName.@DrawPrecipitation && args.Count == 2) {
            @DrawPrecipitation(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ParticleTexture && args.Count == 1) {
            var callRet = @ParticleTexture(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.WeatherStreakShape>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CanvasTexture>(callRet);
            return true;
        }
        if (method == MethodName.@LightningFlash && args.Count == 1) {
            var callRet = @LightningFlash(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@DrawClouds && args.Count == 2) {
            @DrawClouds(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@TargetCloudiness && args.Count == 0) {
            var callRet = @TargetCloudiness();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@BuildCloudTexture && args.Count == 0) {
            var callRet = @BuildCloudTexture();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ImageTexture>(callRet);
            return true;
        }
        if (method == MethodName.@Blur && args.Count == 2) {
            @Blur(global::Godot.NativeInterop.VariantUtils.ConvertTo<float[]>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@AlignDown && args.Count == 2) {
            var callRet = @AlignDown(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@SmoothStep && args.Count == 3) {
            var callRet = @SmoothStep(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        return base.InvokeGodotClassMethod(method, args, out ret);
    }
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static bool InvokeGodotClassStaticMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@WeatherAmounts && args.Count == 1) {
            var callRet = @WeatherAmounts(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Color>(callRet);
            return true;
        }
        if (method == MethodName.@ParticleTexture && args.Count == 1) {
            var callRet = @ParticleTexture(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::ClankerWorld.GodotClient.UI.WeatherStreakShape>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.CanvasTexture>(callRet);
            return true;
        }
        if (method == MethodName.@LightningFlash && args.Count == 1) {
            var callRet = @LightningFlash(global::Godot.NativeInterop.VariantUtils.ConvertTo<double>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@BuildCloudTexture && args.Count == 0) {
            var callRet = @BuildCloudTexture();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.ImageTexture>(callRet);
            return true;
        }
        if (method == MethodName.@AlignDown && args.Count == 2) {
            var callRet = @AlignDown(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@SmoothStep && args.Count == 3) {
            var callRet = @SmoothStep(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        ret = default;
        return false;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassMethod(in godot_string_name method)
    {
        if (method == MethodName.@WeatherAmounts) {
           return true;
        }
        if (method == MethodName.@UpdateRegions) {
           return true;
        }
        if (method == MethodName.@CoverageAt) {
           return true;
        }
        if (method == MethodName.@Follow) {
           return true;
        }
        if (method == MethodName.@_Process) {
           return true;
        }
        if (method == MethodName.@_Draw) {
           return true;
        }
        if (method == MethodName.@MapRect) {
           return true;
        }
        if (method == MethodName.@FieldCoversCamera) {
           return true;
        }
        if (method == MethodName.@RebuildField) {
           return true;
        }
        if (method == MethodName.@PaintWashes) {
           return true;
        }
        if (method == MethodName.@DrawPrecipitation) {
           return true;
        }
        if (method == MethodName.@ParticleTexture) {
           return true;
        }
        if (method == MethodName.@LightningFlash) {
           return true;
        }
        if (method == MethodName.@DrawClouds) {
           return true;
        }
        if (method == MethodName.@TargetCloudiness) {
           return true;
        }
        if (method == MethodName.@BuildCloudTexture) {
           return true;
        }
        if (method == MethodName.@Blur) {
           return true;
        }
        if (method == MethodName.@AlignDown) {
           return true;
        }
        if (method == MethodName.@SmoothStep) {
           return true;
        }
        return base.HasGodotClassMethod(method);
    }
}

}
