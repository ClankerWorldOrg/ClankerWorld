﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.Launcher {

partial class Launcher
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the methods contained in this class, for fast lookup.
    /// </summary>
    public new class MethodName : global::Godot.Control.MethodName {
        /// <summary>
        /// Cached name for the '_Ready' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Ready = "_Ready";
        /// <summary>
        /// Cached name for the '_ExitTree' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_ExitTree = "_ExitTree";
        /// <summary>
        /// Cached name for the 'Build' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Build = "Build";
        /// <summary>
        /// Cached name for the 'BuildPlayPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildPlayPage = "BuildPlayPage";
        /// <summary>
        /// Cached name for the 'BuildVersionsPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildVersionsPage = "BuildVersionsPage";
        /// <summary>
        /// Cached name for the 'BuildSettingsPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildSettingsPage = "BuildSettingsPage";
        /// <summary>
        /// Cached name for the 'UpdateDeveloperHint' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdateDeveloperHint = "UpdateDeveloperHint";
        /// <summary>
        /// Cached name for the 'ChooseLocalBuild' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ChooseLocalBuild = "ChooseLocalBuild";
        /// <summary>
        /// Cached name for the 'SectionLabel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SectionLabel = "SectionLabel";
        /// <summary>
        /// Cached name for the 'StyleButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @StyleButton = "StyleButton";
        /// <summary>
        /// Cached name for the 'ShowPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowPage = "ShowPage";
        /// <summary>
        /// Cached name for the 'ShowLauncherUpdate' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowLauncherUpdate = "ShowLauncherUpdate";
        /// <summary>
        /// Cached name for the 'RefreshInstalled' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshInstalled = "RefreshInstalled";
        /// <summary>
        /// Cached name for the 'UpdatePlayButton' method.
        /// </summary>
        public new static readonly global::Godot.StringName @UpdatePlayButton = "UpdatePlayButton";
        /// <summary>
        /// Cached name for the 'RebuildVersionRows' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RebuildVersionRows = "RebuildVersionRows";
        /// <summary>
        /// Cached name for the 'SetBusy' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetBusy = "SetBusy";
        /// <summary>
        /// Cached name for the 'SetStatus' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetStatus = "SetStatus";
        /// <summary>
        /// Cached name for the 'SaveSettings' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SaveSettings = "SaveSettings";
        /// <summary>
        /// Cached name for the 'FormatSize' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FormatSize = "FormatSize";
        /// <summary>
        /// Cached name for the 'BuildHostPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildHostPage = "BuildHostPage";
        /// <summary>
        /// Cached name for the 'OpenHostPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenHostPage = "OpenHostPage";
        /// <summary>
        /// Cached name for the 'RefreshHostControls' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshHostControls = "RefreshHostControls";
        /// <summary>
        /// Cached name for the 'ClearHostRequests' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ClearHostRequests = "ClearHostRequests";
        /// <summary>
        /// Cached name for the 'BuildJoinPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BuildJoinPage = "BuildJoinPage";
        /// <summary>
        /// Cached name for the 'EnsureJoinSession' method.
        /// </summary>
        public new static readonly global::Godot.StringName @EnsureJoinSession = "EnsureJoinSession";
        /// <summary>
        /// Cached name for the 'OpenJoinPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OpenJoinPage = "OpenJoinPage";
        /// <summary>
        /// Cached name for the 'RefreshJoinPage' method.
        /// </summary>
        public new static readonly global::Godot.StringName @RefreshJoinPage = "RefreshJoinPage";
    }
    /// <summary>
    /// Get the method information for all the methods declared in this class.
    /// This method is used by Godot to register the available methods in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotMethodList()
    {
        var methods = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(27);
        methods.Add(new(name: MethodName.@_Ready, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@_ExitTree, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@Build, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildPlayPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildVersionsPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildSettingsPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdateDeveloperHint, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ChooseLocalBuild, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SectionLabel, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Label")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@StyleButton, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "button", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Button")), new(type: (global::Godot.Variant.Type)1, name: "primary", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "page", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Control")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowLauncherUpdate, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshInstalled, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@UpdatePlayButton, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RebuildVersionRows, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetBusy, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "value", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetStatus, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SaveSettings, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FormatSize, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "bytes", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildHostPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenHostPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshHostControls, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ClearHostRequests, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@BuildJoinPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@EnsureJoinSession, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OpenJoinPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@RefreshJoinPage, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        return methods;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool InvokeGodotClassMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@_Ready && args.Count == 0) {
            @_Ready();
            ret = default;
            return true;
        }
        if (method == MethodName.@_ExitTree && args.Count == 0) {
            @_ExitTree();
            ret = default;
            return true;
        }
        if (method == MethodName.@Build && args.Count == 0) {
            @Build();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildPlayPage && args.Count == 0) {
            @BuildPlayPage();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildVersionsPage && args.Count == 0) {
            @BuildVersionsPage();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildSettingsPage && args.Count == 0) {
            @BuildSettingsPage();
            ret = default;
            return true;
        }
        if (method == MethodName.@UpdateDeveloperHint && args.Count == 0) {
            @UpdateDeveloperHint();
            ret = default;
            return true;
        }
        if (method == MethodName.@ChooseLocalBuild && args.Count == 0) {
            @ChooseLocalBuild();
            ret = default;
            return true;
        }
        if (method == MethodName.@SectionLabel && args.Count == 1) {
            var callRet = @SectionLabel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(callRet);
            return true;
        }
        if (method == MethodName.@StyleButton && args.Count == 2) {
            @StyleButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowPage && args.Count == 1) {
            @ShowPage(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Control>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowLauncherUpdate && args.Count == 0) {
            @ShowLauncherUpdate();
            ret = default;
            return true;
        }
        if (method == MethodName.@RefreshInstalled && args.Count == 0) {
            @RefreshInstalled();
            ret = default;
            return true;
        }
        if (method == MethodName.@UpdatePlayButton && args.Count == 0) {
            @UpdatePlayButton();
            ret = default;
            return true;
        }
        if (method == MethodName.@RebuildVersionRows && args.Count == 0) {
            @RebuildVersionRows();
            ret = default;
            return true;
        }
        if (method == MethodName.@SetBusy && args.Count == 1) {
            @SetBusy(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SetStatus && args.Count == 1) {
            @SetStatus(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SaveSettings && args.Count == 0) {
            @SaveSettings();
            ret = default;
            return true;
        }
        if (method == MethodName.@FormatSize && args.Count == 1) {
            var callRet = @FormatSize(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@BuildHostPage && args.Count == 0) {
            @BuildHostPage();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenHostPage && args.Count == 0) {
            @OpenHostPage();
            ret = default;
            return true;
        }
        if (method == MethodName.@RefreshHostControls && args.Count == 0) {
            @RefreshHostControls();
            ret = default;
            return true;
        }
        if (method == MethodName.@ClearHostRequests && args.Count == 0) {
            @ClearHostRequests();
            ret = default;
            return true;
        }
        if (method == MethodName.@BuildJoinPage && args.Count == 0) {
            @BuildJoinPage();
            ret = default;
            return true;
        }
        if (method == MethodName.@EnsureJoinSession && args.Count == 0) {
            @EnsureJoinSession();
            ret = default;
            return true;
        }
        if (method == MethodName.@OpenJoinPage && args.Count == 0) {
            @OpenJoinPage();
            ret = default;
            return true;
        }
        if (method == MethodName.@RefreshJoinPage && args.Count == 0) {
            @RefreshJoinPage();
            ret = default;
            return true;
        }
        return base.InvokeGodotClassMethod(method, args, out ret);
    }
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static bool InvokeGodotClassStaticMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@SectionLabel && args.Count == 1) {
            var callRet = @SectionLabel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Label>(callRet);
            return true;
        }
        if (method == MethodName.@StyleButton && args.Count == 2) {
            @StyleButton(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Button>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@FormatSize && args.Count == 1) {
            var callRet = @FormatSize(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        ret = default;
        return false;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassMethod(in godot_string_name method)
    {
        if (method == MethodName.@_Ready) {
           return true;
        }
        if (method == MethodName.@_ExitTree) {
           return true;
        }
        if (method == MethodName.@Build) {
           return true;
        }
        if (method == MethodName.@BuildPlayPage) {
           return true;
        }
        if (method == MethodName.@BuildVersionsPage) {
           return true;
        }
        if (method == MethodName.@BuildSettingsPage) {
           return true;
        }
        if (method == MethodName.@UpdateDeveloperHint) {
           return true;
        }
        if (method == MethodName.@ChooseLocalBuild) {
           return true;
        }
        if (method == MethodName.@SectionLabel) {
           return true;
        }
        if (method == MethodName.@StyleButton) {
           return true;
        }
        if (method == MethodName.@ShowPage) {
           return true;
        }
        if (method == MethodName.@ShowLauncherUpdate) {
           return true;
        }
        if (method == MethodName.@RefreshInstalled) {
           return true;
        }
        if (method == MethodName.@UpdatePlayButton) {
           return true;
        }
        if (method == MethodName.@RebuildVersionRows) {
           return true;
        }
        if (method == MethodName.@SetBusy) {
           return true;
        }
        if (method == MethodName.@SetStatus) {
           return true;
        }
        if (method == MethodName.@SaveSettings) {
           return true;
        }
        if (method == MethodName.@FormatSize) {
           return true;
        }
        if (method == MethodName.@BuildHostPage) {
           return true;
        }
        if (method == MethodName.@OpenHostPage) {
           return true;
        }
        if (method == MethodName.@RefreshHostControls) {
           return true;
        }
        if (method == MethodName.@ClearHostRequests) {
           return true;
        }
        if (method == MethodName.@BuildJoinPage) {
           return true;
        }
        if (method == MethodName.@EnsureJoinSession) {
           return true;
        }
        if (method == MethodName.@OpenJoinPage) {
           return true;
        }
        if (method == MethodName.@RefreshJoinPage) {
           return true;
        }
        return base.HasGodotClassMethod(method);
    }
}

}
