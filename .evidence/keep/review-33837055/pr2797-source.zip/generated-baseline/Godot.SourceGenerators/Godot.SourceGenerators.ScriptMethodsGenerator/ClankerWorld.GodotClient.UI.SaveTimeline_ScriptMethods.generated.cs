﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SaveTimeline
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the methods contained in this class, for fast lookup.
    /// </summary>
    public new class MethodName : global::Godot.PanelContainer.MethodName {
        /// <summary>
        /// Cached name for the 'FollowLayout' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FollowLayout = "FollowLayout";
        /// <summary>
        /// Cached name for the 'ViewSize' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ViewSize = "ViewSize";
        /// <summary>
        /// Cached name for the 'SetMaximumHeight' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetMaximumHeight = "SetMaximumHeight";
        /// <summary>
        /// Cached name for the 'Select' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Select = "Select";
        /// <summary>
        /// Cached name for the 'Reveal' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Reveal = "Reveal";
        /// <summary>
        /// Cached name for the 'QueueReveal' method.
        /// </summary>
        public new static readonly global::Godot.StringName @QueueReveal = "QueueReveal";
    }
    /// <summary>
    /// Get the method information for all the methods declared in this class.
    /// This method is used by Godot to register the available methods in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotMethodList()
    {
        var methods = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(6);
        methods.Add(new(name: MethodName.@FollowLayout, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@ViewSize, returnVal: new(type: (global::Godot.Variant.Type)5, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetMaximumHeight, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "height", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Select, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "id", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Reveal, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "id", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@QueueReveal, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        return methods;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool InvokeGodotClassMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@FollowLayout && args.Count == 0) {
            @FollowLayout();
            ret = default;
            return true;
        }
        if (method == MethodName.@ViewSize && args.Count == 0) {
            var callRet = @ViewSize();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Vector2>(callRet);
            return true;
        }
        if (method == MethodName.@SetMaximumHeight && args.Count == 1) {
            @SetMaximumHeight(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Select && args.Count == 1) {
            @Select(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Reveal && args.Count == 1) {
            @Reveal(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@QueueReveal && args.Count == 0) {
            @QueueReveal();
            ret = default;
            return true;
        }
        return base.InvokeGodotClassMethod(method, args, out ret);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassMethod(in godot_string_name method)
    {
        if (method == MethodName.@FollowLayout) {
           return true;
        }
        if (method == MethodName.@ViewSize) {
           return true;
        }
        if (method == MethodName.@SetMaximumHeight) {
           return true;
        }
        if (method == MethodName.@Select) {
           return true;
        }
        if (method == MethodName.@Reveal) {
           return true;
        }
        if (method == MethodName.@QueueReveal) {
           return true;
        }
        return base.HasGodotClassMethod(method);
    }
}

}
