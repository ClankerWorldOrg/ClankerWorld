﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SaveTimelineRows
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the methods contained in this class, for fast lookup.
    /// </summary>
    public new class MethodName : global::Godot.Control.MethodName {
        /// <summary>
        /// Cached name for the 'LaneY' method.
        /// </summary>
        public new static readonly global::Godot.StringName @LaneY = "LaneY";
        /// <summary>
        /// Cached name for the 'Refresh' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Refresh = "Refresh";
        /// <summary>
        /// Cached name for the 'X' method.
        /// </summary>
        public new static readonly global::Godot.StringName @X = "X";
        /// <summary>
        /// Cached name for the 'LayoutPoints' method.
        /// </summary>
        public new static readonly global::Godot.StringName @LayoutPoints = "LayoutPoints";
        /// <summary>
        /// Cached name for the 'LayoutTags' method.
        /// </summary>
        public new static readonly global::Godot.StringName @LayoutTags = "LayoutTags";
        /// <summary>
        /// Cached name for the '_GetTooltip' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_GetTooltip = "_GetTooltip";
        /// <summary>
        /// Cached name for the '_GuiInput' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_GuiInput = "_GuiInput";
        /// <summary>
        /// Cached name for the 'Choose' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Choose = "Choose";
        /// <summary>
        /// Cached name for the 'Hit' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Hit = "Hit";
        /// <summary>
        /// Cached name for the '_Draw' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_Draw = "_Draw";
        /// <summary>
        /// Cached name for the 'DrawBranches' method.
        /// </summary>
        public new static readonly global::Godot.StringName @DrawBranches = "DrawBranches";
        /// <summary>
        /// Cached name for the 'Corner' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Corner = "Corner";
        /// <summary>
        /// Cached name for the 'Tag' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Tag = "Tag";
        /// <summary>
        /// Cached name for the 'TagRect' method.
        /// </summary>
        public new static readonly global::Godot.StringName @TagRect = "TagRect";
        /// <summary>
        /// Cached name for the 'Disc' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Disc = "Disc";
        /// <summary>
        /// Cached name for the 'Ring' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Ring = "Ring";
        /// <summary>
        /// Cached name for the 'Diamond' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Diamond = "Diamond";
    }
    /// <summary>
    /// Get the method information for all the methods declared in this class.
    /// This method is used by Godot to register the available methods in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotMethodList()
    {
        var methods = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(17);
        methods.Add(new(name: MethodName.@LaneY, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "lane", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Refresh, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@X, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)3, name: "day", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@LayoutPoints, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@LayoutTags, returnVal: new(type: (global::Godot.Variant.Type)3, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@_GetTooltip, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "atPosition", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@_GuiInput, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "event", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("InputEvent")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Choose, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "id", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "activate", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "fromKeyboard", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Hit, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)5, name: "at", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@_Draw, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@DrawBranches, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@Corner, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)20, name: "color", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "forkX", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "parentY", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)3, name: "y", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "dotted", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Tag, returnVal: new(type: (global::Godot.Variant.Type)7, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "font", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Font")), new(type: (global::Godot.Variant.Type)2, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)5, name: "at", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "fill", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "ink", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "edge", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@TagRect, returnVal: new(type: (global::Godot.Variant.Type)7, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "font", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Font")), new(type: (global::Godot.Variant.Type)2, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)5, name: "at", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Disc, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Image")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "edge", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "fill", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "highlight", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Ring, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Image")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "edge", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "fill", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "accent", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Diamond, returnVal: new(type: (global::Godot.Variant.Type)24, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("Image")), flags: (global::Godot.MethodFlags)33, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "size", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "edge", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)20, name: "fill", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        return methods;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool InvokeGodotClassMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@LaneY && args.Count == 1) {
            var callRet = @LaneY(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@Refresh && args.Count == 0) {
            @Refresh();
            ret = default;
            return true;
        }
        if (method == MethodName.@X && args.Count == 1) {
            var callRet = @X(global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@LayoutPoints && args.Count == 0) {
            @LayoutPoints();
            ret = default;
            return true;
        }
        if (method == MethodName.@LayoutTags && args.Count == 0) {
            var callRet = @LayoutTags();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@_GetTooltip && args.Count == 1) {
            var callRet = @_GetTooltip(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@_GuiInput && args.Count == 1) {
            @_GuiInput(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.InputEvent>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Choose && args.Count == 3) {
            @Choose(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Hit && args.Count == 1) {
            var callRet = @Hit(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@_Draw && args.Count == 0) {
            @_Draw();
            ret = default;
            return true;
        }
        if (method == MethodName.@DrawBranches && args.Count == 0) {
            @DrawBranches();
            ret = default;
            return true;
        }
        if (method == MethodName.@Corner && args.Count == 5) {
            @Corner(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<float>(args[3]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[4]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Tag && args.Count == 7) {
            var callRet = @Tag(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Font>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[3]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[4]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[5]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[6]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(callRet);
            return true;
        }
        if (method == MethodName.@TagRect && args.Count == 4) {
            var callRet = @TagRect(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Font>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(callRet);
            return true;
        }
        if (method == MethodName.@Disc && args.Count == 4) {
            var callRet = @Disc(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Image>(callRet);
            return true;
        }
        if (method == MethodName.@Ring && args.Count == 4) {
            var callRet = @Ring(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Image>(callRet);
            return true;
        }
        if (method == MethodName.@Diamond && args.Count == 3) {
            var callRet = @Diamond(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Image>(callRet);
            return true;
        }
        return base.InvokeGodotClassMethod(method, args, out ret);
    }
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static bool InvokeGodotClassStaticMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@LaneY && args.Count == 1) {
            var callRet = @LaneY(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<float>(callRet);
            return true;
        }
        if (method == MethodName.@TagRect && args.Count == 4) {
            var callRet = @TagRect(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Font>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Vector2>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Rect2>(callRet);
            return true;
        }
        if (method == MethodName.@Disc && args.Count == 4) {
            var callRet = @Disc(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Image>(callRet);
            return true;
        }
        if (method == MethodName.@Ring && args.Count == 4) {
            var callRet = @Ring(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[2]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[3]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Image>(callRet);
            return true;
        }
        if (method == MethodName.@Diamond && args.Count == 3) {
            var callRet = @Diamond(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.Color>(args[2]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<global::Godot.Image>(callRet);
            return true;
        }
        ret = default;
        return false;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassMethod(in godot_string_name method)
    {
        if (method == MethodName.@LaneY) {
           return true;
        }
        if (method == MethodName.@Refresh) {
           return true;
        }
        if (method == MethodName.@X) {
           return true;
        }
        if (method == MethodName.@LayoutPoints) {
           return true;
        }
        if (method == MethodName.@LayoutTags) {
           return true;
        }
        if (method == MethodName.@_GetTooltip) {
           return true;
        }
        if (method == MethodName.@_GuiInput) {
           return true;
        }
        if (method == MethodName.@Choose) {
           return true;
        }
        if (method == MethodName.@Hit) {
           return true;
        }
        if (method == MethodName.@_Draw) {
           return true;
        }
        if (method == MethodName.@DrawBranches) {
           return true;
        }
        if (method == MethodName.@Corner) {
           return true;
        }
        if (method == MethodName.@Tag) {
           return true;
        }
        if (method == MethodName.@TagRect) {
           return true;
        }
        if (method == MethodName.@Disc) {
           return true;
        }
        if (method == MethodName.@Ring) {
           return true;
        }
        if (method == MethodName.@Diamond) {
           return true;
        }
        return base.HasGodotClassMethod(method);
    }
}

}
