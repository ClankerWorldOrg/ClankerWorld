﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class SlotList
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the methods contained in this class, for fast lookup.
    /// </summary>
    public new class MethodName : global::Godot.ScrollContainer.MethodName {
        /// <summary>
        /// Cached name for the 'Style' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Style = "Style";
        /// <summary>
        /// Cached name for the 'GetItemTitle' method.
        /// </summary>
        public new static readonly global::Godot.StringName @GetItemTitle = "GetItemTitle";
        /// <summary>
        /// Cached name for the 'Clear' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Clear = "Clear";
        /// <summary>
        /// Cached name for the 'Select' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Select = "Select";
        /// <summary>
        /// Cached name for the 'GetSelectedItems' method.
        /// </summary>
        public new static readonly global::Godot.StringName @GetSelectedItems = "GetSelectedItems";
        /// <summary>
        /// Cached name for the '_GuiInput' method.
        /// </summary>
        public new static readonly global::Godot.StringName @_GuiInput = "_GuiInput";
        /// <summary>
        /// Cached name for the 'OnCardInput' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OnCardInput = "OnCardInput";
        /// <summary>
        /// Cached name for the 'Choose' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Choose = "Choose";
        /// <summary>
        /// Cached name for the 'SetHovered' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetHovered = "SetHovered";
        /// <summary>
        /// Cached name for the 'Restyle' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Restyle = "Restyle";
    }
    /// <summary>
    /// Get the method information for all the methods declared in this class.
    /// This method is used by Godot to register the available methods in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotMethodList()
    {
        var methods = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(10);
        methods.Add(new(name: MethodName.@Style, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "state", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@GetItemTitle, returnVal: new(type: (global::Godot.Variant.Type)4, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Clear, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@Select, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "scrollIntoView", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@GetSelectedItems, returnVal: new(type: (global::Godot.Variant.Type)30, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@_GuiInput, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)24, name: "event", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("InputEvent")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@OnCardInput, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)24, name: "input", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false, className: new global::Godot.StringName("InputEvent")),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Choose, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SetHovered, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Restyle, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        return methods;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool InvokeGodotClassMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@Style && args.Count == 1) {
            var callRet = @Style(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@GetItemTitle && args.Count == 1) {
            var callRet = @GetItemTitle(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<string>(callRet);
            return true;
        }
        if (method == MethodName.@Clear && args.Count == 0) {
            @Clear();
            ret = default;
            return true;
        }
        if (method == MethodName.@Select && args.Count == 2) {
            @Select(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@GetSelectedItems && args.Count == 0) {
            var callRet = @GetSelectedItems();
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int[]>(callRet);
            return true;
        }
        if (method == MethodName.@_GuiInput && args.Count == 1) {
            @_GuiInput(global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.InputEvent>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@OnCardInput && args.Count == 2) {
            @OnCardInput(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<global::Godot.InputEvent>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Choose && args.Count == 1) {
            @Choose(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SetHovered && args.Count == 1) {
            @SetHovered(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Restyle && args.Count == 0) {
            @Restyle();
            ret = default;
            return true;
        }
        return base.InvokeGodotClassMethod(method, args, out ret);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassMethod(in godot_string_name method)
    {
        if (method == MethodName.@Style) {
           return true;
        }
        if (method == MethodName.@GetItemTitle) {
           return true;
        }
        if (method == MethodName.@Clear) {
           return true;
        }
        if (method == MethodName.@Select) {
           return true;
        }
        if (method == MethodName.@GetSelectedItems) {
           return true;
        }
        if (method == MethodName.@_GuiInput) {
           return true;
        }
        if (method == MethodName.@OnCardInput) {
           return true;
        }
        if (method == MethodName.@Choose) {
           return true;
        }
        if (method == MethodName.@SetHovered) {
           return true;
        }
        if (method == MethodName.@Restyle) {
           return true;
        }
        return base.HasGodotClassMethod(method);
    }
}

}
