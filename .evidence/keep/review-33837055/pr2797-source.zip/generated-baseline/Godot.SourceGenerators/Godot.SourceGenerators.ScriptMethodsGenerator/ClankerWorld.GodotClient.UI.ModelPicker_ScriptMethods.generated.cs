﻿using Godot;
using Godot.NativeInterop;

namespace ClankerWorld.GodotClient.UI {

partial class ModelPicker
{
#pragma warning disable CS0109 // Disable warning about redundant 'new' keyword
    /// <summary>
    /// Cached StringNames for the methods contained in this class, for fast lookup.
    /// </summary>
    public new class MethodName : global::Godot.VBoxContainer.MethodName {
        /// <summary>
        /// Cached name for the 'SetModel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SetModel = "SetModel";
        /// <summary>
        /// Cached name for the 'BeginLoading' method.
        /// </summary>
        public new static readonly global::Godot.StringName @BeginLoading = "BeginLoading";
        /// <summary>
        /// Cached name for the 'IsLatest' method.
        /// </summary>
        public new static readonly global::Godot.StringName @IsLatest = "IsLatest";
        /// <summary>
        /// Cached name for the 'ShowError' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowError = "ShowError";
        /// <summary>
        /// Cached name for the 'ShowTypedOnly' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ShowTypedOnly = "ShowTypedOnly";
        /// <summary>
        /// Cached name for the 'Lists' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Lists = "Lists";
        /// <summary>
        /// Cached name for the 'ChooseWhenEmpty' method.
        /// </summary>
        public new static readonly global::Godot.StringName @ChooseWhenEmpty = "ChooseWhenEmpty";
        /// <summary>
        /// Cached name for the 'AskWhenUnusable' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AskWhenUnusable = "AskWhenUnusable";
        /// <summary>
        /// Cached name for the 'FollowList' method.
        /// </summary>
        public new static readonly global::Godot.StringName @FollowList = "FollowList";
        /// <summary>
        /// Cached name for the 'Rebuild' method.
        /// </summary>
        public new static readonly global::Godot.StringName @Rebuild = "Rebuild";
        /// <summary>
        /// Cached name for the 'AddModel' method.
        /// </summary>
        public new static readonly global::Godot.StringName @AddModel = "AddModel";
        /// <summary>
        /// Cached name for the 'SelectCurrent' method.
        /// </summary>
        public new static readonly global::Godot.StringName @SelectCurrent = "SelectCurrent";
        /// <summary>
        /// Cached name for the 'OnItemSelected' method.
        /// </summary>
        public new static readonly global::Godot.StringName @OnItemSelected = "OnItemSelected";
    }
    /// <summary>
    /// Get the method information for all the methods declared in this class.
    /// This method is used by Godot to register the available methods in the editor.
    /// Do not call this method.
    /// </summary>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    internal new static global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo> GetGodotMethodList()
    {
        var methods = new global::System.Collections.Generic.List<global::Godot.Bridge.MethodInfo>(13);
        methods.Add(new(name: MethodName.@SetModel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "model", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "isNewAgent", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@BeginLoading, returnVal: new(type: (global::Godot.Variant.Type)2, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "fallbackModel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@IsLatest, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "lookup", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowError, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "message", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "fallbackModel", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "canRetry", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ShowTypedOnly, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "model", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@Lists, returnVal: new(type: (global::Godot.Variant.Type)1, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "model", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@ChooseWhenEmpty, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@AskWhenUnusable, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@FollowList, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@Rebuild, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)1, name: "canRetry", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@AddModel, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)4, name: "model", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)4, name: "text", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), new(type: (global::Godot.Variant.Type)1, name: "available", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        methods.Add(new(name: MethodName.@SelectCurrent, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: null, defaultArguments: null));
        methods.Add(new(name: MethodName.@OnItemSelected, returnVal: new(type: (global::Godot.Variant.Type)0, name: "", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false), flags: (global::Godot.MethodFlags)1, arguments: new() { new(type: (global::Godot.Variant.Type)2, name: "index", hint: (global::Godot.PropertyHint)0, hintString: "", usage: (global::Godot.PropertyUsageFlags)6, exported: false),  }, defaultArguments: null));
        return methods;
    }
#pragma warning restore CS0109
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool InvokeGodotClassMethod(in godot_string_name method, NativeVariantPtrArgs args, out godot_variant ret)
    {
        if (method == MethodName.@SetModel && args.Count == 2) {
            @SetModel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[1]));
            ret = default;
            return true;
        }
        if (method == MethodName.@BeginLoading && args.Count == 1) {
            var callRet = @BeginLoading(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<int>(callRet);
            return true;
        }
        if (method == MethodName.@IsLatest && args.Count == 1) {
            var callRet = @IsLatest(global::Godot.NativeInterop.VariantUtils.ConvertTo<int>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@ShowError && args.Count == 3) {
            @ShowError(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@ShowTypedOnly && args.Count == 1) {
            @ShowTypedOnly(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@Lists && args.Count == 1) {
            var callRet = @Lists(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]));
            ret = global::Godot.NativeInterop.VariantUtils.CreateFrom<bool>(callRet);
            return true;
        }
        if (method == MethodName.@ChooseWhenEmpty && args.Count == 0) {
            @ChooseWhenEmpty();
            ret = default;
            return true;
        }
        if (method == MethodName.@AskWhenUnusable && args.Count == 0) {
            @AskWhenUnusable();
            ret = default;
            return true;
        }
        if (method == MethodName.@FollowList && args.Count == 0) {
            @FollowList();
            ret = default;
            return true;
        }
        if (method == MethodName.@Rebuild && args.Count == 1) {
            @Rebuild(global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[0]));
            ret = default;
            return true;
        }
        if (method == MethodName.@AddModel && args.Count == 3) {
            @AddModel(global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[0]), global::Godot.NativeInterop.VariantUtils.ConvertTo<string>(args[1]), global::Godot.NativeInterop.VariantUtils.ConvertTo<bool>(args[2]));
            ret = default;
            return true;
        }
        if (method == MethodName.@SelectCurrent && args.Count == 0) {
            @SelectCurrent();
            ret = default;
            return true;
        }
        if (method == MethodName.@OnItemSelected && args.Count == 1) {
            @OnItemSelected(global::Godot.NativeInterop.VariantUtils.ConvertTo<long>(args[0]));
            ret = default;
            return true;
        }
        return base.InvokeGodotClassMethod(method, args, out ret);
    }
    /// <inheritdoc/>
    [global::System.ComponentModel.EditorBrowsable(global::System.ComponentModel.EditorBrowsableState.Never)]
    protected override bool HasGodotClassMethod(in godot_string_name method)
    {
        if (method == MethodName.@SetModel) {
           return true;
        }
        if (method == MethodName.@BeginLoading) {
           return true;
        }
        if (method == MethodName.@IsLatest) {
           return true;
        }
        if (method == MethodName.@ShowError) {
           return true;
        }
        if (method == MethodName.@ShowTypedOnly) {
           return true;
        }
        if (method == MethodName.@Lists) {
           return true;
        }
        if (method == MethodName.@ChooseWhenEmpty) {
           return true;
        }
        if (method == MethodName.@AskWhenUnusable) {
           return true;
        }
        if (method == MethodName.@FollowList) {
           return true;
        }
        if (method == MethodName.@Rebuild) {
           return true;
        }
        if (method == MethodName.@AddModel) {
           return true;
        }
        if (method == MethodName.@SelectCurrent) {
           return true;
        }
        if (method == MethodName.@OnItemSelected) {
           return true;
        }
        return base.HasGodotClassMethod(method);
    }
}

}
