from pathlib import Path
import gzip,json,hashlib,subprocess,shutil,collections,xml.etree.ElementTree as ET
from check_pair import read_report
r=Path('/workspace/review-coverage-33837055');a=r/'pr2753-author';o=r/'pr2753-verified';o.mkdir(exist_ok=True);w=Path('/workspace/review-2753-33837055')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=w)
manifest=json.loads((a/'manifest.json').read_text())
for m in manifest:
 p=a/m['path'];b=gzip.decompress(p.read_bytes()) if m['gzip'] else p.read_bytes();assert sha(b)==m['sha256'] and len(b)==m['bytes'],p
scope=json.loads((a/'audit/scope.json').read_text());assert scope['head']==git('rev-parse','HEAD').decode().strip();assert scope['base']==git('rev-parse','HEAD^').decode().strip()
assert all(p.decode().startswith('tests/') for p in git('diff','--name-only','HEAD^','HEAD').splitlines())
settings=sha((w/'skills/test-audit/references/coverage.runsettings').read_bytes());sides=[];metadata=[];cases=[]
for side,label in [('before','before'),('head','final')]:
 m=json.loads((a/side/(label+'-run.json')).read_text());assert m['exit_code']==0 and m['head']==scope['base' if side=='before' else 'head'];assert m['settings_sha256']==settings;assert m['args'][m['args'].index('--filter')+1]==scope['filter'];assert m['filter_sha256']==sha(scope['filter'].encode())
 destination=o/label;destination.mkdir(exist_ok=True);(destination/'report').mkdir(exist_ok=True)
 for name in ['coverage.json','coverage.cobertura.xml']:
  paths=list((a/side/label).rglob(name+'.gz'));assert paths;bs=[gzip.decompress(p.read_bytes()) for p in paths];assert len({sha(b) for b in bs})==1;(destination/'report'/name).write_bytes(bs[0])
 tr=list((a/side/label).rglob('tests.trx'));assert len(tr)==1;shutil.copyfile(tr[0],destination/'coverage.trx')
 report,xp,ct=read_report(destination,5);sides.append(report);metadata.append(m)
 t=ET.parse(tr[0]).getroot();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};defs={v.get('id'):v.find('t:TestMethod',ns).get('className').split(',')[0]+'.'+v.find('t:TestMethod',ns).get('name') for v in t.findall('.//t:UnitTest',ns)};rows=t.findall('.//t:UnitTestResult',ns);actual=collections.Counter(defs[v.get('testId')] for v in rows);assert set(actual)==set(scope['selected_methods_by_side'][label]);cases.append(dict(actual))
pins=lambda m:{Path(b['source']).name:b['sha256'] for b in m['binary_hashes'] if 'ClankerWorld.Tests' not in b['source']};assert pins(metadata[0])==pins(metadata[1]);assert metadata[0]['DOTNET_PROCESSOR_COUNT']==metadata[1]['DOTNET_PROCESSOR_COUNT']==4
assert sides[0].keys()==sides[1].keys();stats={}
for asm in sides[0]:
 stats[asm]={}
 for k in ['lines','branches']:
  b=sides[0][asm][k];h=sides[1][asm][k];assert b==h,(asm,k);stats[asm][k]={'total':len(b),'covered':sum(b.values()),'lost':0,'gained':0}
result={'head':scope['head'],'base':scope['base'],'author_archive':(a/'archive-commit.txt').read_text(),'manifest_verified':len(manifest),'production_pin_hashes_match':pins(metadata[0]),'binary_bytes_omitted_by_author_archive':True,'settings':settings,'cases':cases,'stats':stats,'gross_loss_bound_pp':0,'relative_change':0,'native_or_skipped_cases':0,'reused_raw_reports_no_coverage_rerun':True}
(o/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
