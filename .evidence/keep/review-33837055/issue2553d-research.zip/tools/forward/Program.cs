using System.Collections.Immutable;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);
var files=Directory.GetFiles(root+"/src/ClankerWorld.Simulation","*.cs",SearchOption.AllDirectories).Where(p=>!p.Contains("/bin/")&&!p.Contains("/obj/")).ToList();
files.Add(root+"/src/ClankerWorld.Simulation/obj/Release/net10.0/ClankerWorld.Simulation.GlobalUsings.g.cs");
foreach(var f in new[]{"AgentPlacementRules.cs","BoundedText.cs","RoutineHelperDefaults.cs","Contracts/CalendarRules.cs","Contracts/NeedStates.cs"})files.Add(root+"/src/ClankerWorld.Shared/"+f);files.AddRange(Directory.GetFiles(root+"/src/ClankerWorld.Shared/WorldEvents","*.cs"));
var trees=files.Select(f=>CSharpSyntaxTree.ParseText(File.ReadAllText(f),path:f)).ToArray();
var refs=((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator).Select(p=>MetadataReference.CreateFromFile(p));
var comp=CSharpCompilation.Create("ClankerWorld.Simulation",trees,refs,new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,nullableContextOptions:NullableContextOptions.Enable));

var rows=new List<object>();
foreach(var tree in trees.Where(t=>new[]{"Markets","Goods","Inventory","Production","Construction","Orders","Instructions","Actions","Queries"}.Any(d=>t.FilePath.Contains("/World/"+d+"/")))){var model=comp.GetSemanticModel(tree);foreach(var node in tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>()){var method=model.GetDeclaredSymbol(node)!;if(method.Arity!=0||method.IsVirtual||method.IsOverride||method.DeclaredAccessibility is not(Accessibility.Private or Accessibility.Internal)||node.AttributeLists.Count>0)continue;var expression=node.ExpressionBody?.Expression??(node.Body?.Statements.Count==1?node.Body.Statements[0] is ReturnStatementSyntax ret?ret.Expression:node.Body.Statements[0] is ExpressionStatementSyntax statement?statement.Expression:null:null);if(expression is not InvocationExpressionSyntax call||model.GetSymbolInfo(call).Symbol is not IMethodSymbol target||target.Arity!=0||target.GetAttributes().Any(a=>a.AttributeClass?.Name=="ConditionalAttribute"))continue;bool simple=call.ArgumentList.Arguments.All(a=>a.Expression is IdentifierNameSyntax||a.Expression is LiteralExpressionSyntax||a.Expression is MemberAccessExpressionSyntax m&&m.Expression is IdentifierNameSyntax);rows.Add(new{name=method.Name,owner=method.ContainingType.ToDisplayString(),file=tree.FilePath,lines=node.ToFullString().Count(c=>c=='\n'),source=node.ToFullString(),target=target.ToDisplayString(),simple});}}
File.WriteAllText(output+"/instance-forwarders.json",JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("Forwarding candidate count: "+rows.Count);
