using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=args[0];var output=args[1];var context=JsonDocument.Parse(File.ReadAllText(output+"/context.json"));
var held=context.RootElement.GetProperty("maps").EnumerateArray().SelectMany(x=>x.GetProperty("value").GetProperty("files").EnumerateArray()).Select(x=>Path.GetFullPath(root+"/"+x.GetProperty("filename").GetString())).ToHashSet();
var rows=new List<object>();
foreach(var folder in new[]{"Markets","Goods","Inventory","Production","Construction","Orders","Instructions","Actions","Queries"})
foreach(var file in Directory.GetFiles(root+"/src/ClankerWorld.Simulation/World/"+folder,"*.cs")){
 var tree=CSharpSyntaxTree.ParseText(File.ReadAllText(file),path:file);
 foreach(var method in tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>()){
  if(method.Body?.Statements is not [ReturnStatementSyntax{Expression:not null} ret]||method.DescendantTrivia().Any(t=>t.IsDirective)||ret.GetLeadingTrivia().Any(t=>!t.IsKind(SyntaxKind.WhitespaceTrivia)&&!t.IsKind(SyntaxKind.EndOfLineTrivia)))continue;
  rows.Add(new{file,folder,name=method.Identifier.ValueText,held=held.Contains(file),lines=method.Body.ToFullString().Count(c=>c=='\n'),source=method.ToFullString(),expression=ret.Expression!.ToFullString()});
 }
}
File.WriteAllText(output+"/single-return-audit.json",JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(rows));
