using System.Collections.Immutable;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);
var files=Directory.GetFiles(root+"/src/ClankerWorld.Simulation","*.cs",SearchOption.AllDirectories).Where(p=>!p.Contains("/bin/")&&!p.Contains("/obj/")).ToList();
files.Add(root+"/src/ClankerWorld.Simulation/obj/Release/net10.0/ClankerWorld.Simulation.GlobalUsings.g.cs");
foreach(var f in new[]{"AgentPlacementRules.cs","BoundedText.cs","RoutineHelperDefaults.cs","Contracts/CalendarRules.cs","Contracts/NeedStates.cs"})files.Add(root+"/src/ClankerWorld.Shared/"+f);files.AddRange(Directory.GetFiles(root+"/src/ClankerWorld.Shared/WorldEvents","*.cs"));
var trees=files.Select(f=>CSharpSyntaxTree.ParseText(File.ReadAllText(f),path:f)).ToArray();
var refs=((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator).Select(p=>MetadataReference.CreateFromFile(p));
var comp=CSharpCompilation.Create("ClankerWorld.Simulation",trees,refs,new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,nullableContextOptions:NullableContextOptions.Enable));
var candidates=new Dictionary<IMethodSymbol,MethodDeclarationSyntax>(SymbolEqualityComparer.Default);
foreach(var tree in trees.Where(t=>new[]{"Markets","Goods","Inventory","Production","Construction","Orders","Instructions","Actions","Queries"}.Any(d=>t.FilePath.Contains("/World/"+d+"/")))){var model=comp.GetSemanticModel(tree);foreach(var node in tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>()){
 if(model.GetDeclaredSymbol(node) is not IMethodSymbol m||m.IsVirtual||m.IsOverride||m.IsAbstract||m.IsExtern||m.ExplicitInterfaceImplementations.Length>0||node.AttributeLists.Count>0||m.MethodKind!=MethodKind.Ordinary)continue;
 if(m.DeclaredAccessibility!=Accessibility.Private&&!(m.IsStatic&&m.ContainingType.DeclaredAccessibility==Accessibility.Internal))continue;
 candidates.Add(m,node);
}}
var used=new HashSet<IMethodSymbol>(SymbolEqualityComparer.Default);
foreach(var tree in trees){var model=comp.GetSemanticModel(tree);foreach(var name in tree.GetRoot().DescendantNodes().OfType<SimpleNameSyntax>()){
 var info=model.GetSymbolInfo(name);foreach(var symbol in new[]{info.Symbol}.Concat(info.CandidateSymbols))if(symbol is IMethodSymbol m)used.Add(m.OriginalDefinition);
}}
var tests=Directory.GetFiles(root+"/tests","*.cs",SearchOption.AllDirectories).Where(p=>!p.Contains("/obj/")&&!p.Contains("/bin/")).Select(p=>(p,text:File.ReadAllText(p))).ToArray();
var report=candidates.Where(p=>!used.Contains(p.Key)).Select(p=>new{name=p.Key.Name,owner=p.Key.ContainingType.ToDisplayString(),file=p.Value.SyntaxTree.FilePath,lines=p.Value.ToFullString().Count(c=>c=='\n'),source=p.Value.ToFullString(),testRefs=tests.Where(t=>t.text.Contains(p.Key.Name,StringComparison.Ordinal)).Select(t=>t.p).ToArray()}).ToArray();
File.WriteAllText(output+"/unused-methods.json",JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{candidates=candidates.Count,unused=report.Length,totalLines=report.Where(r=>r.testRefs.Length==0).Sum(r=>r.lines),rows=report.Where(r=>r.testRefs.Length==0).Select(r=>new{r.name,r.owner,r.lines})}));

