from pathlib import Path
import json,re
p=Path('/workspace/review-coverage-33837055/fix2551b');o=json.loads((p/'dispatch-original.json').read_text());head=Path('/workspace/fix-2551b-33837055/src/ClankerWorld.Simulation/World/Civic')
s=(head/'TownSystem.Council.cs').read_text();old=Path('/workspace/base-2553b-835-33837055/src/ClankerWorld.Simulation/World/Civic/TownSystem.Council.cs').read_text()
assert old[:old.index('        var visitPlan =')]==s[:s.index('        // Current authority')]
assert old[old.index('        if (parts[2] == "resettle")'):]==s[s.index('        if (parts[2] == "resettle")'):]
casts=re.findall(r'var (\w+) = plan as (\w+) \?\? originalPlan as (\w+);',s)
oldcasts=re.findall(r'var (\w+) = originalPlan as (\w+);',o['casts'])
assert len(casts)==31 and [(a,b) for a,b,c in casts if b==c]==oldcasts
checks=re.findall(r'if \((Check\w+)\(world, (\w+)\)\.Refusal',o['oldApply'])
assert len(checks)==31
visitchecks=dict(re.findall(r'(\w+ActionPlan) typed => (Check\w+)\(world, typed\)\.Allowed,',o['oldVisit']))
applychecks={dict(oldcasts)[name]:check for check,name in checks}
assert len(visitchecks)==31 and visitchecks==applychecks
bindings=re.findall(r'(\w+ActionPlan) typed => (Bind\w+\([^;\n]+\)),',s)
assert len(bindings)==15
for name,call in o['bindings']:
    typ=dict(oldcasts)[name];expected=re.sub(r'\b'+name+r'\b','typed',call)
    assert dict(bindings)[typ]==expected
p.joinpath('application-preservation.json').write_text(json.dumps({'unchangedPrefix':True,'unchangedSuffixFromResettle':True,'preservedSuppliedCasts':len(casts),'exactBindings':len(bindings),'initialCheckCalls':len(checks),'sameCheckForEveryPlanType':True,'details':'31 original unrelated supplied-plan casts preserved as selected typed plan ?? original typed plan. Founding, parsing, token resolution, town/council gate and application suffix are byte-identical. Decoder disjointness permits the shared offering order; visit bypass retained explicitly. Source shape/bindings and existing runtime scenarios supply the evidence.'},indent=2))
print('Exact prefix/suffix; 31 supplied casts, 15 binding bodies and 31 shared initial check targets verified')
