from pathlib import Path
import re,json
root=Path('/workspace/fix-2551b-33837055/src/ClankerWorld.Simulation/World/Civic')
v=(root/'TownSystem.VisitActionPlans.cs').read_text();c=(root/'TownSystem.Council.cs').read_text()
a=v.index('            ActionPlan? plan;');b=v.index('            if (allowed)',a)
old=v[a:b]
chain=old[old.index('            if (TownProject'):old.index('            var allowed')]
rows=re.findall(r'(?:if|else if) \((.*?)\)\n                plan = candidate.ActionPlan as (\w+) \?\? (.*?);',chain)
assert len(rows)==31,len(rows)
factory='    private ActionPlan? PlanCivicCandidate(ITownWorld world, string actor, string candidate,\n        ActionPlan? originalPlan, out bool recognized)\n    {\n        recognized = true;\n'
for cond,typ,call in rows:
 factory+='        if ('+cond.replace('candidate.Id','candidate')+')\n            return originalPlan as '+typ+' ?? '+call+';\n'
factory+='        recognized = false;\n        return null;\n    }\n\n'
switch=old[old.index('            var allowed = plan switch'):].replace('            var allowed = plan switch','    private ActionCheck? CheckCivicCandidatePlan(ITownWorld world, ActionPlan? plan) => plan switch',1)
switch='\n'.join(line[8:] if line.startswith('        ') else line for line in switch.splitlines())+'\n'
switch=switch.replace('.Allowed,',',').replace('_ => false','_ => null')
newv=v[:a]+'''            var plan = PlanCivicCandidate(world, actor, candidate.Id, candidate.ActionPlan, out var recognized);
            if (!recognized) continue;
'''+v[b:].replace('if (allowed)','if (CheckCivicCandidatePlan(world, plan)?.Allowed == true)',1)
newv=newv[:-2]+'\n'+factory+switch+'}\n'
a=c.index('        var visitPlan = originalPlan as ');b=c.index('        // Current authority',a);casts=c[a:b]
a2=b;b2=c.index('        if (parts[2] == "resettle")',a2)
oldapply=c[a2:b2]
binds=re.findall(r'            (\w+) = (Bind\w+\([^;]+\));',oldapply)
assert len(binds)==15,len(binds)
types=dict(re.findall(r'var (\w+) = originalPlan as (\w+);',casts))
newapply='''        // Current authority, live notice knowledge and exact contest IDs are checked again when delayed responses arrive.
        ActionPlan? plan;
        bool recognized;
        if (parts[2] == "visit")
        {
            recognized = true;
            plan = originalPlan as CivicVisitActionPlan ??
                (CivicVisitChoice.Decode(selectedId) is { } visit ? PlanCivicVisit(world, actor, visit) : null);
        }
        else plan = PlanCivicCandidate(world, actor, selectedId, originalPlan, out recognized);
        if (recognized)
        {
            if (plan is null) return;
            plan = plan switch
            {
'''
for name,call in binds:
 newapply+='                '+types[name]+' typed => '+re.sub(r'\b'+name+r'\b','typed',call)+',\n'
newapply+='''                _ => plan,
            };
            if (CheckCivicCandidatePlan(world, plan)?.Refusal is { } refusal)
            {
                world.RefuseChoice(plan, refusal);
                return;
            }
        }
        else
        {
            var current = new List<CognitionCandidate>();
            if (world.IsChild(actor)) AddChildNonLandCandidates(world, current, actor);
            else AddTownCivicCandidates(world, current, actor);
            if (!current.Any(c => c.Id == selectedId)) return;
            plan = originalPlan;
        }
'''
newcasts=re.sub(r'originalPlan as (\w+);',r'plan as \1 ?? originalPlan as \1;',casts)
newc=c[:a]+newapply+newcasts+c[b2:]
# Exact old/new source and dispatch inventories are preserved outside the product tree.
out=Path('/workspace/review-coverage-33837055/fix2551b')
(out/'TownSystem.VisitActionPlans.proposed.cs').write_text(newv)
(out/'TownSystem.Council.proposed.cs').write_text(newc)
(out/'dispatch-original.json').write_text(json.dumps({'rows':rows,'bindings':binds,'oldVisit':old,'oldApply':oldapply,'casts':casts},indent=2))
for name,old,new in [('Visit',v,newv),('Council',c,newc)]:print(name,len(old.splitlines()),len(new.splitlines()),len(old.splitlines())-len(new.splitlines()))
