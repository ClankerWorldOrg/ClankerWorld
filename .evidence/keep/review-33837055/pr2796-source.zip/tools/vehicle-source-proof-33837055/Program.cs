using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using System.Text.Json;
var root=args[0];var output=args[1];var dir=root+"/src/ClankerWorld.GodotClient/UI/Graphics/";
var expected=JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(output+"/expected-sources.json"))!;
expected.Add("VehicleSpriteDrawing.cs",File.ReadAllText(output+"/shared-helper-expected.cs"));
foreach(var (name,source) in expected)
{
 var a=CSharpSyntaxTree.ParseText(source).GetRoot();var b=CSharpSyntaxTree.ParseText(File.ReadAllText(dir+name)).GetRoot();
 if(!a.DescendantTokens().Select(t=>(t.RawKind,t.Text)).SequenceEqual(b.DescendantTokens().Select(t=>(t.RawKind,t.Text))))throw new Exception("unexpected tokens "+name);
 string[] Comments(Microsoft.CodeAnalysis.SyntaxNode n)=>n.DescendantTrivia(descendIntoTrivia:true).Where(t=>t.IsKind(SyntaxKind.SingleLineCommentTrivia)||t.IsKind(SyntaxKind.MultiLineCommentTrivia)||t.IsKind(SyntaxKind.SingleLineDocumentationCommentTrivia)).Select(t=>t.ToString()).ToArray();
 if(!Comments(a).SequenceEqual(Comments(b)))throw new Exception("unexpected comments "+name);
}
var info=new System.Diagnostics.ProcessStartInfo("git"){WorkingDirectory=root,RedirectStandardOutput=true};foreach(var a in new[]{"diff","--name-only","835f9db1155bfb03fb741b2d5bcde9de50031316","HEAD"})info.ArgumentList.Add(a);using var process=System.Diagnostics.Process.Start(info)!;var changed=process.StandardOutput.ReadToEnd().Split('\n',StringSplitOptions.RemoveEmptyEntries);process.WaitForExit();if(process.ExitCode!=0)throw new Exception("git failed");
if(!changed.Where(f=>f.EndsWith(".cs")).Order().SequenceEqual(expected.Keys.Select(f=>"src/ClankerWorld.GodotClient/UI/Graphics/"+f).Order()))throw new Exception("unexpected C# changed files");
if(changed.Any(f=>f.StartsWith("tests/")||f.Contains("/ClientChecks/")||f.StartsWith("src/ClankerWorld.Simulation/")))throw new Exception("tests/checks/simulation changed");
var report=new{changedCSharpFiles=3,expectedExtractionTokensAndCommentsExactlyEqual=true,allOtherCSharpSourcesUnchanged=true,testsAndClientChecksUnchanged=true,simulationUnchanged=true};File.WriteAllText(output+"/source-proof.json",JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(report));
