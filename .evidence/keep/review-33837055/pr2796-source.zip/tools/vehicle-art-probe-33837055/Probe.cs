using Godot;
using ClankerWorld.GodotClient.UI;
using System.Security.Cryptography;
using System.Text.Json;
public partial class Probe : Node
{
    public override void _Ready()
    {
        try
        {
            var output=OS.GetCmdlineUserArgs().Single();
            using var sheet=Image.CreateEmpty(640,240,false,Image.Format.Rgba8);
            sheet.Fill(new Color("b8beac"));
            var rows=new List<object>();
            for(var pose=0;pose<5;pose++)
                for(var facing=0;facing<8;facing++)
                    foreach(var size in new[]{32,16})
                    {
                        using var image=pose<2?BoatSprites.Sprite(facing,pose==1,size):HandcartSprites.Sprite(facing,pose!=2,pose==4,size);
                        var pixels=image.GetData();
                        rows.Add(new{pose,facing,size,width=image.GetWidth(),height=image.GetHeight(),sha256=Convert.ToHexString(SHA256.HashData(pixels))});
                        File.WriteAllBytes(output+$"/pose-{pose}-facing-{facing}-size-{size}.rgba",pixels);
                        sheet.BlendRect(image,new Rect2I(0,0,image.GetWidth(),image.GetHeight()),new Vector2I(facing*80+(size==32?0:40),pose*48));
                    }
            sheet.Resize(1280,480,Image.Interpolation.Nearest);
            if(sheet.SavePng(output+"/vehicle-contact-sheet.png")!=Error.Ok)throw new Exception("PNG save failed");
            File.WriteAllText(output+"/vehicle-rendered-pixels.json",JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));
            GD.Print("VEHICLE_ART_EVIDENCE 80 images captured: boat resting/rowing, handcart empty/loaded/pulled; all eight facings at32/16px.");
            GetTree().Quit();
        }
        catch(Exception e){GD.PrintErr(e);GetTree().Quit(1);}
    }
}
