using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;
var root=args[0];var output=args[1];var baseline=output+"/baseline-binaries/ClankerWorld.GodotClient.dll";var head=root+"/src/ClankerWorld.GodotClient/.godot/mono/temp/bin/Release/ClankerWorld.GodotClient.dll";
var a=Read(baseline);var b=Read(head);var removed=a.Api.Except(b.Api).ToArray();var added=b.Api.Except(a.Api).ToArray();
if(removed.Length+added.Length>0)throw new Exception(JsonSerializer.Serialize(new{removed,added}));
var psi=new System.Diagnostics.ProcessStartInfo("git"){WorkingDirectory=root,RedirectStandardOutput=true};psi.ArgumentList.Add("rev-parse");psi.ArgumentList.Add("HEAD");using var process=System.Diagnostics.Process.Start(psi)!;var commit=process.StandardOutput.ReadToEnd().Trim();process.WaitForExit();if(process.ExitCode!=0)throw new Exception("git failed");
var beforeVersion=Versions.InformationalVersion(baseline);var afterVersion=Versions.InformationalVersion(head);if(!beforeVersion.EndsWith("835f9db1155bfb03fb741b2d5bcde9de50031316")||!afterVersion.EndsWith(commit))throw new Exception("build revision mismatch");
var report=new{publicApiEntries=b.Api.Count,externalPublicApiExactlyEqual=true,beforeBodies=a.Bodies,afterBodies=b.Bodies,bodyReduction=a.Bodies-b.Bodies,beforeVersion,afterVersion,sha256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(head))),limit="Compiled public signatures/defaults and method inventory; source extraction and independent native pixel assertions establish drawing preservation."};File.WriteAllText(output+"/compiled-api-proof.json",JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(report));
static Inventory Read(string file)
{
 using var pe=new PEReader(File.OpenRead(file));var r=pe.GetMetadataReader();var names=new Names();var api=new HashSet<string>();var bodies=0;
 bool Visible(TypeDefinitionHandle h){var t=r.GetTypeDefinition(h);return t.GetDeclaringType().IsNil?(t.Attributes&TypeAttributes.VisibilityMask)==TypeAttributes.Public:(t.Attributes&TypeAttributes.VisibilityMask)==TypeAttributes.NestedPublic&&Visible(t.GetDeclaringType());}
 foreach(var h in r.TypeDefinitions)
 {
  var t=r.GetTypeDefinition(h);var tn=names.GetTypeFromDefinition(r,h,0);foreach(var mh in t.GetMethods())if(r.GetMethodDefinition(mh).RelativeVirtualAddress!=0)bodies++;
  if(!Visible(h))continue;api.Add("type|"+tn+"|"+t.Attributes);
  foreach(var mh in t.GetMethods())
  {
   var m=r.GetMethodDefinition(mh);if((m.Attributes&MethodAttributes.MemberAccessMask) is not (MethodAttributes.Public or MethodAttributes.Family or MethodAttributes.FamORAssem))continue;var s=m.DecodeSignature(names,(object?)null);
   var parameters=m.GetParameters().Select(ph=>{var p=r.GetParameter(ph);var c=p.GetDefaultValue();return p.SequenceNumber+":"+r.GetString(p.Name)+":"+p.Attributes+":"+(c.IsNil?"":Convert.ToHexString(r.GetBlobBytes(r.GetConstant(c).Value)));});
   api.Add("method|"+tn+"|"+r.GetString(m.Name)+"|"+m.Attributes+"|"+s.ReturnType+"("+string.Join(",",s.ParameterTypes)+")|"+string.Join(";",parameters));
  }
  foreach(var fh in t.GetFields()){var f=r.GetFieldDefinition(fh);if((f.Attributes&FieldAttributes.FieldAccessMask) is not (FieldAttributes.Public or FieldAttributes.Family or FieldAttributes.FamORAssem))continue;var c=f.GetDefaultValue();api.Add("field|"+tn+"|"+r.GetString(f.Name)+"|"+f.Attributes+"|"+f.DecodeSignature(names,(object?)null)+"|"+(c.IsNil?"":Convert.ToHexString(r.GetBlobBytes(r.GetConstant(c).Value))));}
 }
 return new(api,bodies);
}
record Inventory(HashSet<string> Api,int Bodies);
