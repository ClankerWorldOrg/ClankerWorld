using System.Reflection.Metadata;
sealed class Names:ISignatureTypeProvider<string,object?>
{
 public string GetArrayType(string e,ArrayShape s)=>e+"["+s.Rank+"]";public string GetByReferenceType(string e)=>e+"&";public string GetFunctionPointerType(MethodSignature<string>s)=>"fn("+string.Join(",",s.ParameterTypes)+")->"+s.ReturnType;public string GetGenericInstantiation(string t,System.Collections.Immutable.ImmutableArray<string>a)=>t+"<"+string.Join(",",a)+">";public string GetGenericMethodParameter(object?c,int i)=>"!!"+i;public string GetGenericTypeParameter(object?c,int i)=>"!"+i;public string GetModifiedType(string m,string u,bool q)=>u+"mod("+m+","+q+")";public string GetPinnedType(string e)=>e+" pinned";public string GetPointerType(string e)=>e+"*";public string GetPrimitiveType(PrimitiveTypeCode c)=>c.ToString();public string GetSZArrayType(string e)=>e+"[]";
 public string GetTypeFromDefinition(MetadataReader r,TypeDefinitionHandle h,byte k){var t=r.GetTypeDefinition(h);return t.GetDeclaringType().IsNil?r.GetString(t.Namespace)+"."+r.GetString(t.Name):GetTypeFromDefinition(r,t.GetDeclaringType(),0)+"+"+r.GetString(t.Name);}
 public string GetTypeFromReference(MetadataReader r,TypeReferenceHandle h,byte k){var t=r.GetTypeReference(h);return r.GetString(t.Namespace)+"."+r.GetString(t.Name);}
 public string GetTypeFromSpecification(MetadataReader r,object?c,TypeSpecificationHandle h,byte k)=>r.GetTypeSpecification(h).DecodeSignature(this,c);
}
