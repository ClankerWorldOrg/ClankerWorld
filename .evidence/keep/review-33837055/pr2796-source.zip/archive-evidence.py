from pathlib import Path
import json,zipfile,hashlib,shutil,subprocess
p=Path('/workspace/review-coverage-33837055/fix2557');root=Path('/workspace/fix-2557-33837055');target=Path('/workspace/review-evidence-33837055/.evidence/keep/review-33837055')
receipt=json.loads((p/'final-check-receipts.json').read_text());assert receipt['status']=='passed' and receipt['head']=='a35189525ff212fceaa743e908960784fafceb5a'
tests=json.loads((p/'focused-reconciliation.json').read_text());assert tests['cases']==7 and tests['methods']==6 and tests['wholeClasses']==2 and not tests['partialClasses'] and tests['outcomes']=={'Passed':7}
pixels=json.loads((p/'native-pixel-pair.json').read_text());assert pixels['images']==80 and pixels['allRawRgbaBytesEqual'] and pixels['nativeCopiesByteEqual']
for name in ['vehicle-source-proof-33837055','vehicle-api-proof-33837055','vehicle-art-probe-33837055']:
 for f in (Path('/workspace')/name).iterdir():
  if f.is_file() and f.suffix in {'.cs','.csproj','.godot','.tscn'}:
   dest=p/'tools'/name/f.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
base='835f9db1155bfb03fb741b2d5bcde9de50031316'
(p/'final-product.patch').write_bytes(subprocess.check_output(['git','diff',base,'HEAD'],cwd=root))
for name in subprocess.check_output(['git','diff','--name-only',base,'HEAD'],cwd=root,text=True).splitlines():
 for kind in ['before','after']:
  if kind=='before':
   r=subprocess.run(['git','show',base+':'+name],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
   if r.returncode:continue
   data=r.stdout
  else:data=(root/name).read_bytes()
  dest=p/'changed-sources'/kind/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
excluded={'baseline-binaries','head-binaries','native-pixel-pair','visual-scratch','ci','scratch','first-head-590b'}
source=[(f,f.relative_to(p)) for f in sorted(p.rglob('*')) if f.is_file() and not (excluded&set(f.relative_to(p).parts)) and f.name!='archive-manifest.json' and f.suffix not in {'.dll','.pdb','.zip'}]
binaries=[(f,f.relative_to(p)) for folder in ['baseline-binaries','head-binaries'] for f in sorted((p/folder).iterdir()) if f.is_file()]
native=[(f,f.relative_to(p/'native-pixel-pair')) for f in sorted((p/'native-pixel-pair').rglob('*')) if f.is_file() and 'scratch' not in f.relative_to(p/'native-pixel-pair').parts]
rows=[]
for kind,files in [('source',source),('binaries',binaries),('native-pixels',native)]:
 out=target/f'pr2796-{kind}.zip'
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,9) as z:
  for f,name in files:z.write(f,name)
 assert out.stat().st_size<32*1024*1024
 rows.append({'kind':kind,'file':out.name,'bytes':out.stat().st_size,'files':len(files),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
(p/'archive-manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
