from pathlib import Path
import os,subprocess,json,hashlib,time
p=Path('/workspace/review-coverage-33837055/fix2557');root=Path('/workspace/fix-2557-33837055');probe=Path('/workspace/vehicle-art-probe-33837055');env=os.environ.copy();env['PATH']='/workspace/.tools/dotnet:'+env['PATH'];env['DOTNET_PROCESSOR_COUNT']='4'
receipts=json.loads((p/'final-check-receipts.json').read_text());assert any(s['name']=='final-full-build' and s['exit']==0 for s in receipts['steps'])
cache=Path(os.environ.get('CLANKERWORLD_TOOL_CACHE',str(Path(os.environ.get('XDG_CACHE_HOME',str(Path.home()/'.cache')))/'clankerworld/tools')));engine=next(cache.rglob('Godot_v4.7.2-stable_mono_linux.x86_64'));rows=[]
for kind,assembly in [('base',p/'baseline-binaries/ClankerWorld.GodotClient.dll'),('head',root/'src/ClankerWorld.GodotClient/.godot/mono/temp/bin/Release/ClankerWorld.GodotClient.dll')]:
 out=p/'native-pixel-pair'/kind;out.mkdir(parents=True,exist_ok=True);start=time.monotonic()
 with open(out/'build.log','w') as log:r=subprocess.run(['dotnet','build',str(probe/'VehicleArtProbe.csproj'),'-c','Debug','-nr:false','-maxcpucount:1','-p:VehicleGameAssembly='+str(assembly)],env=env,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(kind,'build failed')
 copied=probe/'.godot/mono/temp/bin/Debug/ClankerWorld.GodotClient.dll';assert copied.read_bytes()==assembly.read_bytes(),(kind,'actual native copy mismatch')
 runenv=env.copy()
 for name in ['CONFIG','DATA','CACHE']:runenv['XDG_'+name+'_HOME']=str(out/'scratch'/name.lower())
 with open(out/'engine.log','w') as log:r=subprocess.run([str(engine),'--headless','--path',str(probe),'--',str(out)],env=runenv,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 assert r.returncode==0,(kind,'engine failed')
 log=(out/'engine.log').read_text();assert 'VEHICLE_ART_EVIDENCE 80 images captured' in log and not any(s in log for s in ['ERROR:','were leaked','still in use at exit']),log
 rows.append({'kind':kind,'actualAssemblySha256':hashlib.sha256(assembly.read_bytes()).hexdigest(),'seconds':time.monotonic()-start})
a=p/'native-pixel-pair/base';b=p/'native-pixel-pair/head';before=json.loads((a/'vehicle-rendered-pixels.json').read_text());after=json.loads((b/'vehicle-rendered-pixels.json').read_text());assert len(before)==80 and before==after
files=sorted(f.name for f in a.glob('*.rgba'));assert len(files)==80 and files==sorted(f.name for f in b.glob('*.rgba'))
for name in files:assert (a/name).read_bytes()==(b/name).read_bytes(),name
report={'baseCommit':'835f9db1155bfb03fb741b2d5bcde9de50031316','headCommit':'a35189525ff212fceaa743e908960784fafceb5a','images':80,'allRawRgbaBytesEqual':True,'allDimensionsAndDigestsEqual':True,'nativeCopiesByteEqual':True,'runs':rows};(p/'native-pixel-pair.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
