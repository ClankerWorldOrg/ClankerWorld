from pathlib import Path
import subprocess,os,time,json,sys
p=Path('/workspace/review-coverage-33837055/fix2557');root=Path('/workspace/fix-2557-33837055');env=os.environ.copy();env['PATH']='/workspace/.tools/dotnet:'+env['PATH'];env['DOTNET_PROCESSOR_COUNT']='4';env['ClankerWorld__Clock__StrictTickFailures']='true'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='a35189525ff212fceaa743e908960784fafceb5a';rows=[]
steps=[
 ('final-full-build',['dotnet','build','tests/ClankerWorld.Tests/ClankerWorld.Tests.csproj','-c','Release','--no-restore','-nr:false','-maxcpucount:1']),
 ('focused-tests',['dotnet','test','tests/ClankerWorld.Tests/ClankerWorld.Tests.csproj','-c','Release','--no-build','--no-restore','--filter',(p/'focused-filter.txt').read_text(),'--logger','trx;LogFileName=focused.trx','--results-directory',str(p/'results')]),
 ('final-source-proof',['dotnet','run','--project','/workspace/vehicle-source-proof-33837055','-c','Release','--no-build','--',str(root),str(p)]),
 ('final-compiled-api-proof',['dotnet','run','--project','/workspace/vehicle-api-proof-33837055','-c','Release','--no-build','--',str(root),str(p)]),
 ('final-godot-client',['bash','scripts/verify-godot-client.sh'])
]
for name,args in steps:
 start=time.monotonic()
 with open(p/(name+'.log'),'w') as log:result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'head':head,'name':name,'command':args,'exit':result.returncode,'seconds':time.monotonic()-start})
 (p/'final-check-receipts.json').write_text(json.dumps({'pid':os.getpid(),'head':head,'status':'failed' if result.returncode else 'running','steps':rows},indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if result.returncode:sys.exit(result.returncode)
(p/'final-check-receipts.json').write_text(json.dumps({'pid':os.getpid(),'head':head,'status':'passed','steps':rows},indent=2)+'\n')
