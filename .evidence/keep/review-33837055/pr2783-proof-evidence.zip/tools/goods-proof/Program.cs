using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var baseline=Path.GetFullPath(args[0]);var head=Path.GetFullPath(args[1]);var output=Path.GetFullPath(args[2]);
var dead=JsonDocument.Parse(File.ReadAllText(output+"/dead-members.json")).RootElement.EnumerateArray().ToArray();
var imports=JsonDocument.Parse(File.ReadAllText(output+"/selected-imports.json")).RootElement.GetProperty("unused").EnumerateArray().ToArray();
var reports=new List<object>();var methodCount=0;var importCount=0;
foreach(var file in Directory.GetFiles(baseline+"/src/ClankerWorld.Simulation","*.cs",SearchOption.AllDirectories).Where(p=>!p.Contains("/bin/")&&!p.Contains("/obj/"))){
 var rel=Path.GetRelativePath(baseline,file);var candidate=Path.Combine(head,rel);if(!File.Exists(candidate))throw new Exception("Unexpected removed file "+rel);
 var root=CSharpSyntaxTree.ParseText(File.ReadAllText(file)).GetRoot();var methods=root.DescendantNodes().OfType<MethodDeclarationSyntax>().Where(n=>dead.Any(x=>x.GetProperty("file").GetString()==candidate&&x.GetProperty("source").GetString()==n.ToFullString())).ToArray();
 if(methods.Any(n=>!n.Modifiers.Any(SyntaxKind.PrivateKeyword)))throw new Exception("Nonprivate removal");
 var us=root.DescendantNodes().OfType<UsingDirectiveSyntax>().Where(n=>imports.Any(x=>x.GetProperty("file").GetString()==candidate&&x.GetProperty("source").GetString()==n.ToString())).ToArray();
 methodCount+=methods.Length;importCount+=us.Length;var expected=root.RemoveNodes(methods.Cast<SyntaxNode>().Concat(us),SyntaxRemoveOptions.KeepNoTrivia)!;var actual=CSharpSyntaxTree.ParseText(File.ReadAllText(candidate)).GetRoot();
 if(Tokens(expected)!=Tokens(actual))throw new Exception("Unexpected retained token difference "+rel);
 reports.Add(new{file=rel,removedMethods=methods.Length,removedImports=us.Length,retainedOrderedTokensExact=true});
}
if(methodCount!=1||importCount!=392)throw new Exception("Wrong removal counts "+methodCount+"/"+importCount);
var result=new{removedMethods=methodCount,removedImports=importCount,filesChecked=reports.Count,reports,proof="Every remaining ordered token, including all implementation bodies, checks, fields, properties, types and signatures, matches the clean base after only the one declared private method and 392 compiler-proven unused imports are removed."};File.WriteAllText(output+"/proof.json",JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{methodCount,importCount,filesChecked=reports.Count}));
static string Tokens(SyntaxNode n)=>string.Join("\u001f",n.DescendantTokens().Select(t=>t.RawKind+":"+t.Text));
