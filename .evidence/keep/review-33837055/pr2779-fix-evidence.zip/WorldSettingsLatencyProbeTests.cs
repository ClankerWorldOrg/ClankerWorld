namespace ClankerWorld.Tests;

// Temporary isolated diagnostic, never included in the source PR.
public sealed class WorldSettingsLatencyProbeTests
{
    private static readonly Dictionary<(bool Manual, bool Jev), HeldRequest> Requests =
        new[] { (false, false), (false, true), (true, false), (true, true) }
            .ToDictionary(key => key, _ => new HeldRequest());

    internal static async Task HoldAsync(bool manual, bool jev, CancellationToken token)
    {
        var held = Requests[(manual, jev)];
        held.Token = token;
        using var cancellation = token.Register(() => held.Cancelled.TrySetResult());
        held.Started.TrySetResult();
        await held.Release.Task.ConfigureAwait(false);
    }

    [Fact]
    public async Task OriginalDeadlineCancelsHeldJsonButControlledCompatibilityStillPasses()
    {
        var original = new[]
        {
            new OriginalWorldSettingsDeadlineProbe().WorldSettingsRequireTheHostToAdvertiseWorldBoundActions(false, true),
            new OriginalWorldSettingsDeadlineProbe().WorldSettingsRequireTheHostToAdvertiseWorldBoundActions(true, true),
        };
        var controlled = new[]
        {
            new ControlledWorldSettingsDeadlineProbe().WorldSettingsRequireTheHostToAdvertiseWorldBoundActions(false, true),
            new ControlledWorldSettingsDeadlineProbe().WorldSettingsRequireTheHostToAdvertiseWorldBoundActions(true, true),
        };
        try
        {
            await ModelWorkHarness.WaitForSignalAsync(Task.WhenAll(Requests.Values.Select(item => item.Started.Task)));
            // The actual production 15-second timers signal cancellation. There
            // is no sleep, estimated timing assertion or production deadline change.
            await ModelWorkHarness.WaitForSignalAsync(Task.WhenAll(
                Requests.Where(pair => !pair.Key.Manual).Select(pair => pair.Value.Cancelled.Task)));
            foreach (var entry in Requests)
                Assert.Equal(!entry.Key.Manual, entry.Value.Token.IsCancellationRequested);
        }
        finally
        {
            foreach (var held in Requests.Values) held.Release.TrySetResult();
        }
        foreach (var task in original)
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => task);
        await Task.WhenAll(controlled);
        Console.WriteLine("CLOCK_PROBE: both real deadlines cancelled held signed JSON; both manual-clock variants retained every original world/payload assertion and passed.");
    }

    private sealed class HeldRequest
    {
        public InlineCompletionSource Started { get; } = new();
        public InlineCompletionSource Cancelled { get; } = new();
        public InlineCompletionSource Release { get; } = new();
        public CancellationToken Token { get; set; }
    }
}
