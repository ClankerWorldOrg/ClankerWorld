using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Text.Json;

var names = new HashSet<string>(StringComparer.Ordinal)
{
    "ValidConstructionIdentity", "CompleteProductionJob", "IsToolRequestRecipeId",
    "AdvanceWorldSystemsTo", "GatherRareMaterial",
};
foreach (var path in args)
{
    using var stream = File.OpenRead(path);
    using var pe = new PEReader(stream);
    var reader = pe.GetMetadataReader();
    var targets = new Dictionary<int, string>();
    foreach (var handle in reader.TypeDefinitions)
    {
        var type = reader.GetTypeDefinition(handle);
        if (reader.GetString(type.Namespace) != "ClankerWorld.Simulation.World" ||
            reader.GetString(type.Name) != "WorldRuntime") continue;
        foreach (var methodHandle in type.GetMethods())
        {
            var method = reader.GetMethodDefinition(methodHandle);
            var name = reader.GetString(method.Name);
            if (!names.Contains(name)) continue;
            if ((method.Attributes & MethodAttributes.MemberAccessMask) != MethodAttributes.Private)
                throw new Exception($"Candidate {name} is not private");
            targets.Add(MetadataTokens.GetToken(methodHandle), name);
        }
    }
    var hits = targets.ToDictionary(x => x.Value, _ => new List<string>());
    int bodies = 0;
    foreach (var handle in reader.MethodDefinitions)
    {
        var method = reader.GetMethodDefinition(handle);
        if (method.RelativeVirtualAddress == 0) continue;
        var il = pe.GetMethodBody(method.RelativeVirtualAddress).GetILBytes()!;
        bodies++;
        // Every method-definition operand occupies four consecutive IL bytes.
        // Scanning every byte boundary is a superset of valid operands: zero
        // occurrences proves no such token use; any hit needs disassembly.
        for (int offset = 0; offset <= il.Length - 4; offset++)
        {
            var token = BitConverter.ToInt32(il, offset);
            if (!targets.TryGetValue(token, out var target)) continue;
            var owner = reader.GetTypeDefinition(method.GetDeclaringType());
            hits[target].Add(reader.GetString(owner.Name) + "." + reader.GetString(method.Name) + "@" + offset);
        }
    }
    Console.WriteLine(JsonSerializer.Serialize(new { path, bodies, targets, candidate_token_occurrences = hits }));
}
