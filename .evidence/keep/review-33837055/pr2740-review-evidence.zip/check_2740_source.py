from pathlib import Path
import subprocess,json,re,hashlib
w=Path('/workspace/review-2740-33837055');o=Path('/workspace/review-coverage-33837055/pr2740-local');o.mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=w,text=True)
fs=git('diff','--name-only','HEAD^','HEAD').splitlines();helper=next(f for f in fs if f.endswith('/RawInventoryTestState.cs'));body=git('show','HEAD:'+helper);n=lambda s:re.sub(r'[\s,]','',s);wanted='statewith{Society=state.Societywith{Society=state.Society.Societywith{Inventory=inventory}}};';assert n(body.split('=>',1)[1].rsplit('}',1)[0])==wanted
records=[];total=0
for f in fs:
 if f==helper:continue
 a=git('show','HEAD^:'+f);b=git('show','HEAD:'+f);m=re.search(r'    private static WorldRuntimeState WithInventory\([^;]+;',a);assert m,f;assert n(m.group().split('=>',1)[1])==wanted,f
 rebuilt=a[:m.start()]+a[m.end():];rebuilt=re.sub(r'\n{3,}','\n\n',rebuilt);new=b.replace('using static ClankerWorld.Tests.RawInventoryTestState;\n','');assert rebuilt==new,f
 calls=len(re.findall(r'\bWithInventory\s*\(',b));total+=calls;records.append({'file':f,'calls':calls,'base_sha':hashlib.sha256(a.encode()).hexdigest(),'head_sha':hashlib.sha256(b.encode()).hexdigest(),'other_text_attributes_assertions_arguments_identical':True})
assert len(records)==7 and total==27
main=git('rev-parse','origin/main').strip();tree=git('merge-tree','--write-tree',main,'HEAD').strip()
for f in fs:
 if f==helper:continue
 a=git('show',main+':'+f);b=git('show',tree+':'+f);m=re.search(r'    private static WorldRuntimeState WithInventory\([^;]+;',a);assert m,f;rebuilt=a[:m.start()]+a[m.end():];rebuilt=re.sub(r'\n{3,}','\n\n',rebuilt);new=b.replace('using static ClankerWorld.Tests.RawInventoryTestState;\n','');assert rebuilt==new,('main-preservation',f)
assert git('show',tree+':'+helper)==body
assert not git('diff','HEAD^','HEAD','--','src','.github','skills','tests/ClankerWorld.Tests/ClankerWorld.Tests.csproj')
result={'head':git('rev-parse','HEAD').strip(),'base':git('rev-parse','HEAD^').strip(),'main':main,'merge_tree':tree,'files':records,'calls':total,'helper':'three exact record copies preserving raw Inventory reference; no field/static initializer/custody normalization','main_composition':'all unrelated main text retained, including Care/DirectBarter/Orchard changes','coverage_review_adopted':'independent Codex session1ea2a056 comment6360267927 on exactunchangedhead: complete73case union, rawstable branch identities inclunmapped, gross0pp each/total; originalraw workspace notavailable locally, no coverage repeated','fixes':'none'}
(o/'source-proof.json').write_text(json.dumps(result,indent=2));(o/'diff.patch').write_text(git('diff','HEAD^','HEAD'));print(json.dumps({k:v for k,v in result.items() if k not in ['files']}))
