using ClankerWorld.Simulation.Cognition;

using static ClankerWorld.Simulation.World.WorldRuntime.AnimalSharedRules;

namespace ClankerWorld.Simulation.World;

internal sealed partial class AnimalSystem
{
    internal static bool IsAnimalOrder(string action) => action is "animal_care" or "animal_collect" or "animal_tame" or
        "animal_lead_home" or "animal_saddle" or "animal_mount" or "animal_dismount";

    internal OrderTask? ParseAnimalOrder(IAnimalWorld world, string text, string actor)
    {
        if (!world.IsAdult(actor)) return null;
        var repeat = false;
        if (text.StartsWith("repeat ", StringComparison.OrdinalIgnoreCase)) { repeat = true; text = text[7..]; }
        foreach (var (prefix, action) in new[] { ("care for ", "care"), ("collect from ", "collect"), ("tame ", "tame"),
                     ("lead home ", "lead_home"), ("saddle ", "saddle"), ("mount ", "mount"), ("dismount ", "dismount") })
        {
            if (!text.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || repeat && action is not ("care" or "collect")) continue;
            var name = text[prefix.Length..].Trim();
            var targets = State.Animals.Where(animal => animal.DiedTick is null && animal.Id == name).ToArray();
            if (targets.Length == 0) targets = State.Animals.Where(animal => animal.DiedTick is null &&
                string.Equals(animal.Name, name, StringComparison.OrdinalIgnoreCase)).ToArray();
            if (targets.Length != 1) return null;
            var animal = targets[0];
            if (!AnimalHouseholdMember(world, actor, animal) && !MayCareForAnimal(world, actor, animal) && !MayRideAnimal(world, actor, animal) &&
                !(action == "tame" && animal.HouseholdId is null && world.Map.FootDistance(world.Agents[actor].Position, animal.Position) <= 4)) return null;
            return OrderStore.CreateOrderTask((("animal_" + action)) switch
            {
                "animal_care" => OrderStore.CreateAnimalCareOrderDefinition(TargetAnimalId: animal.Id!),
                "animal_collect" => OrderStore.CreateAnimalCollectOrderDefinition(TargetAnimalId: animal.Id!),
                "animal_tame" => OrderStore.CreateAnimalTameOrderDefinition(TargetAnimalId: animal.Id!),
                "animal_lead_home" => OrderStore.CreateAnimalLeadHomeOrderDefinition(TargetAnimalId: animal.Id!),
                "animal_saddle" => OrderStore.CreateAnimalSaddleOrderDefinition(TargetAnimalId: animal.Id!),
                "animal_mount" => OrderStore.CreateAnimalMountOrderDefinition(TargetAnimalId: animal.Id!),
                "animal_dismount" => OrderStore.CreateAnimalDismountOrderDefinition(TargetAnimalId: animal.Id!),
                _ => throw new InvalidOperationException("The parser returned an unsupported order kind."),
            }, "queued", 1, 0, "animal_tasks", repeat);
        }
        return null;
    }

    internal CognitionCandidate? AnimalOrderCandidate(IAnimalWorld world, OwnerQueuedInstruction instruction)
    {
        var actor = instruction.TargetAgentId;
        var animal = Animal(instruction.Task!.TargetAnimalId!);
        if (!world.IsAdult(actor) || animal is not { DiedTick: null } ||
            instruction.Task.Action == "animal_care" && animal.CareUntilTick <= world.WorldTick && !HasAnimalCareOrderSupplies(world, actor, animal)) return null;
        return new("animal_order", "Follow the order for " + animal.Name + ", using its actual location, permissions and physical supplies.", 0, animal.Id);
    }

    // Admission can inspect replacement supplies before execution releases an unrelated retained trip.
    internal bool HasAnimalCareOrderSupplies(IAnimalWorld world, string actor, AnimalState animal) => MayCareForAnimal(world, actor, animal) &&
        (AnimalCareInputs(world, actor, animal, AnimalRules.Definition(animal.Species).DailyFeed,
            AnimalRules.Definition(animal.Species).DailyWater) is not null ||
         State.SupplyTrips.Any(trip => trip.ActorId == actor && trip.AnimalId == animal.Id && trip.Action == "care") ||
         AnimalSupplyChoices(world, actor, ignoreActiveTrip: true).Any(supply => supply.AnimalId == animal.Id && supply.Action == "care"));

    internal string AnimalOrderBlockedReason(IAnimalWorld world, OwnerQueuedInstruction instruction) =>
        instruction.Task is { Action: "animal_care", TargetAnimalId: { } id } && Animal(id) is { DiedTick: null } animal &&
        animal.CareUntilTick <= world.WorldTick && MayCareForAnimal(world, instruction.TargetAgentId, animal) &&
        !HasAnimalCareOrderSupplies(world, instruction.TargetAgentId, animal)
            ? "Waiting for safe feed and jug water to care for " + animal.Name + "."
            : "Waiting for the animal, permission, an open route, carrying space, and feed or jug water.";

    internal void ExecuteAnimalOrder(IAnimalWorld world, OwnerQueuedInstruction instruction)
    {
        var actor = instruction.TargetAgentId;
        var order = instruction.Task!;
        var animal = Animal(order.TargetAnimalId!);
        if (animal is not { DiedTick: null }) return;
        var action = order.Action[7..];
        if (State.SupplyTrips.FirstOrDefault(trip => trip.ActorId == actor) is { } trip &&
            (trip.AnimalId != animal.Id || trip.Action != action))
            FinishAnimalSupplyTrip(world, actor);
        var oldCare = animal.CareUntilTick;
        var oldProduct = animal.ReadyProductLotId;
        var choice = AnimalChoices(world, actor).FirstOrDefault(choice => choice.AnimalId == animal.Id && choice.Action == action);
        var previousPosition = world.Agents[actor].Position;
        if (choice is not null) _ = ApplyAnimalCandidate(world, actor, choice.Id);
        if (CreditEffect()) return;
        if (world.Agents[actor].Position != previousPosition) return;
        if (action is "care" or "collect" or "saddle")
        {
            if (State.SupplyTrips.FirstOrDefault(trip => trip.ActorId == actor && trip.AnimalId == animal.Id) is not null)
                _ = ApplyAnimalSupplyCandidate(world, actor, AnimalSupplyTripId(actor));
            else if (AnimalSupplyChoices(world, actor).FirstOrDefault(supply => supply.AnimalId == animal.Id && supply.Action == action) is { } supply)
                _ = ApplyAnimalSupplyCandidate(world, actor, supply.Id);
        }
        // A supply pickup can finish collection immediately at the animal.
        if (CreditEffect()) return;
        if (choice is null) world.SetOrderStatus(instruction, OrderStatus.Blocked, "Waiting for permission to handle this animal, its supplies, a ready product or a free yard place.");

        bool CreditEffect()
        {
            animal = Animal(animal.Id)!;
            var finished = action switch
            {
                "care" => MayCareForAnimal(world, actor, animal) && animal.CareUntilTick > oldCare,
                "collect" => oldProduct is not null && animal.ReadyProductLotId is null && MayCareForAnimal(world, actor, animal),
                "tame" => AnimalHouseholdMember(world, actor, animal),
                "lead_home" => AnimalHouseholdMember(world, actor, animal) && AssignedAnimalYard(world, animal) is { } yard &&
                    YardTiles(world, yard).Contains(animal.Position) && animal.LeaderId is null,
                "saddle" => AnimalHouseholdMember(world, actor, animal) && animal.SaddleLotId is not null,
                "mount" => animal.RiderId == actor,
                _ => animal.RiderId is null,
            };
            if (!finished) return false;
            world.CreditOrderEffect(instruction, Identity.Parse(AnimalOrderReceiptId(instruction.InstructionId, animal.Id,
                (action == "care" ? animal.CareUntilTick.ToString(System.Globalization.CultureInfo.InvariantCulture) :
                 action == "collect" ? oldProduct : world.WorldTick.ToString(System.Globalization.CultureInfo.InvariantCulture)))), 1);
            return true;
        }
    }

    internal void CancelAnimalSupplyForOrder(IAnimalWorld world, OwnerQueuedInstruction instruction)
    {
        if (instruction.Task is not { } order || !IsAnimalOrder(order.Action)) return;
        if (State.SupplyTrips.Any(trip => trip.ActorId == instruction.TargetAgentId &&
                trip.AnimalId == order.TargetAnimalId && trip.Action == order.Action[7..]))
            FinishAnimalSupplyTrip(world, instruction.TargetAgentId);
    }
}

