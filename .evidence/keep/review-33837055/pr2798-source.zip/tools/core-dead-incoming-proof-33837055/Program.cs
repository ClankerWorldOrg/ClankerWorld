using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Reflection.Emit;
using System.Reflection;
using System.Text.Json;
var output=args[0];var targets=JsonSerializer.Deserialize<Target[]>(File.ReadAllText(output+"/dead-targets.json"))!;var result=new List<object>();
foreach(var file in args.Skip(1))
{
 using var pe=new PEReader(File.OpenRead(file));var r=pe.GetMetadataReader();
 string TypeName(EntityHandle h){if(h.IsNil)return "";if(h.Kind==HandleKind.TypeDefinition){var t=r.GetTypeDefinition((TypeDefinitionHandle)h);return t.GetDeclaringType().IsNil?r.GetString(t.Namespace)+"."+r.GetString(t.Name):TypeName(t.GetDeclaringType())+"+"+r.GetString(t.Name);}if(h.Kind==HandleKind.TypeReference){var t=r.GetTypeReference((TypeReferenceHandle)h);return r.GetString(t.Namespace)+"."+r.GetString(t.Name);}return "";}
 Target? Method(EntityHandle h){if(h.Kind==HandleKind.MethodSpecification)return Method(r.GetMethodSpecification((MethodSpecificationHandle)h).Method);string owner,name;BlobHandle signature;if(h.Kind==HandleKind.MethodDefinition){var m=r.GetMethodDefinition((MethodDefinitionHandle)h);owner=TypeName(m.GetDeclaringType());name=r.GetString(m.Name);signature=m.Signature;}else if(h.Kind==HandleKind.MemberReference){var m=r.GetMemberReference((MemberReferenceHandle)h);owner=TypeName(m.Parent);name=r.GetString(m.Name);signature=m.Signature;}else return null;var b=r.GetBlobReader(signature);var header=b.ReadSignatureHeader();if(header.Kind!=SignatureKind.Method)return null;if(header.IsGeneric)b.ReadCompressedInteger();var count=b.ReadCompressedInteger();return targets.SingleOrDefault(t=>t.owner==owner&&t.name==name&&t.parameters==count);}
 var foundDefinitions=r.MethodDefinitions.Select(h=>(h,target:Method(h))).Where(x=>x.target is not null).Select(x=>x.target!.signature).ToArray();
 var refs=new List<object>();var ops=typeof(OpCodes).GetFields(BindingFlags.Public|BindingFlags.Static).Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)!).ToDictionary(x=>unchecked((ushort)x.Value));
 foreach(var mh in r.MethodDefinitions){var m=r.GetMethodDefinition(mh);if(m.RelativeVirtualAddress==0)continue;var bytes=pe.GetMethodBody(m.RelativeVirtualAddress).GetILBytes()!;for(var i=0;i<bytes.Length;){var offset=i;ushort code=bytes[i++];if(code==0xfe)code=(ushort)(0xfe00|bytes[i++]);var op=ops[code];if(op.OperandType is OperandType.InlineMethod or OperandType.InlineTok){var h=MetadataTokens.EntityHandle(BitConverter.ToInt32(bytes,i));var target=Method(h);if(target is not null)refs.Add(new{from=TypeName(m.GetDeclaringType())+"."+r.GetString(m.Name),target=target.signature,offset});}var size=op.OperandType switch{OperandType.InlineNone=>0,OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar=>1,OperandType.InlineVar=>2,OperandType.InlineI8 or OperandType.InlineR=>8,OperandType.InlineSwitch=>4+4*BitConverter.ToInt32(bytes,i),_=>4};i+=size;}}
 if(refs.Count!=0)throw new Exception(file+" has incoming references: "+JsonSerializer.Serialize(refs));
 result.Add(new{file,foundDefinitions,incoming=refs.Count});
}
File.WriteAllText(output+"/dead-compiled-incoming.json",JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(result));
record Target(string owner,string name,int parameters,string signature);
