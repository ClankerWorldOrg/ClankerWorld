from pathlib import Path
import json
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
tree = ET.parse(root / 'tests/focused.trx')
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
results = tree.findall('.//t:UnitTestResult', ns)
definitions = tree.findall('.//t:TestDefinitions/t:UnitTest', ns)
methods = {x.attrib['id']: x.find('t:TestMethod', ns).attrib for x in definitions}
scope = {x['fqn'] for x in json.loads((root / 'test-scope.json').read_text())}
counts = {}
unique = set()
for result in results:
    assert result.attrib['outcome'] == 'Passed', result.attrib
    method = methods[result.attrib['testId']]
    cls = method['className'].split(',')[0]
    assert cls in scope, (cls, scope)
    unique.add((cls, method['name']))
    counts[cls] = counts.get(cls, 0) + 1
assert set(counts) == scope, (set(counts), scope)
counters = tree.find('.//t:ResultSummary/t:Counters', ns).attrib
assert int(counters['total']) == int(counters['executed']) == int(counters['passed']) == len(results)
for key in ['failed', 'error', 'timeout', 'aborted', 'inconclusive', 'notRunnable', 'notExecuted', 'disconnected']:
    assert int(counters.get(key, 0)) == 0, (key, counters)
summary = {'cases': len(results), 'methods': len(unique), 'classes': len(counts),
           'perClass': counts, 'counters': counters,
           'times': tree.find('t:Times', ns).attrib,
           'methodIdentities': [{'class': c, 'method': m} for c, m in sorted(unique)],
           'head': '7e8e92b1f0bac5df2cda9c4fea046878660436f3',
           'scope': 'one normal run, whole selected classes; no product test edits'}
(root / 'test-result.json').write_text(json.dumps(summary, indent=2))
print(json.dumps({k: summary[k] for k in ['cases', 'methods', 'classes', 'times']}))
