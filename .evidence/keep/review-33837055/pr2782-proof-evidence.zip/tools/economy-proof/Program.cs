using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=Path.GetFullPath(args[0]);var baseline=Path.GetFullPath(args[1]);var output=Path.GetFullPath(args[2]);
var plan=JsonDocument.Parse(File.ReadAllText(output+"/inline-plan.json")).RootElement;
var selected=plan.GetProperty("selected").EnumerateArray().ToArray();var receipts=plan.GetProperty("receipts").EnumerateArray().ToArray();
var dead=JsonDocument.Parse(File.ReadAllText(output+"/dead-members.json")).RootElement.EnumerateArray().ToArray();
var imports=JsonDocument.Parse(File.ReadAllText(output+"/unused-imports.json")).RootElement.GetProperty("unused").EnumerateArray().ToArray();
var files=Directory.GetFiles(root+"/src/ClankerWorld.Simulation","*.cs",SearchOption.AllDirectories).Where(p=>!p.Contains("/obj/")&&!p.Contains("/bin/")).ToList();
files.Add(root+"/src/ClankerWorld.Simulation/obj/Release/net10.0/ClankerWorld.Simulation.GlobalUsings.g.cs");foreach(var f in new[]{"AgentPlacementRules.cs","BoundedText.cs","RoutineHelperDefaults.cs","Contracts/CalendarRules.cs","Contracts/NeedStates.cs"})files.Add(root+"/src/ClankerWorld.Shared/"+f);files.AddRange(Directory.GetFiles(root+"/src/ClankerWorld.Shared/WorldEvents","*.cs"));
var trees=files.Select(f=>CSharpSyntaxTree.ParseText(File.ReadAllText(f),path:f)).ToArray();var refs=((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator).Select(p=>MetadataReference.CreateFromFile(p));var comp=CSharpCompilation.Create("ClankerWorld.Simulation",trees,refs,new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,nullableContextOptions:NullableContextOptions.Enable));
var bindings=new List<object>();var retained=new List<object>();
var missing=Directory.GetFiles(baseline+"/src/ClankerWorld.Simulation","*.cs",SearchOption.AllDirectories).Where(p=>!p.Contains("/obj/")&&!p.Contains("/bin/")&&!File.Exists(Path.Combine(root,Path.GetRelativePath(baseline,p)))).ToArray();
if(missing.Length!=1||!missing[0].EndsWith("/WorldRuntime.DirectBarterPlans.cs"))throw new Exception("Unexpected missing source");
var scaffold=CSharpSyntaxTree.ParseText(File.ReadAllText(missing[0])).GetRoot();var oldMethods=scaffold.DescendantNodes().OfType<MethodDeclarationSyntax>().ToArray();if(oldMethods.Length!=2||oldMethods.Any(m=>!selected.Any(x=>x.GetProperty("source").GetString()==m.ToFullString()))||scaffold.DescendantNodes().OfType<ClassDeclarationSyntax>().Single().Members.Count!=2)throw new Exception("Unexpected removed scaffold");

foreach(var t in trees.Where(t=>!t.FilePath.Contains("/obj/")&&t.FilePath.Contains("/src/ClankerWorld.Simulation/"))){var path=t.FilePath;var rel=Path.GetRelativePath(root,path);var original=CSharpSyntaxTree.ParseText(File.ReadAllText(Path.Combine(baseline,rel))).GetRoot();var model=comp.GetSemanticModel(t);
 var rs=receipts.Where(r=>r.GetProperty("File").GetString()==path).ToArray();
 foreach(var r in rs){var after=Tokens(SyntaxFactory.ParseExpression(r.GetProperty("After").GetString()!));var candidates=t.GetRoot().DescendantNodes().OfType<InvocationExpressionSyntax>().Where(n=>Tokens(n)==after).ToArray();if(candidates.Length==0)throw new Exception("Missing replacement "+r);var target=r.GetProperty("Target").GetString();foreach(var n in candidates){var actual=model.GetSymbolInfo(n).Symbol?.ToDisplayString();if(actual!=target)throw new Exception("Wrong binding "+n+" expected "+target+" actual "+actual);}bindings.Add(new{file=rel,wrapper=r.GetProperty("Wrapper").GetString(),target,matches=candidates.Length});}
 var removed=selected.Where(x=>x.GetProperty("file").GetString()==path).Select(x=>x.GetProperty("source").GetString()!).Concat(dead.Where(x=>x.GetProperty("file").GetString()==path).Select(x=>x.GetProperty("source").GetString()!)).ToHashSet();var us=imports.Where(x=>x.GetProperty("file").GetString()==path).Select(x=>x.GetProperty("source").GetString()!).ToHashSet();
 var rewritten=new Replay(rs,removed,us).Visit(original)!;if(Tokens(rewritten)!=Tokens(t.GetRoot()))throw new Exception("Unexpected retained token difference "+rel);retained.Add(new{file=rel,originalTokens=original.DescendantTokens().Count(),headTokens=t.GetRoot().DescendantTokens().Count()});
}
var errors=comp.GetDiagnostics().Where(d=>d.Severity==DiagnosticSeverity.Error).Select(d=>d.ToString()).ToArray();if(errors.Any(e=>!e.Contains("CS8795")||!e.Contains("CivicTickText")))throw new Exception(string.Join("\n",errors));
var result=new{bindings,retained,knownSourceOnlyGeneratorDiagnostics=errors,removedEmptyPartialFiles=missing.Select(p=>Path.GetRelativePath(baseline,p)),removedMethods=selected.Length+dead.Count(x=>x.GetProperty("kind").GetString()=="method"),removedConstants=dead.Count(x=>x.GetProperty("kind").GetString()=="constant"),removedImports=imports.Length};File.WriteAllText(output+"/proof.json",JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{bindingReceipts=bindings.Count,retainedFiles=retained.Count,result.removedMethods,result.removedConstants,result.removedImports}));
static string Tokens(SyntaxNode n)=>string.Join("\u001f",n.DescendantTokens().Select(t=>t.RawKind+":"+t.Text));
sealed class Replay(JsonElement[] receipts,HashSet<string> removed,HashSet<string> us):CSharpSyntaxRewriter{
 public override SyntaxNode? VisitMethodDeclaration(MethodDeclarationSyntax n)=>removed.Contains(n.ToFullString())?null:base.VisitMethodDeclaration(n);
 public override SyntaxNode? VisitFieldDeclaration(FieldDeclarationSyntax n)=>removed.Contains(n.ToFullString())?null:base.VisitFieldDeclaration(n);
 public override SyntaxNode? VisitUsingDirective(UsingDirectiveSyntax n)=>us.Contains(n.ToString())?null:base.VisitUsingDirective(n);
 public override SyntaxNode? VisitInvocationExpression(InvocationExpressionSyntax n){var line=n.GetLocation().GetLineSpan().StartLinePosition.Line+1;var hits=receipts.Where(r=>r.GetProperty("Line").GetInt32()==line&&r.GetProperty("Before").GetString()==n.ToString()).ToArray();if(hits.Length>1)throw new Exception("Ambiguous receipt");return hits.Length==1?SyntaxFactory.ParseExpression(hits[0].GetProperty("After").GetString()!):base.VisitInvocationExpression(n);}
}
