from pathlib import Path
import json,zipfile,hashlib,shutil,subprocess
p=Path('/workspace/review-coverage-33837055/fix2551e');root=Path('/workspace/fix-2551e-33837055');target=Path('/workspace/review-evidence-33837055/.evidence/keep/review-33837055')
assert json.loads((p/'final-check-receipts.json').read_text())['status']=='passed'
r=json.loads((p/'focused-reconciliation.json').read_text());assert r['methods']==228 and r['wholeClasses']==41 and len(r['partialClasses'])==5 and r['outcomes']=={'Passed':r['cases']}
b=json.loads((p/'compiled-proof.json').read_text());assert len(b['removedUserMethods'])==0 and b['beforeBodies']==b['afterBodies'] and not b['addedUserMethods'] and b['allNonGeneratedStateFieldsUnchanged'] and b['testCopyByteEqual']
for variant,head in [('base','835f9db1155bfb03fb741b2d5bcde9de50031316'),('candidate','e56b4901c6fdbdbf80af60a52b5734e5d5b88c8e')]:
 run=json.loads((p/'native'/variant/'run.json').read_text());assert run['Commit']==head and run['WorkingTree']==''
assert 'Equivalent: 68 native frames' in (p/'native-equivalence.log').read_text()
for name in ['civic-scaffold-audit-33837055','civic-field-audit-33837055','civic-merge-transform-33837055','economy-formatted-proof-33837055','economy-layout-api-proof-33837055','towns-test-scope-33837055']:
 for f in (Path('/workspace')/name).iterdir():
  if f.is_file() and f.suffix in {'.cs','.csproj'}:
   dest=p/'tools'/name/f.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
for extension in ['dll','pdb']:
 name='ClankerWorld.Simulation.'+extension;dest=p/'head-binaries'/name;dest.parent.mkdir(exist_ok=True);shutil.copy2(root/'src/ClankerWorld.Simulation/bin/Release/net10.0'/name,dest)
base='835f9db1155bfb03fb741b2d5bcde9de50031316';(p/'final-product.patch').write_bytes(subprocess.check_output(['git','diff','--no-renames',base,'HEAD'],cwd=root))
for name in subprocess.check_output(['git','diff','--no-renames','--name-only',base,'HEAD'],cwd=root,text=True).splitlines():
 for kind in ['before','after']:
  if kind=='after' and not (root/name).exists():continue
  if kind=='before' and subprocess.run(['git','cat-file','-e',base+':'+name],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0:continue
  data=subprocess.check_output(['git','show',base+':'+name],cwd=root) if kind=='before' else (root/name).read_bytes()
  dest=p/'changed-sources'/kind/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
binaryFolders={'baseline-binaries','head-binaries','native-binaries'}
source=[(f,f.relative_to(p)) for f in sorted(p.rglob('*')) if f.is_file() and not ((binaryFolders|{'ci','scratch','native','__pycache__'})&set(f.relative_to(p).parts)) and f.name!='archive-manifest.json' and not f.name.startswith('first-') and not f.name.startswith('ci-') and f.suffix not in {'.dll','.pdb','.zip'}]
binaries=[(f,f.relative_to(p)) for folder in sorted(binaryFolders) for f in sorted((p/folder).iterdir()) if f.is_file()]
native=[(f,f.relative_to(p)) for f in sorted((p/'native').rglob('*')) if f.is_file()];rows=[]
for kind,files in [('source',source),('binaries',binaries),('native',native)]:
 out=target/f'pr2800-{kind}.zip'
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,9) as z:
  for f,name in files:z.write(f,name)
 assert out.stat().st_size<32*1024*1024
 rows.append({'kind':kind,'file':out.name,'bytes':out.stat().st_size,'files':len(files),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
(p/'archive-manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
