from pathlib import Path
import json,zipfile,hashlib
p=Path('/workspace/review-coverage-33837055/fix2554c');native=Path('/workspace/native-2793-33837055');target=Path('/workspace/review-evidence-33837055/.evidence/keep/review-33837055');target.mkdir(parents=True,exist_ok=True)
r=json.load(open(p/'focused-reconciliation.json'));assert r['methods']==313 and r['classes']==55 and r['outcomes']=={'Passed':r['cases']}
source=[(f,f.relative_to(p)) for f in sorted(p.rglob('*')) if f.is_file() and f.name!='archive-manifest.json' and not ({'baseline-binaries','pinned-binaries'}&set(f.relative_to(p).parts)) and f.suffix not in {'.zip','.dll','.pdb'}]
binaries=[(f,f.relative_to(p)) for folder in [p/'baseline-binaries',p/'pinned-binaries'] for f in sorted(folder.rglob('*')) if f.is_file()]
sets={'source':source,'binaries':binaries,'native':[(f,f.relative_to(native)) for f in sorted(native.rglob('*')) if f.is_file()]};rows=[]
for label,files in sets.items():
 path=target/('pr2793-'+label+'.zip')
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,9) as z:
  for f,name in files:z.write(f,name)
 rows.append({'kind':label,'file':str(path),'bytes':path.stat().st_size,'files':len(files),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 assert path.stat().st_size<32*1024*1024
(p/'archive-manifest.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
