import pathlib,subprocess,json,re,os,xml.etree.ElementTree as ET
w=pathlib.Path('/workspace/review-2751-33837055'); out=pathlib.Path('/workspace/review-coverage-33837055/pr2751-local');out.mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=w,text=True)
head=git('rev-parse','HEAD').strip();base=git('rev-parse','HEAD^').strip();files=git('diff','--name-only',base,head).splitlines();removed=[]
for f in files:
 a=git('show',f'{base}:{f}'); b=git('show',f'{head}:{f}')
 assert all(not x.lstrip().startswith('#') for x in a.splitlines()),f
 clean=lambda s:[x for x in s.splitlines() if x.strip() and not re.fullmatch(r'using [\w.]+;',x)]
 assert clean(a)==clean(b),f
 for line in git('diff','--unified=0',base,head,'--',f).splitlines():
  if line.startswith('-') and not line.startswith('---') and line[1:].strip():
   assert re.fullmatch(r'using [\w.]+;',line[1:]),line
   removed.append({'file':f,'line':line[1:]})
assert len(files)==14 and len(removed)==37
assert all(f.startswith('src/ClankerWorld.Simulation/World/Civic/') for f in files)
(out/'source-proof.json').write_text(json.dumps({'head':head,'base':base,'files':files,'removed':removed,'ordered_other_lines_identical':True,'conditional_directives':False},indent=2))
flt='|'.join('FullyQualifiedName~ClankerWorld.Tests.'+x+'.' for x in ['TownSystemTests','GovernmentInvariantTests','CivicInvariantTests','CaseAuthorityInvariantTests','CouncilInvariantTests'])
(out/'filter.txt').write_text(flt)
env=os.environ.copy();env['DOTNET_PROCESSOR_COUNT']='4';env['CLANKERWORLD_TEST_FAIL_ON_TICK_BUDGET']='1'
cmd=['/workspace/.tools/dotnet/dotnet','test','tests/ClankerWorld.Tests/ClankerWorld.Tests.csproj','-c','Release','--no-build','--no-restore','--filter',flt]
for name,extra in [('discovery',['--list-tests']),('focused',['--logger','trx;LogFileName=focused.trx','--results-directory',str(out)])]:
 with (out/(name+'.log')).open('w') as f:subprocess.run(cmd+extra,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(name,'passed',flush=True)
r=ET.parse(out/'focused.trx').getroot();ns={'t':r.tag.split('}')[0][1:]};counts=r.find('.//t:Counters',ns).attrib
print(json.dumps(counts));assert counts['total']=='54' and counts['passed']=='54' and counts['failed']=='0'
