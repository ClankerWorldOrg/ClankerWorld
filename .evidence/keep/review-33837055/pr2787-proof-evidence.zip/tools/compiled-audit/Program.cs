using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Text.Json;

var root=args[0];var evidence=args[1];
var maps=JsonDocument.Parse(File.ReadAllText(evidence+"/adapters/before-interface-map.json")).RootElement.EnumerateObject().Select(x=>x.Name.Split('|')[1]).Distinct().Order().ToArray();
var baseline=Read(evidence+"/baseline-binaries/ClankerWorld.Simulation.dll");
var nativeBaseline=Read(evidence+"/pinned-binaries/native-baseline/ClankerWorld.Simulation.dll");
File.WriteAllText(evidence+"/native-baseline-inventory-differences.json",JsonSerializer.Serialize(new{pinnedBodies=baseline.BodyCount,nativeBodies=nativeBaseline.BodyCount,removed=baseline.Methods.Except(nativeBaseline.Methods).ToArray(),added=nativeBaseline.Methods.Except(baseline.Methods).ToArray()},new JsonSerializerOptions{WriteIndented=true}));
var head=Read(root+"/src/ClankerWorld.Simulation/bin/Release/net10.0/ClankerWorld.Simulation.dll");
var tests=Read(root+"/tests/ClankerWorld.Tests/bin/Release/net10.0/ClankerWorld.Simulation.dll");
foreach(var name in maps){var key="ClankerWorld.Simulation.World.WorldRuntime+"+name;if(baseline.Fields[key].Length!=1||head.Fields[key].Length!=0||tests.Fields[key].Length!=0)throw new Exception("Unexpected adapter field count "+name);}
const string baseName="ClankerWorld.Simulation.World.WorldRuntime+GoodsRuntimeAdapter";
if(head.Fields[baseName].Length!=1||tests.Fields[baseName].Length!=1)throw new Exception("Shared base must have exactly one runtime field");
bool Target(string x)=>maps.Any(n=>x.StartsWith("ClankerWorld.Simulation.World.WorldRuntime+"+n+"|"))||x.StartsWith(baseName+"|");
if(nativeBaseline.BodyCount!=baseline.BodyCount||!nativeBaseline.Methods.Where(Target).ToHashSet().SetEquals(baseline.Methods.Where(Target)))throw new Exception("Actual named native baseline adapter inventory differs");
var removed=baseline.Methods.Except(head.Methods).Where(Target).ToArray();var added=head.Methods.Except(baseline.Methods).Where(Target).ToArray();
if(removed.Length!=274||added.Length!=74||added.Any(x=>!x.StartsWith(baseName+"|"))||removed.Any(x=>!maps.Any(n=>x.StartsWith("ClankerWorld.Simulation.World.WorldRuntime+"+n+"|"))))throw new Exception("Unexpected declaration change: removed"+removed.Length+" added"+added.Length);
if(baseline.BodyCount-head.BodyCount!=200)throw new Exception("Unexpected global body delta");
if(!head.Methods.SetEquals(tests.Methods))throw new Exception("Test output uses a different production declaration inventory");
Console.WriteLine(JsonSerializer.Serialize(new{head="8eaf3cec373b9670fdfa485a37e62b0b974f7eab",adapterCount=maps.Length,before=baseline.BodyCount,after=head.BodyCount,netBodyReduction=baseline.BodyCount-head.BodyCount,removedDeclarations=removed,addedDeclarations=added,childCaptureFieldsAfter=0,sharedRuntimeFields=head.Fields[baseName],nativeBaselineNamedAdapterInventoryMatches=true,testOutputMatches=true},new JsonSerializerOptions{WriteIndented=true}));

static Inventory Read(string path){using var fs=File.OpenRead(path);using var pe=new PEReader(fs);var r=pe.GetMetadataReader();string Name(TypeDefinitionHandle h){var t=r.GetTypeDefinition(h);return t.GetDeclaringType().IsNil?r.GetString(t.Namespace)+"."+r.GetString(t.Name):Name(t.GetDeclaringType())+"+"+r.GetString(t.Name);}
 var methods=new HashSet<string>();var fields=new Dictionary<string,string[]>();var bodies=0;
 foreach(var h in r.TypeDefinitions){var t=r.GetTypeDefinition(h);var name=Name(h);fields[name]=t.GetFields().Where(f=>(r.GetFieldDefinition(f).Attributes&FieldAttributes.Static)==0).Select(f=>r.GetString(r.GetFieldDefinition(f).Name)).ToArray();foreach(var mh in t.GetMethods()){var m=r.GetMethodDefinition(mh);if(m.RelativeVirtualAddress!=0)bodies++;var blob=r.GetBlobReader(m.Signature);blob.ReadSignatureHeader();var arity=(m.Attributes&MethodAttributes.Static)!=0?"static":"instance";var count=m.GetParameters().Count(p=>r.GetParameter(p).SequenceNumber>0);methods.Add(name+"|"+r.GetString(m.Name)+"|"+arity+"|"+count);}}
 return new(methods,fields,bodies);
}
record Inventory(HashSet<string> Methods,Dictionary<string,string[]> Fields,int BodyCount);
