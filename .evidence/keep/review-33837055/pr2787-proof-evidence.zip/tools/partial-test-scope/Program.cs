using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
using System.Xml.Linq;
var root=args[0];var output=args[1];
var planned=JsonDocument.Parse(File.ReadAllText(output+"/focused-scope.json")).RootElement.EnumerateArray();
XNamespace trx="http://microsoft.com/schemas/VisualStudio/TeamTest/2010";var already=XDocument.Load(output+"/focused-results/focused.trx").Descendants(trx+"TestMethod").Select(m=>(string)m.Attribute("className")!+"."+(string)m.Attribute("name")!).ToHashSet();
var rows=new List<object>();var methods=new List<string>();
foreach(var item in planned){var file=item.GetProperty("file").GetString()!;var tree=CSharpSyntaxTree.ParseText(File.ReadAllText(root+"/"+file));var syntax=tree.GetRoot();var ns=syntax.DescendantNodes().OfType<BaseNamespaceDeclarationSyntax>().First().Name.ToString();var owner=syntax.DescendantNodes().OfType<ClassDeclarationSyntax>().First();var name=ns+"."+owner.Identifier.ValueText;
 if(name==item.GetProperty("class").GetString())continue;
 foreach(var method in owner.Members.OfType<MethodDeclarationSyntax>().Where(m=>m.AttributeLists.SelectMany(a=>a.Attributes).Any(a=>a.Name.ToString() is "Fact" or "Theory"))){var full=name+"."+method.Identifier.ValueText;if(already.Contains(full))continue;methods.Add(full);rows.Add(new{file,@class=name,method=method.Identifier.ValueText,full});}
}
File.WriteAllText(output+"/partial-method-scope.json",JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));File.WriteAllText(output+"/partial-method-filter.txt",string.Join("|",methods.Distinct().Select(m=>"FullyQualifiedName="+m)));Console.WriteLine(JsonSerializer.Serialize(new{methods=methods.Distinct().Count(),scope=rows}));
