using DeliveryOrderPlan = ClankerWorld.Simulation.World.OrderSystem.DeliveryOrderPlan;
using ClankerWorld.Simulation.Cognition;
using ClankerWorld.Simulation.Content;
using ClankerWorld.Simulation.Kernel;
using ClankerWorld.Simulation.Society;

namespace ClankerWorld.Simulation.World;

/// <summary>
/// Keeps a household workstation stocked for its own recipes. Recipes there
/// use only on-site stock, so an adult of the holding household carries the
/// inputs in: from what they carry, from the household's own stock, or by
/// gathering from a reachable source. The Farmhouse, Blacksmith and House
/// keep their older, dedicated hauling.
/// </summary>
public sealed partial class WorldRuntime
{
    private const string SupplyWorkstationPrefix = WorkstationSupplyChoice.Prefix;

    /// <summary>Enough on-site stock for two batches of the largest recipe needing the item.</summary>
    private const int SupplyBatches = 2;

    internal sealed record WorkstationSupplyNeed(PlacedBuilding Building, BuildingDefinition Definition,
        string ItemKind, int Missing, InventoryLot? Carried, InventoryLot? HouseholdStock, MapResource? Source);

    private static bool HasDedicatedSupply(BuildingDefinition definition) =>
        definition.Tags.Any(tag => tag is "house" or "farmhouse" or "blacksmith");

    /// <summary>The source station's live two-batch input need, independent of available supply actions.</summary>
    private int WorkstationInputTarget(PlacedBuilding building, string itemKind) => building.HouseholdId is { } householdId
        ? worldContent.Recipes.Where(recipe => recipe.WorkstationBuildingId == building.DefinitionId &&
                !recipe.IsCrop && !IsGenericFoodRecipe(recipe) && NeedsRecipeOutput(recipe, householdId))
            .SelectMany(recipe => recipe.Inputs).Where(input => input.ResourceId == itemKind)
            .Select(input => input.Amount).DefaultIfEmpty(0).Max() * SupplyBatches
        : 0;

    private static int UsableWorkstationQuantity(InventoryCheckpoint inventory, InventoryLot lot) =>
        InventoryRules.HasUsableContainer(InventoryIndex.For(inventory), lot)
            ? Math.Max(0, InventoryRules.AvailableQuantity(InventoryIndex.For(inventory), lot)) : 0;

    private static int WorkstationOnsiteQuantity(InventoryCheckpoint inventory, PlacedBuilding building, string itemKind) =>
        building.HouseholdId is { } householdId ? InventoryIndex.For(inventory).StoredAt(building.InstanceId).Where(lot => lot.OwnerId == householdId &&
                lot.StorageBuildingId == building.InstanceId && lot.ItemKind == itemKind)
            .Sum(lot => UsableWorkstationQuantity(inventory, lot)) : 0;

    private int WorkstationIncomingQuantity(InventoryCheckpoint inventory, PlacedBuilding building, string itemKind) =>
        building.HouseholdId is { } householdId ? WorkstationIncomingLots(inventory, building.InstanceId).Where(lot =>
                lot.ItemKind == itemKind && (lot.OwnerId == householdId ||
                    society.Checkpoint.Agents.Any(person => person.Id == lot.OwnerId &&
                        person.HouseholdId == householdId && person.Status == SocietyAgentStatus.Active)) &&
                CanCreditWorkstationIncoming(inventory, lot))
            .Sum(lot => UsableWorkstationQuantity(inventory, lot)) : 0;

    private static bool CanCreditWorkstationIncoming(InventoryCheckpoint inventory, InventoryLot lot)
    {
        var root = lot.ContainerLotId is { } containerId ? inventory.GetLot(containerId) : lot;
        return !InventoryContainerRules.IsContainer(root.ItemKind) ||
            !UnusableDeliveryStock(inventory, root) && !HasActiveContainerReservation(inventory, root.Id);
    }

    private int WorkstationSourceSurplus(InventoryCheckpoint inventory, InventoryLot resource)
    {
        if (resource.StorageBuildingId is not { } sourceId ||
            worldSimulation.Buildings.FirstOrDefault(building => building.InstanceId == sourceId &&
                building.HouseholdId == resource.OwnerId) is not { } source)
            return int.MaxValue;
        var available = WorkstationOnsiteQuantity(inventory, source, resource.ItemKind);
        var incoming = WorkstationIncomingQuantity(inventory, source, resource.ItemKind);
        return Math.Max(0, available + incoming - WorkstationInputTarget(source, resource.ItemKind));
    }

    /// <summary>Actual available loose stock above its held source station's live input reserve.</summary>
    private int WorkstationStockSurplus(InventoryCheckpoint inventory, InventoryLot resource) =>
        Math.Min(UsableWorkstationQuantity(inventory, resource),
            WorkstationSourceSurplus(inventory, resource));

    /// <summary>A whole vessel may leave only when every moved ingredient is source surplus.</summary>
    private bool CanRemoveWorkstationStock(InventoryCheckpoint inventory, InventoryLot root, int quantity)
    {
        if (quantity <= 0) return false;
        if (!InventoryContainerRules.IsContainer(root.ItemKind))
            return quantity <= WorkstationStockSurplus(inventory, root);
        if (quantity != 1 || UnusableDeliveryStock(inventory, root) || HasActiveContainerReservation(inventory, root.Id))
            return false;
        return InventoryIndex.For(inventory).ContentsOf(root.Id)
            .GroupBy(lot => lot.ItemKind).All(group =>
                group.Sum(lot => UsableWorkstationQuantity(inventory, lot)) <=
                    WorkstationSourceSurplus(inventory, group.First()));
    }

    private IEnumerable<WorkstationSupplyNeed> WorkstationSupplyNeeds(string actor, string? itemKind = null,
        string? buildingId = null, int maximumResourceQuantity = int.MaxValue, string? sourceLotId = null)
    {
        if (society.Checkpoint.GetAgent(actor).HouseholdId is not { } householdId)
            yield break;
        var definitions = worldContent.BuildingDefinitions;
        foreach (var building in worldSimulation.Buildings.Where(item => item.HouseholdId == householdId &&
                     (buildingId is null || item.InstanceId == buildingId))
                     .OrderBy(item => item.InstanceId, StringComparer.Ordinal))
        {
            if (!definitions.TryGetValue(building.DefinitionId, out var definition) ||
                HouseholdBuildingKind(definition) is null)
                continue;
            var recipes = WorkstationSupplyRecipes(definition, householdId);
            foreach (var input in recipes.SelectMany(recipe => recipe.Inputs).GroupBy(input => input.ResourceId))
            {
                if (itemKind is not null && input.Key != itemKind) continue;
                var inventory = society.Checkpoint.Inventory;
                var missing = WorkstationSupplyMissing(building, input.Key, recipes);
                if (missing <= 0)
                    continue;
                var deliveryRoom = DestinationRoom(inventory, building.InstanceId);
                var carried = FindGoods(new(GoodsUse.CarriedInputs, actor, new([actor, householdId]), GoodsKinds.One(input.Key))).Matches.Select(match => match.Lot)
                    // Water travels inside a carried jug, so look through the vessel to its contents.
                    .Select(lot => lot.ContainerLotId is { } containerId
                        ? inventory.GetLot(containerId) : lot)
                    .Where(lot => PersonalEquipmentRules.IsCarried(lot, actor) &&
                        (sourceLotId is null || lot.Id == sourceLotId) &&
                        lot.DeliveryBuildingId is null && deliveryRoom > 0 && TransportSystem.SpareCarriedQuantity(this.HandcartWorld, actor, lot) > 0 &&
                        (!InventoryContainerRules.IsContainer(lot.ItemKind) ||
                         ContainerFamilyQuantity(inventory, lot.Id) <= deliveryRoom) &&
                        (!InventoryContainerRules.IsContainer(lot.ItemKind) ||
                         DeliveryResourceQuantity(lot, input.Key) <= maximumResourceQuantity) &&
                        (!InventoryContainerRules.IsContainer(lot.ItemKind) ||
                         !HasActiveContainerReservation(inventory, lot.Id)))
                    .DistinctBy(lot => lot.Id)
                    .OrderBy(lot => lot.Id, StringComparer.Ordinal).FirstOrDefault();
                var stock = carried is not null ? null : SpareHouseholdStock(actor, householdId, input.Key, building,
                    maximumResourceQuantity, sourceLotId) ??
                    AvailableWarehouseStock(actor, input.Key).FirstOrDefault(lot =>
                        RecheckGoods(DeliveryGoodsRequest(actor, lot.OwnerId, lot.ItemKind, building.InstanceId), lot.Id) is not null &&
                        (sourceLotId is null || lot.Id == sourceLotId) &&
                        WorkstationPickupQuantity(actor, inventory, lot, building.InstanceId, int.MaxValue) > 0 &&
                        (!InventoryContainerRules.IsContainer(lot.ItemKind) ||
                         DeliveryResourceQuantity(lot, input.Key) <= maximumResourceQuantity));
                var source = carried is not null || stock is not null ? null : MaterialSource(input.Key, actor, building.Position);
                if (source is not null && (deliveryRoom <= 0 ||
                    ProjectMaterialCarryUnits(actor, input.Key, source) > FreeCarryCapacity(actor)))
                    source = null;
                if (carried is null && stock is null && source is null)
                    continue;
                if (stock is not null && FreeCarryCapacity(actor) == 0 || source is not null &&
                    FreeCarryCapacity(actor) < ProjectMaterialCarryUnits(actor, input.Key, source))
                    continue;
                yield return new WorkstationSupplyNeed(building, definition, input.Key, missing, carried, stock, source);
            }
        }
    }

    private int WorkstationPickupQuantity(string actor, InventoryCheckpoint inventory, InventoryLot stock,
        string destinationId, int missing)
    {
        var destination = worldSimulation.Buildings.SingleOrDefault(building => building.InstanceId == destinationId);
        var capacity = destination is null ? 0 : Math.Min(PickupCarryCapacity(actor, stock, destination.Position),
            DestinationRoom(inventory, destinationId));
        if (capacity <= 0)
            return 0;
        return InventoryContainerRules.IsContainer(stock.ItemKind)
            ? ContainerFamilyQuantity(inventory, stock.Id) <= capacity &&
                CanRemoveWorkstationStock(inventory, stock, 1) ? 1 : 0
            : Math.Min(HouseHaulLoadQuantity, Math.Min(capacity, Math.Min(missing,
                WorkstationStockSurplus(inventory, stock))));
    }

    private InventoryLot? SpareHouseholdStock(string actor, string householdId, string itemKind,
        PlacedBuilding destination, int maximumResourceQuantity = int.MaxValue, string? sourceLotId = null)
    {
        var inventory = society.Checkpoint.Inventory;
        return FindGoods(DeliveryGoodsRequest(actor, householdId, itemKind, destination.InstanceId)).Matches
            .Select(match => match.Root)
            .Where(lot => lot.CarrierId is null &&
                (sourceLotId is null || lot.Id == sourceLotId) &&
                (!InventoryContainerRules.IsContainer(lot.ItemKind) ||
                 DeliveryResourceQuantity(lot, itemKind) <= maximumResourceQuantity) &&
                (lot.StorageBuildingId is null || worldSimulation.Buildings.Any(building =>
                    building.InstanceId == lot.StorageBuildingId && worldContent.Buildings.Any(definition =>
                        definition.CanonicalId == building.DefinitionId &&
                        definition.Tags.Any(tag => tag is "house" or "silo" or "farmhouse" or "restaurant" or "animal-yard")))))
            .Where(lot => WorkstationPickupQuantity(actor, inventory, lot, destination.InstanceId, int.MaxValue) > 0)
            .DistinctBy(lot => lot.Id)
            .OrderBy(lot => lot.Id, StringComparer.Ordinal).FirstOrDefault();
    }

    private void AddWorkstationSupplyCandidate(List<CognitionCandidate> candidates, string actor)
    {
        if (PlanWorkstationSupply(actor) is not { } plan || !CheckActionPlan(plan).Allowed) return;
        var definition = worldContent.BuildingDefinitions[plan.DefinitionId];
        candidates.Add(new CognitionCandidate(plan.CandidateId,
            $"Bring {plan.ItemKind} into the household {definition.DisplayName} for its work.",
            24, plan.BuildingId)
        { ActionPlan = plan });
    }

    private DeliveryOrderPlan? GetWorkstationOrderPlan(string actor, AgentState person,
        OrderTask order, int maximumQuantity)
    {
        if (!IsAdult(actor) || HouseholdFor(actor) is not { } householdId) return null;
        var inventory = society.Checkpoint.Inventory;
        foreach (var need in WorkstationSupplyNeeds(actor, order.TargetItemKind,
                     order.TargetStorageBuildingId, maximumQuantity, order.DeliveryLotId)
                     .Where(need => DeliveryDestinationMatches(order, need.Building)))
        {
            var carrier = need.Carried ?? need.HouseholdStock;
            if (carrier is null) continue;
            var direct = need.Carried is not null;
            var container = InventoryContainerRules.IsContainer(carrier.ItemKind);
            var quantity = direct
                ? container ? ContainerFamilyQuantity(inventory, carrier.Id) <=
                    DestinationRoom(inventory, need.Building.InstanceId) ? 1 : 0
                    : Math.Min(maximumQuantity, Math.Min(DestinationRoom(inventory, need.Building.InstanceId),
                        Math.Min(need.Missing, TransportSystem.SpareCarriedQuantity(this.HandcartWorld, actor, carrier))))
                : WorkstationPickupQuantity(actor, inventory, carrier, need.Building.InstanceId,
                    Math.Min(need.Missing, maximumQuantity));
            if (quantity <= 0) continue;
            var resourceQuantity = container ? DeliveryResourceQuantity(carrier, need.ItemKind) : quantity;
            if (resourceQuantity <= 0 || resourceQuantity > maximumQuantity) continue;
            var resource = carrier.ItemKind == need.ItemKind ? carrier : InventoryIndex.For(inventory).ContentsOf(carrier.Id)
                .Where(lot => lot.ItemKind == need.ItemKind)
                .OrderBy(lot => lot.Id, StringComparer.Ordinal).First();
            return new DeliveryOrderPlan("workstation_input", need.Building, householdId,
                carrier, resource, quantity, resourceQuantity, DirectDelivery: direct);
        }
        return null;
    }
}
