using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Text.Json;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
var root=args[0];var output=args[1];var plan=JsonDocument.Parse(File.ReadAllText(output+"/inline-plan.json")).RootElement;
var removed=plan.GetProperty("methods").EnumerateArray().Select(m=>Regex.Match(m.GetProperty("name").GetString()!,@"WorldRuntime\.(\w+)\(").Groups[1].Value).GroupBy(n=>n).ToDictionary(g=>g.Key,g=>g.Count());
var baseline=Read(output+"/baseline-binaries/ClankerWorld.Simulation.dll");var head=Read(root+"/src/ClankerWorld.Simulation/bin/Release/net10.0/ClankerWorld.Simulation.dll");var tests=Read(root+"/tests/ClankerWorld.Tests/bin/Release/net10.0/ClankerWorld.Simulation.dll");
foreach(var name in baseline.RootMethods.Keys.Union(head.RootMethods.Keys)){var difference=baseline.RootMethods.GetValueOrDefault(name)-head.RootMethods.GetValueOrDefault(name);if(difference!=removed.GetValueOrDefault(name))throw new Exception("Unexpected method delta "+name+" "+difference);}
if(!baseline.RootInstanceFields.SequenceEqual(head.RootInstanceFields))throw new Exception("Root instance state changed");
if(head.Bodies!=baseline.Bodies-removed.Values.Sum())throw new Exception("Unexpected compiled body delta");
if(!head.CaptureFields.SequenceEqual(baseline.CaptureFields))throw new Exception("Generated capture state changed");
if(head.Sha!=tests.Sha)throw new Exception("Focused production assembly differs from full build");
Console.WriteLine(JsonSerializer.Serialize(new{removedMethods=removed,baselineBodies=baseline.Bodies,headBodies=head.Bodies,netBodiesRemoved=baseline.Bodies-head.Bodies,rootInstanceFieldsUnchanged=true,capturedFieldsUnchanged=true,generatedMethodOrdinalsCanonicalized=true,headTestAssemblyByteIdentical=true,headSha256=head.Sha},new JsonSerializerOptions{WriteIndented=true}));
static Inventory Read(string path){using var fs=File.OpenRead(path);using var pe=new PEReader(fs);var reader=pe.GetMetadataReader();var handle=reader.TypeDefinitions.Single(h=>{var t=reader.GetTypeDefinition(h);return reader.GetString(t.Namespace)=="ClankerWorld.Simulation.World"&&reader.GetString(t.Name)=="WorldRuntime";});var type=reader.GetTypeDefinition(handle);var methods=type.GetMethods().Select(h=>Canonical(reader.GetString(reader.GetMethodDefinition(h).Name))).GroupBy(n=>n).ToDictionary(g=>g.Key,g=>g.Count());var fields=type.GetFields().Select(h=>reader.GetFieldDefinition(h)).Where(f=>(f.Attributes&FieldAttributes.Static)==0).Select(f=>reader.GetString(f.Name)).Order().ToArray();var captures=reader.TypeDefinitions.Where(h=>reader.GetString(reader.GetTypeDefinition(h).Name).Contains("DisplayClass")).SelectMany(h=>{var t=reader.GetTypeDefinition(h);var name=reader.GetString(t.Name);return t.GetFields().Select(fh=>Canonical(name)+":"+reader.GetString(reader.GetFieldDefinition(fh).Name));}).Order().ToArray();return new(methods,fields,captures,reader.MethodDefinitions.Count(h=>reader.GetMethodDefinition(h).RelativeVirtualAddress!=0),Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path))));}
static string Canonical(string name){name=Regex.Replace(name,@"(?<=b__)\d+","#");name=Regex.Replace(name,@"(?<=\|)\d+","#");name=Regex.Replace(name,@"(?<=<>c__DisplayClass)\d+","#");return name;}
record Inventory(Dictionary<string,int> RootMethods,string[] RootInstanceFields,string[] CaptureFields,int Bodies,string Sha);
