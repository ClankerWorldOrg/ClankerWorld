from pathlib import Path
import json,xml.etree.ElementTree as ET,collections
p=Path('/workspace/review-coverage-33837055/fix2552c');scope=json.loads((p/'focused-scope.json').read_text());expected={m['Full'] for m in scope['methods']};actual=set();outcomes=collections.Counter();rows=[]
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for path in [p/'results/focused.trx',p/'results/shop.trx']:
 root=ET.parse(path).getroot();methods={}
 for test in root.findall('.//t:UnitTest',ns):
  method=test.find('t:TestMethod',ns);methods[test.attrib['id']]=method.attrib['className']+'.'+method.attrib['name']
 results=root.findall('.//t:UnitTestResult',ns);names={methods[r.attrib['testId']] for r in results};assert not actual&names,sorted(actual&names);actual|=names
 counts=collections.Counter(r.attrib['outcome'] for r in results);assert counts=={'Passed':len(results)},counts;outcomes.update(counts)
 counters=root.find('.//t:Counters',ns).attrib;assert int(counters['passed'])==len(results)==int(counters['total']) and int(counters.get('failed','0'))==0,counters
 rows.append({'file':str(path),'cases':len(results),'methods':len(names),'outcomes':dict(counts),'counters':counters})
assert actual==expected,{'missing':sorted(expected-actual),'unexpected':sorted(actual-expected)}
report={'cases':sum(outcomes.values()),'methods':len(actual),'classes':len({m['Class'] for m in scope['methods']}),'wholeClasses':len(scope['wholeClasses']),'partialClasses':scope['partialClasses'],'outcomes':dict(outcomes),'runs':rows,'missing':[],'unexpected':[],'plannedMethods':sorted(expected),'executedMethods':sorted(actual)}
(p/'focused-reconciliation.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['plannedMethods','executedMethods','runs']}))
