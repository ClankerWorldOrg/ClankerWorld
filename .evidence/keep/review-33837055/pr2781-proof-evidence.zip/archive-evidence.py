from pathlib import Path
import json,zipfile,hashlib
source=Path('/workspace/review-coverage-33837055/fix2554');dest=Path('/workspace/review-evidence-33837055/.evidence/keep/review-33837055');dest.mkdir(parents=True,exist_ok=True);r=json.loads((source/'result.json').read_text());r['ci'].update(status='allrequiredpassed',scope_job=120405067938,installer_job=120410822691,verify_job=120413403308,actual_checkout='fb535192238e6b6a766077babd86b13031cec7d9');(source/'result.json').write_text(json.dumps(r,indent=2))
files=sorted(p for p in source.rglob('*') if p.is_file());groups={'proof':[p for p in files if p.relative_to(source).parts[0] not in ['native','binaries','baseline-binaries']],'native':[p for p in files if p.relative_to(source).parts[0]=='native'],'binaries':[p for p in files if p.relative_to(source).parts[0] in ['binaries','baseline-binaries']]};rows=[]
for name,group in groups.items():
 archive=dest/('pr2781-'+name+'-evidence.zip')
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in group:z.write(p,p.relative_to(source))
 row=dict(file=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=len(group));assert row['bytes']<32*1024*1024,row;rows.append(row)
(dest/'pr2781-archives.json').write_text(json.dumps(rows,indent=2));(dest/'pr2781-final-ci.json').write_bytes((source/'final-ci.json').read_bytes());(dest/'pr2781-result.json').write_bytes((source/'result.json').read_bytes())
index=f'''# PR2781 unused forwarding and import cleanup evidence

Codex session33837055. NEVER merge or open a PR for this evidence branch.

Source PR https://github.com/ClankerWorldOrg/ClankerWorld/pull/2781 ; Refs2554 remains open. Base `{r['base']}`, head `{r['head']}`. Source+32/-433=401net fewer,67files; tests/docs unchanged. Area183files14,611lines,559 fewer than original15,170;3,034target still short2,475. No exhaustion or speed claim.

## Immutable archives

'''
for row in rows:index+=f"- `{row['file']}` — {row['bytes']}bytes,{row['files']}files,SHA256`{row['sha256']}`.\n"
index+='''
Proof ZIP: complete before/after copies of changed source, final diff and SHA256manifest, bound surveys, baseline/head compiled references, complete ordered-token proof/tool sources, compiler diagnostics, build/format/stale logs, normal TRX/console log and exact-head CI logs. Original Family step and its later grouped continuation are labelled separately; result.json is final.

Native ZIP: unchanged portable probe, exact clean checkout run.json, logs and all68initial/committed checkpoint/event/digest frames for each baseline and candidate. Defaults2seeds x generated/legacy x17frames. Decompressed checkpoints, ordered events and observed digests match exactly. Bounded correctness proof; no whole-path or performance claim.

Binary ZIP:12SHA256-pinned actual binary/symbol roles, including original baseline reference scan, separately built native base/head outputs, and actual focused test-output Test/Simulation/Server copies. Local full dependent Release build ran against final working source before8fe9e348commit; source hashes match it. Its informational version may name the previous commit. Exact clean native outputs and full CI independently use final8fe9e348. This provenance is explicit in binaries.json/result.json.

## Verified result

All540normal cases passed,0skips/failures,189unique methods,17whole actual classes including partials; one normal run. Native68frames exact. Locked full dependent Release build0warnings/errors(127.63s), all scoped formatting verification, diff/stale checks passed. No tests/assertions weakened or pruned; no local full suite/coverage/manual gameplay.

All78private method names had0incoming references in original pinned baseline50,364method bodies; actual focused and native head outputs each have50,286bodies and none of the78names. Scan is limited to nongeneric same-module MethodDef windows, supplemented by complete bound source, external name/reflection review and whole dependent build. Retained private reflection/delegate seams remain. Test AdmittedTickhits are unrelated ModelWorkTransition property reads. Production's only GetMethod hit is StackTrace inspection; no dynamic invocation. Simulation has no preprocessor directives outside third-party code.

All184original scoped files preserve every remaining ordered code token after78private method removals and171compiler-proven unused imports. One resulting empty partial deleted;12comment blocks moved to live implementations. Actual implementations, registrations, checks, fields, types, signatures, state and event behavior remain. Source-only compiler diagnostic omits unrelated GeneratedRegex implementation and reports that sole known error; actual full build succeeds. #2775's CommunityWorldfile is excluded.

Exact-head Verify39950911637passed all8test shards, formatting/export, Windows documentation/storage and installer120410822691; final verify120413403308green. Scope120405067938 personally read actual checkoutfb535192238e6b6a766077babd86b13031cec7d9, exact8fe9e348into main7f97fc4b. Timing120410566958and all10growth rows read:3271shared15,411s versus14,042s(+10%), rows span boats, markets, conversation, inventory and household scenarios. No causal speed conclusion or extra benchmark.
'''
(dest/'pr2781-fix-evidence.md').write_text(index);print(json.dumps(rows,indent=2))
