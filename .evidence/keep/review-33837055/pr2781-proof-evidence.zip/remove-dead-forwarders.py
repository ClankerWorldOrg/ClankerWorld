from pathlib import Path
import json,re,hashlib
root=Path('/workspace/fix-2554-33837055');e=Path('/workspace/review-coverage-33837055/fix2554');rows=json.loads((e/'dead-forwarders.json').read_text());assert len(rows)==66 and len({r['name'] for r in rows})==66
family=root/'src/ClankerWorld.Simulation/World/Family';sources={Path(r['file']):Path(r['file']).read_text() for r in rows};moves=[]
for r in rows:
 assert r['selected'] and not r['calls'] and not r['reasons'];p=Path(r['file']);assert sources[p].count(r['source'])==1,(p,r['name']);sources[p]=sources[p].replace(r['source'],'',1)
 prefix=r['source'].split('    private ',1)[0];comments=[line for line in prefix.splitlines() if line.lstrip().startswith('//')]
 if not comments:continue
 comment='\n'.join(comments)+'\n'
 if r['name']=='ChildHelpingHouse':
  target=family/'FamilySystem.Children.cs';s=sources.get(target,target.read_text());marker='    internal const int ChildHelpingLoad = 4;';assert s.count(marker)==1;sources[target]=s.replace(marker,comment+marker,1)
 else:
  matches=[]
  for target in family.glob('Family*.cs'):
   s=sources.get(target,target.read_text());ms=list(re.finditer(r'^    (?:internal|private|public)\b[^\n]*\b'+r['name']+r'\(',s,re.M))
   for m in ms:matches.append((target,s,m.start()))
  assert len(matches)==1,(r['name'],[(p.name,i) for p,s,i in matches]);target,s,i=matches[0];assert comment not in s; sources[target]=s[:i]+comment+s[i:]
 moves.append(dict(name=r['name'],source=r['file'],target=str(target),comment=comment))
for p,s in sources.items():p.write_text(s)
p=family/'WorldRuntime.ChildHelping.cs';s=p.read_text();assert re.fullmatch(r'(?:using [^;]+;\s*)*namespace ClankerWorld\.Simulation\.World;\s*public sealed partial class WorldRuntime\s*\{\s*\}\s*',s),s;p.unlink()
(e/'comment-moves.json').write_text(json.dumps(moves,indent=2));print('Removed66 private dead forwarders, deleted their one empty partial file, relocated',len(moves),'useful comment blocks to live implementations')
