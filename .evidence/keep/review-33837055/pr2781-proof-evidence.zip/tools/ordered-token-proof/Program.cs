using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var rows=JsonDocument.Parse(File.ReadAllText(args[2])).RootElement.EnumerateArray().Select(x=>new{file=x.GetProperty("file").GetString()!.Split("/World/")[1],name=x.GetProperty("name").GetString()!}).ToArray();
var unused=args.Length>3?JsonDocument.Parse(File.ReadAllText(args[3])).RootElement.GetProperty("unused").EnumerateArray().Select(x=>new{file=x.GetProperty("file").GetString()!.Split("/World/")[1],source=x.GetProperty("source").GetString()!}).ToArray():[];
var total=0;var reports=new List<object>();
foreach(var file in new[]{"Family","Community","Agents","Conversations","Knowledge","Cognition"}.SelectMany(d=>Directory.GetFiles(args[0]+"/src/ClankerWorld.Simulation/World/"+d,"*.cs"))){
 var name=file.Split("/World/")[1];var root=CSharpSyntaxTree.ParseText(File.ReadAllText(file)).GetRoot();var selected=rows.Where(x=>x.file==name).Select(x=>x.name).ToHashSet();var nodes=root.DescendantNodes().OfType<MethodDeclarationSyntax>().Where(n=>n.Ancestors().OfType<TypeDeclarationSyntax>().First().Identifier.ValueText=="WorldRuntime"&&selected.Contains(n.Identifier.ValueText)).ToArray();
 if(nodes.Length!=selected.Count||nodes.Any(n=>!n.Modifiers.Any(SyntaxKind.PrivateKeyword)))throw new Exception("Wrong removal shape "+file);total+=nodes.Length;
 var remove=nodes.Cast<SyntaxNode>().Concat(root.DescendantNodes().OfType<UsingDirectiveSyntax>().Where(u=>unused.Any(x=>x.file==name&&x.source==u.ToString()))).ToArray();var expected=root.RemoveNodes(remove,SyntaxRemoveOptions.KeepNoTrivia)!;var head=args[1]+"/src/ClankerWorld.Simulation/World/"+name;
 if(!File.Exists(head)){
  var types=expected.DescendantNodes().OfType<TypeDeclarationSyntax>().ToArray();if(name!="Family/WorldRuntime.ChildHelping.cs"||types.Length!=1||types[0].Members.Count!=0)throw new Exception("Unexpected file deletion "+name);
  reports.Add(new{file=name,removedMethods=nodes.Length,emptyPartialDeleted=true});continue;
 }
 var actual=CSharpSyntaxTree.ParseText(File.ReadAllText(head)).GetRoot();string Tokens(SyntaxNode n)=>string.Join("\n",n.DescendantTokens().Select(t=>t.Text));if(Tokens(expected)!=Tokens(actual))throw new Exception("Retained ordered token change "+name);
 reports.Add(new{file=name,removedMethods=nodes.Length,retainedOrderedTokensExact=true});
}
if(total!=78)throw new Exception("Expected78 removals, got"+total);
Console.WriteLine(JsonSerializer.Serialize(new{removedPrivateMethods=total,filesChecked=reports.Count,reports,proof="Every remaining ordered token, including all implementation bodies, action registrations, checks, fields, properties, types and signatures is exact after only78declared private method removals and listed compiler-proven unused imports. Comments/trivia ignored; one empty partial file deleted."},new JsonSerializerOptions{WriteIndented=true}));
