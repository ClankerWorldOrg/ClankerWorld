using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Text.Json;

var allTownMethods = args[1] == "--town-all";
var requested = allTownMethods ? new List<Target>() : JsonSerializer.Deserialize<List<Target>>(File.ReadAllText(args[1]))!;
using var stream = File.OpenRead(args[0]);
using var pe = new PEReader(stream);
var reader = pe.GetMetadataReader();
string Owner(TypeDefinitionHandle handle)
{
    var type = reader.GetTypeDefinition(handle);
    var parent = type.GetDeclaringType();
    return parent.IsNil
        ? reader.GetString(type.Namespace) + "." + reader.GetString(type.Name)
        : Owner(parent) + "+" + reader.GetString(type.Name);
}
var targets = new Dictionary<int, string>();
foreach (var handle in reader.MethodDefinitions)
{
    var method = reader.GetMethodDefinition(handle);
    var owner = Owner(method.GetDeclaringType());
    var name = reader.GetString(method.Name);
    if ((allTownMethods && (owner == "ClankerWorld.Simulation.World.TownSystem" || owner == "ClankerWorld.Simulation.World.TownSystem+CivicHistoryIndex") &&
            method.GetGenericParameters().Count == 0 && !name.StartsWith('.')) ||
        requested.Any(item => item.Owner == owner && item.Name == name))
        targets.Add(MetadataTokens.GetToken(handle), owner + "." + name);
}
var hits = targets.ToDictionary(item => item.Key, _ => new List<string>());
var bodies = 0;
foreach (var handle in reader.MethodDefinitions)
{
    var method = reader.GetMethodDefinition(handle);
    if (method.RelativeVirtualAddress == 0) continue;
    bodies++;
    var il = pe.GetMethodBody(method.RelativeVirtualAddress).GetILBytes()!;
    // Every byte window is a superset of actual MethodDef operands. A zero
    // count proves no MethodDef use; positive windows require source/IL review.
    for (var offset = 0; offset <= il.Length - 4; offset++)
    {
        var token = BitConverter.ToInt32(il, offset);
        if (hits.TryGetValue(token, out var list))
            list.Add(Owner(method.GetDeclaringType()) + "." + reader.GetString(method.Name) + "@" + offset);
    }
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    assembly = args[0], bodies,
    targets = targets.Select(item => new { token = item.Key, name = item.Value, incoming = hits[item.Key] }),
    requested,
    limits = "Same-module non-generic MethodDef uses only; supplement with complete source/reflection searches and full dependent build for cross-assembly uses."
}, new JsonSerializerOptions { WriteIndented = true }));
record Target(string Owner, string Name);
