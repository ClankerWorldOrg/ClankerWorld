using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
var root=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);
var files=Directory.GetFiles(root+"/src/ClankerWorld.Simulation","*.cs",SearchOption.AllDirectories).Where(p=>!p.Contains("/bin/")&&!p.Contains("/obj/")).ToList();
files.Add(root+"/src/ClankerWorld.Simulation/obj/Release/net10.0/ClankerWorld.Simulation.GlobalUsings.g.cs");
foreach(var f in new[]{"AgentPlacementRules.cs","BoundedText.cs","RoutineHelperDefaults.cs","Contracts/CalendarRules.cs","Contracts/NeedStates.cs"})files.Add(root+"/src/ClankerWorld.Shared/"+f);files.AddRange(Directory.GetFiles(root+"/src/ClankerWorld.Shared/WorldEvents","*.cs"));
var trees=files.Select(f=>CSharpSyntaxTree.ParseText(File.ReadAllText(f),path:f)).ToArray();
var refs=((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator).Select(p=>MetadataReference.CreateFromFile(p));
var comp=CSharpCompilation.Create("ClankerWorld.Simulation",trees,refs,new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,nullableContextOptions:NullableContextOptions.Enable));
if(args.Length>2 && args[2]=="imports"){
 var diags=comp.GetDiagnostics();Console.WriteLine(JsonSerializer.Serialize(new{errors=diags.Where(d=>d.Severity==DiagnosticSeverity.Error).Select(d=>d.ToString()).ToArray(),unused=diags.Where(d=>d.Id=="CS8019"&&new[]{"Family","Community","Agents","Conversations","Knowledge","Cognition"}.Any(folder=>d.Location.SourceTree!.FilePath.Contains("/World/"+folder+"/"))&&!d.Location.SourceTree!.FilePath.EndsWith("/Community/WorldRuntime.CommunityWorld.cs")).Select(d=>new{file=d.Location.SourceTree!.FilePath,line=d.Location.GetLineSpan().StartLinePosition.Line+1,source=d.Location.SourceTree.GetText().ToString(d.Location.SourceSpan)}).ToArray()},new JsonSerializerOptions{WriteIndented=true}));return;
}
var candidates=new List<Candidate>();
foreach(var t in trees.Where(t=>new[]{"Family","Community","Agents","Conversations","Knowledge","Cognition"}.Any(d=>t.FilePath.Contains("/World/"+d+"/WorldRuntime.")))){var model=comp.GetSemanticModel(t);
 foreach(var n in t.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>()){
  if(model.GetDeclaredSymbol(n) is not IMethodSymbol {DeclaredAccessibility:Accessibility.Private,Arity:0} symbol||symbol.ContainingType.Name!="WorldRuntime")continue;
  if(n.ExpressionBody?.Expression is not InvocationExpressionSyntax call||model.GetSymbolInfo(call).Symbol is not IMethodSymbol target||target.ContainingType.Name is not ("FamilySystem" or "FamilyWillService" or "CommunitySystem" or "CognitionSystem" or "ConversationSystem" or "AgentStore"))continue;
  var paramsInOrder=new List<string>();var prefixes=new List<string>();bool shape=true;
  foreach(var arg in call.ArgumentList.Arguments){if(arg.Expression is IdentifierNameSyntax id && symbol.Parameters.Any(p=>p.Name==id.Identifier.ValueText))paramsInOrder.Add(id.Identifier.ValueText);else if(arg.Expression is IdentifierNameSyntax port&&port.Identifier.ValueText.EndsWith("World"))prefixes.Add(port.Identifier.ValueText);else shape=false;}
  var reason=new List<string>();
  if(!shape||!paramsInOrder.SequenceEqual(symbol.Parameters.Select(p=>p.Name))||prefixes.Count>(symbol.IsStatic?0:1))reason.Add("not simple same-order parameter forwarding with at most one Family port");
  if(symbol.Parameters.Any(p=>p.RefKind!=RefKind.None))reason.Add("ref/out parameter");
  if(!SymbolEqualityComparer.Default.Equals(symbol.ReturnType,target.ReturnType))reason.Add("different return conversion");
  var forwarded=target.Parameters.Skip(prefixes.Count).ToArray();if(forwarded.Length!=symbol.Parameters.Length||forwarded.Where((p,i)=>!SymbolEqualityComparer.Default.Equals(p.Type,symbol.Parameters[i].Type)).Any())reason.Add("different parameter conversion");
  if(target.ContainingType.GetMembers(target.Name).OfType<IMethodSymbol>().Count()!=1)reason.Add("overloaded target");
  candidates.Add(new(symbol,n,t.FilePath,target,call,prefixes.SingleOrDefault(),reason));
 }
}
foreach(var t in trees){var model=comp.GetSemanticModel(t);foreach(var id in t.GetRoot().DescendantNodes().OfType<IdentifierNameSyntax>()){
 if(model.GetSymbolInfo(id).Symbol is not IMethodSymbol symbol)continue;var c=candidates.FirstOrDefault(c=>SymbolEqualityComparer.Default.Equals(symbol,c.Symbol));if(c is null)continue;
 SyntaxNode expression=id.Parent is MemberAccessExpressionSyntax m&&m.Name==id?m:id;
 var call=expression.Parent as InvocationExpressionSyntax;
 if(call is null||call.Expression!=expression){c.Reasons.Add("non-invocation reference:"+t.FilePath+":"+(id.GetLocation().GetLineSpan().StartLinePosition.Line+1));continue;}
 if(expression is MemberAccessExpressionSyntax mem&&mem.Expression is not (IdentifierNameSyntax or ThisExpressionSyntax)){c.Reasons.Add("complex receiver:"+mem.Expression);}
 if(expression.Parent?.Parent is ConditionalAccessExpressionSyntax ||id.Parent is MemberBindingExpressionSyntax)c.Reasons.Add("conditional receiver");
 var indices=call.ArgumentList.Arguments.Select((a,i)=>a.NameColon is null?i:c.Symbol.Parameters.IndexOf(c.Symbol.Parameters.Single(p=>p.Name==a.NameColon.Name.Identifier.ValueText))).ToArray();if(!indices.SequenceEqual(indices.Order()))c.Reasons.Add("out-of-order named arguments");
 c.Calls.Add(new(t.FilePath,call.GetLocation().GetLineSpan().StartLinePosition.Line+1,call.ToString(),indices));
}}
var testFiles=Directory.GetFiles(root+"/tests","*",SearchOption.AllDirectories).Where(p=>p.EndsWith(".cs")&&!p.Contains("/obj/")&&!p.Contains("/bin/")).ToArray();
var testContents=testFiles.Select(f=>(file:f,source:File.ReadAllText(f))).ToArray();
foreach(var c in candidates){foreach(var (f,s) in testContents){if(s.Contains('"'+c.Symbol.Name+'"')||s.Contains("nameof(WorldRuntime."+c.Symbol.Name+")"))c.Reasons.Add("test name literal/reflection:"+f);}}
var report=candidates.Select(c=>new{file=c.File,name=c.Symbol.Name,signature=c.Symbol.ToDisplayString(),lines=c.Node.ToString().Count(x=>x=='\n')+1,fullLines=c.Node.ToFullString().Count(x=>x=='\n'),source=c.Node.ToFullString(),target=c.Target.ToDisplayString(),port=c.Port,calls=c.Calls,reasons=c.Reasons.Distinct().ToArray(),selected=c.Reasons.Count==0}).ToArray();
Directory.CreateDirectory(output);File.WriteAllText(output+"/family-forwarders.json",JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));File.WriteAllText(output+"/forwarder-targets.json",JsonSerializer.Serialize(candidates.Select(c=>new{Owner="ClankerWorld.Simulation.World.WorldRuntime",Name=c.Symbol.Name}).Distinct().ToArray(),new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{total=candidates.Count,selected=report.Count(c=>c.selected),estimatedFullLines=report.Where(c=>c.selected).Sum(c=>c.fullLines),skipped=report.Where(c=>!c.selected).Select(c=>new{c.name,c.reasons}),selectedRows=report.Where(c=>c.selected).Select(c=>new{c.name,c.lines,c.fullLines,calls=c.calls.Count,c.port})},new JsonSerializerOptions{WriteIndented=true}));
record Call(string File,int Line,string Source,int[] ParameterIndices);
record Candidate(IMethodSymbol Symbol,MethodDeclarationSyntax Node,string File,IMethodSymbol Target,InvocationExpressionSyntax Template,string? Port,List<string> Reasons){public List<Call> Calls{get;}=[];}
